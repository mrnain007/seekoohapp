package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class StudentProfile {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("profileImageUrl")
    @Expose
    private String profileImageUrl;
    @SerializedName("boardExam")
    @Expose
    private Board boardExam;
    @SerializedName("city")
    @Expose
    private City city;
    @SerializedName("grade")
    @Expose
    private Grade grade;

    public StudentProfile() {
    }

    public StudentProfile(Integer id, String profileImageUrl, Board boardExam, City city, Grade grade) {
        this.id = id;
        this.profileImageUrl = profileImageUrl;
        this.boardExam = boardExam;
        this.city = city;
        this.grade = grade;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProfileImageUrl() {
        return profileImageUrl;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

    public Board getBoardExam() {
        return boardExam;
    }

    public void setBoardExam(Board boardExam) {
        this.boardExam = boardExam;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Grade getGrade() {
        return grade;
    }

    public void setGrade(Grade grade) {
        this.grade = grade;
    }
}
