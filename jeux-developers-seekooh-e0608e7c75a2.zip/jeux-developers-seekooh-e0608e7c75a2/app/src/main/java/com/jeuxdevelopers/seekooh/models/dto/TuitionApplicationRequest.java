package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TuitionApplicationRequest {
    @SerializedName("coverLetter")
    @Expose
    private String coverLetter;

    public TuitionApplicationRequest() {
    }

    public TuitionApplicationRequest(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    private TuitionApplicationRequest(Builder builder) {
        setCoverLetter(builder.coverLetter);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getCoverLetter() {
        return coverLetter;
    }

    public void setCoverLetter(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    public static final class Builder {
        private String coverLetter;

        private Builder() {
        }

        public Builder coverLetter(String coverLetter) {
            this.coverLetter = coverLetter;
            return this;
        }

        public TuitionApplicationRequest build() {
            return new TuitionApplicationRequest(this);
        }
    }
}
