package com.jeuxdevelopers.seekooh.ui.tutor.activities.details.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ItemReviewTutorDetailsBinding;
import com.jeuxdevelopers.seekooh.models.TutorReview;

public class ReviewTutorDetailsAdapter extends ListAdapter<TutorReview, ReviewTutorDetailsAdapter.ReviewViewHolder> {

    private static final DiffUtil.ItemCallback<TutorReview> DIFF_CALLBACK = new DiffUtil.ItemCallback<TutorReview>() {
        @Override
        public boolean areItemsTheSame(@NonNull TutorReview oldItem, @NonNull TutorReview newItem) {
//            return oldItem.getEventId().equals(newItem.getEventId());
            return true;
        }

        @Override
        public boolean areContentsTheSame(@NonNull TutorReview oldItem, @NonNull TutorReview newItem) {
//            return oldItem.equals(newItem);
            return true;
        }
    };

    public ReviewTutorDetailsAdapter() {
        super(DIFF_CALLBACK);
    }

    @NonNull
    @Override
    public ReviewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemReviewTutorDetailsBinding binding = ItemReviewTutorDetailsBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ReviewViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ReviewViewHolder holder, int position) {
        holder.bind(getItem(position));
    }

    public static class ReviewViewHolder extends RecyclerView.ViewHolder {
        private final ItemReviewTutorDetailsBinding binding;

        public ReviewViewHolder(ItemReviewTutorDetailsBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(TutorReview model) {
            Glide.with(binding.getRoot().getContext())
                    .load(model.getReviewerImageUrl())
                    .placeholder(R.drawable.profile_image_placeholder)
                    .into(binding.reviewerProfileImg);
            binding.ratingBar.setRating(model.getRating().floatValue());
            binding.reviewerName.setText(model.getReviewerName());
            binding.reviewTitleTv.setText(model.getTitle());
            binding.reviewDescTv.setText(model.getDescription());
        }
    }
}
