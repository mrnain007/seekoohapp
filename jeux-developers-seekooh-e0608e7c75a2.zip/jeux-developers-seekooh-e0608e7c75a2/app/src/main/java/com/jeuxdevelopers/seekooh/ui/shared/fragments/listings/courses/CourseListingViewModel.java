package com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.courses;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.paging.Pager;
import androidx.paging.PagingConfig;
import androidx.paging.PagingData;
import androidx.paging.PagingLiveData;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.dto.CourseEnrollmentResponse;
import com.jeuxdevelopers.seekooh.models.pagination.CourseListingRxPagingSource;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;
import com.jeuxdevelopers.seekooh.repos.listing.ListingRepo;
import com.jeuxdevelopers.seekooh.repos.listing.ListingRepoImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class CourseListingViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final ListingRepo listingRepo;
    private final AppRepo appRepo;

    // Filters
    public String search;
    public Boolean isOnline;
    public Set<Integer> subjectIds = new HashSet<>();

    public LiveData<PagingData<Object>> pagingLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Subject>>> getSubjectsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<CourseEnrollmentResponse>> enrollmentRequestLiveData = new MutableLiveData<>();

    public CourseListingViewModel() {
        listingRepo = new ListingRepoImpl(disposables);
        appRepo = new AppRepoImpl(disposables);
        init();
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void init() {
        PagingConfig pagingConfig = new PagingConfig(1000, 1000 * 2, false, 1000);
        Pager<Integer, Object> pager = new Pager<>(
                pagingConfig,
                () -> new CourseListingRxPagingSource(listingRepo, disposables, search, isOnline, new ArrayList<>(subjectIds)));
        pagingLiveData = PagingLiveData.cachedIn(PagingLiveData.getLiveData(pager), this);
    }

    public void getSubjects() {
        disposables.add(appRepo.getSubjects()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getSubjectsResponseResource -> {
                    getSubjectsLiveData.setValue(getSubjectsResponseResource);
                }, throwable -> {
                    getSubjectsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void courseEnrollment(@NonNull Integer courseId) {
        disposables.add(appRepo.courseEnrollment(courseId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(enrollmentResponse -> {
                    enrollmentRequestLiveData.setValue(enrollmentResponse);
                }, throwable -> {
                    enrollmentRequestLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
