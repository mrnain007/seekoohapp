package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CourseReview {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("reviewerName")
    @Expose
    private String reviewerName;
    @SerializedName("reviewerImageUrl")
    @Expose
    private String reviewerImageUrl;
    @SerializedName("reviewerId")
    @Expose
    private Integer reviewerId;
    @SerializedName("reviewerRole")
    @Expose
    private Role reviewerRole;
    @SerializedName("courseId")
    @Expose
    private Integer courseId;

    public CourseReview() {
    }

    public CourseReview(Integer id, Double rating, String title, String description, String reviewerName, String reviewerImageUrl, Integer reviewerId, Role reviewerRole, Integer courseId) {
        this.id = id;
        this.rating = rating;
        this.title = title;
        this.description = description;
        this.reviewerName = reviewerName;
        this.reviewerImageUrl = reviewerImageUrl;
        this.reviewerId = reviewerId;
        this.reviewerRole = reviewerRole;
        this.courseId = courseId;
    }

    private CourseReview(Builder builder) {
        setId(builder.id);
        setRating(builder.rating);
        setTitle(builder.title);
        setDescription(builder.description);
        setReviewerName(builder.reviewerName);
        setReviewerImageUrl(builder.reviewerImageUrl);
        setReviewerId(builder.reviewerId);
        setReviewerRole(builder.reviewerRole);
        setCourseId(builder.courseId);
    }

    public static Builder builder() {
        return new Builder();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getReviewerName() {
        return reviewerName;
    }

    public void setReviewerName(String reviewerName) {
        this.reviewerName = reviewerName;
    }

    public String getReviewerImageUrl() {
        return reviewerImageUrl;
    }

    public void setReviewerImageUrl(String reviewerImageUrl) {
        this.reviewerImageUrl = reviewerImageUrl;
    }

    public Integer getReviewerId() {
        return reviewerId;
    }

    public void setReviewerId(Integer reviewerId) {
        this.reviewerId = reviewerId;
    }

    public Role getReviewerRole() {
        return reviewerRole;
    }

    public void setReviewerRole(Role reviewerRole) {
        this.reviewerRole = reviewerRole;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CourseReview that = (CourseReview) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (rating != null ? !rating.equals(that.rating) : that.rating != null) return false;
        if (title != null ? !title.equals(that.title) : that.title != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null)
            return false;
        if (reviewerName != null ? !reviewerName.equals(that.reviewerName) : that.reviewerName != null)
            return false;
        if (reviewerImageUrl != null ? !reviewerImageUrl.equals(that.reviewerImageUrl) : that.reviewerImageUrl != null)
            return false;
        if (reviewerId != null ? !reviewerId.equals(that.reviewerId) : that.reviewerId != null)
            return false;
        if (reviewerRole != null ? !reviewerRole.equals(that.reviewerRole) : that.reviewerRole != null)
            return false;
        return courseId != null ? courseId.equals(that.courseId) : that.courseId == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (rating != null ? rating.hashCode() : 0);
        result = 31 * result + (title != null ? title.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (reviewerName != null ? reviewerName.hashCode() : 0);
        result = 31 * result + (reviewerImageUrl != null ? reviewerImageUrl.hashCode() : 0);
        result = 31 * result + (reviewerId != null ? reviewerId.hashCode() : 0);
        result = 31 * result + (reviewerRole != null ? reviewerRole.hashCode() : 0);
        result = 31 * result + (courseId != null ? courseId.hashCode() : 0);
        return result;
    }

    public static final class Builder {
        private Integer id;
        private Double rating;
        private String title;
        private String description;
        private String reviewerName;
        private String reviewerImageUrl;
        private Integer reviewerId;
        private Role reviewerRole;
        private Integer courseId;

        private Builder() {
        }

        public Builder id(Integer id) {
            this.id = id;
            return this;
        }

        public Builder rating(Double rating) {
            this.rating = rating;
            return this;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder reviewerName(String reviewerName) {
            this.reviewerName = reviewerName;
            return this;
        }

        public Builder reviewerImageUrl(String reviewerImageUrl) {
            this.reviewerImageUrl = reviewerImageUrl;
            return this;
        }

        public Builder reviewerId(Integer reviewerId) {
            this.reviewerId = reviewerId;
            return this;
        }

        public Builder reviewerRole(Role reviewerRole) {
            this.reviewerRole = reviewerRole;
            return this;
        }

        public Builder courseId(Integer courseId) {
            this.courseId = courseId;
            return this;
        }

        public CourseReview build() {
            return new CourseReview(this);
        }
    }
}
