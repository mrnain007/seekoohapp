package com.jeuxdevelopers.seekooh.ui.shared.activities.tuitions;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavOptions;
import androidx.navigation.fragment.NavHostFragment;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityPostTuitionBinding;
import com.jeuxdevelopers.seekooh.utils.Constants;

public class PostTuitionActivity extends AppCompatActivity {

    private ActivityPostTuitionBinding binding;
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPostTuitionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initNavController();
        getArgs();
    }

    private void initNavController() {
        final NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_container_view);
        navController = navHostFragment.getNavController();
    }

    private void getArgs() {
        String postTuitionStr = getIntent().getStringExtra(Constants.POST_TUITION_AD);
        if (postTuitionStr != null) {
            navController.navigate(R.id.postTuitionFragment, null, new NavOptions.Builder()
                    .setPopUpTo(navController.getGraph().getStartDestinationId(), true)
                    .build());
        }
    }
}