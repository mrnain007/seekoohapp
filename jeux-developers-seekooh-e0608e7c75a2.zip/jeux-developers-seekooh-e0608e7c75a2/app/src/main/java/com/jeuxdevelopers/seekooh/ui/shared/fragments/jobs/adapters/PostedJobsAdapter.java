package com.jeuxdevelopers.seekooh.ui.shared.fragments.jobs.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.jeuxdevelopers.seekooh.databinding.ItemMyJobsBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemTvMyTuitionsBinding;
import com.jeuxdevelopers.seekooh.models.TeachingJob;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class PostedJobsAdapter extends ListAdapter<TeachingJob, PostedJobsAdapter.PostedJobsViewHolder> {
    private static final DiffUtil.ItemCallback<TeachingJob> DIFF_CALLBACK = new DiffUtil.ItemCallback<TeachingJob>() {
        @Override
        public boolean areItemsTheSame(@NonNull TeachingJob oldItem, @NonNull TeachingJob newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull TeachingJob oldItem, @NonNull TeachingJob newItem) {
            return oldItem.equals(newItem);
        }
    };

    private Listener listener;

    public PostedJobsAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @NonNull
    @Override
    public PostedJobsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemMyJobsBinding binding = ItemMyJobsBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new PostedJobsViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PostedJobsViewHolder holder, int position) {
        holder.bind(getItem(position));
        holder.binding.viewApplicantsBtn.setOnClickListener(v -> listener.onViewApplicantsBtnClicked(position));
        holder.binding.editBtn.setOnClickListener(v -> listener.onEditBtnClicked(position));
        holder.binding.deleteBtn.setOnClickListener(v -> listener.onDeleteBtnClicked(position));
    }

    public static class PostedJobsViewHolder extends RecyclerView.ViewHolder {
        private final ItemMyJobsBinding binding;

        public PostedJobsViewHolder(ItemMyJobsBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(TeachingJob model) {
            Context context = binding.getRoot().getContext();
            if (Utils.isDataNull(context, model)) {
                return;
            }
            if (model.getStatus() != null) {
                switch (model.getStatus()) {
                    case PENDING:
                        binding.jobStatusShortTv.setText("Pending Approval");
                        break;
                    case APPROVED:
                        binding.jobStatusShortTv.setText("Approved");
                        binding.jobStatusLongTv.setText("Congratulations! Your request has been approved.");
                        break;
                    case REJECTED:
                        binding.jobStatusShortTv.setText("Rejected");
                        binding.jobStatusLongTv.setText("Sorry, your request has been rejected.");
                        break;
                    default:
                        binding.jobStatusShortTv.setText("Status NA");
                        binding.jobStatusLongTv.setText("Sorry, the status is currently unavailable due to an error.");
                        break;
                }
            } else {
                binding.jobStatusShortTv.setText("Status NA");
                binding.jobStatusLongTv.setText("Sorry, the status is currently unavailable.");
            }

            binding.timeTv.setText("Posted " + Utils.getPrettyTime(model.getCreatedAt()));
            binding.jobDescription.setText(model.getJobDescription());

            binding.subjectsContainer.itemsLl.removeAllViews();
            binding.subjectsContainer.fieldNameTv.setText("Subjects:");
            model.getSubjects().forEach(subject -> {
                TextView textView = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
                textView.setText(subject.getName());
                binding.subjectsContainer.itemsLl.addView(textView);
            });

            binding.gradesContainer.itemsLl.removeAllViews();
            binding.gradesContainer.fieldNameTv.setText("Grades:");
            model.getGrades().forEach(grade -> {
                TextView textView = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
                textView.setText(grade.getName());
                binding.gradesContainer.itemsLl.addView(textView);
            });

            binding.localityContainer.itemsLl.removeAllViews();
            binding.localityContainer.fieldNameTv.setText("Locality:");
            TextView areaTv = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
            TextView cityTv = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
            areaTv.setText(model.getArea());
            cityTv.setText(model.getCity().getName());
            binding.localityContainer.itemsLl.addView(areaTv);
            binding.localityContainer.itemsLl.addView(cityTv);
        }
    }

    public interface Listener {
        void onViewApplicantsBtnClicked(int position);

        void onEditBtnClicked(int position);

        void onDeleteBtnClicked(int position);
    }
}
