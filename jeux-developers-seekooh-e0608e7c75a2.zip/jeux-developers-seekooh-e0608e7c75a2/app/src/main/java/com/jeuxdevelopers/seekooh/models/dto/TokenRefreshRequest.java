package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TokenRefreshRequest {
    @SerializedName("refreshToken")
    @Expose
    private String refreshToken;

    public TokenRefreshRequest() {
    }

    private TokenRefreshRequest(Builder builder) {
        setRefreshToken(builder.refreshToken);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public static final class Builder {
        private String refreshToken;

        private Builder() {
        }

        public Builder refreshToken(String refreshToken) {
            this.refreshToken = refreshToken;
            return this;
        }

        public TokenRefreshRequest build() {
            return new TokenRefreshRequest(this);
        }
    }
}