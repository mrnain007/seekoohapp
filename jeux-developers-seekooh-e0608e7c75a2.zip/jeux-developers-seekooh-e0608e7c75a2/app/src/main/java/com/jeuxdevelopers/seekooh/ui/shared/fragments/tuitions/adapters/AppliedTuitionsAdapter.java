package com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions.adapters;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ItemAppliedTuitionBinding;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TuitionListing;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationResponse;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class AppliedTuitionsAdapter extends ListAdapter<TuitionApplicationResponse, AppliedTuitionsAdapter.AppliedTuitionViewHolder> {

    private final RecyclerView recyclerView;
    private final Listener listener;

    public AppliedTuitionsAdapter(RecyclerView recyclerView, Listener listener) {
        super(DIFF_CALLBACK);
        this.recyclerView = recyclerView;
        this.listener = listener;
    }

    private static final DiffUtil.ItemCallback<TuitionApplicationResponse> DIFF_CALLBACK = new DiffUtil.ItemCallback<TuitionApplicationResponse>() {
        @Override
        public boolean areItemsTheSame(@NonNull TuitionApplicationResponse oldItem, @NonNull TuitionApplicationResponse newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull TuitionApplicationResponse oldItem, @NonNull TuitionApplicationResponse newItem) {
            return oldItem.equals(newItem);
        }
    };

    @NonNull
    @Override
    public AppliedTuitionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemAppliedTuitionBinding binding = ItemAppliedTuitionBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new AppliedTuitionViewHolder(binding);
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onBindViewHolder(@NonNull AppliedTuitionViewHolder holder, int position) {
        // Set up the touch listener for the MotionLayout to enable horizontal swipe and disable vertical scroll
        holder.binding.getRoot().setOnTouchListener(new View.OnTouchListener() {
            float startX, startY;
            boolean isSwiping = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getX();
                        startY = event.getY();
                        isSwiping = false;
                        // Disable vertical scrolling of the RecyclerView
                        recyclerView.setVerticalScrollBarEnabled(false);
                        break;
                    case MotionEvent.ACTION_MOVE:
                        float deltaX = event.getX() - startX;
                        float deltaY = event.getY() - startY;
                        if (Math.abs(deltaX) > Math.abs(deltaY) && !isSwiping) {
                            // User is swiping horizontally, disable vertical scrolling of the RecyclerView
                            recyclerView.setVerticalScrollBarEnabled(false);
                            isSwiping = true;
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        // Enable vertical scrolling of the RecyclerView
                        recyclerView.setVerticalScrollBarEnabled(true);
                        break;
                }
                return false;
            }
        });
        holder.binding.deleteBtn.setOnClickListener(v -> listener.onDeleteBtnClicked(position));
        holder.bind(getItem(position), recyclerView);
    }

    public static class AppliedTuitionViewHolder extends RecyclerView.ViewHolder {
        private final ItemAppliedTuitionBinding binding;

        public AppliedTuitionViewHolder(ItemAppliedTuitionBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(TuitionApplicationResponse model, RecyclerView recyclerView) {
            TuitionListing data = model.getTuition();
            Glide.with(binding.getRoot()
                            .getContext())
                    .load(data.getProfileImageUrl())
                    .placeholder(R.drawable.profile_image_placeholder)
                    .into(binding.profileImg);
            binding.userNameTv.setText(data.getFullName());
            binding.postTimeTv.setText(Utils.getPrettyTime(data.getCreatedAt()));
            binding.classTypeTv.setText(data.getOnlineClass() ? "Online classes" : "On-site classes");
            binding.subjectDetailsTv.setText(String.join(", ", Utils.toStringList(data.getSubjects(), Subject::getName)));
            binding.gradeDetailsTv.setText(String.join(", ", Utils.toStringList(data.getGrades(), Grade::getName)));
            binding.genderDetailsTv.setText(data.getTutorGender() != null ? data.getTutorGender().getName() : "Doesn't matter");
            binding.locationDetailsTv.setText(data.getOnlineClass() ? "Online" : "On-site");
        }
    }

    public interface Listener {
        void onDeleteBtnClicked(int position);
    }
}
