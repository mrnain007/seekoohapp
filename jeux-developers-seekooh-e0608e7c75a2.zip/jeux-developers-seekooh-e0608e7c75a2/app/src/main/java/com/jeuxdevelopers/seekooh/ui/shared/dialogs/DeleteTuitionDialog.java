package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.app.Dialog;
import android.content.Context;

import androidx.annotation.NonNull;

public class DeleteTuitionDialog extends Dialog {
    public DeleteTuitionDialog(@NonNull Context context) {
        super(context);
    }
}
