package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class InstituteRegistrationRequest {
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("facebookId")
    @Expose
    private String facebookId;
    @SerializedName("instituteProfile")
    @Expose
    private InstituteProfile instituteProfile;

    public InstituteRegistrationRequest() {
    }

    private InstituteRegistrationRequest(Builder builder) {
        setEmail(builder.email);
        setPassword(builder.password);
        setPhoneNumber(builder.phoneNumber);
        setFacebookId(builder.facebookId);
        setInstituteProfile(builder.instituteProfile);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getFacebookId() {
        return facebookId;
    }

    public void setFacebookId(String facebookId) {
        this.facebookId = facebookId;
    }

    public InstituteProfile getInstituteProfile() {
        return instituteProfile;
    }

    public void setInstituteProfile(InstituteProfile instituteProfile) {
        this.instituteProfile = instituteProfile;
    }

    public static class InstituteProfile {
        @SerializedName("nameOfInstitute")
        @Expose
        private String nameOfInstitute;
        @SerializedName("description")
        @Expose
        private String description;
        @SerializedName("instituteTypeId")
        @Expose
        private Integer instituteTypeId;
        @SerializedName("isRegistered")
        @Expose
        private Boolean isRegistered;
        @SerializedName("cityId")
        @Expose
        private Integer cityId;
        @SerializedName("subjectIds")
        @Expose
        private List<Integer> subjectIds;
        @SerializedName("classIds")
        @Expose
        private List<Integer> classIds;
        @SerializedName("boardExamIds")
        @Expose
        private List<Integer> boardExamIds;


        public InstituteProfile() {
        }

        public InstituteProfile(String nameOfInstitute, String description, Integer instituteTypeId, Boolean isRegistered, Integer cityId, List<Integer> subjectIds, List<Integer> classIds, List<Integer> boardExamIds) {
            this.nameOfInstitute = nameOfInstitute;
            this.description = description;
            this.instituteTypeId = instituteTypeId;
            this.isRegistered = isRegistered;
            this.cityId = cityId;
            this.subjectIds = subjectIds;
            this.classIds = classIds;
            this.boardExamIds = boardExamIds;
        }

        private InstituteProfile(Builder builder) {
            setNameOfInstitute(builder.nameOfInstitute);
            setDescription(builder.description);
            setInstituteTypeId(builder.instituteTypeId);
            isRegistered = builder.isRegistered;
            setCityId(builder.cityId);
            setSubjectIds(builder.subjectIds);
            setClassIds(builder.classIds);
            setBoardExamIds(builder.boardExamIds);
        }

        public static Builder builder() {
            return new Builder();
        }

        public String getNameOfInstitute() {
            return nameOfInstitute;
        }

        public void setNameOfInstitute(String nameOfInstitute) {
            this.nameOfInstitute = nameOfInstitute;
        }

        public Integer getInstituteTypeId() {
            return instituteTypeId;
        }

        public void setInstituteTypeId(Integer instituteTypeId) {
            this.instituteTypeId = instituteTypeId;
        }

        public Boolean getRegistered() {
            return isRegistered;
        }

        public void setRegistered(Boolean registered) {
            isRegistered = registered;
        }

        public Integer getCityId() {
            return cityId;
        }

        public void setCityId(Integer cityId) {
            this.cityId = cityId;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public List<Integer> getSubjectIds() {
            return subjectIds;
        }

        public void setSubjectIds(List<Integer> subjectIds) {
            this.subjectIds = subjectIds;
        }

        public List<Integer> getClassIds() {
            return classIds;
        }

        public void setClassIds(List<Integer> classIds) {
            this.classIds = classIds;
        }

        public List<Integer> getBoardExamIds() {
            return boardExamIds;
        }

        public void setBoardExamIds(List<Integer> boardExamIds) {
            this.boardExamIds = boardExamIds;
        }

        public static final class Builder {
            private String nameOfInstitute;
            private String description;
            private Integer instituteTypeId;
            private Boolean isRegistered;
            private Integer cityId;
            private List<Integer> subjectIds;
            private List<Integer> classIds;
            private List<Integer> boardExamIds;

            private Builder() {
            }

            public Builder nameOfInstitute(String nameOfInstitute) {
                this.nameOfInstitute = nameOfInstitute;
                return this;
            }

            public Builder description(String description) {
                this.description = description;
                return this;
            }

            public Builder instituteTypeId(Integer instituteTypeId) {
                this.instituteTypeId = instituteTypeId;
                return this;
            }

            public Builder isRegistered(Boolean isRegistered) {
                this.isRegistered = isRegistered;
                return this;
            }

            public Builder cityId(Integer cityId) {
                this.cityId = cityId;
                return this;
            }

            public Builder subjectIds(List<Integer> subjectIds) {
                this.subjectIds = subjectIds;
                return this;
            }

            public Builder classIds(List<Integer> classIds) {
                this.classIds = classIds;
                return this;
            }

            public Builder boardExamIds(List<Integer> boardExamIds) {
                this.boardExamIds = boardExamIds;
                return this;
            }

            public InstituteProfile build() {
                return new InstituteProfile(this);
            }
        }
    }

    public static final class Builder {
        private String email;
        private String password;
        private String phoneNumber;
        private String facebookId;
        private InstituteProfile instituteProfile;

        private Builder() {
        }

        public Builder email(String email) {
            this.email = email;
            return this;
        }

        public Builder password(String password) {
            this.password = password;
            return this;
        }

        public Builder phoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }

        public Builder facebookId(String facebookId) {
            this.facebookId = facebookId;
            return this;
        }

        public Builder instituteProfile(InstituteProfile instituteProfile) {
            this.instituteProfile = instituteProfile;
            return this;
        }

        public InstituteRegistrationRequest build() {
            return new InstituteRegistrationRequest(this);
        }
    }
}