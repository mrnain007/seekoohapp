package com.jeuxdevelopers.seekooh.models.chat;

public class FirebaseUser {
    private String userId;
    private String fullName;
    private String profileImgUrl;
    private boolean block;
    private String fcm;

    public FirebaseUser() {
    }

    private FirebaseUser(Builder builder) {
        setUserId(builder.userId);
        setFullName(builder.fullName);
        setProfileImgUrl(builder.profileImgUrl);
        setBlock(builder.block);
        setFcm(builder.fcm);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getProfileImgUrl() {
        return profileImgUrl;
    }

    public void setProfileImgUrl(String profileImgUrl) {
        this.profileImgUrl = profileImgUrl;
    }

    public boolean isBlock() {
        return block;
    }

    public void setBlock(boolean block) {
        this.block = block;
    }

    public String getFcm() {
        return fcm;
    }

    public void setFcm(String fcm) {
        this.fcm = fcm;
    }

    public static final class Builder {
        private String userId;
        private String fullName;
        private String profileImgUrl;
        private boolean block;

        private String fcm;

        private Builder() {
        }

        public Builder userId(String userId) {
            this.userId = userId;
            return this;
        }

        public Builder fullName(String fullName) {
            this.fullName = fullName;
            return this;
        }

        public Builder profileImgUrl(String profileImgUrl) {
            this.profileImgUrl = profileImgUrl;
            return this;
        }

        public Builder block(boolean block) {
            this.block = block;
            return this;
        }

        public Builder fcm(String fcm) {
            this.fcm = fcm;
            return this;
        }

        public FirebaseUser build() {
            return new FirebaseUser(this);
        }
    }
}
