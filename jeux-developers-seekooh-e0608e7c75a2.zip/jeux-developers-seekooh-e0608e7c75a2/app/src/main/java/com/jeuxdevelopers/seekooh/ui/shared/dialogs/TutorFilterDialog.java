package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.app.Dialog;
import android.content.Context;
import androidx.annotation.NonNull;

public class TutorFilterDialog extends Dialog {
    public TutorFilterDialog(@NonNull Context context) {
        super(context);
    }
}
