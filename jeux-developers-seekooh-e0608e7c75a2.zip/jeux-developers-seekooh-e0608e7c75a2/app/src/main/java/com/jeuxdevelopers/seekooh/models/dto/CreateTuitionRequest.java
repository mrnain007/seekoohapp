package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.TutorTimeSlot;

import java.util.List;

public class CreateTuitionRequest {
    @SerializedName("onlineClass")
    @Expose
    private Boolean onlineClass;
    @SerializedName("area")
    @Expose
    private String area;
    @SerializedName("jobDescription")
    @Expose
    private String jobDescription;
    @SerializedName("verifiedTutorsOnly")
    @Expose
    private Boolean verifiedTutorsOnly;
    @SerializedName("salaryAmount")
    @Expose
    private Integer salaryAmount;
    @SerializedName("cityId")
    @Expose
    private Integer cityId;
    @SerializedName("subjectIds")
    @Expose
    private List<Integer> subjectIds;
    @SerializedName("suggestedSubjects")
    @Expose
    private List<String> suggestedSubjects;
    @SerializedName("gradeIds")
    @Expose
    private List<Integer> gradeIds;
    @SerializedName("suggestedGrades")
    @Expose
    private List<String> suggestedGrades;
    @SerializedName("boardExamIds")
    @Expose
    private List<Integer> boardExamIds;
    @SerializedName("preferredDayValues")
    @Expose
    private List<Integer> preferredDayValues;
    @SerializedName("tuitionTimeSlot")
    @Expose
    private TuitionTimeSlot tuitionTimeSlot;
    @SerializedName("salaryTypeId")
    @Expose
    private Integer salaryTypeId;
    @SerializedName("tutorGenderId")
    @Expose
    private Integer tutorGenderId;

    public CreateTuitionRequest() {
    }

    private CreateTuitionRequest(Builder builder) {
        setOnlineClass(builder.onlineClass);
        setArea(builder.area);
        setJobDescription(builder.jobDescription);
        setVerifiedTutorsOnly(builder.verifiedTutorsOnly);
        setSalaryAmount(builder.salaryAmount);
        setCityId(builder.cityId);
        setSubjectIds(builder.subjectIds);
        setSuggestedSubjects(builder.suggestedSubjects);
        setGradeIds(builder.gradeIds);
        setSuggestedGrades(builder.suggestedGrades);
        setBoardExamIds(builder.boardExamIds);
        setPreferredDayValues(builder.preferredDayValues);
        setTuitionTimeSlot(builder.tuitionTimeSlot);
        setSalaryTypeId(builder.salaryTypeId);
        setTutorGenderId(builder.tutorGenderId);
    }

    public static Builder builder() {
        return new Builder();
    }

    public Boolean getOnlineClass() {
        return onlineClass;
    }

    public void setOnlineClass(Boolean onlineClass) {
        this.onlineClass = onlineClass;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public Boolean getVerifiedTutorsOnly() {
        return verifiedTutorsOnly;
    }

    public void setVerifiedTutorsOnly(Boolean verifiedTutorsOnly) {
        this.verifiedTutorsOnly = verifiedTutorsOnly;
    }

    public Integer getSalaryAmount() {
        return salaryAmount;
    }

    public void setSalaryAmount(Integer salaryAmount) {
        this.salaryAmount = salaryAmount;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public List<Integer> getSubjectIds() {
        return subjectIds;
    }

    public void setSubjectIds(List<Integer> subjectIds) {
        this.subjectIds = subjectIds;
    }

    public List<String> getSuggestedSubjects() {
        return suggestedSubjects;
    }

    public void setSuggestedSubjects(List<String> suggestedSubjects) {
        this.suggestedSubjects = suggestedSubjects;
    }

    public List<Integer> getGradeIds() {
        return gradeIds;
    }

    public void setGradeIds(List<Integer> gradeIds) {
        this.gradeIds = gradeIds;
    }

    public List<String> getSuggestedGrades() {
        return suggestedGrades;
    }

    public void setSuggestedGrades(List<String> suggestedGrades) {
        this.suggestedGrades = suggestedGrades;
    }

    public List<Integer> getBoardExamIds() {
        return boardExamIds;
    }

    public void setBoardExamIds(List<Integer> boardExamIds) {
        this.boardExamIds = boardExamIds;
    }

    public List<Integer> getPreferredDayValues() {
        return preferredDayValues;
    }

    public void setPreferredDayValues(List<Integer> preferredDayValues) {
        this.preferredDayValues = preferredDayValues;
    }

    public TuitionTimeSlot getTuitionTimeSlot() {
        return tuitionTimeSlot;
    }

    public void setTuitionTimeSlot(TuitionTimeSlot tuitionTimeSlot) {
        this.tuitionTimeSlot = tuitionTimeSlot;
    }

    public Integer getSalaryTypeId() {
        return salaryTypeId;
    }

    public void setSalaryTypeId(Integer salaryTypeId) {
        this.salaryTypeId = salaryTypeId;
    }

    public Integer getTutorGenderId() {
        return tutorGenderId;
    }

    public void setTutorGenderId(Integer tutorGenderId) {
        this.tutorGenderId = tutorGenderId;
    }

    public static class TuitionTimeSlot {
        @SerializedName("fromTime")
        @Expose
        private Integer fromTime;
        @SerializedName("toTime")
        @Expose
        private Integer toTime;

        public TuitionTimeSlot() {
        }

        public TuitionTimeSlot(Integer fromTime, Integer toTime) {
            this.fromTime = fromTime;
            this.toTime = toTime;
        }

        public Integer getFromTime() {
            return fromTime;
        }

        public void setFromTime(Integer fromTime) {
            this.fromTime = fromTime;
        }

        public Integer getToTime() {
            return toTime;
        }

        public void setToTime(Integer toTime) {
            this.toTime = toTime;
        }
    }

    public static final class Builder {
        private Boolean onlineClass;
        private String area;
        private String jobDescription;
        private Boolean verifiedTutorsOnly;
        private Integer salaryAmount;
        private Integer cityId;
        private List<Integer> subjectIds;
        private List<String> suggestedSubjects;
        private List<Integer> gradeIds;
        private List<String> suggestedGrades;
        private List<Integer> boardExamIds;
        private List<Integer> preferredDayValues;
        private TuitionTimeSlot tuitionTimeSlot;
        private Integer salaryTypeId;
        private Integer tutorGenderId;

        private Builder() {
        }

        public Builder onlineClass(Boolean onlineClass) {
            this.onlineClass = onlineClass;
            return this;
        }

        public Builder area(String area) {
            this.area = area;
            return this;
        }

        public Builder jobDescription(String jobDescription) {
            this.jobDescription = jobDescription;
            return this;
        }

        public Builder verifiedTutorsOnly(Boolean verifiedTutorsOnly) {
            this.verifiedTutorsOnly = verifiedTutorsOnly;
            return this;
        }

        public Builder salaryAmount(Integer salaryAmount) {
            this.salaryAmount = salaryAmount;
            return this;
        }

        public Builder cityId(Integer cityId) {
            this.cityId = cityId;
            return this;
        }

        public Builder subjectIds(List<Integer> subjectIds) {
            this.subjectIds = subjectIds;
            return this;
        }

        public Builder suggestedSubjects(List<String> suggestedSubjects) {
            this.suggestedSubjects = suggestedSubjects;
            return this;
        }

        public Builder gradeIds(List<Integer> gradeIds) {
            this.gradeIds = gradeIds;
            return this;
        }

        public Builder suggestedGrades(List<String> suggestedGrades) {
            this.suggestedGrades = suggestedGrades;
            return this;
        }

        public Builder boardExamIds(List<Integer> boardExamIds) {
            this.boardExamIds = boardExamIds;
            return this;
        }

        public Builder preferredDayValues(List<Integer> preferredDayValues) {
            this.preferredDayValues = preferredDayValues;
            return this;
        }

        public Builder tuitionTimeSlot(TuitionTimeSlot tuitionTimeSlot) {
            this.tuitionTimeSlot = tuitionTimeSlot;
            return this;
        }

        public Builder salaryTypeId(Integer salaryTypeId) {
            this.salaryTypeId = salaryTypeId;
            return this;
        }

        public Builder tutorGenderId(Integer tutorGenderId) {
            this.tutorGenderId = tutorGenderId;
            return this;
        }

        public CreateTuitionRequest build() {
            return new CreateTuitionRequest(this);
        }
    }
}
