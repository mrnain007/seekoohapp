package com.jeuxdevelopers.seekooh.ui.shared.fragments.privacy;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.common.util.CollectionUtils;
import com.jeuxdevelopers.seekooh.databinding.FragmentAccountPrivacyBinding;
import com.jeuxdevelopers.seekooh.models.dto.EditPrivacySettingsRequest;
import com.jeuxdevelopers.seekooh.models.dto.PrivacySettingsResponse;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.jobs.JobApplicationsViewModel;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class AccountPrivacyFragment extends Fragment implements View.OnClickListener {

    private FragmentAccountPrivacyBinding binding;
    private AccountPrivacyViewModel viewModel;
    private PrivacySettingsResponse data;
    private WaitingDialog waitingDialog;
    private CompoundButton.OnCheckedChangeListener phoneVisibilityCheckListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentAccountPrivacyBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(AccountPrivacyViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        fetchData();
    }

    private void fetchData() {
        viewModel.getPrivacySettings();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext(), () -> {
            waitingDialog.dismiss();
            requireActivity().onBackPressed();
        });
        phoneVisibilityCheckListener = (buttonView, isChecked) -> {
            EditPrivacySettingsRequest editPrivacySettingsRequest = EditPrivacySettingsRequest.builder()
                    .phoneVisibility(isChecked)
                    .build();
            viewModel.editPrivacySettings(editPrivacySettingsRequest);
        };
        binding.phoneVisibilitySw.setOnCheckedChangeListener(phoneVisibilityCheckListener);
    }

    private void initObservers() {
        viewModel.getPrivacySettingsLiveData.observe(getViewLifecycleOwner(), privacySettingsResponse -> {
            switch (privacySettingsResponse.getStatus()) {
                case ERROR:
                    waitingDialog.showError(privacySettingsResponse.getMessage());
                    Utils.showToast(requireContext(), privacySettingsResponse.getMessage());
                    break;
                case LOADING:
                    waitingDialog.show(privacySettingsResponse.getMessage());
                    break;
                case SUCCESS:
                    data = privacySettingsResponse.getData();
                    setData();
                    waitingDialog.dismiss();
                    break;
            }
        });

        viewModel.editPrivacySettingsLiveData.observe(getViewLifecycleOwner(), privacySettingsResponse -> {
            switch (privacySettingsResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), privacySettingsResponse.getMessage());
                    if (data != null) {
                        setData();
                    }
                    break;
                case LOADING:
                    waitingDialog.show(privacySettingsResponse.getMessage());
                    break;
                case SUCCESS:
                    data = privacySettingsResponse.getData();
                    setData();
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), privacySettingsResponse.getMessage());
                    break;
            }
        });
    }

    private void setData() {
        binding.phoneVisibilitySw.setOnCheckedChangeListener(null);
        binding.phoneVisibilitySw.setChecked(data.getPhoneVisibility());
        binding.phoneVisibilitySw.setOnCheckedChangeListener(phoneVisibilityCheckListener);
        binding.optionsLl.setVisibility(View.VISIBLE);
    }

    private void initClickListeners() {
        binding.backBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == binding.backBtn.getId()) {
            requireActivity().onBackPressed();
        }
    }
}