package com.jeuxdevelopers.seekooh.ui.shared.fragments.account;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.appcompat.widget.PopupMenu;
import androidx.fragment.app.Fragment;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.FragmentAccountSettingsBinding;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class AccountSettingsFragment extends Fragment {

    private FragmentAccountSettingsBinding binding;
    private User user;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentAccountSettingsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initClickListeners();
        initData();
        setData();
    }

    private void setData() {
        if (user != null) {
            binding.emailTv.setText(user.getEmail());
            if (user.getAppSettings() != null && user.getAppSettings().getSelectedRole() != null) {
                showCurrentRole(user.getAppSettings().getSelectedRole().getName());
            }
        }
    }

    private void initData() {
        user = UserPrefs.getUser(requireContext());
    }

    private void initClickListeners() {
        binding.btnBack.setOnClickListener(v -> {
            requireActivity().onBackPressed();
        });
        binding.changeRoleContainer.setOnClickListener(v -> {
            if (Utils.isDataNull(requireContext(), user) || Utils.isDataNull(requireContext(), user.getRoles())) {
                return;
            }
            showRolePopup(new HashSet<>(user.getRoles()));
        });
    }

    private void showRolePopup(Set<Role> roles) {
        ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(requireContext(), R.style.role_popup_menu);
        PopupMenu popup = new PopupMenu(contextThemeWrapper, binding.changeRoleContainer);
        popup.setGravity(Gravity.END);
        for (Role role : roles) {
            MenuItem menuItem = popup.getMenu().add(Menu.NONE, Menu.NONE, Menu.NONE, role.getName());
            menuItem.setOnMenuItemClickListener(item -> {
                UserPrefs.setSelectedRole(requireContext(), role);
                showCurrentRole(role.getName());
                return false;
            });
        }
        popup.show();
    }

    @SuppressLint("SetTextI18n")
    private void showCurrentRole(String roleName) {
        binding.changeRoleTv.setText(roleName);
        if (roleName.equals("ROLE_STUDENT")){
            binding.tvRoleChange.setText("Change your role to institute or teacher");
        }else if (roleName.equals("ROLE_TUTOR")){
            binding.tvRoleChange.setText("Change your role to institute or student");
        }else {
            binding.tvRoleChange.setText("Change your role to student or teacher");
        }
    }
}