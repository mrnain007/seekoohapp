package com.jeuxdevelopers.seekooh.ui.student.fragments.profile;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.FragmentStudentProfileBinding;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.dto.GetProfileResponse;
import com.jeuxdevelopers.seekooh.models.dto.UpdateStudentProfileRequest;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

public class StudentProfileFragment extends Fragment {
    private static final String TAG = "StudentProfileFragment";

    private final int PROFILE_IMAGE_REQUEST_CODE = 1000;
    private boolean isTextWatcherEnabled = false;
    private boolean isEditModeEnabled = false;
    private Uri profileImageUri;
    private Integer selectedGender;

    private FragmentStudentProfileBinding binding;
    private StudentProfileViewModel viewModel;
    private OnBackPressedCallback callback;
    private WaitingDialog waitingDialog;
    private GetProfileResponse data;

    // Drop downs
    private ArrayAdapter<String> boardsArrayAdapter;
    private List<Board> boardsList = new ArrayList<>();
    private Board selectedBoard;

    private ArrayAdapter<String> citiesArrayAdapter;
    private List<City> citiesList = new ArrayList<>();
    private City selectedCity;

    private ArrayAdapter<String> gradesArrayAdapter;
    private List<Grade> gradesList = new ArrayList<>();
    private Grade selectedGrade;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (!isEditModeEnabled) {
                    setEnabled(false);
                    requireActivity().onBackPressed();
                } else {
                    setEditMode(false);
                }
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentStudentProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(StudentProfileViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        fetchData();
    }

    private void initViews() {
        setEditMode(false);
        waitingDialog = new WaitingDialog(requireContext());
    }

    private void setBoardsDropDown() {
        boardsArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(boardsList, Board::getName));
        binding.boardExamAcTv.setAdapter(boardsArrayAdapter);
        binding.boardExamAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedBoard = boardsList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void setCitiesDropDown() {
        citiesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(citiesList, City::getName));
        binding.citiesAcTv.setAdapter(citiesArrayAdapter);
        binding.citiesAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = citiesList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void setGradesDropDown() {
        gradesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(gradesList, Grade::getName));
        binding.gradesAcTv.setAdapter(gradesArrayAdapter);
        binding.gradesAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedGrade = gradesList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void initClickListeners() {
        initTextWatcher();
        binding.profileImgPickerBtn.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(1024).maxResultSize(1920, 1920).crop(1, 1).start(PROFILE_IMAGE_REQUEST_CODE);
        });
        binding.logoutBtn.setOnClickListener(v -> {
            UserPrefs.clearUser(requireContext());
            startActivity(new Intent(requireContext(), AuthActivity.class));
            App.syncPresence();
            requireActivity().finishAffinity();
        });
        binding.genderRg.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == binding.radioMale.getId()) {
                selectedGender = 1;
            } else if (checkedId == binding.radioFemale.getId()) {
                selectedGender = 2;
            }
        });
        binding.editBtn.setOnClickListener(v -> {
            if (isEditModeEnabled) {
                if (validateUserInput()) {
                    String name = binding.nameTl.getEditText().getText().toString().trim();
                    String phone = binding.phoneTl.getEditText().getText().toString().trim();

                    UpdateStudentProfileRequest.StudentProfile studentProfile = UpdateStudentProfileRequest.StudentProfile.builder()
                            .boardExamId(selectedBoard != null ? selectedBoard.getId() : data.getStudentProfile().getBoardExam().getId())
                            .cityId(selectedCity != null ? selectedCity.getId() : data.getStudentProfile().getCity().getId())
                            .gradeId(selectedGrade != null ? selectedGrade.getId() : data.getStudentProfile().getGrade().getId())
                            .build();
                    UpdateStudentProfileRequest updateStudentProfileRequest = UpdateStudentProfileRequest.builder()
                            .fullName(name)
                            .phoneNumber(phone)
                            .genderId(selectedGender != null ? selectedGender : data.getGender().getId())
                            .studentProfile(studentProfile)
                            .build();
                    viewModel.updateStudentProfile(profileImageUri == null ? null : URI.create(profileImageUri.toString()), updateStudentProfileRequest);
                }
            } else {
                setEditMode(true);
            }
        });
    }

    private void initObservers() {
        viewModel.getProfileLiveData
                .observe(getViewLifecycleOwner(), profileResponseResource -> {
                    switch (profileResponseResource.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), profileResponseResource.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(profileResponseResource.getMessage());
                            break;
                        case SUCCESS:
                            Utils.showToast(requireContext(), profileResponseResource.getMessage());
                            data = profileResponseResource.getData();
                            setData();
                            waitingDialog.dismiss();
                            break;
                    }
                });

        viewModel.getBoardsLiveData.observe(getViewLifecycleOwner(), getBoardsResponse -> {
            switch (getBoardsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getBoardsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    boardsList = getBoardsResponse.getData();
                    setBoardsDropDown();
                    break;
            }
        });

        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    citiesList = getCitiesResponse.getData();
                    setCitiesDropDown();
                    break;
            }
        });

        viewModel.getGradesLiveData.observe(getViewLifecycleOwner(), getGradesResponse -> {
            switch (getGradesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getGradesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    gradesList = getGradesResponse.getData();
                    setGradesDropDown();
                    break;
            }
        });

        viewModel.updateStudentProfileLiveData
                .observe(getViewLifecycleOwner(), updateStudentProfileResource -> {
                    switch (updateStudentProfileResource.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), updateStudentProfileResource.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(updateStudentProfileResource.getMessage());
                            break;
                        case SUCCESS:
                            Utils.showToast(requireContext(), updateStudentProfileResource.getMessage());
                            data = updateStudentProfileResource.getData();
                            setEditMode(false);
                            setData();
                            waitingDialog.dismiss();
                            break;
                    }
                });
    }

    private void fetchData() {
        viewModel.getProfile();
        viewModel.getBoards();
        viewModel.getCities();
        viewModel.getGrades();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PROFILE_IMAGE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                profileImageUri = data.getData();
                binding.profileImg.setImageURI(profileImageUri);
            } else if (resultCode == ImagePicker.RESULT_ERROR) {
                Utils.showToast(requireContext(), ImagePicker.getError(data));
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        }
    }

    private void setData() {
        if (Utils.isDataNull(requireContext(), data) || Utils.isDataNull(requireContext(), data.getStudentProfile())) {
            return;
        }

        Glide.with(requireContext())
                .load(data.getStudentProfile().getProfileImageUrl())
                .placeholder(R.drawable.profile_image_placeholder)
                .into(binding.profileImg);
        binding.seekoohIdTl.getEditText().setText(data.getSeekoohId().toUpperCase());
        binding.nameTl.getEditText().setText(data.getFullName());
        binding.emailTl.getEditText().setText(data.getEmail());
        binding.phoneTl.getEditText().setText(data.getPhoneNumber());
        binding.genderRg.check(data.getGender().getId() == 2 ? binding.radioFemale.getId() : binding.radioMale.getId());
        binding.boardExamAcTv.setText(data.getStudentProfile().getBoardExam().getName(), false);
        binding.citiesAcTv.setText(data.getStudentProfile().getCity().getName(), false);
        binding.gradesAcTv.setText(data.getStudentProfile().getGrade().getName(), false);
        binding.mainContainerLl.setVisibility(View.VISIBLE);
    }

    private void setEditMode(boolean enabled) {
        if (!enabled) {
            isEditModeEnabled = false;
            binding.nameTl.setEnabled(false);
            binding.phoneTl.setEnabled(false);
            binding.radioMale.setEnabled(false);
            binding.radioFemale.setEnabled(false);
            binding.boardExamTl.setEnabled(false);
            binding.citiesTl.setEnabled(false);
            binding.gradesTl.setEnabled(false);
            binding.editBtn.setText("Edit");
            return;
        }
        isEditModeEnabled = true;
        binding.nameTl.setEnabled(true);
        binding.phoneTl.setEnabled(true);
        binding.radioMale.setEnabled(true);
        binding.radioFemale.setEnabled(true);
        binding.boardExamTl.setEnabled(true);
        binding.citiesTl.setEnabled(true);
        binding.gradesTl.setEnabled(true);
        binding.editBtn.setText("Update");
    }

    private void initTextWatcher() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateUserInput();
                }
            }
        };

        binding.nameTl.getEditText().addTextChangedListener(textWatcher);
        binding.phoneTl.getEditText().addTextChangedListener(textWatcher);
    }

    private boolean validateUserInput() {
        isTextWatcherEnabled = true;
        boolean isValid = true;
        String name = binding.nameTl.getEditText().getText().toString().trim();
        String phone = binding.phoneTl.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            binding.nameTl.setError("Please enter your name?");
            isValid = false;
        } else {
            binding.nameTl.setError(null);
        }

        if (TextUtils.isEmpty(phone)) {
            binding.phoneTl.setError("Please enter your phone number?");
            isValid = false;
        } else if (!Utils.validatePhoneNumber(phone)) {
            binding.phoneTl.setError("Please enter a valid phone number?");
            isValid = false;
        } else {
            binding.phoneTl.setError(null);
        }

        /*if (selectedBoard == null) {
            binding.boardExamTl.setError("Please select your board/exam?");
            isValid = false;
        } else {
            binding.boardExamTl.setError(null);
        }

        if (selectedCity == null) {
            binding.citiesTl.setError("Please select your city?");
            isValid = false;
        } else {
            binding.citiesTl.setError(null);
        }

        if (selectedGrade == null) {
            binding.gradesTl.setError("Please select your grade?");
            isValid = false;
        } else {
            binding.gradesTl.setError(null);
        }*/

        return isValid;
    }
}