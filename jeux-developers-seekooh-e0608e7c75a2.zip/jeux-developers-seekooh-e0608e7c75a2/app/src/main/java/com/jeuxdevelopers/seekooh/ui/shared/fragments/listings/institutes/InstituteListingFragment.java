package com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.institutes;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.paging.LoadState;

import com.google.android.material.chip.Chip;
import com.jeuxdevelopers.seekooh.databinding.FilterChipLayoutBinding;
import com.jeuxdevelopers.seekooh.databinding.FragmentInstituteListingBinding;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.ui.institute.activities.details.InstituteDetailsActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.FilterInstitutesDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.FilterTutorsDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.institutes.adapter.InstituteListingAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.institutes.adapter.InstituteListingLoadStateAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tutors.adapters.TutorFiltersAdapter;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.List;

public class InstituteListingFragment extends Fragment {

    // Search
    private final Handler handler = new Handler();
    private Runnable delayedAction = null;
    private final int SEARCH_DELAY_MS = 1000;
    private TextWatcher searchTextWatcher;

    private FragmentInstituteListingBinding binding;
    private InstituteListingViewModel viewModel;
    private WaitingDialog waitingDialog;
    private InstituteListingAdapter instituteListingAdapter;
    private TutorFiltersAdapter cityFilterAdapter;
    private FilterInstitutesDialog filterInstitutesDialog;
    private List<City> cityList;
    private User user;

    /*// Filters
    private Integer cityId;
    private List<Integer> subjectIds;
    private List<Integer> gradeIds;*/

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentInstituteListingBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(InstituteListingViewModel.class);
        initViews();
        initObservers();
        fetchData();
        initRoleOptions();
    }

    private void initRoleOptions() {
        user = UserPrefs.getUser(requireContext());
        if (user == null) {
            return;
        }

        boolean hasInstituteRole = user.getRoles().stream()
                .anyMatch(role -> role.getName().equals(Constants.ROLE_INSTITUTE));

        if (!hasInstituteRole) {
            binding.becomeInstituteBtn.setVisibility(View.VISIBLE);
        }
    }

    private void initObservers() {
        viewModel.pagingLiveData
                .observe(getViewLifecycleOwner(), postPagingData -> {
                    instituteListingAdapter.submitData(getLifecycle(), postPagingData);
                });

        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    cityList = getCitiesResponse.getData();
                    break;
            }
        });
    }

    private void initViews() {
        initSearchListener();
        waitingDialog = new WaitingDialog(requireContext());
        filterInstitutesDialog = new FilterInstitutesDialog(requireContext(), new FilterInstitutesDialog.Listener() {
            @Override
            public void onSearchClicked(Boolean isVerified, City selectedCity) {
                viewModel.isVerified = isVerified;
                viewModel.cityId = selectedCity == null ? null : selectedCity.getId();
                instituteListingAdapter.refresh();
                filterInstitutesDialog.dismiss();
            }

            @Override
            public void onResetClicked() {
                setSearchText("");
                viewModel.search = null;
                viewModel.isVerified = null;
                viewModel.cityId = null;
                instituteListingAdapter.refresh();
                filterInstitutesDialog.dismiss();
            }
        });
        initClickListeners();
        initRecycler();
    }

    private void initSearchListener() {
        searchTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                searchText(s.toString().trim());
            }
        };
        binding.searchEt.addTextChangedListener(searchTextWatcher);
    }

    private void searchText(String newText) {
        if (delayedAction != null) {
            handler.removeCallbacks(delayedAction);
        }

        delayedAction = () -> {
            viewModel.search = newText;
            instituteListingAdapter.refresh();
        };

        handler.postDelayed(delayedAction, SEARCH_DELAY_MS);
    }

    private void setSearchText(String text) {
        binding.searchEt.removeTextChangedListener(searchTextWatcher);
        binding.searchEt.setText(text);
        binding.searchEt.addTextChangedListener(searchTextWatcher);
    }

    private void fetchData() {
        viewModel.init();
        viewModel.getCities();
    }

    private void initClickListeners() {
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            instituteListingAdapter.refresh();
        });
        binding.filterBtn.setOnClickListener(v -> {
            if (cityList == null) {
                return;
            }
            filterInstitutesDialog.show(cityList);
        });
        binding.retryBtn.setOnClickListener(v -> {
            instituteListingAdapter.retry();
        });
        binding.becomeInstituteBtn.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AuthActivity.class);
            intent.putExtra(Constants.AUTH_ACTIVITY_MODE, AuthActivity.Mode.BECOME_INSTITUTE.name());
            startActivity(intent);
        });
    }

    private void initRecycler() {
        instituteListingAdapter = new InstituteListingAdapter((position, instituteListing) -> {
            Intent intent = new Intent(requireContext(), InstituteDetailsActivity.class);
            intent.putExtra(Constants.INSTITUTE_ID, instituteListing.getInstituteId());
            startActivity(intent);
        });

        binding.instituteListingRcv.setAdapter(instituteListingAdapter.withLoadStateFooter(
                new InstituteListingLoadStateAdapter(v -> {

                })
        ));

        instituteListingAdapter.addLoadStateListener(combinedLoadStates -> {
            if (combinedLoadStates.getRefresh() instanceof LoadState.Error) {
                LoadState.Error error = (LoadState.Error) combinedLoadStates.getRefresh();

                Utils.showToast(requireContext(), error.getError().getLocalizedMessage());
                binding.shimmer.setVisibility(View.GONE);
                binding.noContentLayout.getRoot().setVisibility(View.VISIBLE);
//                binding.retryBtn.setVisibility(View.VISIBLE);
                binding.instituteListingRcv.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.Loading) {
                binding.shimmer.setVisibility(View.VISIBLE);
                binding.noContentLayout.getRoot().setVisibility(View.GONE);
//                binding.retryBtn.setVisibility(View.GONE);
                binding.instituteListingRcv.setVisibility(View.GONE);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.NotLoading) {
                binding.instituteListingRcv.setVisibility(View.VISIBLE);
                binding.shimmer.setVisibility(View.GONE);
//                binding.retryBtn.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
                binding.noContentLayout.getRoot().setVisibility(instituteListingAdapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
            }
            return null;
        });

        cityFilterAdapter = new TutorFiltersAdapter((position, model) -> {
            if (viewModel.cityId != null) {
                return;
            }
            viewModel.cityId = model.getId();
            instituteListingAdapter.refresh();

            Chip chip = FilterChipLayoutBinding.inflate(LayoutInflater.from(requireContext())).getRoot();
            chip.setText(model.getName());
            chip.setOnCloseIconClickListener(v -> {
                viewModel.cityId = null;
                instituteListingAdapter.refresh();
                binding.filtersChipGroup.removeView(chip);
            });
            binding.filtersChipGroup.addView(chip);
        });
        binding.cityFilters.filterNameTv.setText("City");
        binding.cityFilters.filterRcv.setAdapter(cityFilterAdapter);

        /*// City filter rcv
        cityFilterAdapter = new TutorFiltersAdapter();
        List<Object> objectCityList = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            objectCityList.add("Test");
        }
        binding.cityFilters.filterRcv.setAdapter(cityFilterAdapter);
        cityFilterAdapter.submitList(objectCityList);

        // City filter rcv
        subjectFilterAdapter = new TutorFiltersAdapter();
        List<Object> objectSubjectList = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            objectSubjectList.add("Test");
        }
        binding.subjectFilters.filterRcv.setAdapter(subjectFilterAdapter);
        subjectFilterAdapter.submitList(objectSubjectList);*/
    }
}