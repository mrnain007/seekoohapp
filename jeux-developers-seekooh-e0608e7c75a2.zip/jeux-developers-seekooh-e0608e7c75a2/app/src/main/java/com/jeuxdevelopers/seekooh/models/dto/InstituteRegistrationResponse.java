package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.InstituteProfile;
import com.jeuxdevelopers.seekooh.models.Role;

import java.util.List;

public class InstituteRegistrationResponse {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("seekoohId")
    @Expose
    private String seekoohId;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("roles")
    @Expose
    private List<Role> roles;
    @SerializedName("instituteProfile")
    @Expose
    private InstituteProfile instituteProfile;

    public InstituteRegistrationResponse() {
    }

    public InstituteRegistrationResponse(Integer id, String seekoohId, String email, String phoneNumber, List<Role> roles, InstituteProfile instituteProfile) {
        this.id = id;
        this.seekoohId = seekoohId;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.roles = roles;
        this.instituteProfile = instituteProfile;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSeekoohId() {
        return seekoohId;
    }

    public void setSeekoohId(String seekoohId) {
        this.seekoohId = seekoohId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    public InstituteProfile getInstituteProfile() {
        return instituteProfile;
    }

    public void setInstituteProfile(InstituteProfile instituteProfile) {
        this.instituteProfile = instituteProfile;
    }
}