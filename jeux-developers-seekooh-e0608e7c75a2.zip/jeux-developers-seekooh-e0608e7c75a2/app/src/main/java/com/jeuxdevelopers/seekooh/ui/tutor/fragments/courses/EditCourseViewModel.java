package com.jeuxdevelopers.seekooh.ui.tutor.fragments.courses;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Course;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.dto.CreateCourseRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditCourseRequest;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class EditCourseViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<List<Subject>>> getSubjectsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Course>> getCourseDetailsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Course>> editCourseLiveData = new MutableLiveData<>();

    public EditCourseViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getSubjects() {
        disposables.add(appRepo.getSubjects()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getSubjectsResponseResource -> {
                    getSubjectsLiveData.setValue(getSubjectsResponseResource);
                }, throwable -> {
                    getSubjectsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void editCourse(@NonNull Integer courseId, @NonNull EditCourseRequest editCourseRequest) {
        disposables.add(appRepo.editCourse(courseId, editCourseRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(editCourseResource -> {
                    editCourseLiveData.setValue(editCourseResource);
                }, throwable -> {
                    editCourseLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getCourseDetailsById(@NonNull Integer courseId) {
        disposables.add(appRepo.getCourseDetailsById(courseId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getCourseDetailsResource -> {
                    getCourseDetailsLiveData.setValue(getCourseDetailsResource);
                }, throwable -> {
                    getCourseDetailsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
