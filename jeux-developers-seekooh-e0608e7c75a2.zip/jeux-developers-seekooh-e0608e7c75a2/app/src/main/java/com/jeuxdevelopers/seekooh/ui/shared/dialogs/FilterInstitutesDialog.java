package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.jeuxdevelopers.seekooh.databinding.DialogFilterInstitutesBinding;
import com.jeuxdevelopers.seekooh.databinding.DialogFilterTutorsBinding;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.ui.shared.views.MultiSelectionView;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FilterInstitutesDialog extends Dialog {

    private DialogFilterInstitutesBinding binding;
    private Listener listener;

    // Drop downs
    private ArrayAdapter<String> citiesArrayAdapter;
    private List<City> citiesList = new ArrayList<>();
    private City selectedCity;

    public FilterInstitutesDialog(@NonNull Context context) {
        super(context);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogFilterInstitutesBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));

        initDialog();
    }

    public FilterInstitutesDialog(@NonNull Context context, @NonNull Listener listener) {
        super(context);
        this.listener = listener;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogFilterInstitutesBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));

        initDialog();
    }

    private void initDialog() {
        binding.btnBack.setOnClickListener(v -> {
            dismiss();
        });
        binding.searchBtn.setOnClickListener(v -> {
            if (listener == null) {
                return;
            }

            Boolean isVerified = binding.verifiedOnlySw.isChecked() ? binding.verifiedOnlySw.isChecked() : null;
            listener.onSearchClicked(isVerified, selectedCity);
        });
        binding.resetBtn.setOnClickListener(v -> {
            if (listener == null) {
                return;
            }

            resetUserData();
            listener.onResetClicked();
        });
    }

    private void resetUserData() {
        binding.verifiedOnlySw.setChecked(false);
        selectedCity = null;
        binding.cityAcTv.setText("", false);
    }

    @Override
    public void show() {
    }

    public void show(List<City> citiesList) {
        if (binding != null) {
            setData(citiesList);
        }
        super.show();
    }

    private void setData(List<City> citiesList) {
        this.citiesList = citiesList;
        setCitiesDropDown();
    }

    private void setCitiesDropDown() {
        citiesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(citiesList, City::getName));
        binding.cityAcTv.setAdapter(citiesArrayAdapter);
        binding.cityAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = citiesList.get(position);
        });
    }

    public interface Listener {
        void onSearchClicked(Boolean isVerified, City selectedCity);

        void onResetClicked();
    }
}
