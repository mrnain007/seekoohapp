package com.jeuxdevelopers.seekooh.ui.tutor.fragments.courses;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Course;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class PostedCoursesViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<List<Course>>> getMyCoursesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Void>> deleteCourseLiveData = new MutableLiveData<>();

    public PostedCoursesViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getMyCourses() {
        disposables.add(appRepo.getMyCourses()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getMyCoursesResource -> {
                    getMyCoursesLiveData.setValue(getMyCoursesResource);
                }, throwable -> {
                    getMyCoursesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void deleteCourse(@NonNull Integer courseId) {
        disposables.add(appRepo.deleteCourse(courseId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(deleteCourseResource -> {
                    deleteCourseLiveData.setValue(deleteCourseResource);
                }, throwable -> {
                    deleteCourseLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
