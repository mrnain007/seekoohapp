package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.DialogApplyTuitionBinding;
import com.jeuxdevelopers.seekooh.databinding.DialogDeleteBinding;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TuitionListing;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.text.NumberFormat;

public class ApplyTuitionDialog extends Dialog {

    private DialogApplyTuitionBinding binding;
    private Listener listener;

    public ApplyTuitionDialog(@NonNull Context context) {
        super(context);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogApplyTuitionBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));

        initDialog();
    }

    @Override
    public void show() {
    }

    @Override
    public void dismiss() {
        if (binding != null) {
            binding.coverTl.getEditText().setText("");
            binding.coverTl.setError(null);
            binding.coverTl.clearFocus();
        }
        super.dismiss();
    }

    @SuppressLint("SetTextI18n")
    public void show(TuitionListing data, Listener listener) {
        this.listener = listener;
        binding.positiveBtn.setOnClickListener(v -> {
            if (!validateInput()) {
                return;
            }
            String coverLetter = binding.coverTl.getEditText().getText().toString().trim();
            listener.onPositiveBtnClicked(coverLetter, data.getId());
        });
        Glide.with(binding.getRoot()
                        .getContext())
                .load(data.getProfileImageUrl())
                .placeholder(R.drawable.profile_image_placeholder)
                .into(binding.profileImg);
        binding.userNameTv.setText(data.getFullName());
        binding.postTimeTv.setText(Utils.getPrettyTime(data.getCreatedAt()));
        binding.feeAmountTv.setText(Utils.formatCurrency(data.getSalaryAmount()) + " " + data.getSalaryType().getName());
        binding.tuitionDescription.setText(data.getJobDescription());
        binding.subjectDetailsTv.setText(String.join(", ", Utils.toStringList(data.getSubjects(), Subject::getName)));
        binding.gradeDetailsTv.setText(String.join(", ", Utils.toStringList(data.getGrades(), Grade::getName)));
        binding.genderDetailsTv.setText(data.getTutorGender() != null ? data.getTutorGender().getName() : "Doesn't matter");
        binding.locationDetailsTv.setText(data.getOnlineClass() ? "Online classes" : String.join(", ", data.getArea(), data.getCity().getName()));
        super.show();
    }

    public boolean validateInput() {
        boolean isValid = true;
        String coverLetter = binding.coverTl.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(coverLetter)) {
            binding.coverTl.setError("Please write cover letter for the application?");
            isValid = false;
        } else {
            binding.coverTl.setError(null);
        }
        return isValid;
    }

    private void initDialog() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                validateInput();
            }
        };
        binding.coverTl.getEditText().addTextChangedListener(textWatcher);
        binding.negativeBtn.setOnClickListener(v -> {
            listener.onNegativeBtnClicked();
        });
    }

    public interface Listener {
        void onPositiveBtnClicked(String coverLetter, Integer tuitionId);

        void onNegativeBtnClicked();
    }
}
