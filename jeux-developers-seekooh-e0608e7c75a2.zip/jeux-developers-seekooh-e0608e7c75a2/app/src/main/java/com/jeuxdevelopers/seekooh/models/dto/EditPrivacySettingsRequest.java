package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class EditPrivacySettingsRequest {
    @SerializedName("phoneVisibility")
    @Expose
    private Boolean phoneVisibility;

    public EditPrivacySettingsRequest() {
    }

    public EditPrivacySettingsRequest(Boolean phoneVisibility) {
        this.phoneVisibility = phoneVisibility;
    }

    private EditPrivacySettingsRequest(Builder builder) {
        setPhoneVisibility(builder.phoneVisibility);
    }

    public static Builder builder() {
        return new Builder();
    }

    public Boolean getPhoneVisibility() {
        return phoneVisibility;
    }

    public void setPhoneVisibility(Boolean phoneVisibility) {
        this.phoneVisibility = phoneVisibility;
    }

    public static final class Builder {
        private Boolean phoneVisibility;

        private Builder() {
        }

        public Builder phoneVisibility(Boolean phoneVisibility) {
            this.phoneVisibility = phoneVisibility;
            return this;
        }

        public EditPrivacySettingsRequest build() {
            return new EditPrivacySettingsRequest(this);
        }
    }
}
