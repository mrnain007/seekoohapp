package com.jeuxdevelopers.seekooh.ui.tutor.fragments.courses;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.dto.CourseEnrollmentResponse;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class CourseEnrollmentsViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<List<CourseEnrollmentResponse>>> getCourseEnrollmentLiveData = new MutableLiveData<>();

    public CourseEnrollmentsViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void setGetCourseEnrollments(@NonNull Integer courseId) {
        disposables.add(appRepo.getCourseEnrollments(courseId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(courseEnrollmentsResource -> {
                    getCourseEnrollmentLiveData.setValue(courseEnrollmentsResource);
                }, throwable -> {
                    getCourseEnrollmentLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
