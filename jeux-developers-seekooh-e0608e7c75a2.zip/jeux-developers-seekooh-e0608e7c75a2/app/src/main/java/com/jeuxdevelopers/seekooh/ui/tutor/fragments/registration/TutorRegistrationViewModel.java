package com.jeuxdevelopers.seekooh.ui.tutor.fragments.registration;

import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationRequest;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TutorRegistrationRequest;
import com.jeuxdevelopers.seekooh.models.dto.TutorRegistrationResponse;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;
import com.jeuxdevelopers.seekooh.repos.auth.AuthRepo;
import com.jeuxdevelopers.seekooh.repos.auth.AuthRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;
import timber.log.Timber;

public class TutorRegistrationViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AuthRepo authRepo;
    private final AppRepo appRepo;
    public TutorRegistrationRequest tutorRegistrationRequest;

    public MutableLiveData<Resource<List<City>>> getCitiesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Board>>> getBoardsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Grade>>> getGradesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Subject>>> getSubjectsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<AuthenticationResponse>> authenticationLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<TutorRegistrationResponse>> tutorRegistrationLiveData = new MutableLiveData<>();

    public Uri profileImageUri;

    public TutorRegistrationViewModel() {
        this.authRepo = new AuthRepoImpl(disposables);
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getBoards() {
        disposables.add(appRepo.getBoards()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getBoardsResponseResource -> {
                    getBoardsLiveData.setValue(getBoardsResponseResource);
                }, throwable -> {
                    getBoardsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getCities() {
        disposables.add(appRepo.getCities()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getCitiesResponseResource -> {
                    getCitiesLiveData.setValue(getCitiesResponseResource);
                }, throwable -> {
                    getCitiesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getGrades() {
        disposables.add(appRepo.getGrades()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getGradesResponseResource -> {
                    getGradesLiveData.setValue(getGradesResponseResource);
                }, throwable -> {
                    getGradesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getSubjects() {
        disposables.add(appRepo.getSubjects()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getSubjectsResponseResource -> {
                    getSubjectsLiveData.setValue(getSubjectsResponseResource);
                }, throwable -> {
                    getSubjectsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void registerTutor(@NonNull Uri profileImageUri, @NonNull TutorRegistrationRequest tutorRegistrationRequest) {
        disposables.add(authRepo.registerTutor(profileImageUri, tutorRegistrationRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(tutorRegistrationResponseResource -> {
                    tutorRegistrationLiveData.setValue(tutorRegistrationResponseResource);
                }, throwable -> {
                    tutorRegistrationLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void loginTutor(String email, String password) {
        disposables.add(authRepo.authenticate(new AuthenticationRequest(email, password))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(authenticationResponseResource -> {
                    authenticationLiveData.setValue(authenticationResponseResource);
                }, throwable -> {
                    authenticationLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
