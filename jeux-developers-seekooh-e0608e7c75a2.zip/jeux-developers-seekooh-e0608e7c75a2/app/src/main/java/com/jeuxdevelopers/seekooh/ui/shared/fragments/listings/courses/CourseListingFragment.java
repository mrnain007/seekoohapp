package com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.courses;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.paging.LoadState;

import com.jeuxdevelopers.seekooh.databinding.FragmentCourseListingBinding;
import com.jeuxdevelopers.seekooh.models.CourseListing;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationRequest;
import com.jeuxdevelopers.seekooh.ui.shared.activities.course.details.CourseDetailsActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.ApplyTuitionDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.FilterCoursesDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.FilterTutorsDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.home.HomeFragmentDirections;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.courses.adapters.CourseListingAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.courses.adapters.CourseListingLoadStateAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tuitions.adapters.TuitionListingAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tuitions.adapters.TuitionListingLoadStateAdapter;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class CourseListingFragment extends Fragment {
    private static final String TAG = "CourseListingFragment";

    // Search
    private final Handler handler = new Handler();
    private Runnable delayedAction = null;
    private final int SEARCH_DELAY_MS = 1000;
    private TextWatcher searchTextWatcher;

    private FragmentCourseListingBinding binding;
    private CourseListingViewModel viewModel;
    private CourseListingAdapter courseListingAdapter;
    private FilterCoursesDialog filterCoursesDialog;
    private WaitingDialog waitingDialog;
    private List<Subject> subjectList;
    private User user;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCourseListingBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(CourseListingViewModel.class);
        initViews();
        initObservers();
        fetchData();
        initRoleOptions();
    }

    private void initRoleOptions() {
        user = UserPrefs.getUser(requireContext());
        if (user == null) {
            return;
        }

        boolean hasTutorRole = user.getRoles().stream()
                .anyMatch(role -> role.getName().equals(Constants.ROLE_TUTOR));

        if (hasTutorRole) {
            binding.postCourseBtn.setVisibility(View.VISIBLE);
        } else {
            binding.postCourseBtn.setVisibility(View.GONE);
        }
    }

    private void initViews() {
        initSearchListener();
        waitingDialog = new WaitingDialog(requireContext());
        filterCoursesDialog = new FilterCoursesDialog(requireContext(), new FilterCoursesDialog.Listener() {
            @Override
            public void onSearchClicked(Boolean isOnlineClass, List<Subject> subjectList) {
                viewModel.isOnline = isOnlineClass;
                viewModel.subjectIds.clear();
                viewModel.subjectIds.addAll(Utils.toIdList(subjectList, Subject::getId));
                courseListingAdapter.refresh();
                filterCoursesDialog.dismiss();
            }

            @Override
            public void onResetClicked() {
                setSearchText("");
                viewModel.search = null;
                viewModel.isOnline = null;
                viewModel.subjectIds.clear();
                courseListingAdapter.refresh();
                filterCoursesDialog.dismiss();
            }
        });
        initRecycler();
        initClickListeners();
    }

    private void initSearchListener() {
        searchTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                searchText(s.toString().trim());
            }
        };
        binding.searchEt.addTextChangedListener(searchTextWatcher);
    }

    private void searchText(String newText) {
        if (delayedAction != null) {
            handler.removeCallbacks(delayedAction);
        }

        delayedAction = () -> {
            viewModel.search = newText;
            courseListingAdapter.refresh();
        };

        handler.postDelayed(delayedAction, SEARCH_DELAY_MS);
    }

    private void setSearchText(String text) {
        binding.searchEt.removeTextChangedListener(searchTextWatcher);
        binding.searchEt.setText(text);
        binding.searchEt.addTextChangedListener(searchTextWatcher);
    }

    private void initClickListeners() {
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            courseListingAdapter.refresh();
        });
        binding.filterBtn.setOnClickListener(v -> {
            if (subjectList == null) {
                return;
            }
            filterCoursesDialog.show(subjectList);
        });
        binding.postCourseBtn.setOnClickListener(v -> {
            if (UserPrefs.isTutorProfileVerified(requireContext())) {
                Navigation.findNavController(v).navigate(HomeFragmentDirections.actionHomeFragmentToPostedCoursesFragment());
            } else {
                Utils.showToast(requireContext(), "Only verified tutors can create courses!");
            }
        });
    }

    private void initRecycler() {
        // Listing Rcv
        courseListingAdapter = new CourseListingAdapter(new CourseListingAdapter.Listener() {
            @Override
            public void onViewDetailsClicked(int position, CourseListing courseListing) {
                Intent intent = new Intent(getContext(), CourseDetailsActivity.class);
                intent.putExtra(Constants.COURSE_ID, courseListing.getId());
                startActivity(intent);
            }

            @Override
            public void onEnrolClicked(int position, CourseListing courseListing) {
                viewModel.courseEnrollment(courseListing.getId());
            }
        });

        binding.courseListingRcv.setAdapter(courseListingAdapter.withLoadStateFooter(
                new CourseListingLoadStateAdapter(v -> {

                })
        ));

        courseListingAdapter.addLoadStateListener(combinedLoadStates -> {
            if (combinedLoadStates.getRefresh() instanceof LoadState.Error) {
                LoadState.Error error = (LoadState.Error) combinedLoadStates.getRefresh();

                Utils.showToast(requireContext(), error.getError().getLocalizedMessage());
                binding.shimmer.setVisibility(View.GONE);
                binding.noContentLayout.getRoot().setVisibility(View.VISIBLE);
                binding.courseListingRcv.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.Loading) {
                binding.shimmer.setVisibility(View.VISIBLE);
                binding.noContentLayout.getRoot().setVisibility(View.GONE);
                binding.courseListingRcv.setVisibility(View.GONE);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.NotLoading) {
                binding.courseListingRcv.setVisibility(View.VISIBLE);
                binding.shimmer.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
                binding.noContentLayout.getRoot().setVisibility(courseListingAdapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
            }
            return null;
        });
    }

    private void initObservers() {
        viewModel.pagingLiveData
                .observe(getViewLifecycleOwner(), postPagingData -> {
                    courseListingAdapter.submitData(getLifecycle(), postPagingData);
                });

        viewModel.getSubjectsLiveData.observe(getViewLifecycleOwner(), getSubjectsResponse -> {
            switch (getSubjectsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSubjectsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    subjectList = getSubjectsResponse.getData();
                    break;
            }
        });

        viewModel.enrollmentRequestLiveData.observe(getViewLifecycleOwner(), enrollmentResponse -> {
            switch (enrollmentResponse.getStatus()) {
                case ERROR:
                    Log.e(TAG, "initObservers: " + enrollmentResponse.getMessage());
                    Utils.showToast(requireContext(), enrollmentResponse.getMessage());
                    waitingDialog.dismiss();
                    break;
                case LOADING:
                    waitingDialog.show(enrollmentResponse.getMessage());
                    break;
                case SUCCESS:
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), enrollmentResponse.getMessage());
                    break;
            }
        });
    }

    private void fetchData() {
        viewModel.init();
        viewModel.getSubjects();
    }
}