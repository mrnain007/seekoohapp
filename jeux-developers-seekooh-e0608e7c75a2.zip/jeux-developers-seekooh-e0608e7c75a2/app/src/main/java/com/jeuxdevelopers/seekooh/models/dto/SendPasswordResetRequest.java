package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SendPasswordResetRequest {
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("phone")
    @Expose
    private String phone;
    @SerializedName("verificationType")
    @Expose
    private VerificationType verificationType;

    public SendPasswordResetRequest() {
    }

    private SendPasswordResetRequest(Builder builder) {
        setEmail(builder.email);
        setPhone(builder.phone);
        setVerificationType(builder.verificationType);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public VerificationType getVerificationType() {
        return verificationType;
    }

    public void setVerificationType(VerificationType verificationType) {
        this.verificationType = verificationType;
    }

    public enum VerificationType {
        EMAIL, PHONE
    }

    public static final class Builder {
        private String email;
        private String phone;
        private VerificationType verificationType;

        private Builder() {
        }

        public Builder email(String email) {
            this.email = email;
            return this;
        }

        public Builder phone(String phone) {
            this.phone = phone;
            return this;
        }

        public Builder verificationType(VerificationType verificationType) {
            this.verificationType = verificationType;
            return this;
        }

        public SendPasswordResetRequest build() {
            return new SendPasswordResetRequest(this);
        }
    }
}
