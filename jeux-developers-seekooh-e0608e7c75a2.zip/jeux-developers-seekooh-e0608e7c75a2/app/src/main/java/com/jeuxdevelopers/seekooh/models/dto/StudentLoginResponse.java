package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.JsonElement;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.Gender;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.StudentProfile;

import java.util.List;

public class StudentLoginResponse {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("fullName")
    @Expose
    private String fullName;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("gender")
    @Expose
    private Gender gender;
    @SerializedName("roles")
    @Expose
    private List<Role> roles;
    @SerializedName("studentProfile")
    @Expose
    private StudentProfile studentProfile;
    @SerializedName("tutorProfile")
    @Expose
    private Object tutorProfile;
    @SerializedName("instituteProfile")
    @Expose
    private Object instituteProfile;
    @SerializedName("accessToken")
    @Expose
    private String accessToken;
    @SerializedName("refreshToken")
    @Expose
    private String refreshToken;

    public StudentLoginResponse() {
    }

    public StudentLoginResponse(Integer id, String fullName, String email, String phoneNumber, Gender gender, List<Role> roles, StudentProfile studentProfile, Object tutorProfile, Object instituteProfile, String accessToken, String refreshToken) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.gender = gender;
        this.roles = roles;
        this.studentProfile = studentProfile;
        this.tutorProfile = tutorProfile;
        this.instituteProfile = instituteProfile;
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    public StudentProfile getStudentProfile() {
        return studentProfile;
    }

    public void setStudentProfile(StudentProfile studentProfile) {
        this.studentProfile = studentProfile;
    }

    public Object getTutorProfile() {
        return tutorProfile;
    }

    public void setTutorProfile(Object tutorProfile) {
        this.tutorProfile = tutorProfile;
    }

    public Object getInstituteProfile() {
        return instituteProfile;
    }

    public void setInstituteProfile(Object instituteProfile) {
        this.instituteProfile = instituteProfile;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }
}
