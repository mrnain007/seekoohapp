package com.jeuxdevelopers.seekooh.ui.shared.activities.splash;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.messaging.FirebaseMessaging;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.ui.shared.activities.intro.IntroActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.NotificationUtils;
import com.jeuxdevelopers.seekooh.utils.PrefsUtils;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.concurrent.ExecutionException;

@SuppressLint("CustomSplashScreen")
public class SplashActivity extends AppCompatActivity {
    private static final String TAG = "SplashActivity";
    private final int POST_NOTIFICATIONS_REQUEST_CODE = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        if (!isNotificationPermissionGranted()) {
            requestNotificationPermission();
            return;
        }
        initData();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, POST_NOTIFICATIONS_REQUEST_CODE);
        }
    }

    private boolean isNotificationPermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        } else {
            return true;
        }
    }

    private void initData() {
//        PrefsUtils.putString(getApplicationContext(), Constants.Firebase.FCM_TOKEN, null);
        new Thread(() -> {
            String fcmTokenPref = PrefsUtils.getString(getApplicationContext(), Constants.Firebase.FCM_TOKEN, null);
            if (fcmTokenPref == null) {
                String fcmToken = null;
                try {
                    fcmToken = Tasks.await(FirebaseMessaging.getInstance().getToken());
                } catch (ExecutionException | InterruptedException e) {
                    Log.e(TAG, "initData: ", e);
                }

                if (fcmToken != null) {
                    PrefsUtils.putString(getApplicationContext(), Constants.Firebase.FCM_TOKEN, fcmToken);
                    App.syncPresence();
                }
            }

            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                NotificationUtils.createNotificationChannel(getApplicationContext(), NotificationUtils.CHANNEL_ID, NotificationUtils.CHANNEL_NAME);
                User user = UserPrefs.getUser(this);
                Intent intent = null;
                if (user == null) {
                    intent = new Intent(this, IntroActivity.class);
                } else {
                    intent = new Intent(this, MainActivity.class);
                }
                startActivity(intent);
                finish();
            }, 500);
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == POST_NOTIFICATIONS_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Utils.showToast(this, "Notifications permission granted.");
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.POST_NOTIFICATIONS)) {
                        Utils.showToast(this, "Notifications permission denied.");
                    }
                }
            }
            initData();
        }
    }
}