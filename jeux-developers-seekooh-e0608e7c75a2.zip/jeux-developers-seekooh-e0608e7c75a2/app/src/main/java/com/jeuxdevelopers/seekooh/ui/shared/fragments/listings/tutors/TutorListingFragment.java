package com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tutors;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.paging.LoadState;
import androidx.recyclerview.widget.ConcatAdapter;

import com.google.android.material.chip.Chip;
import com.jeuxdevelopers.seekooh.databinding.FilterChipLayoutBinding;
import com.jeuxdevelopers.seekooh.databinding.FragmentTutorListingBinding;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.dto.AdSettingsResponse;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.FilterTutorsDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tutors.adapters.TutorFiltersAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tutors.adapters.TutorListingAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tutors.adapters.TutorListingLoadStateAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.views.HeaderRcvAdapter;
import com.jeuxdevelopers.seekooh.ui.tutor.activities.details.TutorDetailsActivity;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class TutorListingFragment extends Fragment {

    // Search
    private final Handler handler = new Handler();
    private Runnable delayedAction = null;
    private final int SEARCH_DELAY_MS = 1000;
    private TextWatcher searchTextWatcher;

    private FragmentTutorListingBinding binding;
    private TutorListingViewModel viewModel;
    private WaitingDialog waitingDialog;
    private TutorListingAdapter tutorListingAdapter;
    private TutorFiltersAdapter cityFilterAdapter;
    private TutorFiltersAdapter subjectFilterAdapter;
    private TutorFiltersAdapter gradeFilterAdapter;
    private FilterTutorsDialog filterTutorsDialog;
    private List<Board> boardList;
    private List<Grade> gradeList;
    private List<Subject> subjectList;
    private List<City> cityList;
    private User user;

    /*// Filters
    private Integer cityId;
    private List<Integer> subjectIds;
    private List<Integer> gradeIds;*/

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentTutorListingBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(TutorListingViewModel.class);
        initViews();
        initObservers();
        fetchData();
        initRoleOptions();
    }

    private void initRoleOptions() {
        user = UserPrefs.getUser(requireContext());
        if (user == null) {
            return;
        }

        boolean hasTutorRole = user.getRoles().stream()
                .anyMatch(role -> role.getName().equals(Constants.ROLE_TUTOR));

        if (!hasTutorRole) {
            binding.becomeTutorBtn.setVisibility(View.VISIBLE);
        }
    }

    private void initObservers() {

        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
                    binding.cityFilters.shimmerFl.setVisibility(View.VISIBLE);
                    break;
                case SUCCESS:
                    binding.cityFilters.shimmerFl.setVisibility(View.GONE);
                    cityList = getCitiesResponse.getData();
                    cityFilterAdapter.submitList(cityList
                            .stream()
                            .map(city -> new TutorFiltersAdapter
                                    .FilterModel(city.getId(), city.getName()))
                            .collect(Collectors.toList()));
                    break;
            }
        });

        viewModel.getSubjectsLiveData.observe(getViewLifecycleOwner(), getSubjectsResponse -> {
            switch (getSubjectsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSubjectsResponse.getMessage());
                    break;
                case LOADING:
                    binding.subjectFilters.shimmerFl.setVisibility(View.VISIBLE);
                    break;
                case SUCCESS:
                    binding.subjectFilters.shimmerFl.setVisibility(View.GONE);
                    subjectList = getSubjectsResponse.getData();
                    subjectFilterAdapter.submitList(subjectList
                            .stream()
                            .map(subject -> new TutorFiltersAdapter
                                    .FilterModel(subject.getId(), subject.getName()))
                            .collect(Collectors.toList()));
                    break;
            }
        });

        viewModel.getGradesLiveData.observe(getViewLifecycleOwner(), getGradesResponse -> {
            switch (getGradesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getGradesResponse.getMessage());
                    break;
                case LOADING:
                    binding.gradeFilters.shimmerFl.setVisibility(View.VISIBLE);
                    break;
                case SUCCESS:
                    binding.gradeFilters.shimmerFl.setVisibility(View.GONE);
                    gradeList = getGradesResponse.getData();
                    gradeFilterAdapter.submitList(gradeList
                            .stream()
                            .map(grade -> new TutorFiltersAdapter
                                    .FilterModel(grade.getId(), grade.getName()))
                            .collect(Collectors.toList()));
                    break;
            }
        });

        viewModel.getBoardsLiveData.observe(getViewLifecycleOwner(), getBoardsResponse -> {
            switch (getBoardsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getBoardsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    boardList = getBoardsResponse.getData();
                    break;
            }
        });

        viewModel.getAdSettingsLiveData.observe(getViewLifecycleOwner(), adSettingsResponse -> {
            switch (adSettingsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), adSettingsResponse.getMessage());
                    viewModel.adSettingsResponse = new AdSettingsResponse(null, null);
                    viewModel.initPagingData();
                    viewModel.pagingLiveData
                            .observe(getViewLifecycleOwner(), postPagingData -> {
                                tutorListingAdapter.submitData(getLifecycle(), postPagingData);
                            });
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    viewModel.adSettingsResponse = adSettingsResponse.getData();
                    viewModel.initPagingData();
                    viewModel.pagingLiveData
                            .observe(getViewLifecycleOwner(), postPagingData -> {
                                tutorListingAdapter.submitData(getLifecycle(), postPagingData);
                            });
                    break;
            }
        });

    }

    private void initViews() {
        initSearchListener();
        waitingDialog = new WaitingDialog(requireContext());
        filterTutorsDialog = new FilterTutorsDialog(requireContext(), new FilterTutorsDialog.Listener() {
            @Override
            public void onSearchClicked(Boolean isVerified, Boolean isOnline, Boolean isInPerson, Integer selectedGenderId, City selectedCity, List<Subject> subjectList, List<Grade> gradeList, Board selectedBoard) {
                binding.filtersChipGroup.removeAllViews();
                viewModel.isVerified = isVerified;
                viewModel.teachesOnline = isOnline;
                viewModel.teachesInPerson = isInPerson;
                viewModel.genderId = selectedGenderId;
                viewModel.cityId = selectedCity == null ? null : selectedCity.getId();
                viewModel.subjectIds.clear();
                viewModel.subjectIds.addAll(Utils.toIdList(subjectList, Subject::getId));
                viewModel.gradeIds.clear();
                viewModel.gradeIds.addAll(Utils.toIdList(gradeList, Grade::getId));
                viewModel.boardExamIds.clear();
                if (selectedBoard != null) {
                    viewModel.boardExamIds.add(selectedBoard.getId());
                }
                tutorListingAdapter.refresh();
                filterTutorsDialog.dismiss();
            }

            @Override
            public void onResetClicked() {
                binding.filtersChipGroup.removeAllViews();
                setSearchText("");
                viewModel.search = null;
                viewModel.isVerified = null;
                viewModel.teachesOnline = null;
                viewModel.teachesInPerson = null;
                viewModel.genderId = null;
                viewModel.cityId = null;
                viewModel.subjectIds.clear();
                viewModel.gradeIds.clear();
                viewModel.boardExamIds.clear();
                tutorListingAdapter.refresh();
                filterTutorsDialog.dismiss();
            }
        });
        initClickListeners();
        initRecycler();
    }

    private void initSearchListener() {
        searchTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                searchText(s.toString().trim());
            }
        };
        binding.searchEt.addTextChangedListener(searchTextWatcher);
    }

    private void searchText(String newText) {
        if (delayedAction != null) {
            handler.removeCallbacks(delayedAction);
        }

        delayedAction = () -> {
            viewModel.search = newText;
            tutorListingAdapter.refresh();
        };

        handler.postDelayed(delayedAction, SEARCH_DELAY_MS);
    }

    private void setSearchText(String text) {
        binding.searchEt.removeTextChangedListener(searchTextWatcher);
        binding.searchEt.setText(text);
        binding.searchEt.addTextChangedListener(searchTextWatcher);
    }

    private void fetchData() {
        viewModel.getAdSettings();
        viewModel.getCities();
        viewModel.getSubjects();
        viewModel.getGrades();
        viewModel.getBoards();
    }

    private void initClickListeners() {
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            tutorListingAdapter.refresh();
        });
        binding.filterBtn.setOnClickListener(v -> {
            if (cityList == null || subjectList == null || gradeList == null || boardList == null) {
                return;
            }
            filterTutorsDialog.show(cityList, subjectList, gradeList, boardList);
        });
        binding.retryBtn.setOnClickListener(v -> {
            tutorListingAdapter.retry();
        });
        binding.becomeTutorBtn.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AuthActivity.class);
            intent.putExtra(Constants.AUTH_ACTIVITY_MODE, AuthActivity.Mode.BECOME_TUTOR.name());
            startActivity(intent);
        });
    }

    private void initRecycler() {
        // Listing Rcv

        /*List<Object> objectList = new ArrayList<>();
        for (int i = 0; i < 15; i++) {
            objectList.add("Test");
        }*/
//        tutorListingAdapter.submitList(Utils.addAdItems(5, new AdModel(), objectList));

//        binding.tutorListingRcv.scrollToPosition(14);

        HeaderRcvAdapter headerRcvAdapter = new HeaderRcvAdapter(new HeaderRcvAdapter.Listener() {
            @Override
            public void onViewApplicantsBtnClicked(int position) {

            }

            @Override
            public void onEditBtnClicked(int position) {

            }

            @Override
            public void onDeleteBtnClicked(int position) {

            }
        });
        headerRcvAdapter.submitList(Collections.singletonList("dsa"));
        tutorListingAdapter = new TutorListingAdapter((position, tutorListing) -> {
            Intent intent = new Intent(requireContext(), TutorDetailsActivity.class);
            intent.putExtra(Constants.TUTOR_ID, tutorListing.getTutorId());
            startActivity(intent);
        });

        binding.tutorListingRcv.setAdapter(tutorListingAdapter
                .withLoadStateFooter(new TutorListingLoadStateAdapter(v -> {

        })));

        tutorListingAdapter.addLoadStateListener(combinedLoadStates -> {
            if (combinedLoadStates.getRefresh() instanceof LoadState.Error) {
                LoadState.Error error = (LoadState.Error) combinedLoadStates.getRefresh();

                Utils.showToast(requireContext(), error.getError().getLocalizedMessage());
                binding.shimmer.setVisibility(View.GONE);
                binding.noContentLayout.getRoot().setVisibility(View.VISIBLE);
//                binding.retryBtn.setVisibility(View.VISIBLE);
                binding.tutorListingRcv.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.Loading) {
                binding.shimmer.setVisibility(View.VISIBLE);
                binding.noContentLayout.getRoot().setVisibility(View.GONE);
//                binding.retryBtn.setVisibility(View.GONE);
                binding.tutorListingRcv.setVisibility(View.GONE);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.NotLoading) {
                binding.tutorListingRcv.setVisibility(View.VISIBLE);
                binding.shimmer.setVisibility(View.GONE);
//                binding.retryBtn.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
                binding.noContentLayout.getRoot().setVisibility(tutorListingAdapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
            }
            return null;
        });

        cityFilterAdapter = new TutorFiltersAdapter((position, model) -> {
            if (viewModel.cityId != null) {
                return;
            }
            viewModel.cityId = model.getId();
            tutorListingAdapter.refresh();

            Chip chip = FilterChipLayoutBinding.inflate(LayoutInflater.from(requireContext())).getRoot();
            chip.setText(model.getName());
            chip.setOnCloseIconClickListener(v -> {
                viewModel.cityId = null;
                tutorListingAdapter.refresh();
                binding.filtersChipGroup.removeView(chip);
            });
            binding.filtersChipGroup.addView(chip);
        });
        binding.cityFilters.filterNameTv.setText("City");
        binding.cityFilters.filterRcv.setAdapter(cityFilterAdapter);

        subjectFilterAdapter = new TutorFiltersAdapter((position, model) -> {
            if (viewModel.subjectIds.contains(model.getId())) {
                return;
            }
            viewModel.subjectIds.add(model.getId());
            tutorListingAdapter.refresh();

            Chip chip = FilterChipLayoutBinding.inflate(LayoutInflater.from(requireContext())).getRoot();
            chip.setText(model.getName());
            chip.setOnCloseIconClickListener(v -> {
                viewModel.subjectIds.remove(model.getId());
                tutorListingAdapter.refresh();
                binding.filtersChipGroup.removeView(chip);
            });
            binding.filtersChipGroup.addView(chip);
        });
        binding.subjectFilters.filterNameTv.setText("Subjects");
        binding.subjectFilters.filterRcv.setAdapter(subjectFilterAdapter);

        gradeFilterAdapter = new TutorFiltersAdapter((position, model) -> {
            if (viewModel.gradeIds.contains(model.getId())) {
                return;
            }
            viewModel.gradeIds.add(model.getId());
            tutorListingAdapter.refresh();

            Chip chip = FilterChipLayoutBinding.inflate(LayoutInflater.from(requireContext())).getRoot();
            chip.setText(model.getName());
            chip.setOnCloseIconClickListener(v -> {
                viewModel.gradeIds.remove(model.getId());
                tutorListingAdapter.refresh();
                binding.filtersChipGroup.removeView(chip);
            });
            binding.filtersChipGroup.addView(chip);
        });
        binding.gradeFilters.filterNameTv.setText("Grades");
        binding.gradeFilters.filterRcv.setAdapter(gradeFilterAdapter);

        /*// City filter rcv
        cityFilterAdapter = new TutorFiltersAdapter();
        List<Object> objectCityList = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            objectCityList.add("Test");
        }
        binding.cityFilters.filterRcv.setAdapter(cityFilterAdapter);
        cityFilterAdapter.submitList(objectCityList);

        // City filter rcv
        subjectFilterAdapter = new TutorFiltersAdapter();
        List<Object> objectSubjectList = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            objectSubjectList.add("Test");
        }
        binding.subjectFilters.filterRcv.setAdapter(subjectFilterAdapter);
        subjectFilterAdapter.submitList(objectSubjectList);*/
    }
}