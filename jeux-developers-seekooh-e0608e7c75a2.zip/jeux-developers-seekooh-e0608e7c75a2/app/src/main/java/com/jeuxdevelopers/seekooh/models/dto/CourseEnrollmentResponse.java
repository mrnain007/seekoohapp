package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Gender;
import com.jeuxdevelopers.seekooh.models.Grade;

public class CourseEnrollmentResponse {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("courseId")
    @Expose
    private Long courseId;
    @SerializedName("student")
    @Expose
    private Student student;

    public CourseEnrollmentResponse() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getCourseId() {
        return courseId;
    }

    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CourseEnrollmentResponse that = (CourseEnrollmentResponse) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (courseId != null ? !courseId.equals(that.courseId) : that.courseId != null)
            return false;
        return student != null ? student.equals(that.student) : that.student == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (courseId != null ? courseId.hashCode() : 0);
        result = 31 * result + (student != null ? student.hashCode() : 0);
        return result;
    }

    public static class Student {
        @SerializedName("userId")
        @Expose
        private Long userId;
        @SerializedName("seekoohId")
        @Expose
        private String seekoohId;
        @SerializedName("fullName")
        @Expose
        private String fullName;
        @SerializedName("email")
        @Expose
        private String email;
        @SerializedName("phoneNumber")
        @Expose
        private String phoneNumber;
        @SerializedName("gender")
        @Expose
        private Gender gender;
        @SerializedName("lastSeen")
        @Expose
        private Long lastSeen;
        @SerializedName("isOnline")
        @Expose
        private Boolean isOnline;
        @SerializedName("id")
        @Expose
        private Long id;
        @SerializedName("profileImageUrl")
        @Expose
        private String profileImageUrl;
        @SerializedName("boardExam")
        @Expose
        private Board boardExam;
        @SerializedName("city")
        @Expose
        private City city;
        @SerializedName("grade")
        @Expose
        private Grade grade;

        public Student() {
        }

        public Long getUserId() {
            return userId;
        }

        public void setUserId(Long userId) {
            this.userId = userId;
        }

        public String getSeekoohId() {
            return seekoohId;
        }

        public void setSeekoohId(String seekoohId) {
            this.seekoohId = seekoohId;
        }

        public String getFullName() {
            return fullName;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        public Gender getGender() {
            return gender;
        }

        public void setGender(Gender gender) {
            this.gender = gender;
        }

        public Long getLastSeen() {
            return lastSeen;
        }

        public void setLastSeen(Long lastSeen) {
            this.lastSeen = lastSeen;
        }

        public Boolean getOnline() {
            return isOnline;
        }

        public void setOnline(Boolean online) {
            isOnline = online;
        }

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getProfileImageUrl() {
            return profileImageUrl;
        }

        public void setProfileImageUrl(String profileImageUrl) {
            this.profileImageUrl = profileImageUrl;
        }

        public Board getBoardExam() {
            return boardExam;
        }

        public void setBoardExam(Board boardExam) {
            this.boardExam = boardExam;
        }

        public City getCity() {
            return city;
        }

        public void setCity(City city) {
            this.city = city;
        }

        public Grade getGrade() {
            return grade;
        }

        public void setGrade(Grade grade) {
            this.grade = grade;
        }
    }
}
