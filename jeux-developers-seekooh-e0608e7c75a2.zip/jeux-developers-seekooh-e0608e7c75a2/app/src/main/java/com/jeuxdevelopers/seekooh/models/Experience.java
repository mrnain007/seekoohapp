package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Experience {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("expDuration")
    @Expose
    private String expDuration;
    @SerializedName("expDetails")
    @Expose
    private String expDetails;

    public Experience() {
    }

    public Experience(Integer id, String expDuration, String expDetails) {
        this.id = id;
        this.expDuration = expDuration;
        this.expDetails = expDetails;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getExpDuration() {
        return expDuration;
    }

    public void setExpDuration(String expDuration) {
        this.expDuration = expDuration;
    }

    public String getExpDetails() {
        return expDetails;
    }

    public void setExpDetails(String expDetails) {
        this.expDetails = expDetails;
    }
}
