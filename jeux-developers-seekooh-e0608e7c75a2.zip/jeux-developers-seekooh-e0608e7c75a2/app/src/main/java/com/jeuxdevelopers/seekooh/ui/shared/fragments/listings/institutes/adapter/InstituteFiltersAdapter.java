package com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.institutes.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.jeuxdevelopers.seekooh.databinding.ItemPopularFiltersBinding;

public class InstituteFiltersAdapter extends ListAdapter<InstituteFiltersAdapter.FilterModel, InstituteFiltersAdapter.TutorListingViewHolder> {

    private static final DiffUtil.ItemCallback<FilterModel> DIFF_CALLBACK = new DiffUtil.ItemCallback<FilterModel>() {
        @Override
        public boolean areItemsTheSame(@NonNull InstituteFiltersAdapter.FilterModel oldItem, @NonNull InstituteFiltersAdapter.FilterModel newItem) {
//            return oldItem.getEventId().equals(newItem.getEventId());
            return false;
        }

        @Override
        public boolean areContentsTheSame(@NonNull InstituteFiltersAdapter.FilterModel oldItem, @NonNull InstituteFiltersAdapter.FilterModel newItem) {
//            return oldItem.equals(newItem);
            return false;
        }
    };
    private final Listener listener;

    public InstituteFiltersAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    public static class TutorListingViewHolder extends RecyclerView.ViewHolder {
        private final ItemPopularFiltersBinding binding;

        public TutorListingViewHolder(ItemPopularFiltersBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(InstituteFiltersAdapter.FilterModel model) {
            binding.getRoot().setText(model.getName());
        }
    }

    @NonNull
    @Override
    public TutorListingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemPopularFiltersBinding binding = ItemPopularFiltersBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new TutorListingViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TutorListingViewHolder holder, int position) {
        holder.binding.getRoot().setOnClickListener(v -> listener.onClick(position, getItem(position)));
        holder.bind(getItem(position));
    }

    public interface Listener {
        void onClick(int position, FilterModel model);
    }

    public static class FilterModel {
        private Integer id;
        private String  name;

        public FilterModel() {
        }

        public FilterModel(Integer id, String name) {
            this.id = id;
            this.name = name;
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}
