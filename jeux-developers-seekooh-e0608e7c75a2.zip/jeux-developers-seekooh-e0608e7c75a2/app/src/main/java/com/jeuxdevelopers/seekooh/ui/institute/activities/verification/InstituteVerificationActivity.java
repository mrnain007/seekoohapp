package com.jeuxdevelopers.seekooh.ui.institute.activities.verification;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.NavGraph;
import androidx.navigation.fragment.NavHostFragment;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityInstituteVerificationBinding;
import com.jeuxdevelopers.seekooh.models.dto.VerificationStatusResponse;
import com.jeuxdevelopers.seekooh.ui.institute.fragments.verification.InstituteVerificationViewModel;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class InstituteVerificationActivity extends AppCompatActivity {

    private ActivityInstituteVerificationBinding binding;
    private InstituteVerificationViewModel viewModel;
    private NavController navController;
    private WaitingDialog waitingDialog;
    private VerificationStatusResponse statusData;
    private boolean isResubmission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInstituteVerificationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        viewModel = new ViewModelProvider(this).get(InstituteVerificationViewModel.class);
        initNavController();
        initViews();
        initObservers();
        fetchData();
    }

    private void fetchData() {
        viewModel.getInstituteVerificationStatus();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(this);
    }

    private void initNavController() {
        final NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_container_view);
        navController = navHostFragment.getNavController();
    }

    private void initObservers() {
        viewModel.verificationStatusLiveData
                .observe(this, verificationStatusResponse -> {
                    switch (verificationStatusResponse.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(this, verificationStatusResponse.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(verificationStatusResponse.getMessage());
                            break;
                        case SUCCESS:
                            statusData = verificationStatusResponse.getData();
                            String status = statusData.getStatus();
                            isResubmission = status.equals(Constants.UserVerificationStatus.RESUBMISSION_REQUESTED.name());
                            initFragment();
                            waitingDialog.dismiss();
                            break;
                    }
                });
    }

    private void initFragment() {
        NavGraph navGraph = navController.getNavInflater().inflate(R.navigation.institute_verification_navigation);
        String status = statusData.getStatus();
        Bundle args = new Bundle();
        if (status.equals(Constants.UserVerificationStatus.DOCUMENTS_REQUIRED.name())) {
            navGraph.setStartDestination(R.id.instituteVerifyNowFragment);
        } else if (status.equals(Constants.UserVerificationStatus.PAYMENT_PENDING.name())) {
            navGraph.setStartDestination(R.id.instituteVerificationPaymentFragment);
        } else if (status.equals(Constants.UserVerificationStatus.RESUBMISSION_REQUESTED.name())) {
            // Create a Bundle object to hold your arguments
            args.putBoolean(Constants.UserVerificationStatus.RESUBMISSION_REQUESTED.name(), true);
            navGraph.setStartDestination(R.id.instituteVerificationDocumentFragment);
        } else if (status.equals(Constants.UserVerificationStatus.UNDER_REVIEW.name())
                || status.equals(Constants.UserVerificationStatus.VERIFICATION_COMPLETE.name())) {
            navGraph.setStartDestination(R.id.instituteVerificationStatusFragment);
        }
        navController.setGraph(navGraph, args);
    }
}