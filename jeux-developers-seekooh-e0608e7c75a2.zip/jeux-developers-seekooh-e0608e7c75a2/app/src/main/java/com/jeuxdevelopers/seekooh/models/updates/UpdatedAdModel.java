package com.jeuxdevelopers.seekooh.models.updates;

import com.google.gson.annotations.SerializedName;

public class UpdatedAdModel {
    @SerializedName("id")
    private int id;

    @SerializedName("bannerImage")
    private String bannerImage;

    @SerializedName("url")
    private String url;

    @SerializedName("created_at")
    private String createdAt;

    @SerializedName("updated_at")
    private String updatedAt;

    public UpdatedAdModel() {
    }

    public UpdatedAdModel(int id, String bannerImage, String url, String createdAt, String updatedAt) {
        this.id = id;
        this.bannerImage = bannerImage;
        this.url = url;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBannerImage() {
        return bannerImage;
    }

    public void setBannerImage(String bannerImage) {
        this.bannerImage = bannerImage;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
