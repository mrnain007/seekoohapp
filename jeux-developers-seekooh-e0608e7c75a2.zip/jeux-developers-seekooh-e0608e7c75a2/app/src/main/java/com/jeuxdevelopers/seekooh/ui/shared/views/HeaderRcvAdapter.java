package com.jeuxdevelopers.seekooh.ui.shared.views;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.jeuxdevelopers.seekooh.databinding.ItemMyTuitionsBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemRcvHeaderBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemTvMyTuitionsBinding;
import com.jeuxdevelopers.seekooh.models.TuitionTimeSlot;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class HeaderRcvAdapter extends ListAdapter<String, HeaderRcvAdapter.HeaderViewViewHolder> {
    private static final DiffUtil.ItemCallback<String> DIFF_CALLBACK = new DiffUtil.ItemCallback<String>() {
        @Override
        public boolean areItemsTheSame(@NonNull String oldItem, @NonNull String newItem) {
            return oldItem.equals(newItem);
        }

        @Override
        public boolean areContentsTheSame(@NonNull String oldItem, @NonNull String newItem) {
            return oldItem.equals(newItem);
        }
    };

    private Listener listener;

    public HeaderRcvAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @NonNull
    @Override
    public HeaderViewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemRcvHeaderBinding binding = ItemRcvHeaderBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new HeaderViewViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull HeaderViewViewHolder holder, int position) {
        holder.bind(getItem(position));
        holder.binding.viewApplicantsBtn.setOnClickListener(v -> listener.onViewApplicantsBtnClicked(position));
        holder.binding.editBtn.setOnClickListener(v -> listener.onEditBtnClicked(position));
        holder.binding.deleteBtn.setOnClickListener(v -> listener.onDeleteBtnClicked(position));
    }

    public static class HeaderViewViewHolder extends RecyclerView.ViewHolder {
        private final ItemRcvHeaderBinding binding;

        public HeaderViewViewHolder(ItemRcvHeaderBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(String model) {

        }
    }

    public interface Listener {
        void onViewApplicantsBtnClicked(int position);

        void onEditBtnClicked(int position);

        void onDeleteBtnClicked(int position);
    }
}
