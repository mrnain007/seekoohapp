package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CreateTutorReviewRequest {
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("reviewerRoleId")
    @Expose
    private Integer reviewerRoleId;

    public CreateTutorReviewRequest() {
    }

    public CreateTutorReviewRequest(Double rating, String title, String description, Integer reviewerRoleId) {
        this.rating = rating;
        this.title = title;
        this.description = description;
        this.reviewerRoleId = reviewerRoleId;
    }

    private CreateTutorReviewRequest(Builder builder) {
        setRating(builder.rating);
        setTitle(builder.title);
        setDescription(builder.description);
        setReviewerRoleId(builder.reviewerRoleId);
    }

    public static Builder builder() {
        return new Builder();
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getReviewerRoleId() {
        return reviewerRoleId;
    }

    public void setReviewerRoleId(Integer reviewerRoleId) {
        this.reviewerRoleId = reviewerRoleId;
    }

    public static final class Builder {
        private Double rating;
        private String title;
        private String description;
        private Integer reviewerRoleId;

        private Builder() {
        }

        public Builder rating(Double rating) {
            this.rating = rating;
            return this;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder reviewerRoleId(Integer reviewerRoleId) {
            this.reviewerRoleId = reviewerRoleId;
            return this;
        }

        public CreateTutorReviewRequest build() {
            return new CreateTutorReviewRequest(this);
        }
    }
}
