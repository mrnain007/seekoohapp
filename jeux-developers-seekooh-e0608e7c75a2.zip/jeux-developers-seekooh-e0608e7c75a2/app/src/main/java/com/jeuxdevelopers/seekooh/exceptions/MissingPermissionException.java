package com.jeuxdevelopers.seekooh.exceptions;

public class MissingPermissionException extends RuntimeException {
    public MissingPermissionException(String msg, Throwable cause) {
        super(msg, cause);
    }

    public MissingPermissionException(String msg) {
        super(msg);
    }
}
