package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.DialogJobApplicationBinding;
import com.jeuxdevelopers.seekooh.databinding.DialogTuitionApplicationBinding;
import com.jeuxdevelopers.seekooh.models.Qualification;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TutorListing;
import com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationResponse;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.List;

public class JobApplicationDialog extends Dialog {

    private DialogJobApplicationBinding binding;
    private Listener listener;

    public JobApplicationDialog(@NonNull Context context) {
        super(context);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogJobApplicationBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));

        initDialog();
    }

    @Override
    public void show() {
    }

    @Override
    public void dismiss() {
        if (binding != null) {
            binding.coverTl.getEditText().setText("");
            binding.coverTl.setError(null);
            binding.coverTl.clearFocus();
        }
        super.dismiss();
    }

    @SuppressLint("SetTextI18n")
    public void show(TeachingJobApplicationResponse data, Listener listener) {
        this.listener = listener;
        binding.positiveBtn.setOnClickListener(v -> {
        });

        TutorListing tutor = data.getTutor();
        Glide.with(binding.getRoot()
                        .getContext())
                .load(tutor.getProfileImageUrl())
                .placeholder(R.drawable.profile_image_placeholder)
                .into(binding.profileImg);
        binding.tutorName.setText(tutor.getFullName());
        binding.tutorDescription.setText(tutor.getTagLine());
        Qualification qualification = tutor.getQualifications().get(0);
        binding.educationTv.setText(qualification.getDegreeCertName() + " in " + qualification.getYear());
        List<Subject> teachesSubjects = tutor.getTeachesSubjects();
        StringBuilder subjectStr = new StringBuilder();
        teachesSubjects
                .forEach(subject -> subjectStr.append(subject.getName()).append(" . "));
        binding.tutorSubjects.setText(subjectStr.toString());
        binding.locationTv.setText(tutor.getCity().getName());
        binding.canTeachOnlineTv.setVisibility(tutor.getTeachOnline() ? View.VISIBLE : View.GONE);
        binding.verifiedIconImg.setVisibility(tutor.getVerified() ? View.VISIBLE : View.GONE);
        binding.ratingTv.setText(tutor.getRating().intValue() + "/5");

        if (tutor.getOnline() != null && tutor.getOnline()) {
            binding.lastActiveTv.setText("Active " + Utils.getPrettyTime(System.currentTimeMillis()));
            binding.lastActiveTv.setVisibility(View.VISIBLE);
        } else if (tutor.getLastSeen() != null) {
            binding.lastActiveTv.setText("Active " + Utils.getPrettyTime(tutor.getLastSeen()));
            binding.lastActiveTv.setVisibility(View.VISIBLE);
        } else {
            binding.lastActiveTv.setVisibility(View.INVISIBLE);
        }

        binding.coverTl.getEditText().setText(data.getCoverLetter());

        binding.viewContactBtn.setOnClickListener(v -> {
            listener.onViewContactClicked(data);
        });
        binding.sendMsgBtn.setOnClickListener(v -> {
            listener.onSendMessageClicked(data);
        });
        super.show();
    }

    public boolean validateInput() {
        boolean isValid = true;
        String coverLetter = binding.coverTl.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(coverLetter)) {
            binding.coverTl.setError("Please write cover letter for the application?");
            isValid = false;
        } else {
            binding.coverTl.setError(null);
        }
        return isValid;
    }

    private void initDialog() {
        binding.btnBack.setOnClickListener(v -> {
            dismiss();
        });
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                validateInput();
            }
        };
        binding.coverTl.getEditText().addTextChangedListener(textWatcher);
        binding.negativeBtn.setOnClickListener(v -> {
            listener.onNegativeBtnClicked();
        });
    }

    public interface Listener {
        void onPositiveBtnClicked(String coverLetter, Integer tuitionId);

        void onNegativeBtnClicked();

        void onViewContactClicked(TeachingJobApplicationResponse jobApplicationResponse);
        void onSendMessageClicked(TeachingJobApplicationResponse jobApplicationResponse);
    }
}
