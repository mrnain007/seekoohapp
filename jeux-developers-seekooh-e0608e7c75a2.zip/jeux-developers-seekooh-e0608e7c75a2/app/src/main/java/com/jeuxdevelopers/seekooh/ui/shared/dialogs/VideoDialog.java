package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.jeuxdevelopers.seekooh.databinding.DialogVideoBinding;

public class VideoDialog extends Dialog {

    private DialogVideoBinding binding;
    private Listener listener;
    private String videoUrl;
    private ExoPlayer exoPlayer;

    public VideoDialog(@NonNull Context context) {
        super(context);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogVideoBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));
    }

    @Override
    public void dismiss() {
        releasePlayer();
        super.dismiss();
    }

    @Override
    public void show() {
    }

    public void show(String videoUrl) {
        this.listener = listener;
        this.videoUrl = videoUrl;
        initDialog();
        super.show();
    }

    private void initDialog() {
        exoPlayer = new ExoPlayer.Builder(getContext()).build();
        // Bind the player to the view.
        binding.playerView.setPlayer(exoPlayer);

        // Build the media item.
        MediaItem mediaItem = MediaItem.fromUri(videoUrl);
        // Set the media item to be played.
        exoPlayer.setMediaItem(mediaItem);
        // Prepare the player.
        exoPlayer.prepare();
    }

    public void releasePlayer() {
        if (exoPlayer == null) {
            return;
        }
        exoPlayer.release();
    }

    public interface Listener {
    }
}
