package com.jeuxdevelopers.seekooh.ui.shared.fragments.privacy;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.dto.EditPrivacySettingsRequest;
import com.jeuxdevelopers.seekooh.models.dto.PrivacySettingsResponse;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;
import com.jeuxdevelopers.seekooh.repos.listing.ListingRepo;
import com.jeuxdevelopers.seekooh.repos.listing.ListingRepoImpl;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class AccountPrivacyViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final ListingRepo listingRepo;
    private final AppRepo appRepo;

    public MutableLiveData<Resource<PrivacySettingsResponse>> getPrivacySettingsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<PrivacySettingsResponse>> editPrivacySettingsLiveData = new MutableLiveData<>();

    public AccountPrivacyViewModel() {
        listingRepo = new ListingRepoImpl(disposables);
        appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getPrivacySettings() {
        disposables.add(appRepo.getPrivacySettings()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(privacySettingsResponseResource -> {
                    getPrivacySettingsLiveData.setValue(privacySettingsResponseResource);
                }, throwable -> {
                    getPrivacySettingsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void editPrivacySettings(@NonNull EditPrivacySettingsRequest editPrivacySettingsRequest) {
        disposables.add(appRepo.editPrivacySettings(editPrivacySettingsRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(editPrivacySettingsResource -> {
                    editPrivacySettingsLiveData.setValue(editPrivacySettingsResource);
                }, throwable -> {
                    editPrivacySettingsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
