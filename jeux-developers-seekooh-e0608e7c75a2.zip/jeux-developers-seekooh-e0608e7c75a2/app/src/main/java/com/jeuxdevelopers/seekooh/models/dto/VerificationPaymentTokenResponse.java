package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class VerificationPaymentTokenResponse {
    @SerializedName("paymentToken")
    @Expose
    private String paymentToken;
    @SerializedName("paymentGateway")
    @Expose
    private String paymentGateway;
    @SerializedName("paymentMethod")
    @Expose
    private VerificationPaymentTokenRequest.PaymentMethod paymentMethod;

    public VerificationPaymentTokenResponse() {
    }

    public String getPaymentToken() {
        return paymentToken;
    }

    public void setPaymentToken(String paymentToken) {
        this.paymentToken = paymentToken;
    }

    public String getPaymentGateway() {
        return paymentGateway;
    }

    public void setPaymentGateway(String paymentGateway) {
        this.paymentGateway = paymentGateway;
    }

    public VerificationPaymentTokenRequest.PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(VerificationPaymentTokenRequest.PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    @Override
    public String toString() {
        return "VerificationPaymentTokenResponse{" +
                "paymentToken='" + paymentToken + '\'' +
                ", paymentGateway='" + paymentGateway + '\'' +
                ", paymentMethod=" + paymentMethod +
                '}';
    }
}