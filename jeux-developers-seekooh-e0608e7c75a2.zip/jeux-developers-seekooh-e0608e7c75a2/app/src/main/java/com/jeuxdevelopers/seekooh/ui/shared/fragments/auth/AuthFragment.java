package com.jeuxdevelopers.seekooh.ui.shared.fragments.auth;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.viewpager2.widget.ViewPager2;

import com.jeuxdevelopers.seekooh.databinding.FragmentAuthBinding;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.auth.adapters.AuthPagerAdapter;

public class AuthFragment extends Fragment implements View.OnClickListener {
    private static final String TAG = "AuthFragment";

    private FragmentAuthBinding binding;
    private NavController navController;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAuthBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);
        initViewPager();
        initClickListeners();
    }

    private void initClickListeners() {
        binding.studentBtn.setOnClickListener(this);
        binding.tutorBtn.setOnClickListener(this);
        binding.instituteBtn.setOnClickListener(this);
    }

    private void initViewPager() {
        binding.viewPager.setOffscreenPageLimit(3);
        binding.viewPager.setAdapter(new AuthPagerAdapter(requireActivity().getSupportFragmentManager(), getLifecycle()));
        binding.viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        binding.studentBtn.setSelectedTab(true, binding.tabContainerLl);
                        break;
                    case 1:
                        binding.tutorBtn.setSelectedTab(true, binding.tabContainerLl);
                        break;
                    case 2:
                        binding.instituteBtn.setSelectedTab(true, binding.tabContainerLl);
                        break;

                }
            }
        });
    }

    public void gotoPasswordResetFragment() {
        navController.navigate(AuthFragmentDirections.actionAuthFragmentToForgotPasswordFragment());
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == binding.studentBtn.getId()) {
            binding.viewPager.setCurrentItem(0);
        } else if (v.getId() == binding.tutorBtn.getId()) {
            binding.viewPager.setCurrentItem(1);
        } else if (v.getId() == binding.instituteBtn.getId()) {
            binding.viewPager.setCurrentItem(2);
        }
    }
}