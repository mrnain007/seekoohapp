package com.jeuxdevelopers.seekooh.ui.shared.fragments.verification;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.jeuxdevelopers.seekooh.databinding.FragmentTutorVerifyNowBinding;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.PrefsUtils;

public class TutorVerifyNowFragment extends Fragment implements View.OnClickListener {

    private FragmentTutorVerifyNowBinding binding;
    private NavController navController;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentTutorVerifyNowBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);
        initClickListeners();
    }

    private void initClickListeners() {
        binding.verifyNowBtn.setOnClickListener(this);
        binding.skipBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == binding.verifyNowBtn.getId()) {
            navController.navigate(TutorVerifyNowFragmentDirections.actionTutorVerifyNowFragmentToTutorVerificationPaymentFragment());
        } else if (v.getId() == binding.skipBtn.getId()) {
            if (PrefsUtils.getBoolean(requireContext(), Constants.FIRST_TIME, false)) {
                PrefsUtils.putBoolean(requireContext(), Constants.FIRST_TIME, false);
                startActivity(new Intent(requireActivity(), MainActivity.class));
                requireActivity().finishAffinity();
            } else {
                requireActivity().onBackPressed();
            }
        }
    }
}