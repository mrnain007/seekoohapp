package com.jeuxdevelopers.seekooh.ui.shared.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.MediaController;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityDebugBinding;
import com.jeuxdevelopers.seekooh.ui.shared.activities.paymob.PaymobWebViewActivity;

public class DebugActivity extends AppCompatActivity {
    private final int PAYMOB_WEBVIEW_REQUEST = 1000;

    private ActivityDebugBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDebugBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.button2.setOnClickListener(v -> {
//            startTransactionActivity();
//            startPayActivityNoToken(true);
            startPaymentWebView();
        });
    }

    private void startPaymentWebView() {
        Intent webViewIntent = new Intent(this, PaymobWebViewActivity.class);
        webViewIntent.putExtra("ActionBar", false);
        webViewIntent.putExtra("three_d_secure_url", "https://pakistan.paymob.com/api/acceptance/iframes/75741?payment_token=ZXlKaGJHY2lPaUpJVXpVeE1pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SjFjMlZ5WDJsa0lqbzFNVFUyTVN3aVlXMXZkVzUwWDJObGJuUnpJam94T1Rrd01Dd2lZM1Z5Y21WdVkza2lPaUpRUzFJaUxDSnBiblJsWjNKaGRHbHZibDlwWkNJNk5USTBPVGNzSW05eVpHVnlYMmxrSWpveE1UVXpNekF5TENKaWFXeHNhVzVuWDJSaGRHRWlPbnNpWm1seWMzUmZibUZ0WlNJNklrcHZhRzRpTENKc1lYTjBYMjVoYldVaU9pSkViMlVpTENKemRISmxaWFFpT2lKT1FTSXNJbUoxYVd4a2FXNW5Jam9pVGtFaUxDSm1iRzl2Y2lJNklrNUJJaXdpWVhCaGNuUnRaVzUwSWpvaVRrRWlMQ0pqYVhSNUlqb2lUa0VpTENKemRHRjBaU0k2SWs1Qklpd2lZMjkxYm5SeWVTSTZJazVCSWl3aVpXMWhhV3dpT2lKMWMyVnlNREpBWjIxaGFXd3VZMjl0SWl3aWNHaHZibVZmYm5WdFltVnlJam9pS3preU16RXdNVEl6TkRVMk55SXNJbkJ2YzNSaGJGOWpiMlJsSWpvaVRrRWlMQ0psZUhSeVlWOWtaWE5qY21sd2RHbHZiaUk2SWs1QkluMHNJbXh2WTJ0ZmIzSmtaWEpmZDJobGJsOXdZV2xrSWpwMGNuVmxMQ0psZUhBaU9qRTJPREF5TVRjM016QXNJbkJ0YTE5cGNDSTZJakV4TVM0NE9DNHlNVGN1TWpNM0luMC5tMDVjLXRRcklQQTRnTVdWbGVDbWNuVUdoZ2h4Mmp6elFrUWxFVlBSN3Babktwc1F6ZXI1b0RZcDRkUFpab2lXYXpJbUs4d1p5d3FJWGNiOHROR1lkdw==");
        webViewIntent.putExtra("theme_color", getResources().getColor(R.color.white));
        startActivityForResult(webViewIntent, PAYMOB_WEBVIEW_REQUEST);
    }

    /*private void startTransactionActivity() {
        Intent pay_intent = new Intent(this, PayActivity.class);

        // this key is used to save the card by deafult.
        pay_intent.putExtra(PayActivityIntentKeys.SAVE_CARD_DEFAULT, false);

        // this key is used to display the savecard checkbox.
        pay_intent.putExtra(PayActivityIntentKeys.SHOW_SAVE_CARD, true);

        //this key is used to set the theme color(Actionbar, statusBar, button).
        pay_intent.putExtra(PayActivityIntentKeys.THEME_COLOR, getResources().getColor(R.color.dark_cyan));

        // this key is to wether display the Actionbar or not.
        pay_intent.putExtra("ActionBar", true);

        // this key is used to define the language. takes for ex ("ar", "en") as inputs.
        pay_intent.putExtra("language", "en");

        startActivityForResult(pay_intent, 1000);
        Intent secure_intent = new Intent(this, ThreeDSecureWebViewActivty.class);
        secure_intent.putExtra("ActionBar", true);

    }*/

    /*private void startPayActivityNoToken(Boolean showSaveCard) {
        Intent pay_intent = new Intent(this, PayActivity.class);
        putNormalExtras(pay_intent);
        // this key is used to save the card by deafult.
        pay_intent.putExtra(PayActivityIntentKeys.SAVE_CARD_DEFAULT, false);
        // this key is used to display the savecard checkbox.
        pay_intent.putExtra(PayActivityIntentKeys.SHOW_SAVE_CARD, showSaveCard);
        //this key is used to set the theme color(Actionbar, statusBar, button).
        pay_intent.putExtra(PayActivityIntentKeys.THEME_COLOR, getResources().getColor(R.color.dark_cyan));
        // this key is to whether display the Actionbar or not.
        pay_intent.putExtra("ActionBar", false);
        // this key is used to define the language. takes for ex ("ar", "en") as inputs.
        pay_intent.putExtra("language", "en");
        // this Key is used to set text to Pay confirm button.
        pay_intent.putExtra("PAY_BUTTON_TEXT", "SAVE");
        startActivityForResult(pay_intent, 1000);
    }*/

    /*private void putNormalExtras(Intent intent) {
        intent.putExtra(PayActivityIntentKeys.PAYMENT_KEY, "ZXlKaGJHY2lPaUpJVXpVeE1pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SjFjMlZ5WDJsa0lqbzFNVFUyTVN3aVlXMXZkVzUwWDJObGJuUnpJam94T1Rrd01Dd2lZM1Z5Y21WdVkza2lPaUpRUzFJaUxDSnBiblJsWjNKaGRHbHZibDlwWkNJNk5USTBPVGNzSW05eVpHVnlYMmxrSWpveE1UVXpNekF5TENKaWFXeHNhVzVuWDJSaGRHRWlPbnNpWm1seWMzUmZibUZ0WlNJNklrcHZhRzRpTENKc1lYTjBYMjVoYldVaU9pSkViMlVpTENKemRISmxaWFFpT2lKT1FTSXNJbUoxYVd4a2FXNW5Jam9pVGtFaUxDSm1iRzl2Y2lJNklrNUJJaXdpWVhCaGNuUnRaVzUwSWpvaVRrRWlMQ0pqYVhSNUlqb2lUa0VpTENKemRHRjBaU0k2SWs1Qklpd2lZMjkxYm5SeWVTSTZJazVCSWl3aVpXMWhhV3dpT2lKMWMyVnlNREpBWjIxaGFXd3VZMjl0SWl3aWNHaHZibVZmYm5WdFltVnlJam9pS3preU16RXdNVEl6TkRVMk55SXNJbkJ2YzNSaGJGOWpiMlJsSWpvaVRrRWlMQ0psZUhSeVlWOWtaWE5qY21sd2RHbHZiaUk2SWs1QkluMHNJbXh2WTJ0ZmIzSmtaWEpmZDJobGJsOXdZV2xrSWpwMGNuVmxMQ0psZUhBaU9qRTJPREF5TVRNeU5EUXNJbkJ0YTE5cGNDSTZJakV4TVM0NE9DNHlNVEl1TVRNNUluMC42ODRfNE5zQVdXbUhBejFxQ09hT2RaZHFxZXJHMHZHekNrNi1NN1FtMDdqQ3JKcnZERlpIcHFHbTQ0Q0FuYVU3S0JZR0ItY2x0Ul9SQXNBaWNNWXNCdw==");
        //   intent.putExtra(PayActivityIntentKeys.THREE_D_SECURE_ACTIVITY_TITLE, "Verification");
    }*/

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PAYMOB_WEBVIEW_REQUEST) {
            if (resultCode == IntentConstants.USER_CANCELED) {
                Utils.showToast(this, "User Canceled");
            } else if (resultCode == IntentConstants.MISSING_ARGUMENT) {
                Utils.showToast(this, "Missing args");
            } else if (resultCode == 17) {
                // USER_FINISHED_3D_VERIFICATION
                if (data == null) {
                    Utils.showToast(this, "Data null success");
                    return;
                }
                Utils.showToast(this, "Success");
                String raw_pay_response = data.getStringExtra("raw_pay_response");
                String s = raw_pay_response.toLowerCase();
            }
        }
    }*/

    private void initExov2() {
        ExoPlayer player = new ExoPlayer.Builder(this).build();
        // Bind the player to the view.
        binding.playerView.setPlayer(player);

        // Build the media item.
        MediaItem mediaItem = MediaItem.fromUri("http://192.168.0.104:5333/aws/%d0%9a%d0%bb%d0%b8%d0%bf-Sandra-Johnny-Wanna-Live.mp4");
        // Set the media item to be played.
        player.setMediaItem(mediaItem);
        // Prepare the player.
        player.prepare();

        binding.button2.setOnClickListener(v -> {
            // Start the playback.
            player.play();
        });
    }

    private void initVideView() {
        binding.videoView.setVideoPath("http://192.168.0.104:5333/aws/%d0%9a%d0%bb%d0%b8%d0%bf-Sandra-Johnny-Wanna-Live.mp4");
        MediaController mediaController = new MediaController(this);
        binding.videoView.setMediaController(mediaController);
        mediaController.setAnchorView(binding.videoView);
        binding.videoView.seekTo(10000);
        binding.button2.setOnClickListener(v -> {
            binding.videoView.start();
        });
    }
}