package com.jeuxdevelopers.seekooh.models.updates;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class AdApiResponse {
    @SerializedName("status")
    private String status;

    @SerializedName("code")
    private int code;

    @SerializedName("data")
    private List<UpdatedAdModel> data;

    @SerializedName("message")
    private String message;

    public AdApiResponse() {
    }

    public AdApiResponse(String status, int code, List<UpdatedAdModel> data, String message) {
        this.status = status;
        this.code = code;
        this.data = data;
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<UpdatedAdModel> getData() {
        return data;
    }

    public void setData(List<UpdatedAdModel> data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
