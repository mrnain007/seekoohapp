package com.jeuxdevelopers.seekooh.ui.tutor.fragments.login;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInStatusCodes;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.FragmentTutorLoginBinding;
import com.jeuxdevelopers.seekooh.models.AppSettings;
import com.jeuxdevelopers.seekooh.models.InstituteProfile;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationResponse;
import com.jeuxdevelopers.seekooh.models.dto.SocialLoginRequest;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.auth.AuthFragment;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import org.json.JSONException;

import java.util.Arrays;
import java.util.Optional;

import timber.log.Timber;

public class TutorLoginFragment extends Fragment {
    private static final String TAG = "TutorLoginFragment";
    private static final int RC_SIGN_IN = 1001;

    private FragmentTutorLoginBinding binding;
    private TutorLoginViewModel viewModel;
    private WaitingDialog waitingDialog;

    // Social login
    private GoogleSignInOptions googleSignInOptions;
    private GoogleSignInClient googleSignInClient;
    private CallbackManager fbCallbackManager;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentTutorLoginBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(TutorLoginViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        initSocialLogins();
    }

    private void initSocialLogins() {
        initGoogleLogin();
        initFbLogin();
    }

    private void initGoogleLogin() {
        googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestId()
                .requestEmail()
                .requestProfile()
                .requestIdToken(Constants.GOOGLE_CLIENT_ID)
                .build();
        googleSignInClient = GoogleSignIn.getClient(requireContext(), googleSignInOptions);
        googleSignInClient.signOut();
    }

    private void initFbLogin() {
        disconnectFromFacebook();
        fbCallbackManager = CallbackManager.Factory.create();
        LoginManager.getInstance().registerCallback(fbCallbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                // Get the Access Token
                AccessToken accessToken = loginResult.getAccessToken();
                // Access token to string
                String token = accessToken.getToken();
                // Get the User ID
                String userId = accessToken.getUserId();
                SocialLoginRequest socialLoginRequest = SocialLoginRequest.builder()
                        .token(token)
                        .provider(SocialLoginRequest.Provider.FACEBOOK)
                        .build();
                viewModel.socialLogin(socialLoginRequest);
//                getUserFbProfile(accessToken);
            }

            @Override
            public void onCancel() {
                // Handle cancel
            }

            @Override
            public void onError(@NonNull FacebookException error) {
                // Handle error
                FacebookException error1 = error;
                Utils.showToast(requireContext(), error.getMessage());
            }
        });
    }

    private void getUserFbProfile(AccessToken accessToken) {
        // Get the User's Profile
        GraphRequest request = GraphRequest.newMeRequest(accessToken, (object, response) -> {
            // Parse the User's Profile information
            if (object != null) {
                try {
                    String name = object.getString("name");
                    String email = object.getString("email");
                    String profilePicUrl = object.getJSONObject("picture").getJSONObject("data").getString("url");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e(TAG, "onSuccess: Facebook login response null.");
            }
        });

        // Execute the Graph Request
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,email,picture.type(large)");
        request.setParameters(parameters);
        request.executeAsync();
    }

    private void handleGoogleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            Log.d(TAG, "handleGoogleSignInResult: ");
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            String idToken = account.getIdToken();
            if (account.getIdToken() == null) {
                Utils.showToast(requireContext(), "Google sign-in failed due to invalid response.");
                return;
            }
            SocialLoginRequest socialLoginRequest = SocialLoginRequest.builder()
                    .token(idToken)
                    .provider(SocialLoginRequest.Provider.GOOGLE)
                    .build();
            viewModel.socialLogin(socialLoginRequest);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            int statusCode = e.getStatusCode();
            Timber.tag(TAG).d("signInResult:failed code=%s", statusCode);

            switch (statusCode) {
                case GoogleSignInStatusCodes.SIGN_IN_FAILED:
                    Utils.showToast(requireContext(), "Sign-in failed. Please try again later.");
                    break;
                case GoogleSignInStatusCodes.NETWORK_ERROR:
                    Utils.showToast(requireContext(), "Network error. Please check your internet connection and try again.");
                    break;
                default:
                    Utils.showToast(requireContext(), "Sign-in failed. Please try again later. " + statusCode);
                    break;
            }
        }
    }

    public void disconnectFromFacebook() {
        if (AccessToken.getCurrentAccessToken() == null) {
            return; // already logged out
        }
        new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/permissions/", null,
                HttpMethod.DELETE, graphResponse -> LoginManager.getInstance().logOut()).executeAsync();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleGoogleSignInResult(task);
        }
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext());
        setSpannableStringOnSignUp();
    }

    private void setSpannableStringOnSignUp() {
        String text = "Don't have an account? ";
        String text2 = "SignUp";
        SpannableString spannableString = new SpannableString(text2);
        spannableString.setSpan(new ForegroundColorSpan(Color.RED), 0, text2.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        binding.gotoSignupBtn.setText(TextUtils.concat(text, spannableString));
    }

    private void initClickListeners() {
        binding.gotoSignupBtn.setOnClickListener(v -> {
            Navigation.findNavController(v).navigate(R.id.action_authFragment_to_tutorRegistrationFragment);
        });
        binding.loginBtn.setOnClickListener(v -> {
            if (validateInput()) {
                String email = binding.emailTl.getEditText().getText().toString().trim();
                String password = binding.passwordTl.getEditText().getText().toString().trim();

                viewModel.loginTutor(email, password);
            }
        });
        binding.googleBtn.setOnClickListener(v -> {
            Intent signInIntent = googleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, RC_SIGN_IN);
        });
        binding.facebookBtn.setOnClickListener(v -> {
            LoginManager.getInstance().logInWithReadPermissions(this, fbCallbackManager, Arrays.asList("email", "public_profile"));
        });
        binding.forgotBtn.setOnClickListener(v -> {
            FragmentActivity fragmentActivity = requireActivity();
            if (fragmentActivity instanceof AuthActivity) {
                AuthActivity authActivity = (AuthActivity) fragmentActivity;
                authActivity.switchToPasswordResetFragment();
            }
        });
    }

    private void initObservers() {
        viewModel.authenticationLiveData
                .observe(getViewLifecycleOwner(), authenticationResource -> {
                    switch (authenticationResource.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), authenticationResource.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(authenticationResource.getMessage());
                            break;
                        case SUCCESS:
                            AuthenticationResponse authenticationResponse = authenticationResource.getData();
                            Role tutorRole = authenticationResponse.getRoles()
                                    .stream()
                                    .filter(role -> role.getName().equals(Constants.ROLE_TUTOR))
                                    .findFirst()
                                    .orElse(null);
                            if (tutorRole == null) {
                                Utils.showToast(requireContext(), "User not registered as tutor.");
                                waitingDialog.dismiss();
                                return;
                            }
                            User user = Utils.dtoToUser(authenticationResponse);
                            if (user.getAppSettings() == null) {
                                user.setAppSettings(new AppSettings());
                            }
                            user.getAppSettings().setSelectedRole(tutorRole);
                            UserPrefs.saveUser(requireContext(), user);
                            Utils.showToast(requireContext(), authenticationResource.getMessage());
                            waitingDialog.dismiss();
                            startActivity(new Intent(requireContext(), MainActivity.class));

                            String message = Optional.ofNullable(user.getFullName())
                                    .orElseGet(() -> Optional.ofNullable(user.getInstituteProfile())
                                            .map(InstituteProfile::getNameOfInstitute)
                                            .orElse("Welcome"));
                            Utils.showToast(requireContext(), message);
                            App.syncPresence();
                            requireActivity().finishAffinity();
                            break;
                    }
                });

        viewModel.socialLoginLiveData
                .observe(getViewLifecycleOwner(), socialLoginResponse -> {
                    switch (socialLoginResponse.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), socialLoginResponse.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(socialLoginResponse.getMessage());
                            break;
                        case SUCCESS:
                            AuthenticationResponse authenticationResponse = socialLoginResponse.getData();
                            Role tutorRole = authenticationResponse.getRoles()
                                    .stream()
                                    .filter(role -> role.getName().equals(Constants.ROLE_TUTOR))
                                    .findFirst()
                                    .orElse(null);
                            if (tutorRole == null) {
                                Utils.showToast(requireContext(), "User not registered as tutor.");
                                waitingDialog.dismiss();
                                return;
                            }
                            User user = Utils.dtoToUser(authenticationResponse);
                            if (user.getAppSettings() == null) {
                                user.setAppSettings(new AppSettings());
                            }
                            user.getAppSettings().setSelectedRole(tutorRole);
                            UserPrefs.saveUser(requireContext(), user);
                            Utils.showToast(requireContext(), socialLoginResponse.getMessage());
                            waitingDialog.dismiss();
                            startActivity(new Intent(requireContext(), MainActivity.class));

                            String message = Optional.ofNullable(user.getFullName())
                                    .orElseGet(() -> Optional.ofNullable(user.getInstituteProfile())
                                            .map(InstituteProfile::getNameOfInstitute)
                                            .orElse("Welcome"));
                            Utils.showToast(requireContext(), message);
                            App.syncPresence();
                            requireActivity().finishAffinity();
                            break;
                    }
                });
    }

    private boolean validateInput() {
        boolean isValid = true;
        String email = binding.emailTl.getEditText().getText().toString().trim();
        String password = binding.passwordTl.getEditText().getText().toString().trim();
        if (TextUtils.isEmpty(email)) {
            binding.emailTl.setError("Please enter your email address");
            isValid = false;
        } else {
            binding.emailTl.setError(null);
        }

        if (TextUtils.isEmpty(password)) {
            binding.passwordTl.setError("Please enter your password");
            isValid = false;
        } else {
            binding.passwordTl.setError(null);
        }
        return isValid;
    }
}