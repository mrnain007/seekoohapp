package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Tuition {
    @Expose
    @SerializedName("id")
    private Integer id;
    @Expose
    @SerializedName("onlineClass")
    private Boolean onlineClass;
    @Expose
    @SerializedName("area")
    private String area;
    @Expose
    @SerializedName("jobDescription")
    private String jobDescription;
    @Expose
    @SerializedName("verifiedTutorsOnly")
    private Boolean verifiedTutorsOnly;
    @Expose
    @SerializedName("salaryAmount")
    private Integer salaryAmount;
    @Expose
    @SerializedName("status")
    private Status status;
    @Expose
    @SerializedName("city")
    private City city;
    @SerializedName("subjects")
    @Expose
    private List<Subject> subjects;
    @SerializedName("suggestedSubjects")
    @Expose
    private List<String> suggestedSubjects;
    @Expose
    @SerializedName("grades")
    private List<Grade> grades;
    @SerializedName("suggestedGrades")
    @Expose
    private List<String> suggestedGrades;
    @Expose
    @SerializedName("boardExams")
    private List<Board> boardExams;
    @Expose
    @SerializedName("preferredDays")
    private List<DayOfWeek> preferredDays;
    @Expose
    @SerializedName("tuitionTimeSlot")
    private TuitionTimeSlot tuitionTimeSlot;
    @Expose
    @SerializedName("salaryType")
    private SalaryType salaryType;
    @Expose
    @SerializedName("tutorGender")
    private Gender tutorGender;
    @Expose
    @SerializedName("createdAt")
    private Long createdAt;
    @Expose
    @SerializedName("updatedAt")
    private Long updatedAt;

    public Tuition() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Boolean getOnlineClass() {
        return onlineClass;
    }

    public void setOnlineClass(Boolean onlineClass) {
        this.onlineClass = onlineClass;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public Boolean getVerifiedTutorsOnly() {
        return verifiedTutorsOnly;
    }

    public void setVerifiedTutorsOnly(Boolean verifiedTutorsOnly) {
        this.verifiedTutorsOnly = verifiedTutorsOnly;
    }

    public Integer getSalaryAmount() {
        return salaryAmount;
    }

    public void setSalaryAmount(Integer salaryAmount) {
        this.salaryAmount = salaryAmount;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }

    public List<String> getSuggestedSubjects() {
        return suggestedSubjects;
    }

    public void setSuggestedSubjects(List<String> suggestedSubjects) {
        this.suggestedSubjects = suggestedSubjects;
    }

    public List<Grade> getGrades() {
        return grades;
    }

    public void setGrades(List<Grade> grades) {
        this.grades = grades;
    }

    public List<String> getSuggestedGrades() {
        return suggestedGrades;
    }

    public void setSuggestedGrades(List<String> suggestedGrades) {
        this.suggestedGrades = suggestedGrades;
    }

    public List<Board> getBoardExams() {
        return boardExams;
    }

    public void setBoardExams(List<Board> boardExams) {
        this.boardExams = boardExams;
    }

    public List<DayOfWeek> getPreferredDays() {
        return preferredDays;
    }

    public void setPreferredDays(List<DayOfWeek> preferredDays) {
        this.preferredDays = preferredDays;
    }

    public TuitionTimeSlot getTuitionTimeSlot() {
        return tuitionTimeSlot;
    }

    public void setTuitionTimeSlot(TuitionTimeSlot tuitionTimeSlot) {
        this.tuitionTimeSlot = tuitionTimeSlot;
    }

    public SalaryType getSalaryType() {
        return salaryType;
    }

    public void setSalaryType(SalaryType salaryType) {
        this.salaryType = salaryType;
    }

    public Gender getTutorGender() {
        return tutorGender;
    }

    public void setTutorGender(Gender tutorGender) {
        this.tutorGender = tutorGender;
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Long updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Tuition tuition = (Tuition) o;

        if (id != null ? !id.equals(tuition.id) : tuition.id != null) return false;
        if (onlineClass != null ? !onlineClass.equals(tuition.onlineClass) : tuition.onlineClass != null)
            return false;
        if (area != null ? !area.equals(tuition.area) : tuition.area != null) return false;
        if (jobDescription != null ? !jobDescription.equals(tuition.jobDescription) : tuition.jobDescription != null)
            return false;
        if (verifiedTutorsOnly != null ? !verifiedTutorsOnly.equals(tuition.verifiedTutorsOnly) : tuition.verifiedTutorsOnly != null)
            return false;
        if (salaryAmount != null ? !salaryAmount.equals(tuition.salaryAmount) : tuition.salaryAmount != null)
            return false;
        if (status != tuition.status) return false;
        if (city != null ? !city.equals(tuition.city) : tuition.city != null) return false;
        if (subjects != null ? !subjects.equals(tuition.subjects) : tuition.subjects != null)
            return false;
        if (suggestedSubjects != null ? !suggestedSubjects.equals(tuition.suggestedSubjects) : tuition.suggestedSubjects != null)
            return false;
        if (grades != null ? !grades.equals(tuition.grades) : tuition.grades != null) return false;
        if (suggestedGrades != null ? !suggestedGrades.equals(tuition.suggestedGrades) : tuition.suggestedGrades != null)
            return false;
        if (boardExams != null ? !boardExams.equals(tuition.boardExams) : tuition.boardExams != null)
            return false;
        if (preferredDays != null ? !preferredDays.equals(tuition.preferredDays) : tuition.preferredDays != null)
            return false;
        if (tuitionTimeSlot != null ? !tuitionTimeSlot.equals(tuition.tuitionTimeSlot) : tuition.tuitionTimeSlot != null)
            return false;
        if (salaryType != null ? !salaryType.equals(tuition.salaryType) : tuition.salaryType != null)
            return false;
        if (tutorGender != null ? !tutorGender.equals(tuition.tutorGender) : tuition.tutorGender != null)
            return false;
        if (createdAt != null ? !createdAt.equals(tuition.createdAt) : tuition.createdAt != null)
            return false;
        return updatedAt != null ? updatedAt.equals(tuition.updatedAt) : tuition.updatedAt == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (onlineClass != null ? onlineClass.hashCode() : 0);
        result = 31 * result + (area != null ? area.hashCode() : 0);
        result = 31 * result + (jobDescription != null ? jobDescription.hashCode() : 0);
        result = 31 * result + (verifiedTutorsOnly != null ? verifiedTutorsOnly.hashCode() : 0);
        result = 31 * result + (salaryAmount != null ? salaryAmount.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (subjects != null ? subjects.hashCode() : 0);
        result = 31 * result + (suggestedSubjects != null ? suggestedSubjects.hashCode() : 0);
        result = 31 * result + (grades != null ? grades.hashCode() : 0);
        result = 31 * result + (suggestedGrades != null ? suggestedGrades.hashCode() : 0);
        result = 31 * result + (boardExams != null ? boardExams.hashCode() : 0);
        result = 31 * result + (preferredDays != null ? preferredDays.hashCode() : 0);
        result = 31 * result + (tuitionTimeSlot != null ? tuitionTimeSlot.hashCode() : 0);
        result = 31 * result + (salaryType != null ? salaryType.hashCode() : 0);
        result = 31 * result + (tutorGender != null ? tutorGender.hashCode() : 0);
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        return result;
    }

    public enum Status {
        PENDING,
        APPROVED,
        REJECTED
    }
}
