package com.jeuxdevelopers.seekooh.ui.shared.fragments.inbox.adapters;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.common.util.CollectionUtils;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ItemInboxBinding;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.chat.Chat;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class InboxAdapter extends ListAdapter<Chat, InboxAdapter.InboxViewHolder> {

    private static final DiffUtil.ItemCallback<Chat> DIFF_CALLBACK = new DiffUtil.ItemCallback<Chat>() {
        @Override
        public boolean areItemsTheSame(@NonNull Chat oldItem, @NonNull Chat newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Chat oldItem, @NonNull Chat newItem) {
            return oldItem.equals(newItem);
        }
    };
    private Context context;
    private final Listener listener;
    private User user;
    private FirebaseUser myFb;

    public InboxAdapter(Context context, Listener listener) {
        super(DIFF_CALLBACK);
        this.context = context;
        this.listener = listener;
        user = UserPrefs.getUser(context);
        if (user != null && !TextUtils.isEmpty(user.getSeekoohId())) {
            myFb = Utils.toFirebaseUser(user);
        }
    }

    @NonNull
    @Override
    public InboxViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemInboxBinding binding = ItemInboxBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new InboxViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull InboxViewHolder holder, int position) {
        holder.bind(myFb, getItem(position));
        holder.binding.getRoot().setOnClickListener(v -> listener.onItemClicked(position, getItem(position)));
    }

    public static class InboxViewHolder extends RecyclerView.ViewHolder {
        private final ItemInboxBinding binding;

        public InboxViewHolder(ItemInboxBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(FirebaseUser myFb, Chat model) {
            binding.unreadIndicator.setVisibility(model.getSeenBy().contains(myFb.getUserId()) ? View.GONE : View.VISIBLE);
            switch (model.getType()) {
                case PRIVATE:
                    FirebaseUser otherUser = Utils.getOtherChatUser(model, myFb.getUserId());
                    if (otherUser == null) {
                        binding.userNameTv.setText("NA");
                        return;
                    }

                    Glide.with(binding.getRoot().getContext())
                            .load(otherUser.getProfileImgUrl())
                            .placeholder(R.drawable.profile_image_placeholder)
                            .into(binding.profileImg);

                    binding.userNameTv.setText(otherUser.getFullName());
                    if (model.getLastMessage() != null && model.getLastMessageType() != null) {
                        switch (model.getLastMessageType()) {
                            case TEXT:
                                binding.lastMsgTv.setText(model.getLastMessage());
                                break;
                            case IMAGE:
                                binding.lastMsgTv.setText("image");
                                break;
                            case VIDEO:
                                binding.lastMsgTv.setText("video");
                                break;
                        }
                    }
                    break;
                case GROUP:
                    binding.userNameTv.setText("GROUP Chat not configured.");
                    break;
            }
        }
    }

    public interface Listener {
        void onItemClicked(int position, Chat chat);
    }
}
