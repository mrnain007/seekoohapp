package com.jeuxdevelopers.seekooh.repos.listing;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.TutorListing;
import com.jeuxdevelopers.seekooh.models.TutorProfile;
import com.jeuxdevelopers.seekooh.network.SeekoohService;
import com.jeuxdevelopers.seekooh.network.ServiceUtils;
import com.jeuxdevelopers.seekooh.utils.NetworkUtils;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class ListingRepoImpl implements ListingRepo {
    private final SeekoohService seekoohService;
    private final CompositeDisposable disposables;

    public ListingRepoImpl(CompositeDisposable disposables) {
        this.disposables = disposables;
        seekoohService = ServiceUtils.createSeekoohService(SeekoohService.class);
    }

    @Override
    public Observable<Resource<List<TutorListing>>> getTutorsListing(Integer page, Integer size) {
        return null;
    }
}
