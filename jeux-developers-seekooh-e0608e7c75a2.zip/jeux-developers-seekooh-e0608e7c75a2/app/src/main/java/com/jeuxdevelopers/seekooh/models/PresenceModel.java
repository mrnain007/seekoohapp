package com.jeuxdevelopers.seekooh.models;

import com.google.firebase.database.ServerValue;

import java.util.Map;

public class PresenceModel {
    private Boolean presence;
    private Map<String, String> lastSeen = ServerValue.TIMESTAMP;
    private String fcmToken;

    public PresenceModel() {
    }

    private PresenceModel(Builder builder) {
        setPresence(builder.presence);
        setLastSeen(builder.lastSeen);
        setFcmToken(builder.fcmToken);
    }

    public static Builder builder() {
        return new Builder();
    }

    public Boolean getPresence() {
        return presence;
    }

    public void setPresence(Boolean presence) {
        this.presence = presence;
    }

    public Map<String, String> getLastSeen() {
        return lastSeen;
    }

    public void setLastSeen(Map<String, String> lastSeen) {
        this.lastSeen = lastSeen;
    }

    public String getFcmToken() {
        return fcmToken;
    }

    public void setFcmToken(String fcmToken) {
        this.fcmToken = fcmToken;
    }

    public static final class Builder {
        private Boolean presence;
        private Map<String, String> lastSeen = ServerValue.TIMESTAMP;
        private String fcmToken;

        private Builder() {
        }

        public Builder presence(Boolean presence) {
            this.presence = presence;
            return this;
        }

        public Builder lastSeen(Map<String, String> lastSeen) {
            this.lastSeen = lastSeen;
            return this;
        }

        public Builder fcmToken(String fcmToken) {
            this.fcmToken = fcmToken;
            return this;
        }

        public PresenceModel build() {
            return new PresenceModel(this);
        }
    }
}
