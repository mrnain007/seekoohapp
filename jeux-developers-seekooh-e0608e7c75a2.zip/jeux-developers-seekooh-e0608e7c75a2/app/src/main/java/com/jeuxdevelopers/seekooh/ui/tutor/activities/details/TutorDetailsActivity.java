package com.jeuxdevelopers.seekooh.ui.tutor.activities.details;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.PagerSnapHelper;

import com.bumptech.glide.Glide;
import com.google.android.material.chip.Chip;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityTutorDetailsBinding;
import com.jeuxdevelopers.seekooh.databinding.TutorDetailsSubjectChipBinding;
import com.jeuxdevelopers.seekooh.models.Qualification;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.TutorDetails;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;
import com.jeuxdevelopers.seekooh.models.dto.CreateTutorReviewRequest;
import com.jeuxdevelopers.seekooh.ui.shared.activities.chat.ChatActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.CreateTutorReviewDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.VideoDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.tutor.activities.details.adapters.RcvSliderAdapter;
import com.jeuxdevelopers.seekooh.ui.tutor.activities.details.adapters.ReviewTutorDetailsAdapter;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class TutorDetailsActivity extends AppCompatActivity {

    private ActivityTutorDetailsBinding binding;
    private ReviewTutorDetailsAdapter reviewTutorDetailsAdapter;
    //    private SubjectsTutorDetailsAdapter subjectsTutorDetailsAdapter;
    private CreateTutorReviewDialog createTutorReviewDialog;
    private TutorDetailsViewModel viewModel;
    private WaitingDialog waitingDialog;
    private VideoDialog videoDialog;
    private TutorDetails data;
    private User user;
    int tutorId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTutorDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        viewModel = new ViewModelProvider(this).get(TutorDetailsViewModel.class);
        initData();
        initViews();
        initObservers();
        tutorId = getIntent().getIntExtra(Constants.TUTOR_ID, -1);
        fetchData();
    }

    private void initData() {
        user = UserPrefs.getUser(this);
    }

    private void fetchData() {
        if (tutorId != -1) {
            viewModel.getTutorDetails(tutorId);
            viewModel.getTutorReviews(tutorId);
        } else {
            waitingDialog.showError("Error parsing tutorId!");
        }
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(this, this::onBackPressed);
        videoDialog = new VideoDialog(this);
        createTutorReviewDialog = new CreateTutorReviewDialog(this, (title, description, rating) -> {
            if (!UserPrefs.isLoggedIn(this) || UserPrefs.getUser(this) == null) {
                Utils.showToast(this, "Only logged in users can create review!");
                return;
            }
            User user = UserPrefs.getUser(this);
            Role selectedRole = UserPrefs.getSelectedRole(this);
            viewModel.createTutorReview(data.getTutorId(), new CreateTutorReviewRequest(rating, title, description, selectedRole.getId()));
        });
        initRecycler();
        initClickListeners();
    }

    private void initObservers() {
        viewModel.tutorDetailsLiveData.observe(this, getTutorDetailsResponse -> {
            switch (getTutorDetailsResponse.getStatus()) {
                case ERROR:
                    String errorMsg = getTutorDetailsResponse.getMessage();
                    waitingDialog.showError(errorMsg);
                    Utils.showToast(this, errorMsg);
                    break;
                case LOADING:
                    waitingDialog.show(getTutorDetailsResponse.getMessage());
                    break;
                case SUCCESS:
                    waitingDialog.dismiss();
                    data = getTutorDetailsResponse.getData();
                    Log.e("TAG", "initObservers: " + data.toString());
                    setData();
                    break;
            }
        });

        viewModel.tutorReviewsLiveData.observe(this, getTutorReviewsResponse -> {
            switch (getTutorReviewsResponse.getStatus()) {
                case ERROR:
                    String errorMsg = getTutorReviewsResponse.getMessage();
                    Utils.showToast(this, errorMsg);
                    break;
                case LOADING:
                    binding.shimmer.setVisibility(View.VISIBLE);
                    break;
                case SUCCESS:
                    binding.shimmer.setVisibility(View.GONE);
                    reviewTutorDetailsAdapter.submitList(getTutorReviewsResponse.getData());
                    break;
            }
        });

        viewModel.createTutorReviewLiveData.observe(this, createTutorReviewResponse -> {
            switch (createTutorReviewResponse.getStatus()) {
                case ERROR:
                    String errorMsg = createTutorReviewResponse.getMessage();
                    waitingDialog.dismiss();
                    Utils.showToast(this, errorMsg);
                    break;
                case LOADING:
                    waitingDialog.show(createTutorReviewResponse.getMessage());
                    break;
                case SUCCESS:
                    createTutorReviewDialog.dismiss();
                    Utils.showToast(this, createTutorReviewResponse.getMessage());
                    waitingDialog.dismiss();
                    fetchData();
                    break;
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void setData() {
        try {
            Glide.with(this)
                    .load(data.getProfileImageUrl())
                    .placeholder(R.drawable.profile_image_placeholder)
                    .into(binding.profileImg);
            binding.verifiedBtn.setVisibility(data.getVerified() ? View.VISIBLE : View.GONE);
            binding.tutorName.setText(data.getFullName());
            binding.tutorDescription.setText(data.getTagLine());
            binding.ratingTv.setText(data.getRating().intValue() + "/5");
            binding.locationTv.setText(getString(R.string.location_lahore, data.getCity().getName()));
            binding.subjectsChipGroup.removeAllViews();
            data.getTeachesSubjects()
                    .forEach(subject -> {
                        Chip chip = TutorDetailsSubjectChipBinding.inflate(LayoutInflater.from(this)).getRoot();
                        chip.setText(subject.getName());
                        binding.subjectsChipGroup.addView(chip);
                    });
//        StringBuilder strBuilder = new StringBuilder();
            binding.classesTv.setText("");
            data.getTeachesClasses()
                    .forEach(grade -> {
                        Chip chip = TutorDetailsSubjectChipBinding.inflate(LayoutInflater.from(this)).getRoot();
                        chip.setText(grade.getName());
                        binding.classesChipGroup.addView(chip);
                    });
//        binding.classesTv.setText(strBuilder.toString());

            binding.teachingExperienceTv.setText("");
            data.getExperiences()
                    .forEach(experience -> {
                        binding.teachingExperienceTv.setText(binding.teachingExperienceTv.getText() + "\n" + experience.getExpDetails() + " (" + experience.getExpDuration() + ")");
                    });

            binding.timingsTv.setText("");
            data.getTimeSlots().forEach(tutorTimeSlot -> {
                Integer fromTime = tutorTimeSlot.getFromTime();
                Integer toTime = tutorTimeSlot.getToTime();
                String fromTimeStr = Utils.getFormattedTime(fromTime);
                String toTimeStr = Utils.getFormattedTime(toTime);
                binding.timingsTv.setText(binding.timingsTv.getText() + "\n" + fromTimeStr + " to " + toTimeStr + "\n");
            });

            if (data.getDescription() != null && !data.getDescription().isEmpty()) {
                binding.descriptionSection.setVisibility(View.VISIBLE);
                binding.tutorLongDescriptionTv.setText(data.getDescription());
            } else {
                binding.descriptionSection.setVisibility(View.GONE);
            }

            binding.verifiedGroup.setVisibility(data.getVerified() ? View.VISIBLE : View.GONE);
            binding.educationTv.setText("");
            for (int i = data.getQualifications().size() - 1; i >= 0; i--) {
                Qualification qualification = data.getQualifications().get(i);
                binding.educationTv.setText(binding.educationTv.getText() + getString(R.string.education_placeholder, i == data.getQualifications().size() - 1 ? "\nMost Recent: " : "\nPrevious: ", qualification.getDegreeCertName(), "(" + qualification.getYear() + ")"));
            }
            binding.ratingDetailsTv.setText(data.getRating() + " out of 5 based on " + data.getReviewCount() + " ratings");
            binding.ratingBar.setRating(data.getRating().floatValue());
            binding.viewContactBtn.setVisibility(TextUtils.isEmpty(data.getPhoneNumber()) ? View.GONE : View.VISIBLE);
            binding.getRoot().setVisibility(View.VISIBLE);
            initImageSlider();
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("TAG", "setData: " + e.getMessage());
        }
    }

    private void initImageSlider() {
        RcvSliderAdapter adapter = new RcvSliderAdapter((sliderItem, position) -> {
            if (sliderItem.getType() == RcvSliderAdapter.SliderItem.Type.VIDEO) {
                videoDialog.show(sliderItem.getUrl());
            }
        });
        binding.sliderRcv.setAdapter(adapter);

        List<RcvSliderAdapter.SliderItem> sliderItemList = new ArrayList<>();
        RcvSliderAdapter.SliderItem item1 = RcvSliderAdapter.SliderItem.builder()
                .url(data.getProfileImageUrl())
                .build();
        sliderItemList.add(item1);

        if (data.getProfileVideoUrl() != null) {
            RcvSliderAdapter.SliderItem item2 = RcvSliderAdapter.SliderItem.builder()
                    .type(RcvSliderAdapter.SliderItem.Type.VIDEO)
                    .url(data.getProfileVideoUrl())
                    .build();
            sliderItemList.add(item2);
        }
        adapter.submitList(sliderItemList);

        PagerSnapHelper snapHelper = new PagerSnapHelper();
        snapHelper.attachToRecyclerView(binding.sliderRcv);
        binding.rcvPagerIndicator.attachToRecyclerView(binding.sliderRcv);
    }

    private void initClickListeners() {
        binding.submitReviewBtn.setOnClickListener(v -> {
            createTutorReviewDialog.show(data);
        });
        binding.btnBack.setOnClickListener(v -> onBackPressed());
        binding.viewContactBtn.setOnClickListener(v -> {
            if (Utils.isDataNull(this, data, data.getPhoneNumber())) {
                return;
            }
            Intent dialIntent = new Intent(Intent.ACTION_DIAL);
            dialIntent.setData(Uri.parse("tel:" + data.getPhoneNumber()));
            startActivity(dialIntent);
        });
        binding.sendMsgBtn.setOnClickListener(v -> {
            if (user == null) {
                Utils.showToast(this, "Only logged in users can send messages!");
                return;
            }

            String userId = Utils.toFirebaseId(data.getSeekoohId(), Role.builder().name(Constants.ROLE_TUTOR).build());

            if (Utils.toFirebaseId(user.getSeekoohId(), user.getAppSettings().getSelectedRole()).equals(userId)) {
                Utils.showToast(this, "Cannot send message to your own profile!");
                return;
            }

            // TODO : Fetch user from firebase
            FirebaseFirestore firestore = FirebaseFirestore.getInstance();
            firestore.collection("Users").whereEqualTo("userId", userId).get().addOnSuccessListener(queryDocumentSnapshots -> {
                if (queryDocumentSnapshots.isEmpty()) {
                    Utils.showToast(this, "User not found!");
                    return;
                }
                FirebaseUser firebaseUser = queryDocumentSnapshots.toObjects(FirebaseUser.class).get(0);
                Intent intent = new Intent(this, ChatActivity.class);
                intent.putExtra(Constants.Firebase.FIREBASE_USER, new Gson().toJson(firebaseUser));
                //intent.putExtra(Constants.TUTOR_ID, data.getTutorId()); by asim
                startActivity(intent);
            }).addOnFailureListener(e -> {
                Utils.showToast(this, "Failed to fetch user!");
            });

//            FirebaseUser firebaseUser = FirebaseUser.builder()
//                    .userId(userId)
//                    .profileImgUrl(data.getProfileImageUrl())
//                    .fullName(data.getFullName())
//                    .build();
//
//            Intent intent = new Intent(this, ChatActivity.class);
//            intent.putExtra(Constants.Firebase.FIREBASE_USER, new Gson().toJson(firebaseUser));
//            startActivity(intent);
        });
    }

    private void initRecycler() {
        // Listing Rcv
        reviewTutorDetailsAdapter = new ReviewTutorDetailsAdapter();
        binding.reviewsRcv.setAdapter(reviewTutorDetailsAdapter);
    }
}