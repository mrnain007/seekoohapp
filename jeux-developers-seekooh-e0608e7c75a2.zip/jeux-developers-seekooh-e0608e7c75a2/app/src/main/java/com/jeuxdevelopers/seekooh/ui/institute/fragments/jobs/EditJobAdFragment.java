package com.jeuxdevelopers.seekooh.ui.institute.fragments.jobs;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.google.android.gms.common.util.CollectionUtils;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.FragmentEditJobAdBinding;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Experience;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Qualification;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TeachingJob;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.dto.CreateTeachingJobRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditTeachingJobRequest;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.views.MultiSelectionView;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EditJobAdFragment extends Fragment {
    private static final String TAG = "PostJobAdFragment";

    private int jobId = -1;

    private int currentStepNumber = 1;
    private final int lastStepNumber = 5;
    private boolean isTextWatcherEnabled = false;

    private FragmentEditJobAdBinding binding;
    private PostJobViewModel viewModel;
    private NavController navController;
    private OnBackPressedCallback callback;
    private WaitingDialog waitingDialog;

    // Gender
    private Integer selectedGender;

    // Drop downs
    private ArrayAdapter<String> jobTitlesArrayAdapter;
    private List<String> jobTitleList = new ArrayList<>();
    private String selectedJobTitle;

    private ArrayAdapter<String> citiesArrayAdapter;
    private List<City> citiesList = new ArrayList<>();
    private City selectedCity;

    private ArrayAdapter<String> contractTypesArrayAdapter;
    private List<CreateTeachingJobRequest.ContractType> contractTypesList = new ArrayList<>();
    private CreateTeachingJobRequest.ContractType selectedContractType;

    private MultiSelectionView.Data<Subject> subjectData;
    private MultiSelectionView.Data<Grade> gradeData;

    private TeachingJob data;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (currentStepNumber == 1) {
                    setEnabled(false);
                    requireActivity().onBackPressed();
                } else {
                    gotoNextStep(--currentStepNumber);
                }
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentEditJobAdBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);
        viewModel = new ViewModelProvider(this).get(PostJobViewModel.class);
        initViews();
        initObservers();
        initData();
    }

    private void initObservers() {
        viewModel.getGradesLiveData.observe(getViewLifecycleOwner(), getGradesResponse -> {
            switch (getGradesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getGradesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Grade> gradesList = getGradesResponse.getData();
                    gradeData = new MultiSelectionView.Data<>(gradesList, Grade::getName, data.getGrades(), Grade::getId);
                    binding.gradesMsv.setData("Select grade?", gradeData);
                    if (!CollectionUtils.isEmpty(data.getSuggestedGrades())) {
                        data.getSuggestedGrades().forEach(grade -> binding.gradesMsv.addSuggestedItem(grade));
                    }
                    isInitialDataLoaded();
                    break;
            }
        });

        viewModel.getSubjectsLiveData.observe(getViewLifecycleOwner(), getSubjectsResponse -> {
            switch (getSubjectsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSubjectsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Subject> subjectsList = getSubjectsResponse.getData();
                    subjectData = new MultiSelectionView.Data<>(subjectsList, Subject::getName, data.getSubjects(), Subject::getId);
                    binding.subjectsMsv.setData("Select subjects?", subjectData);
                    if (!CollectionUtils.isEmpty(data.getSuggestedSubjects())) {
                        data.getSuggestedSubjects().forEach(subject -> binding.subjectsMsv.addSuggestedItem(subject));
                    }
                    isInitialDataLoaded();
                    break;
            }
        });

        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    citiesList = getCitiesResponse.getData();
                    setCitiesDropDown();
                    isInitialDataLoaded();
                    break;
            }
        });

        viewModel.jobByIdLiveData.observe(getViewLifecycleOwner(), jobDetails -> {
            switch (jobDetails.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), jobDetails.getMessage());
                    waitingDialog.dismiss();
                    break;
                case LOADING:
                    waitingDialog.show(jobDetails.getMessage());
                    break;
                case SUCCESS:
                    Utils.showToast(requireContext(), jobDetails.getMessage());
                    data = jobDetails.getData();
                    waitingDialog.dismiss();
                    fetchData();
                    setJobData();
                    break;
            }
        });

        viewModel.editJobLiveData.observe(getViewLifecycleOwner(), editJobResponse -> {
            switch (editJobResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), editJobResponse.getMessage());
                    waitingDialog.dismiss();
                    break;
                case LOADING:
                    waitingDialog.show(editJobResponse.getMessage());
                    break;
                case SUCCESS:
                    Utils.showToast(requireContext(), editJobResponse.getMessage());
                    waitingDialog.dismiss();
                    navController.popBackStack();
                    break;
            }
        });
    }

    private void initData() {
        EditJobAdFragmentArgs args = EditJobAdFragmentArgs.fromBundle(getArguments());
        jobId = args.getJobId();
        if (jobId == -1) {
            waitingDialog.showError("Error parsing jobId!");
            return;
        }
        viewModel.getTeachingJobById(jobId);
    }

    private void fetchData() {
        viewModel.getSubjects();
        viewModel.getGrades();
        viewModel.getCities();
    }

    private void setJobData() {
        if (Utils.isDataNull(requireContext(), data)) {
            return;
        }

        binding.jobTitleAcTv.setText(data.getJobTitle(), false);

        binding.areaTl.getEditText().setText(data.getArea());
        selectedCity = data.getCity();
        binding.cityAcTv.setText(data.getCity().getName(), false);


        binding.qualificationEtLayout.degreeNameTl.getEditText().setText(data.getQualification().getDegreeCertName());
        binding.qualificationEtLayout.yearTl.getEditText().setText(String.valueOf(data.getQualification().getYear()));
        binding.qualificationEtLayout.marksTl.getEditText().setText(String.valueOf(data.getQualification().getMarks()));
        binding.experienceEtLayout.experienceDurationTl.getEditText().setText(data.getExperience().getExpDuration());
        binding.experienceEtLayout.experienceDetailsTl.getEditText().setText(data.getExperience().getExpDetails());
        binding.langSkillsTl.getEditText().setText(data.getLanguageSkills());
        binding.expertiseTl.getEditText().setText(data.getExpertise());

        selectedContractType = CreateTeachingJobRequest.ContractType.valueOf(data.getContractType());
        binding.contractTypeAcTv.setText(data.getContractType(), false);
        binding.salaryTl.getEditText().setText(String.valueOf(data.getSalaryAmount().intValue()));
        binding.benefitsTl.getEditText().setText(String.join("\n", data.getBenefits()));

        if (data.getTutorGender() != null) {
            selectedGender = data.getTutorGender().getId();
            if (selectedGender == 1) {
                binding.radioMale.setChecked(true);
            } else {
                binding.radioFemale.setChecked(true);
            }
        } else {
            binding.radioDoesNotMatter.setChecked(true);
        }
        binding.jobDescTl.getEditText().setText(data.getJobDescription());
        binding.onlineClassSw.setChecked(data.getOnline());
        binding.teachAtLocationSw.setChecked(data.getInPerson());
        binding.verifiedTutorsOnlySw.setChecked(data.getVerifiedTutorsOnly());
    }

    private void isInitialDataLoaded() {
        if (subjectData != null && gradeData != null && citiesList != null) {
            waitingDialog.dismiss();
        }
    }

    private void setJobTitleDropDown() {
        String[] jobTitles = getResources().getStringArray(R.array.job_titles_array);
        jobTitleList = Arrays.asList(jobTitles);
        jobTitlesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, jobTitleList);
        binding.jobTitleAcTv.setAdapter(jobTitlesArrayAdapter);
        binding.jobTitleAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedJobTitle = jobTitleList.get(position);
            if (isTextWatcherEnabled) {
                validateInputs();
            }
        });
    }

    private void setCitiesDropDown() {
        citiesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(citiesList, City::getName));
        binding.cityAcTv.setAdapter(citiesArrayAdapter);
        binding.cityAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = citiesList.get(position);
            if (isTextWatcherEnabled) {
                validateInputs();
            }
        });
    }

    private void setContractTypesDropDown() {
        contractTypesList.clear();
        contractTypesList.addAll(Arrays.asList(CreateTeachingJobRequest.ContractType.TEMPORARY, CreateTeachingJobRequest.ContractType.PERMANENT));
        contractTypesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(contractTypesList, CreateTeachingJobRequest.ContractType::name));
        binding.contractTypeAcTv.setAdapter(contractTypesArrayAdapter);
        binding.contractTypeAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedContractType = contractTypesList.get(position);
            if (isTextWatcherEnabled) {
                validateInputs();
            }
        });
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext());
        initClickListeners();
        initStepView();
        initMsvData();
        initAsvListeners();
        initMsvListeners();
        setContractTypesDropDown();
        setJobTitleDropDown();
    }

    private void initMsvListeners() {
        binding.subjectsMsv.setListener(() -> {
            if (isTextWatcherEnabled) {
                validateInputs();
            }
            return false;
        });
        binding.gradesMsv.setListener(() -> {
            if (isTextWatcherEnabled) {
                validateInputs();
            }
            return false;
        });
    }

    @SuppressLint("SetTextI18n")
    private void initAsvListeners() {
        binding.subjectsAsv.setListener(fieldValue -> binding.subjectsMsv.addSuggestedItem(fieldValue));
        binding.gradesAsv.setListener(fieldValue -> binding.gradesMsv.addSuggestedItem(fieldValue));
        binding.jobTitleAsv.setListener(fieldValue -> {
            selectedJobTitle = fieldValue;
            binding.jobTitleAcTv.setText(fieldValue, false);
        });
    }

    private void initMsvData() {
        subjectData = new MultiSelectionView.Data<>(new ArrayList<>(), Subject::getName);
        gradeData = new MultiSelectionView.Data<>(new ArrayList<>(), Grade::getName);
    }

    private void initClickListeners() {
        initTextWatcher();
        binding.genderRg.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == binding.radioMale.getId()) {
                selectedGender = 1;
            } else if (checkedId == binding.radioFemale.getId()) {
                selectedGender = 2;
            } else if (checkedId == binding.radioDoesNotMatter.getId()) {
                selectedGender = null;
            }
        });
        binding.btnBack.setOnClickListener(v -> {
            requireActivity().onBackPressed();
        });

        binding.nextBtn.setOnClickListener(v -> {
            if (currentStepNumber < lastStepNumber) {
                if (validateInputs()) {
                    isTextWatcherEnabled = false;
                    gotoNextStep(++currentStepNumber);
                }
            } else {
                if (!validateInputs()) {
                    return;
                }
                List<Subject> selectedSubjects = subjectData.getSelectedItemsList();
                List<Grade> selectedGrades = gradeData.getSelectedItemsList();
                String jobTitle = binding.jobTitleTl.getEditText().getText().toString().trim();
                String area = binding.areaTl.getEditText().getText().toString().trim();

                String degreeName = binding.qualificationEtLayout.degreeNameTl.getEditText().getText().toString().trim();
                String year = binding.qualificationEtLayout.yearTl.getEditText().getText().toString().trim();
                String marks = binding.qualificationEtLayout.marksTl.getEditText().getText().toString().trim();
                String duration = binding.experienceEtLayout.experienceDurationTl.getEditText().getText().toString().trim();
                String exDetails = binding.experienceEtLayout.experienceDetailsTl.getEditText().getText().toString().trim();
                String langSkills = binding.langSkillsTl.getEditText().getText().toString().trim();
                String expertise = binding.expertiseTl.getEditText().getText().toString().trim();

                String salary = binding.salaryTl.getEditText().getText().toString().trim();
                List<String> benefits = Arrays.asList(binding.benefitsTl.getEditText().getText().toString().trim().split("\n"));

                String jobDesc = binding.jobDescTl.getEditText().getText().toString().trim();

                EditTeachingJobRequest editTeachingJobRequest = EditTeachingJobRequest.builder()
                        .subjectIds(Utils.toIdList(selectedSubjects, Subject::getId))
                        .gradeIds(Utils.toIdList(selectedGrades, Grade::getId))
                        .suggestedSubjects(subjectData.getSuggestedItems())
                        .suggestedGrades(gradeData.getSuggestedItems())
                        .jobTitle(jobTitle)
                        .isOnline(binding.onlineClassSw.isChecked())
                        .isInPerson(binding.teachAtLocationSw.isChecked())
                        .cityId(selectedCity.getId())
                        .area(area)
                        .qualification(new Qualification(null, degreeName, Integer.parseInt(year), Double.parseDouble(marks)))
                        .experience(new Experience(null, duration, exDetails))
                        .languageSkills(langSkills)
                        .expertise(expertise)
                        .contractType(EditTeachingJobRequest.ContractType.valueOf(selectedContractType.name()))
                        .salaryAmount(Double.parseDouble(salary))
                        .benefits(benefits)
                        .tutorGenderId(selectedGender)
                        .jobDescription(jobDesc)
                        .verifiedTutorsOnly(binding.verifiedTutorsOnlySw.isChecked())
                        .build();

                viewModel.editTeachingJob(jobId, editTeachingJobRequest);
            }
        });
    }

    private void initTextWatcher() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateInputs();
                }
            }
        };

        binding.areaTl.getEditText().addTextChangedListener(textWatcher);
        binding.salaryTl.getEditText().addTextChangedListener(textWatcher);
        binding.jobDescTl.getEditText().addTextChangedListener(textWatcher);
        binding.benefitsTl.getEditText().addTextChangedListener(textWatcher);
        binding.langSkillsTl.getEditText().addTextChangedListener(textWatcher);
        binding.expertiseTl.getEditText().addTextChangedListener(textWatcher);
        binding.jobTitleTl.getEditText().addTextChangedListener(textWatcher);
        binding.jobDescTl.getEditText().addTextChangedListener(textWatcher);
        binding.contractTypeTl.getEditText().addTextChangedListener(textWatcher);
        binding.qualificationEtLayout.degreeNameTl.getEditText().addTextChangedListener(textWatcher);
        binding.qualificationEtLayout.yearTl.getEditText().addTextChangedListener(textWatcher);
        binding.qualificationEtLayout.marksTl.getEditText().addTextChangedListener(textWatcher);
        binding.experienceEtLayout.experienceDurationTl.getEditText().addTextChangedListener(textWatcher);
        binding.experienceEtLayout.experienceDetailsTl.getEditText().addTextChangedListener(textWatcher);
        binding.cityTl.getEditText().addTextChangedListener(textWatcher);
    }

    private void gotoNextStep(int stepNumber) {
        switch (stepNumber) {
            case 1:
                binding.teachingLayoutLl.setVisibility(View.VISIBLE);
                binding.locationLayoutLl.setVisibility(View.GONE);
                binding.qualificationLayoutLl.setVisibility(View.GONE);
                binding.contractLayoutLl.setVisibility(View.GONE);
                binding.otherDetailsLayoutLl.setVisibility(View.GONE);
                binding.stepView.setActiveStep(1);
                break;
            case 2:
                binding.teachingLayoutLl.setVisibility(View.GONE);
                binding.locationLayoutLl.setVisibility(View.VISIBLE);
                binding.qualificationLayoutLl.setVisibility(View.GONE);
                binding.contractLayoutLl.setVisibility(View.GONE);
                binding.otherDetailsLayoutLl.setVisibility(View.GONE);
                binding.stepView.setActiveStep(2);
                break;
            case 3:
                binding.teachingLayoutLl.setVisibility(View.GONE);
                binding.locationLayoutLl.setVisibility(View.GONE);
                binding.qualificationLayoutLl.setVisibility(View.VISIBLE);
                binding.contractLayoutLl.setVisibility(View.GONE);
                binding.otherDetailsLayoutLl.setVisibility(View.GONE);
                binding.stepView.setActiveStep(3);
                break;
            case 4:
                binding.teachingLayoutLl.setVisibility(View.GONE);
                binding.locationLayoutLl.setVisibility(View.GONE);
                binding.qualificationLayoutLl.setVisibility(View.GONE);
                binding.contractLayoutLl.setVisibility(View.VISIBLE);
                binding.otherDetailsLayoutLl.setVisibility(View.GONE);
                binding.stepView.setActiveStep(4);
                break;
            case 5:
                binding.teachingLayoutLl.setVisibility(View.GONE);
                binding.locationLayoutLl.setVisibility(View.GONE);
                binding.qualificationLayoutLl.setVisibility(View.GONE);
                binding.contractLayoutLl.setVisibility(View.GONE);
                binding.otherDetailsLayoutLl.setVisibility(View.VISIBLE);
                binding.stepView.setActiveStep(5);
                break;
        }

        if (stepNumber == lastStepNumber) {
            binding.nextBtn.setText("Submit");
        } else {
            binding.nextBtn.setText("Next");
        }
    }

    private void initStepView() {
        binding.stepView.setColumnCount(2);
        binding.stepView.setSteps("Teaching", "Location", "Qualifications", "Contact", "Other Details");
        binding.stepView.setActiveStep(1);
    }

    private boolean validateInputs() {
        isTextWatcherEnabled = true;
        boolean isValid = true;
        switch (currentStepNumber) {
            case 1:
                String jobTitle = selectedJobTitle;
                if (binding.subjectsMsv.getData().getSelectedItemsList().isEmpty()) {
                    binding.subjectsMsv.setError("Please select subjects?");
                    isValid = false;
                } else {
                    binding.subjectsMsv.setError(null);
                }
                if (binding.gradesMsv.getData().getSelectedItemsList().isEmpty()) {
                    binding.gradesMsv.setError("Please select grade?");
                    isValid = false;
                } else {
                    binding.gradesMsv.setError(null);
                }
                if (TextUtils.isEmpty(jobTitle)) {
                    binding.jobTitleTl.setError("Please enter job title?");
                    isValid = false;
                } else {
                    binding.jobTitleTl.setError(null);
                }
                break;
            case 2:
                String area = binding.areaTl.getEditText().getText().toString().trim();
                if (TextUtils.isEmpty(area)) {
                    binding.areaTl.setError("Please enter your area?");
                    isValid = false;
                } else {
                    binding.areaTl.setError(null);
                }
                if (selectedCity == null) {
                    binding.cityTl.setError("Please select your city?");
                    isValid = false;
                } else {
                    binding.cityTl.setError(null);
                }
                break;
            case 3:
                String degreeName = binding.qualificationEtLayout.degreeNameTl.getEditText().getText().toString().trim();
                String year = binding.qualificationEtLayout.yearTl.getEditText().getText().toString().trim();
                String marks = binding.qualificationEtLayout.marksTl.getEditText().getText().toString().trim();
                String duration = binding.experienceEtLayout.experienceDurationTl.getEditText().getText().toString().trim();
                String exDetails = binding.experienceEtLayout.experienceDetailsTl.getEditText().getText().toString().trim();
                String langSkills = binding.langSkillsTl.getEditText().getText().toString().trim();
                String expertise = binding.expertiseTl.getEditText().getText().toString().trim();
                if (TextUtils.isEmpty(degreeName)) {
                    binding.qualificationEtLayout.degreeNameTl.setError("Degree name?");
                    isValid = false;
                } else {
                    binding.qualificationEtLayout.degreeNameTl.setError(null);
                }
                if (TextUtils.isEmpty(year)) {
                    binding.qualificationEtLayout.yearTl.setError("Passing year?");
                    isValid = false;
                } else {
                    binding.qualificationEtLayout.yearTl.setError(null);
                }
                if (TextUtils.isEmpty(marks)) {
                    binding.qualificationEtLayout.marksTl.setError("Marks obtained?");
                    isValid = false;
                } else {
                    binding.qualificationEtLayout.marksTl.setError(null);
                }
                if (TextUtils.isEmpty(duration)) {
                    binding.experienceEtLayout.experienceDurationTl.setError("Duration?");
                    isValid = false;
                } else {
                    binding.experienceEtLayout.experienceDurationTl.setError(null);
                }
                if (TextUtils.isEmpty(exDetails)) {
                    binding.experienceEtLayout.experienceDetailsTl.setError("Details?");
                    isValid = false;
                } else {
                    binding.experienceEtLayout.experienceDetailsTl.setError(null);
                }
                if (TextUtils.isEmpty(langSkills)) {
                    binding.langSkillsTl.setError("Language skills requirements?");
                    isValid = false;
                } else {
                    binding.langSkillsTl.setError(null);
                }
                if (TextUtils.isEmpty(expertise)) {
                    binding.expertiseTl.setError("Expertise requirements?");
                    isValid = false;
                } else {
                    binding.expertiseTl.setError(null);
                }
                break;
            case 4:
                String salary = binding.salaryTl.getEditText().getText().toString().trim();
                String benefits = binding.benefitsTl.getEditText().getText().toString().trim();
                if (selectedContractType == null) {
                    binding.contractTypeTl.setError("Select contract type?");
                    isValid = false;
                } else {
                    binding.contractTypeTl.setError(null);
                }
                if (TextUtils.isEmpty(salary)) {
                    binding.salaryTl.setError("Please enter salary amount?");
                    isValid = false;
                } else {
                    binding.salaryTl.setError(null);
                }
                if (TextUtils.isEmpty(benefits)) {
                    binding.benefitsTl.setError("Please enter benefits detail?");
                    isValid = false;
                } else {
                    binding.benefitsTl.setError(null);
                }
                break;
            case 5:
                String jobDesc = binding.jobDescTl.getEditText().getText().toString().trim();
                if (TextUtils.isEmpty(jobDesc)) {
                    binding.jobDescTl.setError("Please enter job descriptions?");
                    isValid = false;
                } else {
                    binding.jobDescTl.setError(null);
                }
                break;
            default:
                isValid = false;
                break;
        }
        return isValid;
    }
}