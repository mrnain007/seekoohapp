package com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ItemMyTuitionsBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemTvMyTuitionsBinding;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.TuitionTimeSlot;
import com.jeuxdevelopers.seekooh.utils.Utils;

import org.ocpsoft.prettytime.PrettyTime;

public class PostedTuitionsAdapter extends ListAdapter<Tuition, PostedTuitionsAdapter.PostedTuitionViewHolder> {
    private static final DiffUtil.ItemCallback<Tuition> DIFF_CALLBACK = new DiffUtil.ItemCallback<com.jeuxdevelopers.seekooh.models.Tuition>() {
        @Override
        public boolean areItemsTheSame(@NonNull Tuition oldItem, @NonNull Tuition newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Tuition oldItem, @NonNull Tuition newItem) {
            return oldItem.equals(newItem);
        }
    };

    private Listener listener;

    public PostedTuitionsAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @NonNull
    @Override
    public PostedTuitionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemMyTuitionsBinding binding = ItemMyTuitionsBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new PostedTuitionViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PostedTuitionViewHolder holder, int position) {
        holder.bind(getItem(position));
        holder.binding.viewApplicantsBtn.setOnClickListener(v -> listener.onViewApplicantsBtnClicked(position));
        holder.binding.editBtn.setOnClickListener(v -> listener.onEditBtnClicked(position));
        holder.binding.deleteBtn.setOnClickListener(v -> listener.onDeleteBtnClicked(position));
    }

    public static class PostedTuitionViewHolder extends RecyclerView.ViewHolder {
        private final ItemMyTuitionsBinding binding;

        public PostedTuitionViewHolder(ItemMyTuitionsBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(Tuition model) {
            Context context = binding.getRoot().getContext();
            if (Utils.isDataNull(context, model)) {
                return;
            }
            if (model.getStatus() != null) {
                switch (model.getStatus()) {
                    case PENDING:
                        binding.tuitionStatusShortTv.setText("Pending Approval");
                        break;
                    case APPROVED:
                        binding.tuitionStatusShortTv.setText("Approved");
                        binding.tuitionStatusLongTv.setText("Congratulations! Your request has been approved.");
                        break;
                    case REJECTED:
                        binding.tuitionStatusShortTv.setText("Rejected");
                        binding.tuitionStatusLongTv.setText("Sorry, your request has been rejected.");
                        break;
                    default:
                        binding.tuitionStatusShortTv.setText("Status NA");
                        binding.tuitionStatusLongTv.setText("Sorry, the status is currently unavailable due to an error.");
                        break;
                }
            } else {
                binding.tuitionStatusShortTv.setText("Status NA");
                binding.tuitionStatusLongTv.setText("Sorry, the status is currently unavailable.");
            }

            binding.timeTv.setText("Posted " + Utils.getPrettyTime(model.getCreatedAt()));
            binding.tuitionDescription.setText(model.getJobDescription());

            binding.subjectsContainer.itemsLl.removeAllViews();
            binding.subjectsContainer.fieldNameTv.setText("Subjects:");
            model.getSubjects().forEach(subject -> {
                TextView textView = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
                textView.setText(subject.getName());
                textView.setTextSize(com.intuit.ssp.R.dimen._9ssp);
                binding.subjectsContainer.itemsLl.addView(textView);
            });

            if (model.getSuggestedSubjects() != null) {
                model.getSuggestedSubjects().forEach(subject -> {
                    TextView textView = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
                    textView.setText(subject);
                    textView.setTextSize(com.intuit.ssp.R.dimen._9ssp);
                    binding.subjectsContainer.itemsLl.addView(textView);
                });
            }

            binding.gradesContainer.itemsLl.removeAllViews();
            binding.gradesContainer.fieldNameTv.setText("Grades:");
            model.getGrades().forEach(grade -> {
                TextView textView = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
                textView.setText(grade.getName());
                textView.setTextSize(com.intuit.ssp.R.dimen._9ssp);
                binding.gradesContainer.itemsLl.addView(textView);
            });

            if (model.getSuggestedGrades() != null) {
                model.getSuggestedGrades().forEach(grade -> {
                    TextView textView = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
                    textView.setText(grade);
                    textView.setTextSize(com.intuit.ssp.R.dimen._9ssp);
                    binding.gradesContainer.itemsLl.addView(textView);
                });
            }

            binding.localityContainer.itemsLl.removeAllViews();
            binding.localityContainer.fieldNameTv.setText("Locality:");
            TextView areaTv = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
            TextView cityTv = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
            areaTv.setText(model.getArea());
            areaTv.setTextSize(com.intuit.ssp.R.dimen._9ssp);
            cityTv.setText(model.getCity().getName());
            cityTv.setTextSize(com.intuit.ssp.R.dimen._9ssp);
            binding.localityContainer.itemsLl.addView(areaTv);
            binding.localityContainer.itemsLl.addView(cityTv);

            binding.boardsContainer.itemsLl.removeAllViews();
            binding.boardsContainer.fieldNameTv.setText("Boards:");
            model.getBoardExams().forEach(board -> {
                TextView textView = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
                textView.setText(board.getName());
                textView.setTextSize(com.intuit.ssp.R.dimen._9ssp);
                binding.boardsContainer.itemsLl.addView(textView);
            });

            binding.daysContainer.itemsLl.removeAllViews();
            binding.daysContainer.fieldNameTv.setText("Days:");
            model.getPreferredDays().forEach(day -> {
                TextView textView = ItemTvMyTuitionsBinding.inflate(LayoutInflater.from(context)).getRoot();
                textView.setText(day.getName());
                textView.setTextSize(com.intuit.ssp.R.dimen._9ssp);
                binding.daysContainer.itemsLl.addView(textView);
            });

            TuitionTimeSlot tuitionTimeSlot = model.getTuitionTimeSlot();
            binding.feeAmountTv.setText(Utils.formatCurrency(model.getSalaryAmount()));
            binding.timingsTv.setText("Timings: " + Utils.getFormattedTime(tuitionTimeSlot.getFromTime()) + " to " + Utils.getFormattedTime(tuitionTimeSlot.getToTime()));
            binding.genderDetailsTv.setText(model.getTutorGender() != null ? model.getTutorGender().getName() : "Doesn't matter");
        }
    }

    public interface Listener {
        void onViewApplicantsBtnClicked(int position);

        void onEditBtnClicked(int position);

        void onDeleteBtnClicked(int position);
    }
}
