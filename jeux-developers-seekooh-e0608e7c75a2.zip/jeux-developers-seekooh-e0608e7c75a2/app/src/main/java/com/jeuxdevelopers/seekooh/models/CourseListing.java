package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CourseListing {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("reviewCount")
    @Expose
    private Integer reviewCount;
    @SerializedName("enrolmentCount")
    @Expose
    private Integer enrolmentCount;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("learningGoals")
    @Expose
    private String learningGoals;
    @SerializedName("minRequirements")
    @Expose
    private List<String> minRequirements;
    @SerializedName("targetAudience")
    @Expose
    private String targetAudience;
    @SerializedName("startMinutes")
    @Expose
    private Integer startMinutes;
    @SerializedName("endMinutes")
    @Expose
    private Integer endMinutes;
    @SerializedName("startDate")
    @Expose
    private Long startDate;
    @SerializedName("endDate")
    @Expose
    private Long endDate;
    @SerializedName("isOnline")
    @Expose
    private Boolean isOnline;
    @SerializedName("isInPerson")
    @Expose
    private Boolean isInPerson;
    @SerializedName("days")
    @Expose
    private List<DayOfWeek> days;
    @SerializedName("subjects")
    @Expose
    private List<Subject> subjects;
    @SerializedName("createdAt")
    @Expose
    private Long createdAt;
    @SerializedName("updatedAt")
    @Expose
    private Long updatedAt;
    @SerializedName("tutorDetails")
    @Expose
    private TutorDetails tutorDetails;

    public CourseListing() {
    }

    public CourseListing(Integer id, String title, Double rating, Integer reviewCount, Integer enrolmentCount, String description, String learningGoals, List<String> minRequirements, String targetAudience, Integer startMinutes, Integer endMinutes, Long startDate, Long endDate, Boolean isOnline, Boolean isInPerson, List<DayOfWeek> days, List<Subject> subjects, Long createdAt, Long updatedAt, TutorDetails tutorDetails) {
        this.id = id;
        this.title = title;
        this.rating = rating;
        this.reviewCount = reviewCount;
        this.enrolmentCount = enrolmentCount;
        this.description = description;
        this.learningGoals = learningGoals;
        this.minRequirements = minRequirements;
        this.targetAudience = targetAudience;
        this.startMinutes = startMinutes;
        this.endMinutes = endMinutes;
        this.startDate = startDate;
        this.endDate = endDate;
        this.isOnline = isOnline;
        this.isInPerson = isInPerson;
        this.days = days;
        this.subjects = subjects;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.tutorDetails = tutorDetails;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Integer getReviewCount() {
        return reviewCount;
    }

    public void setReviewCount(Integer reviewCount) {
        this.reviewCount = reviewCount;
    }

    public Integer getEnrolmentCount() {
        return enrolmentCount;
    }

    public void setEnrolmentCount(Integer enrolmentCount) {
        this.enrolmentCount = enrolmentCount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLearningGoals() {
        return learningGoals;
    }

    public void setLearningGoals(String learningGoals) {
        this.learningGoals = learningGoals;
    }

    public List<String> getMinRequirements() {
        return minRequirements;
    }

    public void setMinRequirements(List<String> minRequirements) {
        this.minRequirements = minRequirements;
    }

    public String getTargetAudience() {
        return targetAudience;
    }

    public void setTargetAudience(String targetAudience) {
        this.targetAudience = targetAudience;
    }

    public Integer getStartMinutes() {
        return startMinutes;
    }

    public void setStartMinutes(Integer startMinutes) {
        this.startMinutes = startMinutes;
    }

    public Integer getEndMinutes() {
        return endMinutes;
    }

    public void setEndMinutes(Integer endMinutes) {
        this.endMinutes = endMinutes;
    }

    public Long getStartDate() {
        return startDate;
    }

    public void setStartDate(Long startDate) {
        this.startDate = startDate;
    }

    public Long getEndDate() {
        return endDate;
    }

    public void setEndDate(Long endDate) {
        this.endDate = endDate;
    }

    public Boolean getOnline() {
        return isOnline;
    }

    public void setOnline(Boolean online) {
        isOnline = online;
    }

    public Boolean getInPerson() {
        return isInPerson;
    }

    public void setInPerson(Boolean inPerson) {
        isInPerson = inPerson;
    }

    public List<DayOfWeek> getDays() {
        return days;
    }

    public void setDays(List<DayOfWeek> days) {
        this.days = days;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Long updatedAt) {
        this.updatedAt = updatedAt;
    }

    public TutorDetails getTutorDetails() {
        return tutorDetails;
    }

    public void setTutorDetails(TutorDetails tutorDetails) {
        this.tutorDetails = tutorDetails;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CourseListing that = (CourseListing) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (title != null ? !title.equals(that.title) : that.title != null) return false;
        if (rating != null ? !rating.equals(that.rating) : that.rating != null) return false;
        if (reviewCount != null ? !reviewCount.equals(that.reviewCount) : that.reviewCount != null)
            return false;
        if (enrolmentCount != null ? !enrolmentCount.equals(that.enrolmentCount) : that.enrolmentCount != null)
            return false;
        if (description != null ? !description.equals(that.description) : that.description != null)
            return false;
        if (learningGoals != null ? !learningGoals.equals(that.learningGoals) : that.learningGoals != null)
            return false;
        if (minRequirements != null ? !minRequirements.equals(that.minRequirements) : that.minRequirements != null)
            return false;
        if (targetAudience != null ? !targetAudience.equals(that.targetAudience) : that.targetAudience != null)
            return false;
        if (startMinutes != null ? !startMinutes.equals(that.startMinutes) : that.startMinutes != null)
            return false;
        if (endMinutes != null ? !endMinutes.equals(that.endMinutes) : that.endMinutes != null)
            return false;
        if (startDate != null ? !startDate.equals(that.startDate) : that.startDate != null)
            return false;
        if (endDate != null ? !endDate.equals(that.endDate) : that.endDate != null) return false;
        if (isOnline != null ? !isOnline.equals(that.isOnline) : that.isOnline != null)
            return false;
        if (isInPerson != null ? !isInPerson.equals(that.isInPerson) : that.isInPerson != null)
            return false;
        if (days != null ? !days.equals(that.days) : that.days != null) return false;
        if (subjects != null ? !subjects.equals(that.subjects) : that.subjects != null)
            return false;
        if (createdAt != null ? !createdAt.equals(that.createdAt) : that.createdAt != null)
            return false;
        if (updatedAt != null ? !updatedAt.equals(that.updatedAt) : that.updatedAt != null)
            return false;
        return tutorDetails != null ? tutorDetails.equals(that.tutorDetails) : that.tutorDetails == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (title != null ? title.hashCode() : 0);
        result = 31 * result + (rating != null ? rating.hashCode() : 0);
        result = 31 * result + (reviewCount != null ? reviewCount.hashCode() : 0);
        result = 31 * result + (enrolmentCount != null ? enrolmentCount.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (learningGoals != null ? learningGoals.hashCode() : 0);
        result = 31 * result + (minRequirements != null ? minRequirements.hashCode() : 0);
        result = 31 * result + (targetAudience != null ? targetAudience.hashCode() : 0);
        result = 31 * result + (startMinutes != null ? startMinutes.hashCode() : 0);
        result = 31 * result + (endMinutes != null ? endMinutes.hashCode() : 0);
        result = 31 * result + (startDate != null ? startDate.hashCode() : 0);
        result = 31 * result + (endDate != null ? endDate.hashCode() : 0);
        result = 31 * result + (isOnline != null ? isOnline.hashCode() : 0);
        result = 31 * result + (isInPerson != null ? isInPerson.hashCode() : 0);
        result = 31 * result + (days != null ? days.hashCode() : 0);
        result = 31 * result + (subjects != null ? subjects.hashCode() : 0);
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        result = 31 * result + (tutorDetails != null ? tutorDetails.hashCode() : 0);
        return result;
    }

    public static class TutorDetails {

        @SerializedName("id")
        @Expose
        private Integer id;
        @SerializedName("seekoohId")
        @Expose
        private String seekoohId;
        @SerializedName("fullName")
        @Expose
        private String fullName;
        @SerializedName("profileImageUrl")
        @Expose
        private String profileImageUrl;
        @SerializedName("rating")
        @Expose
        private Double rating;
        @SerializedName("reviewCount")
        @Expose
        private Integer reviewCount;
        @SerializedName("isVerified")
        @Expose
        private Boolean isVerified;

        public TutorDetails() {
        }

        public TutorDetails(Integer id, String seekoohId, String fullName, String profileImageUrl, Double rating, Integer reviewCount, Boolean isVerified) {
            this.id = id;
            this.seekoohId = seekoohId;
            this.fullName = fullName;
            this.profileImageUrl = profileImageUrl;
            this.rating = rating;
            this.reviewCount = reviewCount;
            this.isVerified = isVerified;
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getSeekoohId() {
            return seekoohId;
        }

        public void setSeekoohId(String seekoohId) {
            this.seekoohId = seekoohId;
        }

        public String getFullName() {
            return fullName;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public String getProfileImageUrl() {
            return profileImageUrl;
        }

        public void setProfileImageUrl(String profileImageUrl) {
            this.profileImageUrl = profileImageUrl;
        }

        public Double getRating() {
            return rating;
        }

        public void setRating(Double rating) {
            this.rating = rating;
        }

        public Integer getReviewCount() {
            return reviewCount;
        }

        public void setReviewCount(Integer reviewCount) {
            this.reviewCount = reviewCount;
        }

        public Boolean getVerified() {
            return isVerified;
        }

        public void setVerified(Boolean verified) {
            isVerified = verified;
        }
    }
}
