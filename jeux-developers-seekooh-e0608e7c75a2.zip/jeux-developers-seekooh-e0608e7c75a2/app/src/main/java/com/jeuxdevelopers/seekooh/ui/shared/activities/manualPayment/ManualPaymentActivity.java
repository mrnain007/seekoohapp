package com.jeuxdevelopers.seekooh.ui.shared.activities.manualPayment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityInstituteVerificationBinding;
import com.jeuxdevelopers.seekooh.databinding.ActivityManualPaymentBinding;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import hilt_aggregated_deps._dagger_hilt_android_internal_lifecycle_DefaultViewModelFactories_ActivityEntryPoint;

public class ManualPaymentActivity extends AppCompatActivity {

    private ActivityManualPaymentBinding binding;
    private User user;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityManualPaymentBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        user = UserPrefs.getUser(this);
        initViews();
        initClickListners();


    }

    private void initClickListners() {
        binding.btnShereSlip.setOnClickListener(v -> {
            String phoneNumber = "+923437335664";

            String name = user.getFullName();
            String email = user.getEmail();
            String id = user.getSeekoohId();
            // Replace "Hello, this is my message!" with your desired message
            String message = name + email + "Seekooh ID= "+id;

            // Create a WhatsApp intent
            Intent whatsappIntent = new Intent(Intent.ACTION_VIEW);
            whatsappIntent.setData(Uri.parse("http://api.whatsapp.com/send?phone=" + phoneNumber + "&text=" + message));

            // Check if WhatsApp is installed
            if (whatsappIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(whatsappIntent);
            } else {
                Utils.showToastLong(context, "Please install WhatsApp first on your mobile!");
            }
        });

        binding.imgCopyBank.setOnClickListener( v -> {
            String textToCopy = "03280108535699";

            // Get the ClipboardManager
            ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);

            // Create a ClipData object to hold the text
            ClipData clipData = ClipData.newPlainText("Copied Text", textToCopy);

            // Set the ClipData to the clipboard
            clipboardManager.setPrimaryClip(clipData);

            // Display a toast indicating that the text has been copied
            Utils.showToastLong(this, "Bank Account# coppied");
        });

        binding.imgCopyJazzcash.setOnClickListener( v -> {
            String textToCopy = "03437335664";

            // Get the ClipboardManager
            ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);

            // Create a ClipData object to hold the text
            ClipData clipData = ClipData.newPlainText("Copied Text", textToCopy);

            // Set the ClipData to the clipboard
            clipboardManager.setPrimaryClip(clipData);

            // Display a toast indicating that the text has been copied
            Utils.showToastLong(this, "JazzCash Account# coppied");
        });
    }

    private void initViews() {
        Role selectedRole = user.getAppSettings().getSelectedRole();
        switch (selectedRole.getName()) {
            case Constants.ROLE_TUTOR:
                binding.tvMainTitle.setText("Register as a Tutor");
                break;
            case Constants.ROLE_INSTITUTE:
                binding.tvMainTitle.setText("Register as a Institute");
                break;
        }
    }
}