package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;

public class VerificationFeeResponse {
    @SerializedName("fee")
    @Expose
    private BigDecimal fee;
    @SerializedName("currency")
    @Expose
    private String currency;

    public VerificationFeeResponse() {
    }

    public VerificationFeeResponse(BigDecimal fee, String currency) {
        this.fee = fee;
        this.currency = currency;
    }

    public BigDecimal getFee() {
        return fee;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}