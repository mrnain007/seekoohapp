package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SocialLoginRequest {
    @SerializedName("token")
    @Expose
    private String  token;
    @SerializedName("provider")
    @Expose
    private Provider provider;

    public SocialLoginRequest() {
    }

    private SocialLoginRequest(Builder builder) {
        setToken(builder.token);
        setProvider(builder.provider);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public enum Provider {
        GOOGLE, FACEBOOK
    }

    public static final class Builder {
        private String token;
        private Provider provider;

        private Builder() {
        }

        public Builder token(String token) {
            this.token = token;
            return this;
        }

        public Builder provider(Provider provider) {
            this.provider = provider;
            return this;
        }

        public SocialLoginRequest build() {
            return new SocialLoginRequest(this);
        }
    }
}
