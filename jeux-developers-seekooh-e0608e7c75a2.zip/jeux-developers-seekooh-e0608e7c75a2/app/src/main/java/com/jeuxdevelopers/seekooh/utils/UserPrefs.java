package com.jeuxdevelopers.seekooh.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jeuxdevelopers.seekooh.models.AppSettings;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.User;

import java.lang.reflect.Type;

public class UserPrefs {

    private static final String PREF_FILE_NAME = "UserPrefs";
    private static final String KEY_USER_JSON = "userJson";
    private static final Gson gson = new Gson();

    public static void saveUser(Context context, User user) {
        String userJson = gson.toJson(user);
        SharedPreferences.Editor editor = getEditor(context);
        editor.putString(KEY_USER_JSON, userJson);
        editor.apply();
    }

    public static User getUser(Context context) {
        String userJson = getSharedPreferences(context).getString(KEY_USER_JSON, null);
        if (TextUtils.isEmpty(userJson)) {
            return null;
        } else {
            Type userType = new TypeToken<User>() {
            }.getType();
            User user = gson.fromJson(userJson, userType);

            /*// Deserialize nested objects
            Type studentProfileType = new TypeToken<StudentProfile>() {}.getType();
            Type tutorProfileType = new TypeToken<TutorProfile>() {}.getType();
            Type instituteProfileType = new TypeToken<InstituteProfile>() {}.getType();

            if (user.getStudentProfile() != null) {
                String studentProfileJson = gson.toJson(user.getStudentProfile());
                StudentProfile studentProfile = gson.fromJson(studentProfileJson, studentProfileType);
                user.setStudentProfile(studentProfile);
            }

            if (user.getTutorProfile() != null) {
                String tutorProfileJson = gson.toJson(user.getTutorProfile());
                TutorProfile tutorProfile = gson.fromJson(tutorProfileJson, tutorProfileType);
                user.setTutorProfile(tutorProfile);
            }

            if (user.getInstituteProfile() != null) {
                String instituteProfileJson = gson.toJson(user.getInstituteProfile());
                InstituteProfile instituteProfile = gson.fromJson(instituteProfileJson, instituteProfileType);
                user.setInstituteProfile(instituteProfile);
            }*/

            return user;
        }
    }

    public static void setSelectedRole(Context context, Role role) throws RuntimeException {
        String userJson = getSharedPreferences(context).getString(KEY_USER_JSON, null);
        if (TextUtils.isEmpty(userJson)) {
            throw new RuntimeException("User data not found.");
        } else {
            Type userType = new TypeToken<User>() {
            }.getType();
            User user = gson.fromJson(userJson, userType);

            if (user == null) {
                throw new RuntimeException("User data not found.");
            }
            if (user.getAppSettings() == null) {
                user.setAppSettings(new AppSettings());
            }
            user.getAppSettings().setSelectedRole(role);
            saveUser(context, user);
        }
    }

    public static Role getSelectedRole(Context context) {
        String userJson = getSharedPreferences(context).getString(KEY_USER_JSON, null);
        if (TextUtils.isEmpty(userJson)) {
            return null;
        } else {
            Type userType = new TypeToken<User>() {
            }.getType();
            User user = gson.fromJson(userJson, userType);

            if (user == null || user.getAppSettings() == null) {
                return null;
            }
            return user.getAppSettings().getSelectedRole();
        }
    }

    public static boolean isLoggedIn(Context context) {
        return getUser(context) != null;
    }

    public static boolean isTutorProfileVerified(Context context) {
        User user = getUser(context);
        return user != null && user.getTutorProfile() != null && user.getTutorProfile().getVerified();
    }

    public static boolean isInstituteProfileVerified(Context context) {
        User user = getUser(context);
        return user != null && user.getInstituteProfile() != null && user.getInstituteProfile().getVerified();
    }

    public static void clearUser(Context context) {
        SharedPreferences.Editor editor = getEditor(context);
        editor.remove(KEY_USER_JSON);
        editor.apply();
    }

    private static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(PREF_FILE_NAME, Context.MODE_PRIVATE);
    }

    private static SharedPreferences.Editor getEditor(Context context) {
        SharedPreferences prefs = getSharedPreferences(context);
        return prefs.edit();
    }
}
