package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TutorDetails {
    @SerializedName("userId")
    @Expose
    private Integer userId;
    @SerializedName("seekoohId")
    @Expose
    private String seekoohId;
    @SerializedName("fullName")
    @Expose
    private String fullName;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("gender")
    @Expose
    private Gender gender;
    @SerializedName("tutorId")
    @Expose
    private Integer tutorId;
    @SerializedName("profileImageUrl")
    @Expose
    private String profileImageUrl;
    @SerializedName("profileVideoUrl")
    @Expose
    private String profileVideoUrl;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("reviewCount")
    @Expose
    private Integer reviewCount;
    @SerializedName("tagLine")
    @Expose
    private String tagLine;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("isVerified")
    @Expose
    private Boolean isVerified;
    @SerializedName("teachOnline")
    @Expose
    private Boolean teachOnline;
    @SerializedName("teachAtLocation")
    @Expose
    private Boolean teachAtLocation;
    @SerializedName("city")
    @Expose
    private City city;
    @SerializedName("address")
    @Expose
    private Address address;
    @SerializedName("qualifications")
    @Expose
    private List<Qualification> qualifications;
    @SerializedName("experiences")
    @Expose
    private List<Experience> experiences;
    @SerializedName("teachesSubjects")
    @Expose
    private List<Subject> teachesSubjects;
    @SerializedName("teachesClasses")
    @Expose
    private List<Grade> teachesClasses;
    @SerializedName("teachesBoardExams")
    @Expose
    private List<Board> teachesBoardExams;
    @SerializedName("timeSlots")
    @Expose
    private List<TutorTimeSlot> timeSlots;
    @SerializedName("availableDays")
    @Expose
    private List<DayOfWeek> availableDays;

    public TutorDetails() {
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getSeekoohId() {
        return seekoohId;
    }

    public void setSeekoohId(String seekoohId) {
        this.seekoohId = seekoohId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public Integer getTutorId() {
        return tutorId;
    }

    public void setTutorId(Integer tutorId) {
        this.tutorId = tutorId;
    }

    public String getProfileImageUrl() {
        return profileImageUrl;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

    public String getProfileVideoUrl() {
        return profileVideoUrl;
    }

    public void setProfileVideoUrl(String profileVideoUrl) {
        this.profileVideoUrl = profileVideoUrl;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Integer getReviewCount() {
        return reviewCount;
    }

    public void setReviewCount(Integer reviewCount) {
        this.reviewCount = reviewCount;
    }

    public String getTagLine() {
        return tagLine;
    }

    public void setTagLine(String tagLine) {
        this.tagLine = tagLine;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getVerified() {
        return isVerified;
    }

    public void setVerified(Boolean verified) {
        isVerified = verified;
    }

    public Boolean getTeachOnline() {
        return teachOnline;
    }

    public void setTeachOnline(Boolean teachOnline) {
        this.teachOnline = teachOnline;
    }

    public Boolean getTeachAtLocation() {
        return teachAtLocation;
    }

    public void setTeachAtLocation(Boolean teachAtLocation) {
        this.teachAtLocation = teachAtLocation;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public List<Qualification> getQualifications() {
        return qualifications;
    }

    public void setQualifications(List<Qualification> qualifications) {
        this.qualifications = qualifications;
    }

    public List<Experience> getExperiences() {
        return experiences;
    }

    public void setExperiences(List<Experience> experiences) {
        this.experiences = experiences;
    }

    public List<Subject> getTeachesSubjects() {
        return teachesSubjects;
    }

    public void setTeachesSubjects(List<Subject> teachesSubjects) {
        this.teachesSubjects = teachesSubjects;
    }

    public List<Grade> getTeachesClasses() {
        return teachesClasses;
    }

    public void setTeachesClasses(List<Grade> teachesClasses) {
        this.teachesClasses = teachesClasses;
    }

    public List<Board> getTeachesBoardExams() {
        return teachesBoardExams;
    }

    public void setTeachesBoardExams(List<Board> teachesBoardExams) {
        this.teachesBoardExams = teachesBoardExams;
    }

    public List<TutorTimeSlot> getTimeSlots() {
        return timeSlots;
    }

    public void setTimeSlots(List<TutorTimeSlot> timeSlots) {
        this.timeSlots = timeSlots;
    }

    public List<DayOfWeek> getAvailableDays() {
        return availableDays;
    }

    public void setAvailableDays(List<DayOfWeek> availableDays) {
        this.availableDays = availableDays;
    }

    @Override
    public String toString() {
        return "TutorDetails{" +
                "userId=" + userId +
                ", seekoohId='" + seekoohId + '\'' +
                ", fullName='" + fullName + '\'' +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", gender=" + gender +
                ", tutorId=" + tutorId +
                ", profileImageUrl='" + profileImageUrl + '\'' +
                ", profileVideoUrl='" + profileVideoUrl + '\'' +
                ", rating=" + rating +
                ", reviewCount=" + reviewCount +
                ", tagLine='" + tagLine + '\'' +
                ", description='" + description + '\'' +
                ", isVerified=" + isVerified +
                ", teachOnline=" + teachOnline +
                ", teachAtLocation=" + teachAtLocation +
                ", city=" + city +
                ", address=" + address +
                ", qualifications=" + qualifications +
                ", experiences=" + experiences +
                ", teachesSubjects=" + teachesSubjects +
                ", teachesClasses=" + teachesClasses +
                ", teachesBoardExams=" + teachesBoardExams +
                ", timeSlots=" + timeSlots +
                ", availableDays=" + availableDays +
                '}';
    }
}
