package com.jeuxdevelopers.seekooh.ui.tutor.fragments.courses;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.google.android.gms.common.util.CollectionUtils;
import com.jeuxdevelopers.seekooh.databinding.FragmentCreateCourseBinding;
import com.jeuxdevelopers.seekooh.databinding.FragmentEditCourseBinding;
import com.jeuxdevelopers.seekooh.models.Course;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.dto.CreateCourseRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditCourseRequest;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.MultiChoiceDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions.EditTuitionFragmentArgs;
import com.jeuxdevelopers.seekooh.ui.shared.views.MultiSelectionView;
import com.jeuxdevelopers.seekooh.ui.tutor.fragments.courses.CreateCourseViewModel;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.time.DayOfWeek;
import java.time.format.TextStyle;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class EditCourseFragment extends Fragment {
    private static final String TAG = "CreateCourseFragment";

    private int courseId = -1;

    private int currentStepNumber = 1;
    private int lastStepNumber = 4;
    private boolean isTextWatcherEnabled = false;

    private FragmentEditCourseBinding binding;
    private EditCourseViewModel viewModel;
    private NavController navController;
    private OnBackPressedCallback callback;

    private MultiSelectionView.Data<Subject> subjectData;
    private MultiChoiceDialog<DayOfWeek> daysMultiChoiceDialog;

    // Timings
    private int startTimeInMinutes = -1;
    private int endTimeInMinutes = -1;

    // Dates
    private long startDateInMillis = -1;
    private long endDateInMillis = -1;
    private WaitingDialog waitingDialog;

    private Course data;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (currentStepNumber == 1) {
                    setEnabled(false);
                    requireActivity().onBackPressed();
                } else {
                    gotoNextStep(--currentStepNumber);
                }
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentEditCourseBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);
        viewModel = new ViewModelProvider(this).get(EditCourseViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        initData();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext());
        initDaysDialog();
        initStepView();
        initMsvListeners();
    }

    private void initMsvListeners() {
        binding.subjectsMsv.setListener(() -> {
            if (isTextWatcherEnabled) {
                validateInputs();
            }
            return false;
        });
    }

    private void initData() {
        EditCourseFragmentArgs args = EditCourseFragmentArgs.fromBundle(getArguments());
        courseId = args.getCourseId();
        if (courseId == -1) {
            waitingDialog.showError("Error parsing tuitionId!");
            return;
        }
        viewModel.getCourseDetailsById(courseId);
    }

    private void initDaysDialog() {
        List<DayOfWeek> daysOfWeek = Arrays.asList(DayOfWeek.values());
        MultiChoiceDialog.Options options = MultiChoiceDialog.Options.builder()
                .sortList(false)
                .build();
        daysMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                options,
                daysOfWeek,
                dayOfWeek -> dayOfWeek.getDisplayName(TextStyle.FULL, Locale.getDefault()),
                selectedItemNames -> {
                    binding.daysAcTv.setText(selectedItemNames);
                    if (isTextWatcherEnabled) {
                        validateInputs();
                    }
                });
    }

    private void initClickListeners() {
        initTextWatcher();
        binding.timingFromTl.getEditText().setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                    (view, selectedHour, selectedMinute) -> {
                        String formattedTime = Utils.getFormattedTime(selectedHour, selectedMinute);
                        binding.timingFromTl.getEditText().setText(formattedTime);
                        startTimeInMinutes = selectedHour * 60 + selectedMinute;
                        if (isTextWatcherEnabled) {
                            validateInputs();
                        }
                    }, hour, minute, false);
            timePickerDialog.show();
        });
        binding.timingToTl.getEditText().setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                    (view, selectedHour, selectedMinute) -> {
                        String formattedTime = Utils.getFormattedTime(selectedHour, selectedMinute);
                        binding.timingToTl.getEditText().setText(formattedTime);
                        endTimeInMinutes = selectedHour * 60 + selectedMinute;
                        if (isTextWatcherEnabled) {
                            validateInputs();
                        }
                    }, hour, minute, false);
            timePickerDialog.show();
        });
        binding.startDateTl.getEditText().setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(),
                    (view, selectedYear, selectedMonth, selectedDayOfMonth) -> {
                        calendar.set(selectedYear, selectedMonth, selectedDayOfMonth, 0, 0, 0);
                        calendar.set(Calendar.MILLISECOND, 0);
                        startDateInMillis = calendar.getTimeInMillis();
                        binding.startDateTl.getEditText().setText(Utils.getFormattedDate(calendar.getTimeInMillis()));
                        if (isTextWatcherEnabled) {
                            validateInputs();
                        }
                    }, year, month, dayOfMonth);
            datePickerDialog.show();
        });
        binding.endDateTl.getEditText().setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(),
                    (view, selectedYear, selectedMonth, selectedDayOfMonth) -> {
                        calendar.set(selectedYear, selectedMonth, selectedDayOfMonth, 0, 0, 0);
                        calendar.set(Calendar.MILLISECOND, 0);
                        endDateInMillis = calendar.getTimeInMillis();
                        binding.endDateTl.getEditText().setText(Utils.getFormattedDate(calendar.getTimeInMillis()));
                        if (isTextWatcherEnabled) {
                            validateInputs();
                        }
                    }, year, month, dayOfMonth);
            datePickerDialog.show();
        });
        binding.btnBack.setOnClickListener(v -> {
            requireActivity().onBackPressed();
        });
        binding.daysAcTv.setOnClickListener(v -> {
            daysMultiChoiceDialog.show("Select course days?");
        });

        binding.nextBtn.setOnClickListener(v -> {
            if (currentStepNumber < lastStepNumber) {
                if (validateInputs()) {
                    isTextWatcherEnabled = false;
                    gotoNextStep(++currentStepNumber);
                }
            } else {
                if (!validateInputs()) {
                    return;
                }

                String title = binding.courseTitleTl.getEditText().getText().toString().trim();
                String description = binding.courseDescriptionTl.getEditText().getText().toString().trim();
                List<Subject> selectedSubjects = subjectData.getSelectedItemsList();
                String learningGoals = binding.learningGoalsTl.getEditText().getText().toString().trim();
                List<String> minRequirements = Arrays.asList(binding.minReqTl.getEditText().getText().toString().trim().split("\n"));
                String targetAudience = binding.targetAudienceTl.getEditText().getText().toString().trim();
                List<DayOfWeek> selectedDays = daysMultiChoiceDialog.getSelectedItemsList();


                EditCourseRequest editCourseRequest = EditCourseRequest.builder()
                        .title(title)
                        .description(description)
                        .subjectIds(Utils.toIdList(selectedSubjects, Subject::getId))
                        .learningGoals(learningGoals)
                        .minRequirements(minRequirements)
                        .targetAudience(targetAudience)
                        .dayValues(Utils.toIdList(selectedDays, DayOfWeek::getValue))
                        .startMinutes(startTimeInMinutes)
                        .endMinutes(endTimeInMinutes)
                        .startDate(startDateInMillis)
                        .endDate(endDateInMillis)
                        .isOnline(binding.onlineCb.isChecked())
                        .isInPerson(binding.inPersonCb.isChecked())
                        .build();

                viewModel.editCourse(courseId, editCourseRequest);
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void initObservers() {
        viewModel.getSubjectsLiveData.observe(getViewLifecycleOwner(), getSubjectsResponse -> {
            switch (getSubjectsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSubjectsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Subject> subjectsList = getSubjectsResponse.getData();
                    subjectData = new MultiSelectionView.Data<>(subjectsList, Subject::getName, data.getSubjects(), Subject::getId);
                    binding.subjectsMsv.setData("Select subjects?", subjectData);
                    isInitialDataLoaded();
                    break;
            }
        });

        viewModel.getCourseDetailsLiveData.observe(getViewLifecycleOwner(), getCourseDetailsResponse -> {
            switch (getCourseDetailsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCourseDetailsResponse.getMessage());
                    waitingDialog.dismiss();
                    break;
                case LOADING:
                    waitingDialog.show(getCourseDetailsResponse.getMessage());
                    break;
                case SUCCESS:
                    Utils.showToast(requireContext(), getCourseDetailsResponse.getMessage());
                    data = getCourseDetailsResponse.getData();
                    waitingDialog.dismiss();
                    fetchData();
                    setCourseData();
                    break;
            }
        });

        viewModel.editCourseLiveData.observe(getViewLifecycleOwner(), editCourseResponse -> {
            switch (editCourseResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), editCourseResponse.getMessage());
                    waitingDialog.dismiss();
                    break;
                case LOADING:
                    waitingDialog.show(editCourseResponse.getMessage());
                    break;
                case SUCCESS:
                    Utils.showToast(requireContext(), editCourseResponse.getMessage());
                    waitingDialog.dismiss();
                    navController.popBackStack();
                    break;
            }
        });
    }

    private void setCourseData() {
        if (Utils.isDataNull(requireContext(), data)) {
            return;
        }

        binding.courseTitleTl.getEditText().setText(data.getTitle());
        binding.courseDescriptionTl.getEditText().setText(data.getDescription());
        binding.learningGoalsTl.getEditText().setText(data.getLearningGoals());
        binding.minReqTl.getEditText().setText(String.join("\n", data.getMinRequirements()));
        binding.targetAudienceTl.getEditText().setText(data.getTargetAudience());
        binding.startDateTl.getEditText().setText(Utils.getFormattedDate(data.getStartDate()));
        startDateInMillis = data.getStartDate();
        binding.endDateTl.getEditText().setText(Utils.getFormattedDate(data.getEndDate()));
        endDateInMillis = data.getEndDate();
        daysMultiChoiceDialog.setSelectedItemsList(Utils.toDayOfWeekList(data.getDays()), DayOfWeek::getValue);
        binding.daysAcTv.setText(String.join(", ", Utils.toStringList(data.getDays(), com.jeuxdevelopers.seekooh.models.DayOfWeek::getName)));
        binding.timingFromTl.getEditText().setText(Utils.getFormattedTime(data.getStartMinutes()));
        startTimeInMinutes = data.getStartMinutes();
        binding.timingToTl.getEditText().setText(Utils.getFormattedTime(data.getEndMinutes()));
        endTimeInMinutes = data.getEndMinutes();
        binding.onlineCb.setChecked(data.getOnline());
        binding.inPersonCb.setChecked(data.getInPerson());
    }

    private void isInitialDataLoaded() {
        if (subjectData != null) {
            waitingDialog.dismiss();
        }
    }

    private void fetchData() {
        viewModel.getSubjects();
    }

    private void gotoNextStep(int stepNumber) {
        switch (stepNumber) {
            case 1:
                binding.aboutLayoutLl.setVisibility(View.VISIBLE);
                binding.goalsLayoutLl.setVisibility(View.GONE);
                binding.durationLayoutLl.setVisibility(View.GONE);
                binding.locationLayoutLl.setVisibility(View.GONE);
                binding.stepView.setActiveStep(1);
                break;
            case 2:
                binding.aboutLayoutLl.setVisibility(View.GONE);
                binding.goalsLayoutLl.setVisibility(View.VISIBLE);
                binding.durationLayoutLl.setVisibility(View.GONE);
                binding.locationLayoutLl.setVisibility(View.GONE);
                binding.stepView.setActiveStep(2);
                break;
            case 3:
                binding.aboutLayoutLl.setVisibility(View.GONE);
                binding.goalsLayoutLl.setVisibility(View.GONE);
                binding.durationLayoutLl.setVisibility(View.VISIBLE);
                binding.locationLayoutLl.setVisibility(View.GONE);
                binding.stepView.setActiveStep(3);
                break;
            case 4:
                binding.aboutLayoutLl.setVisibility(View.GONE);
                binding.goalsLayoutLl.setVisibility(View.GONE);
                binding.durationLayoutLl.setVisibility(View.GONE);
                binding.locationLayoutLl.setVisibility(View.VISIBLE);
                binding.stepView.setActiveStep(4);
                break;
        }

        if (stepNumber == lastStepNumber) {
            binding.nextBtn.setText("Submit");
        } else {
            binding.nextBtn.setText("Next");
        }
    }

    private void initStepView() {
        binding.stepView.setColumnCount(2);
        binding.stepView.setSteps("About", "Goals", "Duration", "Location");
        binding.stepView.setActiveStep(1);
    }

    private void initTextWatcher() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateInputs();
                }
            }
        };

        binding.courseTitleTl.getEditText().addTextChangedListener(textWatcher);
        binding.courseDescriptionTl.getEditText().addTextChangedListener(textWatcher);
        binding.learningGoalsTl.getEditText().addTextChangedListener(textWatcher);
        binding.minReqTl.getEditText().addTextChangedListener(textWatcher);
        binding.targetAudienceTl.getEditText().addTextChangedListener(textWatcher);
        binding.startDateTl.getEditText().addTextChangedListener(textWatcher);
        binding.endDateTl.getEditText().addTextChangedListener(textWatcher);
        binding.timingFromTl.getEditText().addTextChangedListener(textWatcher);
        binding.timingToTl.getEditText().addTextChangedListener(textWatcher);
    }

    private boolean validateInputs() {
        isTextWatcherEnabled = true;
        boolean isValid = true;
        switch (currentStepNumber) {
            case 1:
                String title = binding.courseTitleTl.getEditText().getText().toString().trim();
                String description = binding.courseDescriptionTl.getEditText().getText().toString().trim();
                if (binding.subjectsMsv.getData().getSelectedItemsList().isEmpty()) {
                    binding.subjectsMsv.setError("Please select subjects?");
                    isValid = false;
                } else {
                    binding.subjectsMsv.setError(null);
                }
                if (TextUtils.isEmpty(title)) {
                    binding.courseTitleTl.setError("Please enter course title?");
                    isValid = false;
                } else {
                    binding.courseTitleTl.setError(null);
                }
                if (TextUtils.isEmpty(description)) {
                    binding.courseDescriptionTl.setError("Please enter course description?");
                    isValid = false;
                } else {
                    binding.courseDescriptionTl.setError(null);
                }
                break;
            case 2:
                String learningGoals = binding.learningGoalsTl.getEditText().getText().toString().trim();
                String minRequirements = binding.minReqTl.getEditText().getText().toString().trim();
                String targetAudience = binding.targetAudienceTl.getEditText().getText().toString().trim();

                if (TextUtils.isEmpty(learningGoals)) {
                    binding.learningGoalsTl.setError("Please enter learning goals?");
                    isValid = false;
                } else {
                    binding.learningGoalsTl.setError(null);
                }
                if (TextUtils.isEmpty(minRequirements)) {
                    binding.minReqTl.setError("Please enter minimum requirements?");
                    isValid = false;
                } else {
                    binding.minReqTl.setError(null);
                }
                if (TextUtils.isEmpty(targetAudience)) {
                    binding.targetAudienceTl.setError("Please enter target audience?");
                    isValid = false;
                } else {
                    binding.targetAudienceTl.setError(null);
                }
                break;
            case 3:
                List<DayOfWeek> selectedDays = daysMultiChoiceDialog.getSelectedItemsList();

                if (startDateInMillis == -1) {
                    binding.startDateTl.setError("Select course start date?");
                    isValid = false;
                } else {
                    binding.startDateTl.setError(null);
                }
                if (endDateInMillis == -1) {
                    binding.endDateTl.setError("Select course end date?");
                    isValid = false;
                } else {
                    binding.endDateTl.setError(null);
                }
                if (CollectionUtils.isEmpty(selectedDays)) {
                    binding.daysTl.setError("What days will you be teaching on?");
                    isValid = false;
                } else {
                    binding.daysTl.setError(null);
                }
                if (startTimeInMinutes == -1) {
                    binding.timingFromTl.setError("Starting time?");
                    isValid = false;
                } else {
                    binding.timingFromTl.setError(null);
                }
                if (endTimeInMinutes == -1) {
                    binding.timingToTl.setError("Ending time?");
                    isValid = false;
                } else {
                    binding.timingToTl.setError(null);
                }
                break;
            case 4:
                break;
            default:
                isValid = false;
                break;
        }
        return isValid;
    }
}