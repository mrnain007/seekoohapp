package com.jeuxdevelopers.seekooh.ui.tutor.fragments.registration;

import static android.app.Activity.RESULT_OK;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInStatusCodes;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.FragmentTutorRegistrationBinding;
import com.jeuxdevelopers.seekooh.models.Address;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Gender;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.dto.TutorRegistrationRequest;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;
import com.jeuxdevelopers.seekooh.ui.tutor.activities.address.MapsActivity;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TutorRegistrationFragment extends Fragment {
    private static final String TAG = "TutorRegistrationFragme";
    private final int PROFILE_IMAGE_REQUEST_CODE = 1000;
    private static final int RC_SIGN_IN = 1001;
    private FragmentTutorRegistrationBinding binding;
    private NavController navController;

    // Fields
    private boolean isTextWatcherEnabled = false;
    private Integer selectedGender = 1;

    private ArrayAdapter<String> citiesArrayAdapter;
    private List<City> citiesList = new ArrayList<>();
    private City selectedCity;
    private TutorRegistrationViewModel viewModel;

    private GoogleSignInOptions googleSignInOptions;
    private GoogleSignInClient googleSignInClient;
    private CallbackManager fbCallbackManager;
    private String facebookId;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentTutorRegistrationBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        viewModel = new ViewModelProvider(requireActivity()).get(TutorRegistrationViewModel.class);
        initClickListeners();
        initObservers();
        initSocialLogins();
        fetchData();
        checkAuthMode();
    }

    private void checkAuthMode() {
        FragmentActivity fragmentActivity = requireActivity();
        if (fragmentActivity instanceof AuthActivity) {
            AuthActivity authActivity = (AuthActivity) fragmentActivity;
            if (authActivity.mode == AuthActivity.Mode.BECOME_TUTOR) {
                User user = UserPrefs.getUser(requireContext());
                if (user == null || user.getAccessToken() == null) {
                    return;
                }

                if (!TextUtils.isEmpty(user.getFullName())) {
                    binding.nameTl.setEnabled(false);
                    binding.nameTl.getEditText().setText(user.getFullName());
                }
                if (user.getGender() != null) {
                    Gender gender = user.getGender();
                    if (gender.getName().equalsIgnoreCase("male")) {
                        binding.genderRg.check(binding.radioMale.getId());
                    } else {
                        binding.genderRg.check(binding.radioFemale.getId());
                    }
                    binding.radioMale.setEnabled(false);
                    binding.radioFemale.setEnabled(false);
                }
                binding.emailTl.setEnabled(false);
                binding.emailTl.getEditText().setText(user.getEmail());
                binding.passwordTl.setVisibility(View.GONE);
                binding.passwordLabel.setVisibility(View.GONE);
                binding.confirmedPasswordTl.setVisibility(View.GONE);
                binding.confirmPasswordLabel.setVisibility(View.GONE);
                binding.passwordTl.getEditText().setText(user.getEmail());
                binding.confirmedPasswordTl.getEditText().setText(user.getEmail());
                binding.phoneTl.setEnabled(false);
                binding.phoneTl.getEditText().setText(user.getPhoneNumber());
            }
        }
    }

    private void initViews(@NonNull View view) {
        navController = Navigation.findNavController(view);
    }

    private void initObservers() {
        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    citiesList = getCitiesResponse.getData();
                    setCitiesDropDown();
                    break;
            }
        });
    }

    private void fetchData() {
        viewModel.getCities();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PROFILE_IMAGE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                viewModel.profileImageUri = data.getData();
                binding.profileImg.setImageURI(viewModel.profileImageUri);
            } else if (resultCode == ImagePicker.RESULT_ERROR) {
                Utils.showToast(requireContext(), ImagePicker.getError(data));
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        }
        if (requestCode == 786 && resultCode == RESULT_OK && data != null) {
            String location = data.getStringExtra("LOCATION");
            binding.addressTl.getEditText().setText( location );
        }
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleGoogleSignInResult(task);
        }
    }

    private void initClickListeners() {
        initTextWatcher();
        binding.genderRg.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == binding.radioMale.getId()) {
                selectedGender = 1;
            } else if (checkedId == binding.radioFemale.getId()) {
                selectedGender = 2;
            }
        });
        binding.pickImgBtn.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(1024).maxResultSize(1920, 1920).crop(1, 1).start(PROFILE_IMAGE_REQUEST_CODE);
        });

        binding.addressTl.getEditText().setOnClickListener(view -> startActivityForResult(new Intent(getContext(), MapsActivity.class), 786) );
        binding.addressTl.getEditText().setOnFocusChangeListener((view, b) -> {
            if( b ){
                startActivityForResult(new Intent(getContext(), MapsActivity.class), 786);
            }
        });

        binding.nextBtn.setOnClickListener(v -> {
            if (validateUserInput()) {
                if (viewModel.profileImageUri == null) {
                    Utils.showToast(requireContext(), "Please pick a profile image.");
                    return;
                }
                String name = binding.nameTl.getEditText().getText().toString().trim();
                String phone = binding.phoneTl.getEditText().getText().toString().trim();
                String email = binding.emailTl.getEditText().getText().toString().trim();
                Integer cityId = selectedCity.getId();
                String address = binding.addressTl.getEditText().getText().toString().trim();
                Integer genderId = selectedGender;
                String password = binding.passwordTl.getEditText().getText().toString().trim();
                String tagLine = binding.tagLineTl.getEditText().getText().toString().trim();

                TutorRegistrationRequest.TutorProfile tutorProfile = TutorRegistrationRequest.TutorProfile.builder()
                        .tagLine(tagLine)
                        .cityId(cityId)
                        .address(new Address(null, null, null, address, null))
                        .build();
                viewModel.tutorRegistrationRequest = TutorRegistrationRequest.builder()
                        .fullName(name)
                        .phoneNumber(phone)
                        .email(email)
                        .genderId(genderId)
                        .password(password)
                        .tutorProfile(tutorProfile)
                        .build();
                navController.navigate(TutorRegistrationFragmentDirections
                        .actionTutorRegistrationFragmentToTutorQualificationFragment());
            }
        });

        binding.googleBtn.setOnClickListener(v -> {
            Intent signInIntent = googleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, RC_SIGN_IN);
        });
        binding.facebookBtn.setOnClickListener(v -> {
            LoginManager.getInstance().logInWithReadPermissions(this, fbCallbackManager, Arrays.asList("email", "public_profile"));
        });
    }
    private void setCitiesDropDown() {
        List<String> citiesStringList = new ArrayList<>();
        for (City city : citiesList) {
            citiesStringList.add(city.getName());
        }
        citiesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, citiesStringList);
        binding.citiesAcTv.setAdapter(citiesArrayAdapter);
        binding.citiesAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = citiesList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void initTextWatcher() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateUserInput();
                }
            }
        };

        binding.nameTl.getEditText().addTextChangedListener(textWatcher);
        binding.phoneTl.getEditText().addTextChangedListener(textWatcher);
        binding.emailTl.getEditText().addTextChangedListener(textWatcher);
        binding.passwordTl.getEditText().addTextChangedListener(textWatcher);
        binding.confirmedPasswordTl.getEditText().addTextChangedListener(textWatcher);
        binding.addressTl.getEditText().addTextChangedListener(textWatcher);
        binding.tagLineTl.getEditText().addTextChangedListener(textWatcher);
    }

    private boolean validateUserInput() {
        isTextWatcherEnabled = true;
        boolean isValid = true;
        String name = binding.nameTl.getEditText().getText().toString().trim();
        String phone = binding.phoneTl.getEditText().getText().toString().trim();
        String email = binding.emailTl.getEditText().getText().toString().trim();
        String address = binding.addressTl.getEditText().getText().toString().trim();
        String password = binding.passwordTl.getEditText().getText().toString().trim();
        String confirmedPassword = binding.confirmedPasswordTl.getEditText().getText().toString().trim();
        String tagLine = binding.tagLineTl.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            binding.nameTl.setError("Please enter your name?");
            isValid = false;
        } else {
            binding.nameTl.setError(null);
        }

        if (TextUtils.isEmpty(phone)) {
            binding.phoneTl.setError("Please enter your phone number?");
            isValid = false;
        } else if (!Utils.validatePhoneNumber(phone)) {
            binding.phoneTl.setError("Please enter a valid phone number?");
            isValid = false;

        } else {
            binding.phoneTl.setError(null);
        }

        if (TextUtils.isEmpty(email)) {
            binding.emailTl.setError("Please enter your email address?");
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.emailTl.setError("Please enter a valid email address?");
            isValid = false;
        } else {
            binding.emailTl.setError(null);
        }

        if (TextUtils.isEmpty(address)) {
            binding.addressTl.setError("Please enter your address?");
            isValid = false;
        } else {
            binding.addressTl.setError(null);
        }

        /*if (selectedBoard == null) {
            binding.boardExamTl.setError("Please select your board/exam?");
            isValid = false;
        } else {
            binding.boardExamTl.setError(null);
        }*/

        if (selectedCity == null) {
            binding.citiesTl.setError("Please select your city?");
            isValid = false;
        } else {
            binding.citiesTl.setError(null);
        }

        /*if (selectedGrade == null) {
            binding.gradesTl.setError("Please select your grade?");
            isValid = false;
        } else {
            binding.gradesTl.setError(null);
        }*/

        if (TextUtils.isEmpty(password)) {
            binding.passwordTl.setError("Please set password for your account");
            isValid = false;
        } else if (password.length() < 8) {
            binding.passwordTl.setError("Password length should be at least 8 character");
            isValid = false;
        } else {
            binding.passwordTl.setError(null);
        }

        if (TextUtils.isEmpty(confirmedPassword)) {
            binding.confirmedPasswordTl.setError("Please confirm your password?");
            isValid = false;
        } else if (!confirmedPassword.equals(password)) {
            binding.confirmedPasswordTl.setError("Password mismatch");
            isValid = false;
        } else {
            binding.confirmedPasswordTl.setError(null);
        }

        if (TextUtils.isEmpty(tagLine)) {
            binding.tagLineTl.setError("Please enter tag line for your profile.");
            isValid = false;
        } else {
            binding.tagLineTl.setError(null);
        }

        return isValid;
    }

    private void initSocialLogins() {
        initGoogleLogin();
        initFbLogin();
    }

    private void initFbLogin() {
        disconnectFromFacebook();
        fbCallbackManager = CallbackManager.Factory.create();
        LoginManager.getInstance().registerCallback(fbCallbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                // Get the Access Token
                AccessToken accessToken = loginResult.getAccessToken();
                String token = accessToken.getToken();

                // Get the User ID
                facebookId = accessToken.getUserId();

                // Get the User's Profile
                getFbUserProfile(accessToken);
            }

            @Override
            public void onCancel() {
                // Handle cancel
            }

            @Override
            public void onError(@NonNull FacebookException error) {
                // Handle error
                Log.e(TAG, "initFbLogin onError: " + error.getMessage());
                Utils.showToast(requireContext(), error.getMessage());
            }
        });
    }


    private void getFbUserProfile(AccessToken accessToken) {
        GraphRequest request = GraphRequest.newMeRequest(accessToken, (object, response) -> {
            // Parse the User's Profile information
            if (object != null) {
                try {
                    String name = object.getString("name");
                    String email = object.getString("email");
                    String profilePicUrl = object.getJSONObject("picture").getJSONObject("data").getString("url");

                    binding.nameTl.getEditText().setText(name);
                    binding.emailTl.setEnabled(false);
                    binding.emailTl.getEditText().setText(email);
                    Glide.with(requireContext())
                            .asBitmap()
                            .load(profilePicUrl)
                            .placeholder(R.drawable.profile_image_placeholder)
                            .into(new CustomTarget<Bitmap>() {
                                @Override
                                public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                    viewModel.profileImageUri = Utils.bitmapToUri(requireContext(), resource);
                                    binding.profileImg.setImageURI(viewModel.profileImageUri);
                                }

                                @Override
                                public void onLoadCleared(@Nullable Drawable placeholder) {
                                }
                            });

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e(TAG, "onSuccess: Facebook login response null.");
            }
        });

        // Execute the Graph Request
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,email,picture.type(large)");
        request.setParameters(parameters);
        request.executeAsync();
    }

    public void disconnectFromFacebook() {
        if (AccessToken.getCurrentAccessToken() == null) {
            return; // already logged out
        }
        new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/permissions/", null,
                HttpMethod.DELETE, graphResponse -> LoginManager.getInstance().logOut()).executeAsync();
    }

    private void initGoogleLogin() {
        googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()
                .build();
        googleSignInClient = GoogleSignIn.getClient(requireContext(), googleSignInOptions);
        googleSignInClient.signOut();
    }

    private void handleGoogleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            if (account.getPhotoUrl() != null) {
                Glide.with(requireContext())
                        .asBitmap()
                        .load(account.getPhotoUrl())
                        .placeholder(R.drawable.profile_image_placeholder)
                        .into(new CustomTarget<Bitmap>() {
                            @Override
                            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                viewModel.profileImageUri = Utils.bitmapToUri(requireContext(), resource);
                                binding.profileImg.setImageURI(viewModel.profileImageUri);
                            }

                            @Override
                            public void onLoadCleared(@Nullable Drawable placeholder) {
                            }
                        });
            }
            if (account.getEmail() != null) {
                binding.emailTl.setEnabled(false);
                binding.emailTl.getEditText().setText(account.getEmail());
            }
            if (account.getDisplayName() != null) {
                binding.nameTl.getEditText().setText(account.getDisplayName());
            }
            facebookId = null;
            Log.e(TAG, "handleGoogleSignInResult: ");
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
            int statusCode = e.getStatusCode();

            switch (statusCode) {
                case GoogleSignInStatusCodes.SIGN_IN_FAILED:
                    Utils.showToast(requireContext(), "Sign-in failed. Please try again later.");
                    break;
                case GoogleSignInStatusCodes.NETWORK_ERROR:
                    Utils.showToast(requireContext(), "Network error. Please check your internet connection and try again.");
                    break;
                default:
                    Utils.showToast(requireContext(), "Sign-in failed. Please try again later. " + statusCode);
                    break;
            }
        }
    }
}