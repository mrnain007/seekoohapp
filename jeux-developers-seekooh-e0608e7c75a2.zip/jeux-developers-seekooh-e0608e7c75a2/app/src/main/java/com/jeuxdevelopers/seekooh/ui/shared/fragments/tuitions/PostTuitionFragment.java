package com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions;

import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.google.android.gms.common.util.CollectionUtils;
import com.jeuxdevelopers.seekooh.databinding.FragmentPostTuitionBinding;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.SalaryType;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.dto.CreateTuitionRequest;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.MultiChoiceDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.views.MultiSelectionView;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.time.DayOfWeek;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class PostTuitionFragment extends Fragment {
    private static final String TAG = "PostTuitionFragment";

    private FragmentPostTuitionBinding binding;
    private NavController navController;
    private OnBackPressedCallback callback;
    private int currentStepNumber = 1;
    private int lastStepNumber = 4;
    private boolean isTextWatcherEnabled = false;
    private PostTuitionViewModel viewModel;
    private WaitingDialog waitingDialog;
    private MultiChoiceDialog<DayOfWeek> daysMultiChoiceDialog;

    // Gender
    private Integer selectedGender;

    // Timings
    private int startTimeInMinutes = -1;
    private int endTimeInMinutes = -1;

    // Drop downs
    private ArrayAdapter<String> citiesArrayAdapter;
    private List<City> citiesList = new ArrayList<>();
    private City selectedCity;

    private ArrayAdapter<String> salaryTypesArrayAdapter;
    private List<SalaryType> salaryTypesList = new ArrayList<>();
    private SalaryType selectedSalaryType;

    private MultiSelectionView.Data<Subject> subjectData;
    private MultiSelectionView.Data<Grade> gradeData;
    private MultiSelectionView.Data<Board> boardData;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (currentStepNumber == 1) {
                    setEnabled(false);
                    requireActivity().onBackPressed();
                } else {
                    gotoNextStep(--currentStepNumber);
                }
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentPostTuitionBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);
        viewModel = new ViewModelProvider(this).get(PostTuitionViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        fetchData();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext());
        initDaysDialog();
        initStepView();
        initMsvData();
        initAsvListeners();
        initMsvListeners();
    }

    private void initMsvListeners() {
        binding.subjectsMsv.setListener(() -> {
            if (isTextWatcherEnabled) {
                validateInputs();
            }
            return false;
        });
        binding.gradesMsv.setListener(() -> {
            if (isTextWatcherEnabled) {
                validateInputs();
            }
            return false;
        });
        binding.boardsMsv.setListener(() -> {
            if (isTextWatcherEnabled) {
                validateInputs();
            }
            return false;
        });
    }

    private void initMsvData() {
        subjectData = new MultiSelectionView.Data<>(new ArrayList<>(), Subject::getName);
        gradeData = new MultiSelectionView.Data<>(new ArrayList<>(), Grade::getName);
        boardData = new MultiSelectionView.Data<>(new ArrayList<>(), Board::getName);
    }

    @SuppressLint("SetTextI18n")
    private void initAsvListeners() {
        binding.subjectsAsv.setListener(fieldValue -> binding.subjectsMsv.addSuggestedItem(fieldValue));
        binding.gradesAsv.setListener(fieldValue -> binding.gradesMsv.addSuggestedItem(fieldValue));
    }

    private void initDaysDialog() {
        List<DayOfWeek> daysOfWeek = Arrays.asList(DayOfWeek.values());
        MultiChoiceDialog.Options options = MultiChoiceDialog.Options.builder()
                .sortList(false)
                .build();
        daysMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                options,
                daysOfWeek,
                dayOfWeek -> dayOfWeek.getDisplayName(TextStyle.FULL, Locale.getDefault()),
                selectedItemNames -> {
                    binding.daysAcTv.setText(selectedItemNames);
                    if (isTextWatcherEnabled) {
                        validateInputs();
                    }
                });
    }

    private void initClickListeners() {
        initTextWatcher();
        binding.genderRg.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == binding.radioMale.getId()) {
                selectedGender = 1;
            } else if (checkedId == binding.radioFemale.getId()) {
                selectedGender = 2;
            } else if (checkedId == binding.radioDoesNotMatter.getId()) {
                selectedGender = null;
            }
        });
        binding.btnBack.setOnClickListener(v -> requireActivity().onBackPressed());
        binding.timingFromTl.getEditText().setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                    (view, selectedHour, selectedMinute) -> {
                        String formattedTime = Utils.getFormattedTime(selectedHour, selectedMinute);
                        binding.timingFromTl.getEditText().setText(formattedTime);
                        startTimeInMinutes = selectedHour * 60 + selectedMinute;
                        if (isTextWatcherEnabled) {
                            validateInputs();
                        }
                    }, hour, minute, false);
            timePickerDialog.show();
        });
        binding.timingToTl.getEditText().setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                    (view, selectedHour, selectedMinute) -> {
                        String formattedTime = Utils.getFormattedTime(selectedHour, selectedMinute);
                        binding.timingToTl.getEditText().setText(formattedTime);
                        endTimeInMinutes = selectedHour * 60 + selectedMinute;
                        if (isTextWatcherEnabled) {
                            validateInputs();
                        }
                    }, hour, minute, false);
            timePickerDialog.show();
        });
        binding.daysAcTv.setOnClickListener(v -> {
            daysMultiChoiceDialog.show("Select preferred days?");
        });

        binding.nextBtn.setOnClickListener(v -> {
            Log.e(TAG, "initClickListeners: ");
            if (currentStepNumber < lastStepNumber) {
                Log.e(TAG, "initClickListeners: currentStepNumber < lastStepNumber");
                if (validateInputs()) {
                    Log.e(TAG, "initClickListeners: validateInputs");
                    isTextWatcherEnabled = false;
                    gotoNextStep(++currentStepNumber);
                }
            } else {
                if (!validateInputs()) {
                    return;
                }
                List<Subject> selectedSubjects = subjectData.getSelectedItemsList();
                List<Grade> selectedGrades = gradeData.getSelectedItemsList();
                List<Board> selectedBoards = boardData.getSelectedItemsList();
                String area = binding.areaEt.getText().toString().trim();
                List<DayOfWeek> selectedDays = daysMultiChoiceDialog.getSelectedItemsList();
                String amount = binding.amountEt.getText().toString().trim();
                String jobDesc = binding.jobDescTl.getEditText().getText().toString().trim();

                CreateTuitionRequest createTuitionRequest = CreateTuitionRequest.builder()
                        .subjectIds(Utils.toIdList(selectedSubjects, Subject::getId))
                        .gradeIds(Utils.toIdList(selectedGrades, Grade::getId))
                        .boardExamIds(Utils.toIdList(selectedBoards, Board::getId))
                        .onlineClass(binding.onlineClassSw.isChecked())
                        .area(area)
                        .cityId(selectedCity.getId())
                        .preferredDayValues(Utils.toIdList(selectedDays, DayOfWeek::getValue))
                        .tuitionTimeSlot(new CreateTuitionRequest.TuitionTimeSlot(startTimeInMinutes, endTimeInMinutes))
                        .salaryTypeId(selectedSalaryType.getId())
                        .salaryAmount(Integer.parseInt(amount))
                        .tutorGenderId(selectedGender)
                        .jobDescription(jobDesc)
                        .verifiedTutorsOnly(binding.verifiedTutorsOnlySw.isChecked())
                        .build();

                viewModel.createTuition(createTuitionRequest);
            }
        });
    }

    private void gotoNextStep(int stepNumber) {
        switch (stepNumber) {
            case 1:
                binding.subjectGradeLayoutLl.setVisibility(View.VISIBLE);
                binding.locationLl.setVisibility(View.GONE);
                binding.specificsLl.setVisibility(View.GONE);
                binding.otherDetailsLayoutLl.setVisibility(View.GONE);
                binding.stepView.setActiveStep(1);
                break;
            case 2:
                binding.subjectGradeLayoutLl.setVisibility(View.GONE);
                binding.locationLl.setVisibility(View.VISIBLE);
                binding.specificsLl.setVisibility(View.GONE);
                binding.otherDetailsLayoutLl.setVisibility(View.GONE);
                binding.stepView.setActiveStep(2);
                break;
            case 3:
                binding.subjectGradeLayoutLl.setVisibility(View.GONE);
                binding.locationLl.setVisibility(View.GONE);
                binding.specificsLl.setVisibility(View.VISIBLE);
                binding.otherDetailsLayoutLl.setVisibility(View.GONE);
                binding.stepView.setActiveStep(3);
                break;
            case 4:
                binding.subjectGradeLayoutLl.setVisibility(View.GONE);
                binding.locationLl.setVisibility(View.GONE);
                binding.specificsLl.setVisibility(View.GONE);
                binding.otherDetailsLayoutLl.setVisibility(View.VISIBLE);
                binding.stepView.setActiveStep(4);
                break;
        }

        if (stepNumber == lastStepNumber) {
            binding.nextBtn.setText("Submit");
        } else {
            binding.nextBtn.setText("Next");
        }
    }

    private void initStepView() {
        binding.stepView.setColumnCount(2);
        binding.stepView.setSteps("Subjects & Grades", "Location", "Specifics", "Other Details");
        binding.stepView.setActiveStep(1);
    }

    @SuppressLint("SetTextI18n")
    private void initObservers() {
        viewModel.getBoardsLiveData.observe(getViewLifecycleOwner(), getBoardsResponse -> {
            switch (getBoardsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getBoardsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Board> boardList = getBoardsResponse.getData();
                    boardData = new MultiSelectionView.Data<>(boardList, Board::getName);
                    binding.boardsMsv.setData("Select boards?", boardData);
                    break;
            }
        });

        viewModel.getGradesLiveData.observe(getViewLifecycleOwner(), getGradesResponse -> {
            switch (getGradesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getGradesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Grade> gradesList = getGradesResponse.getData();
                    gradeData = new MultiSelectionView.Data<>(gradesList, Grade::getName);
                    binding.gradesMsv.setData("Select grade?", gradeData);
                    break;
            }
        });

        viewModel.getSubjectsLiveData.observe(getViewLifecycleOwner(), getSubjectsResponse -> {
            switch (getSubjectsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSubjectsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Subject> subjectsList = getSubjectsResponse.getData();
                    subjectData = new MultiSelectionView.Data<>(subjectsList, Subject::getName);
                    binding.subjectsMsv.setData("Select subjects?", subjectData);
                    break;
            }
        });

        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    citiesList = getCitiesResponse.getData();
                    setCitiesDropDown();
                    break;
            }
        });

        viewModel.getSalaryTypesLiveData.observe(getViewLifecycleOwner(), getSalaryTypesResponse -> {
            switch (getSalaryTypesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSalaryTypesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    salaryTypesList = getSalaryTypesResponse.getData();
                    setSalaryTypesDropDown();
                    break;
            }
        });

        viewModel.createTuitionLiveData.observe(getViewLifecycleOwner(), createTuitionResponse -> {
            switch (createTuitionResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), createTuitionResponse.getMessage());
                    waitingDialog.dismiss();
                    break;
                case LOADING:
                    waitingDialog.show(createTuitionResponse.getMessage());
                    break;
                case SUCCESS:
                    Utils.showToast(requireContext(), createTuitionResponse.getMessage());
                    waitingDialog.dismiss();
                    currentStepNumber = 1;
                    requireActivity().onBackPressed();
                    break;
            }
        });
    }

    private void fetchData() {
        viewModel.getSubjects();
        viewModel.getGrades();
        viewModel.getBoards();
        viewModel.getSalaryTypes();
        viewModel.getCities();
    }

    private void setCitiesDropDown() {
        citiesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(citiesList, City::getName));
        binding.cityAcTv.setAdapter(citiesArrayAdapter);
        binding.cityAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = citiesList.get(position);
            if (isTextWatcherEnabled) {
                validateInputs();
            }
        });
    }

    private void setSalaryTypesDropDown() {
        salaryTypesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(salaryTypesList, SalaryType::getName));
        binding.salaryTypeAcTv.setAdapter(salaryTypesArrayAdapter);
        binding.salaryTypeAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedSalaryType = salaryTypesList.get(position);
            if (isTextWatcherEnabled) {
                validateInputs();
            }
        });
    }

    private void initTextWatcher() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateInputs();
                }
            }
        };

        binding.areaTl.getEditText().addTextChangedListener(textWatcher);
        binding.amountTl.getEditText().addTextChangedListener(textWatcher);
        binding.jobDescTl.getEditText().addTextChangedListener(textWatcher);
    }

    private boolean validateInputs() {
        isTextWatcherEnabled = true;
        boolean isValid = true;
        switch (currentStepNumber) {
            case 1:
                if (binding.subjectsMsv.getData().getSelectedItemsList().isEmpty()) {
                    binding.subjectsMsv.setError("Please select subjects?");
                    isValid = false;
                } else {
                    binding.subjectsMsv.setError(null);
                }
                if (binding.gradesMsv.getData().getSelectedItemsList().isEmpty()) {
                    binding.gradesMsv.setError("Please select grade?");
                    isValid = false;
                } else {
                    binding.gradesMsv.setError(null);
                }
                if (binding.boardsMsv.getData().getSelectedItemsList().isEmpty()) {
                    binding.boardsMsv.setError("Please select board/exam?");
                    isValid = false;
                } else {
                    binding.boardsMsv.setError(null);
                }
                break;
            case 2:
                String area = binding.areaEt.getText().toString().trim();
                if (TextUtils.isEmpty(area)) {
                    binding.areaTl.setError("Please enter your area?");
                    isValid = false;
                } else {
                    binding.areaTl.setError(null);
                }
                if (selectedCity == null) {
                    binding.cityTl.setError("Please select your city?");
                    isValid = false;
                } else {
                    binding.cityTl.setError(null);
                }
                break;
            case 3:
                List<DayOfWeek> selectedDays = daysMultiChoiceDialog.getSelectedItemsList();
                String amount = binding.amountEt.getText().toString().trim();

                if (CollectionUtils.isEmpty(selectedDays)) {
                    binding.daysTl.setError("Please select your preferred days?");
                    isValid = false;
                } else {
                    binding.daysTl.setError(null);
                }
                if (startTimeInMinutes == -1) {
                    binding.timingFromTl.setError("Starting time?");
                    isValid = false;
                } else {
                    binding.timingFromTl.setError(null);
                }
                if (endTimeInMinutes == -1) {
                    binding.timingToTl.setError("Ending time?");
                    isValid = false;
                } else {
                    binding.timingToTl.setError(null);
                }
                if (selectedSalaryType == null) {
                    binding.salaryTypeTl.setError("Please select the salary type?");
                    isValid = false;
                } else {
                    binding.salaryTypeTl.setError(null);
                }
                if (TextUtils.isEmpty(amount)) {
                    binding.amountTl.setError("Please enter amount?");
                    isValid = false;
                } else {
                    binding.amountTl.setError(null);
                }
                break;
            case 4:
                String jobDesc = binding.jobDescTl.getEditText().getText().toString().trim();
                if (TextUtils.isEmpty(jobDesc)) {
                    binding.jobDescTl.setError("Please enter the job description?");
                    isValid = false;
                } else {
                    binding.jobDescTl.setError(null);
                }
                break;
            default:
                isValid = false;
                break;
        }
        return isValid;
    }
}