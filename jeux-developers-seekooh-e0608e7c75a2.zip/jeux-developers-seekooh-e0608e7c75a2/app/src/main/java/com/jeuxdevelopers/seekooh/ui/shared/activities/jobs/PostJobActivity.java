package com.jeuxdevelopers.seekooh.ui.shared.activities.jobs;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavOptions;
import androidx.navigation.fragment.NavHostFragment;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityPostJobBinding;
import com.jeuxdevelopers.seekooh.utils.Constants;

public class PostJobActivity extends AppCompatActivity {

    private ActivityPostJobBinding binding;
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPostJobBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initNavController();
        getArgs();
    }

    private void initNavController() {
        final NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_container_view);
        navController = navHostFragment.getNavController();
    }

    private void getArgs() {
        String postJobStr = getIntent().getStringExtra(Constants.POST_JOB_AD);
        if (postJobStr != null) {
            navController.navigate(R.id.postJobAdFragment, null, new NavOptions.Builder()
                    .setPopUpTo(navController.getGraph().getStartDestinationId(), true)
                    .build());
        }
    }
}