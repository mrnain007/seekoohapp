package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class InstituteProfile {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("nameOfInstitute")
    @Expose
    private String nameOfInstitute;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("profileImageUrl")
    @Expose
    private String profileImageUrl;
    @SerializedName("instituteType")
    @Expose
    private InstituteType instituteType;
    @SerializedName("isRegistered")
    @Expose
    private Boolean isRegistered;
    @SerializedName("isVerified")
    @Expose
    private Boolean isVerified;
    @SerializedName("city")
    @Expose
    private City city;
    @SerializedName("teachesSubjects")
    @Expose
    private List<Subject> teachesSubjects;
    @SerializedName("teachesClasses")
    @Expose
    private List<Grade> teachesClasses;
    @SerializedName("teachesBoardExams")
    @Expose
    private List<Board> teachesBoardExams;

    public InstituteProfile() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNameOfInstitute() {
        return nameOfInstitute;
    }

    public void setNameOfInstitute(String nameOfInstitute) {
        this.nameOfInstitute = nameOfInstitute;
    }

    public String getProfileImageUrl() {
        return profileImageUrl;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

    public InstituteType getInstituteType() {
        return instituteType;
    }

    public void setInstituteType(InstituteType instituteType) {
        this.instituteType = instituteType;
    }

    public Boolean getRegistered() {
        return isRegistered;
    }

    public void setRegistered(Boolean registered) {
        isRegistered = registered;
    }

    public Boolean getVerified() {
        return isVerified;
    }

    public void setVerified(Boolean verified) {
        isVerified = verified;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public List<Subject> getTeachesSubjects() {
        return teachesSubjects;
    }

    public void setTeachesSubjects(List<Subject> teachesSubjects) {
        this.teachesSubjects = teachesSubjects;
    }

    public List<Grade> getTeachesClasses() {
        return teachesClasses;
    }

    public void setTeachesClasses(List<Grade> teachesClasses) {
        this.teachesClasses = teachesClasses;
    }

    public List<Board> getTeachesBoardExams() {
        return teachesBoardExams;
    }

    public void setTeachesBoardExams(List<Board> teachesBoardExams) {
        this.teachesBoardExams = teachesBoardExams;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}