package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class InstituteListing {

    @SerializedName("userId")
    @Expose
    private Integer userId;
    @SerializedName("seekoohId")
    @Expose
    private String seekoohId;
    @SerializedName("nameOfInstitute")
    @Expose
    private String nameOfInstitute;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("instituteId")
    @Expose
    private Integer instituteId;
    @SerializedName("profileImageUrl")
    @Expose
    private String profileImageUrl;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("reviewCount")
    @Expose
    private Integer reviewCount;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("isVerified")
    @Expose
    private Boolean isVerified;
    @SerializedName("isRegistered")
    @Expose
    private Boolean isRegistered;
    @SerializedName("city")
    @Expose
    private City city;
    @SerializedName("instituteType")
    @Expose
    private InstituteType instituteType;

    public InstituteListing() {
    }

    public InstituteListing(Integer userId, String seekoohId, String nameOfInstitute, String email, String phoneNumber, Integer instituteId, String profileImageUrl, Double rating, Integer reviewCount, String description, Boolean isVerified, Boolean isRegistered, City city, InstituteType instituteType) {
        this.userId = userId;
        this.seekoohId = seekoohId;
        this.nameOfInstitute = nameOfInstitute;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.instituteId = instituteId;
        this.profileImageUrl = profileImageUrl;
        this.rating = rating;
        this.reviewCount = reviewCount;
        this.description = description;
        this.isVerified = isVerified;
        this.isRegistered = isRegistered;
        this.city = city;
        this.instituteType = instituteType;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getSeekoohId() {
        return seekoohId;
    }

    public void setSeekoohId(String seekoohId) {
        this.seekoohId = seekoohId;
    }

    public String getNameOfInstitute() {
        return nameOfInstitute;
    }

    public void setNameOfInstitute(String nameOfInstitute) {
        this.nameOfInstitute = nameOfInstitute;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Integer getInstituteId() {
        return instituteId;
    }

    public void setInstituteId(Integer instituteId) {
        this.instituteId = instituteId;
    }

    public String getProfileImageUrl() {
        return profileImageUrl;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Integer getReviewCount() {
        return reviewCount;
    }

    public void setReviewCount(Integer reviewCount) {
        this.reviewCount = reviewCount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getVerified() {
        return isVerified;
    }

    public void setVerified(Boolean verified) {
        isVerified = verified;
    }

    public Boolean getRegistered() {
        return isRegistered;
    }

    public void setRegistered(Boolean registered) {
        isRegistered = registered;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public InstituteType getInstituteType() {
        return instituteType;
    }

    public void setInstituteType(InstituteType instituteType) {
        this.instituteType = instituteType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InstituteListing that = (InstituteListing) o;

        if (userId != null ? !userId.equals(that.userId) : that.userId != null) return false;
        if (seekoohId != null ? !seekoohId.equals(that.seekoohId) : that.seekoohId != null)
            return false;
        if (nameOfInstitute != null ? !nameOfInstitute.equals(that.nameOfInstitute) : that.nameOfInstitute != null)
            return false;
        if (email != null ? !email.equals(that.email) : that.email != null) return false;
        if (phoneNumber != null ? !phoneNumber.equals(that.phoneNumber) : that.phoneNumber != null)
            return false;
        if (instituteId != null ? !instituteId.equals(that.instituteId) : that.instituteId != null)
            return false;
        if (profileImageUrl != null ? !profileImageUrl.equals(that.profileImageUrl) : that.profileImageUrl != null)
            return false;
        if (rating != null ? !rating.equals(that.rating) : that.rating != null) return false;
        if (reviewCount != null ? !reviewCount.equals(that.reviewCount) : that.reviewCount != null)
            return false;
        if (description != null ? !description.equals(that.description) : that.description != null)
            return false;
        if (isVerified != null ? !isVerified.equals(that.isVerified) : that.isVerified != null)
            return false;
        if (isRegistered != null ? !isRegistered.equals(that.isRegistered) : that.isRegistered != null)
            return false;
        if (city != null ? !city.equals(that.city) : that.city != null) return false;
        return instituteType != null ? instituteType.equals(that.instituteType) : that.instituteType == null;
    }

    @Override
    public int hashCode() {
        int result = userId != null ? userId.hashCode() : 0;
        result = 31 * result + (seekoohId != null ? seekoohId.hashCode() : 0);
        result = 31 * result + (nameOfInstitute != null ? nameOfInstitute.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (phoneNumber != null ? phoneNumber.hashCode() : 0);
        result = 31 * result + (instituteId != null ? instituteId.hashCode() : 0);
        result = 31 * result + (profileImageUrl != null ? profileImageUrl.hashCode() : 0);
        result = 31 * result + (rating != null ? rating.hashCode() : 0);
        result = 31 * result + (reviewCount != null ? reviewCount.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (isVerified != null ? isVerified.hashCode() : 0);
        result = 31 * result + (isRegistered != null ? isRegistered.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (instituteType != null ? instituteType.hashCode() : 0);
        return result;
    }
}
