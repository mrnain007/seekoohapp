package com.jeuxdevelopers.seekooh.ui.shared.fragments.notifications.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.paging.LoadState;
import androidx.paging.LoadStateAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.jeuxdevelopers.seekooh.databinding.ItemTuitionRcvLoadingBinding;
import com.jeuxdevelopers.seekooh.utils.Utils;

import org.jetbrains.annotations.NotNull;

public class NotificationLoadStateAdapter extends LoadStateAdapter<NotificationLoadStateAdapter.LoadStateViewHolder> {
    // Define Retry Callback
    private View.OnClickListener mRetryCallback;

    public NotificationLoadStateAdapter(View.OnClickListener retryCallback) {
        // Init Retry Callback
        mRetryCallback = retryCallback;
    }

    @NotNull
    @Override
    public LoadStateViewHolder onCreateViewHolder(@NotNull ViewGroup parent, @NotNull LoadState loadState) {
        // Return new LoadStateViewHolder object
        return new LoadStateViewHolder(ItemTuitionRcvLoadingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false), mRetryCallback);
    }

    @Override
    public void onBindViewHolder(@NotNull LoadStateViewHolder holder, @NotNull LoadState loadState) {
        // Call Bind Method to bind visibility  of views
        holder.bind(loadState);
    }

    public static class LoadStateViewHolder extends RecyclerView.ViewHolder {
        ItemTuitionRcvLoadingBinding binding;

        LoadStateViewHolder(@NonNull ItemTuitionRcvLoadingBinding binding, @NonNull View.OnClickListener retryCallback) {
            super(binding.getRoot());
            this.binding = binding;

//            mRetry.setOnClickListener(retryCallback);
        }

        public void bind(LoadState loadState) {
            // Check load state
            // set visibility of widgets based on LoadState
//            binding.progressBar.setVisibility(loadState instanceof LoadState.Loading ? View.VISIBLE : View.GONE);
            binding.shimmerLl.setVisibility(loadState instanceof LoadState.Loading ? View.VISIBLE : View.GONE);
            /*mRetry.setVisibility(loadState instanceof LoadState.Error ? View.VISIBLE : View.GONE);
            mErrorMsg.setVisibility(loadState instanceof LoadState.Error ? View.VISIBLE : View.GONE);*/
        }
    }
}