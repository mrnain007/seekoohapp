package com.jeuxdevelopers.seekooh.ui.tutor.fragments.verification;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.PagerSnapHelper;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.FragmentTutorVerificationPaymentBinding;
import com.jeuxdevelopers.seekooh.models.dto.PaymobResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationFeeResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenRequest;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationStatusResponse;
import com.jeuxdevelopers.seekooh.ui.shared.activities.paymob.PaymobWebViewActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.tutor.fragments.verification.adapters.PaymentMethodsAdapter;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.NetworkUtils;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import timber.log.Timber;

public class TutorVerificationPaymentFragment extends Fragment {
    private final int PAYMOB_PAYMENT_REQUEST = 1000;
    private final int PAYMOB_WEBVIEW_REQUEST = 1001;

    private FragmentTutorVerificationPaymentBinding binding;
    private TutorVerificationViewModel viewModel;
    private NavController navController;
    private WaitingDialog waitingDialog;
    private PaymentMethodsAdapter paymentMethodsAdapter;
    private VerificationStatusResponse statusData;
    private VerificationFeeResponse verificationFeeResponse;
    private VerificationPaymentTokenResponse paymentTokenData;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentTutorVerificationPaymentBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(TutorVerificationViewModel.class);
        navController = Navigation.findNavController(view);
        initViews();
        initClickListeners();
        initObservers();
        fetchData();
    }

    private void fetchData() {
        viewModel.getTutorVerificationStatus();
        viewModel.getTutorVerificationFee();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext());
        initStepView();
        initPaymentMethodsRcv();
    }

    private void initPaymentMethodsRcv() {
        paymentMethodsAdapter = new PaymentMethodsAdapter();

        PaymentMethodsAdapter.PaymentMethod card = PaymentMethodsAdapter.PaymentMethod.builder()
                .paymentMethod(VerificationPaymentTokenRequest.PaymentMethod.CARD)
                .icon(ContextCompat.getDrawable(requireContext(), R.drawable.visa_mastercard_01))
                .build();

        PaymentMethodsAdapter.PaymentMethod easypaisa = PaymentMethodsAdapter.PaymentMethod.builder()
                .paymentMethod(VerificationPaymentTokenRequest.PaymentMethod.EASY_PAISA)
                .icon(ContextCompat.getDrawable(requireContext(), R.drawable.easypaisa))
                .build();

        PaymentMethodsAdapter.PaymentMethod jazzcash = PaymentMethodsAdapter.PaymentMethod.builder()
                .paymentMethod(VerificationPaymentTokenRequest.PaymentMethod.JAZZ_CASH)
                .icon(ContextCompat.getDrawable(requireContext(), R.drawable.jazzcash_logo))
                .build();

        paymentMethodsAdapter.submitList(Arrays.asList(card, easypaisa, jazzcash));
        binding.paymentMethodsRcv.setAdapter(paymentMethodsAdapter);

        PagerSnapHelper snapHelper = new PagerSnapHelper();
        snapHelper.attachToRecyclerView(binding.paymentMethodsRcv);
    }

    private void initObservers() {
        viewModel.verificationFeeLiveData
                .observe(getViewLifecycleOwner(), verificationStatusResponse -> {
                    switch (verificationStatusResponse.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), verificationStatusResponse.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(verificationStatusResponse.getMessage());
                            break;
                        case SUCCESS:
                            verificationFeeResponse = verificationStatusResponse.getData();
                            setData();
                            waitingDialog.dismiss();
                            break;
                    }
                });

        viewModel.verificationStatusLiveData
                .observe(getViewLifecycleOwner(), verificationStatusResponse -> {
                    switch (verificationStatusResponse.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), verificationStatusResponse.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(verificationStatusResponse.getMessage());
                            break;
                        case SUCCESS:
                            statusData = verificationStatusResponse.getData();
                            String status = statusData.getStatus();
                            if (!status.equals(Constants.UserVerificationStatus.PAYMENT_PENDING.name())) {
                                navController.navigate(TutorVerificationPaymentFragmentDirections.actionTutorVerificationPaymentFragmentToTutorVerificationDocumentFragment());
                            }
                            waitingDialog.dismiss();
                            break;
                    }
                });


        viewModel.verificationPaymentTokenLiveData
                .observe(getViewLifecycleOwner(), paymentTokenResponse -> {
                    switch (paymentTokenResponse.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), paymentTokenResponse.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(paymentTokenResponse.getMessage());
                            break;
                        case SUCCESS:
                            paymentTokenData = paymentTokenResponse.getData();
                            startPaymentWebView();
                            waitingDialog.dismiss();
                            break;
                    }
                });
    }

    private void startPaymentWebView() {
        VerificationPaymentTokenRequest.PaymentMethod paymentMethod = paymentTokenData.getPaymentMethod();
        Intent webViewIntent = new Intent(requireActivity(), PaymobWebViewActivity.class);
        webViewIntent.putExtra("ActionBar", false);
        if (paymentMethod == null) {
            webViewIntent.putExtra("three_d_secure_url", "https://pakistan.paymob.com/api/acceptance/iframes/75741?payment_token=" + paymentTokenData.getPaymentToken());
        } else if (paymentMethod == VerificationPaymentTokenRequest.PaymentMethod.CARD) {
            webViewIntent.putExtra("three_d_secure_url", "https://pakistan.paymob.com/api/acceptance/iframes/75741?payment_token=" + paymentTokenData.getPaymentToken());
        } else {
            webViewIntent.putExtra("three_d_secure_url", "https://pakistan.paymob.com/iframe/" + paymentTokenData.getPaymentToken());
        }
        webViewIntent.putExtra("theme_color", getResources().getColor(R.color.white));
        startActivityForResult(webViewIntent, PAYMOB_WEBVIEW_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PAYMOB_WEBVIEW_REQUEST) {
            if (resultCode == 1) {
                Utils.showToast(requireContext(), "User Canceled");
            } else if (resultCode == 2) {
                Utils.showToast(requireContext(), "Missing args");
            } else if (resultCode == 17) {
                // USER_FINISHED_3D_VERIFICATION
                if (data == null) {
                    Utils.showToast(requireContext(), "Data null success");
                    return;
                }
                String rawPayResponse = data.getStringExtra("raw_pay_response");
                PaymobResponse paymobResponse = NetworkUtils.rawResponseToPaymob(rawPayResponse);
                if (paymobResponse != null && paymobResponse.getSuccess().equals("true")) {
                    Utils.showToast(requireContext(), "Transaction successful.");
                    navController.navigate(TutorVerificationPaymentFragmentDirections.actionTutorVerificationPaymentFragmentToTutorVerificationDocumentFragment());
                } else {
                    Utils.showToast(requireContext(), "Transaction failed.");
                }
            }
        }
    }

    /*@Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PAYMOB_PAYMENT_REQUEST) {
            Bundle extras = data.getExtras();
            if (resultCode == IntentConstants.USER_CANCELED) {
                // User canceled and did no payment request was fired
                ToastMaker.displayShortToast(requireActivity(), "User canceled!!");
            } else if (resultCode == IntentConstants.MISSING_ARGUMENT) {
                // You forgot to pass an important key-value pair in the intent's extras
                ToastMaker.displayShortToast(requireActivity(), "Missing Argument == " + extras.getString(IntentConstants.MISSING_ARGUMENT_VALUE));
            } else if (resultCode == IntentConstants.TRANSACTION_ERROR) {
                // An error occurred while handling an API response
                ToastMaker.displayShortToast(requireActivity(), "Reason == " + extras.getString(IntentConstants.TRANSACTION_ERROR_REASON));
            } else if (resultCode == IntentConstants.TRANSACTION_REJECTED) {
                // User attempted to pay but their transaction was rejected

                // Use the static keys declared in PayResponseKeys to extract the fields you want
                ToastMaker.displayShortToast(requireActivity(), extras.getString(PayResponseKeys.DATA_MESSAGE));
            } else if (resultCode == IntentConstants.TRANSACTION_REJECTED_PARSING_ISSUE) {
                // User attempted to pay but their transaction was rejected. An error occurred while reading the returned JSON
                ToastMaker.displayShortToast(requireActivity(), extras.getString(IntentConstants.RAW_PAY_RESPONSE));
            } else if (resultCode == IntentConstants.TRANSACTION_SUCCESSFUL) {
                // User finished their payment successfully

                // Use the static keys declared in PayResponseKeys to extract the fields you want
                ToastMaker.displayShortToast(requireActivity(), extras.getString(PayResponseKeys.DATA_MESSAGE));
            } else if (resultCode == IntentConstants.TRANSACTION_SUCCESSFUL_PARSING_ISSUE) {
                // User finished their payment successfully. An error occurred while reading the returned JSON.
                ToastMaker.displayShortToast(requireActivity(), "TRANSACTION_SUCCESSFUL - Parsing Issue");

                // ToastMaker.displayShortToast(this, extras.getString(IntentConstants.RAW_PAY_RESPONSE));
            } else if (resultCode == IntentConstants.TRANSACTION_SUCCESSFUL_CARD_SAVED) {
                // User finished their payment successfully and card was saved.

                // Use the static keys declared in PayResponseKeys to extract the fields you want
                // Use the static keys declared in SaveCardResponseKeys to extract the fields you want
                ToastMaker.displayShortToast(requireActivity(), "Token == " + extras.getString(SaveCardResponseKeys.TOKEN));
            } else if (resultCode == IntentConstants.USER_CANCELED_3D_SECURE_VERIFICATION) {
                ToastMaker.displayShortToast(requireActivity(), "User canceled 3d secure verification!!");

                // Note that a payment process was attempted. You can extract the original returned values
                // Use the static keys declared in PayResponseKeys to extract the fields you want
                ToastMaker.displayShortToast(requireActivity(), extras.getString(PayResponseKeys.PENDING));
            } else if (resultCode == IntentConstants.USER_CANCELED_3D_SECURE_VERIFICATION_PARSING_ISSUE) {
                ToastMaker.displayShortToast(requireActivity(), "User canceled 3d secure verification - Parsing Issue!!");

                // Note that a payment process was attempted.
                // User finished their payment successfully. An error occurred while reading the returned JSON.
                ToastMaker.displayShortToast(requireActivity(), extras.getString(IntentConstants.RAW_PAY_RESPONSE));
            }
        }
    }*/

    @SuppressLint("SetTextI18n")
    private void setData() {
        if (Utils.isDataNull(requireContext(), verificationFeeResponse)) {
            return;
        }
        VerificationFeeResponse data = this.verificationFeeResponse;

        String currency = data.getCurrency().equals(Constants.Currency.PKR.name()) ? "Rs." : data.getCurrency();
        binding.feeAmountTv.setText(currency + " " + data.getFee().setScale(2, RoundingMode.DOWN).toString());
        binding.paymentContainerLl.setVisibility(View.VISIBLE);
        binding.getRoot().transitionToEnd();
    }

    private void initStepView() {
        binding.stepView.setColumnCount(3);
        binding.stepView.setSteps("Payments", "Documents", "Status");
        binding.stepView.setActiveStep(1);
    }

    private void initClickListeners() {
        binding.payNowBtn.setOnClickListener(v -> {
            VerificationPaymentTokenRequest.PaymentMethod selectedPaymentMethod = paymentMethodsAdapter.getSelectedPaymentMethod();
            VerificationPaymentTokenRequest verificationPaymentTokenRequest = VerificationPaymentTokenRequest.builder()
                    .paymentMethod(selectedPaymentMethod)
                    .build();
            viewModel.getTutorVerificationPaymentToken(verificationPaymentTokenRequest);
//            navController.navigate(TutorVerificationPaymentFragmentDirections.actionTutorVerificationPaymentFragmentToTutorVerificationStatusFragment());
        });
    }
}