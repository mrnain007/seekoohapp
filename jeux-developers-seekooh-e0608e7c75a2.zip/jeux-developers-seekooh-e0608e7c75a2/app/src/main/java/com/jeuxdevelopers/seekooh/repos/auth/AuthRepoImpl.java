package com.jeuxdevelopers.seekooh.repos.auth;

import static java.sql.DriverManager.println;

import android.net.Uri;

import androidx.annotation.NonNull;

import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.InstituteType;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationRequest;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationResponse;
import com.jeuxdevelopers.seekooh.models.dto.InstituteRegistrationRequest;
import com.jeuxdevelopers.seekooh.models.dto.InstituteRegistrationResponse;
import com.jeuxdevelopers.seekooh.models.dto.SendPasswordResetRequest;
import com.jeuxdevelopers.seekooh.models.dto.SendPasswordResetResponse;
import com.jeuxdevelopers.seekooh.models.dto.SocialLoginRequest;
import com.jeuxdevelopers.seekooh.models.dto.StudentRegistrationRequest;
import com.jeuxdevelopers.seekooh.models.dto.StudentRegistrationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TokenRefreshRequest;
import com.jeuxdevelopers.seekooh.models.dto.TokenRefreshResponse;
import com.jeuxdevelopers.seekooh.models.dto.TutorRegistrationRequest;
import com.jeuxdevelopers.seekooh.models.dto.TutorRegistrationResponse;
import com.jeuxdevelopers.seekooh.models.other.SeekoohResponse;
import com.jeuxdevelopers.seekooh.network.SeekoohService;
import com.jeuxdevelopers.seekooh.network.ServiceUtils;
import com.jeuxdevelopers.seekooh.utils.NetworkUtils;

import java.net.URI;
import java.util.List;
import java.util.concurrent.Callable;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.ObservableSource;
import io.reactivex.rxjava3.core.SingleSource;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.functions.Function;
import io.reactivex.rxjava3.schedulers.Schedulers;
import okhttp3.MultipartBody;

public class AuthRepoImpl implements AuthRepo {
    private final SeekoohService seekoohService;
    private final CompositeDisposable disposables;

    public AuthRepoImpl(CompositeDisposable disposables) {
        this.disposables = disposables;
        seekoohService = ServiceUtils.createSeekoohService(SeekoohService.class);
    }

    @Override
    public Observable<Resource<AuthenticationResponse>> authenticate(@NonNull AuthenticationRequest authenticationRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Authentication request is being processed.", null));
            disposables.add(seekoohService.authenticate(authenticationRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(authenticationResponse -> {
                        if (NetworkUtils.isValidResponse(authenticationResponse)) {
                            emitter.onNext(Resource.success(authenticationResponse.getMessage("Authentication successful"), authenticationResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(authenticationResponse.getMessage("Authentication failed"), null));
                        }
                    }, throwable -> {
                        println("throwable: " + throwable);
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Authentication failed due to unknown reason.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<TokenRefreshResponse>> tokenRefresh(@NonNull TokenRefreshRequest tokenRefreshRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Token refresh request is being processed.", null));
            disposables.add(seekoohService.tokenRefresh(tokenRefreshRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(tokenRefreshResponse -> {
                        if (NetworkUtils.isValidResponse(tokenRefreshResponse)) {
                            emitter.onNext(Resource.success(tokenRefreshResponse.getMessage("Token refresh successful"), tokenRefreshResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(tokenRefreshResponse.getMessage("Token refresh failed"), null));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Token refresh failed due to unknown reason.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<AuthenticationResponse>> socialLogin(@NonNull SocialLoginRequest socialLoginRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Authentication request is being processed.", null));
            disposables.add(seekoohService.socialLogin(socialLoginRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(socialLoginResponse -> {
                        if (NetworkUtils.isValidResponse(socialLoginResponse)) {
                            emitter.onNext(Resource.success(socialLoginResponse.getMessage("Authentication successful"), socialLoginResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(socialLoginResponse.getMessage("Authentication failed"), null));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Authentication failed due to unknown reason.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<SendPasswordResetResponse>> requestPasswordReset(@NonNull SendPasswordResetRequest sendPasswordResetRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Password reset request is being processed.", null));
            disposables.add(seekoohService.requestPasswordReset(sendPasswordResetRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(resetPasswordResponse -> {
                        if (NetworkUtils.isValidResponse(resetPasswordResponse)) {
                            emitter.onNext(Resource.success(resetPasswordResponse.getMessage("Password reset request submitted successfully."), resetPasswordResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(resetPasswordResponse.getMessage("Failed to submit password reset request"), null));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit password reset request");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<StudentRegistrationResponse>> registerStudent(@NonNull URI profileImageUri, @NonNull StudentRegistrationRequest studentRegistrationRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Registration request is being processed.", null));
            MultipartBody.Part multipartImage = NetworkUtils.uriToMultipartImage(profileImageUri);
            disposables.add(seekoohService.registerStudent(multipartImage, studentRegistrationRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(studentRegistrationResponse -> {
                        if (NetworkUtils.isValidResponse(studentRegistrationResponse)) {
                            emitter.onNext(Resource.success(studentRegistrationResponse.getMessage("Registration successful"), studentRegistrationResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(studentRegistrationResponse.getMessage("Registration failed"), null));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Registration failed due to unknown reason.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<TutorRegistrationResponse>> registerTutor(@NonNull Uri profileImageUri, @NonNull TutorRegistrationRequest tutorRegistrationRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Registration request is being processed.", null));
            MultipartBody.Part multipartImage = NetworkUtils.uriToMultipartImage(URI.create(profileImageUri.toString()));

            disposables.add(seekoohService.registerTutor(multipartImage, tutorRegistrationRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(tutorRegistrationResponse -> {
                        if (NetworkUtils.isValidResponse(tutorRegistrationResponse)) {
                            emitter.onNext(Resource.success(tutorRegistrationResponse.getMessage("Registration successful."), tutorRegistrationResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(tutorRegistrationResponse.getMessage("Registration failed."), null));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Registration failed due to unknown reason.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<InstituteRegistrationResponse>> registerInstitute(@NonNull URI profileImageUri, @NonNull InstituteRegistrationRequest instituteRegistrationRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Registration request is being processed.", null));
            MultipartBody.Part multipartImage = NetworkUtils.uriToMultipartImage(profileImageUri);
            disposables.add(seekoohService.registerInstitute(multipartImage, instituteRegistrationRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(instituteRegistrationResponse -> {
                        if (NetworkUtils.isValidResponse(instituteRegistrationResponse)) {
                            emitter.onNext(Resource.success(instituteRegistrationResponse.getMessage("Registration successful"), instituteRegistrationResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(instituteRegistrationResponse.getMessage("Registration failed"), null));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Registration failed due to unknown reason.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

        /*@Override
        public Observable<Resource<List<City>>> getCities () {
            return seekoohService.getCities()
                    .subscribeOn(Schedulers.io())
                    .map((Function<SeekoohResponse<List<City>>, Resource<List<City>>>) getCitiesResponse -> {
                        if (NetworkUtils.isValidResponse(getCitiesResponse)) {
                            return Resource.success(getCitiesResponse.getMessage("Cities list fetched successfully."), getCitiesResponse.getData());
                        } else {
                            return Resource.error(getCitiesResponse.getMessage("Failed to fetch Cities list."), null);
                        }
                    }).toObservable()
                    .startWith(Observable.just(Resource.loading("Cities list is being fetch.", null)));
        }*/
}
