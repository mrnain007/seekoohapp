package com.jeuxdevelopers.seekooh.utils;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;

public class NotificationUtils {
    public static final String CHANNEL_ID = "notification_channel_seekooh";
    public static final String CHANNEL_NAME = "Seekooh";

    public static void createNotificationChannel(Context context, String channelId, String channelName) {
        // Check if the device is running Android Oreo (API 26) or above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);

            for (NotificationChannel channel : notificationManager.getNotificationChannels()) {
                if (channel.getId().equals(channelId)) {
                    // The channel with the given ID already exists
                    // You can handle this case as needed
                    // For example, you might want to update the channel properties instead of creating a new one.
                    // To update the properties, you can call the set* methods on the existing channel.
                    return;
                }
            }

            // Create the NotificationChannel with the highest priority
            NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
//            channel.setDescription("channel description");
            // Set other parameters like LED lights, vibration, etc. if needed
            channel.enableVibration(true);
            channel.enableLights(true);
            channel.setLightColor(Color.GREEN);
            channel.setVibrationPattern(new long[]{1000, 1000, 1000, 1000, 1000});

            // Register the NotificationChannel with the system
            notificationManager.createNotificationChannel(channel);
        }
    }
}