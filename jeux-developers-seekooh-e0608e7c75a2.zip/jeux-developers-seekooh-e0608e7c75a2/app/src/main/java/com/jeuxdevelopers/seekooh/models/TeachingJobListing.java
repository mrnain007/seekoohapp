package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.dto.CreateTeachingJobRequest;

import java.util.List;

public class TeachingJobListing {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("isOnline")
    @Expose
    private Boolean isOnline;
    @SerializedName("isInPerson")
    @Expose
    private Boolean isInPerson;
    @SerializedName("verifiedTutorsOnly")
    @Expose
    private Boolean verifiedTutorsOnly;
    @SerializedName("jobTitle")
    @Expose
    private String jobTitle;
    @SerializedName("area")
    @Expose
    private String area;
    @SerializedName("jobDescription")
    @Expose
    private String jobDescription;
    @SerializedName("languageSkills")
    @Expose
    private String languageSkills;
    @SerializedName("expertise")
    @Expose
    private String expertise;
    @SerializedName("salaryAmount")
    @Expose
    private Double salaryAmount;
    @SerializedName("city")
    @Expose
    private City city;
    @SerializedName("benefits")
    @Expose
    private List<String> benefits;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("contractType")
    @Expose
    private ContractType contractType;
    @SerializedName("subjects")
    @Expose
    private List<Subject> subjects;
    @SerializedName("suggestedSubjects")
    @Expose
    private List<String> suggestedSubjects;
    @SerializedName("grades")
    @Expose
    private List<Grade> grades;
    @SerializedName("suggestedGrades")
    @Expose
    private List<String> suggestedGrades;
    @SerializedName("qualification")
    @Expose
    private Qualification qualification;
    @SerializedName("experience")
    @Expose
    private Experience experience;
    @SerializedName("tutorGender")
    @Expose
    private Gender tutorGender;
    @SerializedName("institute")
    @Expose
    private Institute institute;
    @SerializedName("createdAt")
    @Expose
    private Long createdAt;
    @SerializedName("updatedAt")
    @Expose
    private Long updatedAt;

    public TeachingJobListing() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Boolean getOnline() {
        return isOnline;
    }

    public void setOnline(Boolean online) {
        isOnline = online;
    }

    public Boolean getInPerson() {
        return isInPerson;
    }

    public void setInPerson(Boolean inPerson) {
        isInPerson = inPerson;
    }

    public Boolean getVerifiedTutorsOnly() {
        return verifiedTutorsOnly;
    }

    public void setVerifiedTutorsOnly(Boolean verifiedTutorsOnly) {
        this.verifiedTutorsOnly = verifiedTutorsOnly;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public String getLanguageSkills() {
        return languageSkills;
    }

    public void setLanguageSkills(String languageSkills) {
        this.languageSkills = languageSkills;
    }

    public String getExpertise() {
        return expertise;
    }

    public void setExpertise(String expertise) {
        this.expertise = expertise;
    }

    public Double getSalaryAmount() {
        return salaryAmount;
    }

    public void setSalaryAmount(Double salaryAmount) {
        this.salaryAmount = salaryAmount;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public List<String> getBenefits() {
        return benefits;
    }

    public void setBenefits(List<String> benefits) {
        this.benefits = benefits;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ContractType getContractType() {
        return contractType;
    }

    public void setContractType(ContractType contractType) {
        this.contractType = contractType;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }

    public List<String> getSuggestedSubjects() {
        return suggestedSubjects;
    }

    public void setSuggestedSubjects(List<String> suggestedSubjects) {
        this.suggestedSubjects = suggestedSubjects;
    }

    public List<Grade> getGrades() {
        return grades;
    }

    public void setGrades(List<Grade> grades) {
        this.grades = grades;
    }

    public List<String> getSuggestedGrades() {
        return suggestedGrades;
    }

    public void setSuggestedGrades(List<String> suggestedGrades) {
        this.suggestedGrades = suggestedGrades;
    }

    public Qualification getQualification() {
        return qualification;
    }

    public void setQualification(Qualification qualification) {
        this.qualification = qualification;
    }

    public Experience getExperience() {
        return experience;
    }

    public void setExperience(Experience experience) {
        this.experience = experience;
    }

    public Gender getTutorGender() {
        return tutorGender;
    }

    public void setTutorGender(Gender tutorGender) {
        this.tutorGender = tutorGender;
    }

    public Institute getInstitute() {
        return institute;
    }

    public void setInstitute(Institute institute) {
        this.institute = institute;
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Long updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TeachingJobListing that = (TeachingJobListing) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (isOnline != null ? !isOnline.equals(that.isOnline) : that.isOnline != null)
            return false;
        if (isInPerson != null ? !isInPerson.equals(that.isInPerson) : that.isInPerson != null)
            return false;
        if (verifiedTutorsOnly != null ? !verifiedTutorsOnly.equals(that.verifiedTutorsOnly) : that.verifiedTutorsOnly != null)
            return false;
        if (jobTitle != null ? !jobTitle.equals(that.jobTitle) : that.jobTitle != null)
            return false;
        if (area != null ? !area.equals(that.area) : that.area != null) return false;
        if (jobDescription != null ? !jobDescription.equals(that.jobDescription) : that.jobDescription != null)
            return false;
        if (languageSkills != null ? !languageSkills.equals(that.languageSkills) : that.languageSkills != null)
            return false;
        if (expertise != null ? !expertise.equals(that.expertise) : that.expertise != null)
            return false;
        if (salaryAmount != null ? !salaryAmount.equals(that.salaryAmount) : that.salaryAmount != null)
            return false;
        if (city != null ? !city.equals(that.city) : that.city != null) return false;
        if (benefits != null ? !benefits.equals(that.benefits) : that.benefits != null)
            return false;
        if (status != null ? !status.equals(that.status) : that.status != null) return false;
        if (contractType != that.contractType) return false;
        if (subjects != null ? !subjects.equals(that.subjects) : that.subjects != null)
            return false;
        if (suggestedSubjects != null ? !suggestedSubjects.equals(that.suggestedSubjects) : that.suggestedSubjects != null)
            return false;
        if (grades != null ? !grades.equals(that.grades) : that.grades != null) return false;
        if (suggestedGrades != null ? !suggestedGrades.equals(that.suggestedGrades) : that.suggestedGrades != null)
            return false;
        if (qualification != null ? !qualification.equals(that.qualification) : that.qualification != null)
            return false;
        if (experience != null ? !experience.equals(that.experience) : that.experience != null)
            return false;
        if (tutorGender != null ? !tutorGender.equals(that.tutorGender) : that.tutorGender != null)
            return false;
        if (institute != null ? !institute.equals(that.institute) : that.institute != null)
            return false;
        if (createdAt != null ? !createdAt.equals(that.createdAt) : that.createdAt != null)
            return false;
        return updatedAt != null ? updatedAt.equals(that.updatedAt) : that.updatedAt == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (isOnline != null ? isOnline.hashCode() : 0);
        result = 31 * result + (isInPerson != null ? isInPerson.hashCode() : 0);
        result = 31 * result + (verifiedTutorsOnly != null ? verifiedTutorsOnly.hashCode() : 0);
        result = 31 * result + (jobTitle != null ? jobTitle.hashCode() : 0);
        result = 31 * result + (area != null ? area.hashCode() : 0);
        result = 31 * result + (jobDescription != null ? jobDescription.hashCode() : 0);
        result = 31 * result + (languageSkills != null ? languageSkills.hashCode() : 0);
        result = 31 * result + (expertise != null ? expertise.hashCode() : 0);
        result = 31 * result + (salaryAmount != null ? salaryAmount.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (benefits != null ? benefits.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (contractType != null ? contractType.hashCode() : 0);
        result = 31 * result + (subjects != null ? subjects.hashCode() : 0);
        result = 31 * result + (suggestedSubjects != null ? suggestedSubjects.hashCode() : 0);
        result = 31 * result + (grades != null ? grades.hashCode() : 0);
        result = 31 * result + (suggestedGrades != null ? suggestedGrades.hashCode() : 0);
        result = 31 * result + (qualification != null ? qualification.hashCode() : 0);
        result = 31 * result + (experience != null ? experience.hashCode() : 0);
        result = 31 * result + (tutorGender != null ? tutorGender.hashCode() : 0);
        result = 31 * result + (institute != null ? institute.hashCode() : 0);
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        return result;
    }

    public enum ContractType {
        TEMPORARY,
        PERMANENT,
        FIXED_TERM,
        PART_TIME,
        SUBSTITUTE,
        VISITING_FACULTY
    }

    public static class Institute {
        @SerializedName("id")
        @Expose
        private Integer id;
        @SerializedName("nameOfInstitute")
        @Expose
        private String nameOfInstitute;
        @SerializedName("profileImageUrl")
        @Expose
        private String profileImageUrl;

        public Institute() {
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getNameOfInstitute() {
            return nameOfInstitute;
        }

        public void setNameOfInstitute(String nameOfInstitute) {
            this.nameOfInstitute = nameOfInstitute;
        }

        public String getProfileImageUrl() {
            return profileImageUrl;
        }

        public void setProfileImageUrl(String profileImageUrl) {
            this.profileImageUrl = profileImageUrl;
        }
    }
}
