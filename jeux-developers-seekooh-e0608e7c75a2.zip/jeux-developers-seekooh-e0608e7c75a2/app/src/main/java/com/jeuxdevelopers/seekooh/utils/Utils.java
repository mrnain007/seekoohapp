package com.jeuxdevelopers.seekooh.utils;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.loader.content.CursorLoader;

import com.google.android.gms.common.util.CollectionUtils;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jeuxdevelopers.seekooh.exceptions.MissingPermissionException;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.chat.Chat;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TokenRefreshResponse;

import org.ocpsoft.prettytime.PrettyTime;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.StringJoiner;
import java.util.function.Function;
import java.util.stream.Collectors;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class Utils {
    public static <T> List<Object> addAdItems(int interval, T adModel, List<Object> itemsList) {
        for (int i = 0; i < itemsList.size(); i++) {
            if (i % interval == 0) {
                itemsList.add(i, adModel);
            }
        }
        return itemsList;
    }

    public static void showToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    public static void showToastLong(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

    public static String toJson(Object data) {
        return new Gson().toJson(data);
    }

    public static <T> List<String> toStringList(List<T> list, Function<T, String> toString) {
        List<String> stringList = new ArrayList<>();
        for (T t : list) {
            stringList.add(toString.apply(t));
        }
        return stringList;
    }

    public static <T> List<Integer> toIdList(List<T> list, Function<T, Integer> toInteger) {
        List<Integer> idList = new ArrayList<>();
        for (T t : list) {
            idList.add(toInteger.apply(t));
        }
        return idList;
    }

    public static String getAddressFromLatLng(Context context, double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses.size() > 0) {
                Address address = addresses.get(0);
                StringBuilder addressString = new StringBuilder();
                for (int i = 0; i <= address.getMaxAddressLineIndex(); i++) {
                    addressString.append(address.getAddressLine(i)).append(i == address.getMaxAddressLineIndex() ? "" : "\n");
                }
                return addressString.toString();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String stringCapitalize(String input) {
        return input.substring(0, 1).toUpperCase() + input.substring(1).toLowerCase();
    }

    public static Uri bitmapToUri(Context context, @NonNull Bitmap bitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String fileName = "profile_picture_" + System.currentTimeMillis() + ".jpg";
        File cacheDir = context.getCacheDir();
        File imageFile = new File(cacheDir, fileName);

        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            fos.write(bytes.toByteArray());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Uri.fromFile(imageFile);
//        return FileProvider.getUriForFile(context, context.getPackageName() + ".provider", imageFile);
    }

    public static User dtoToUser(AuthenticationResponse authenticationResponse) {
        Gson gson = new Gson();
        String dtoJson = gson.toJson(authenticationResponse);
        return gson.fromJson(dtoJson, new TypeToken<User>() {
        }.getType());
    }

    public static User dtoToUser(TokenRefreshResponse tokenRefreshResponse) {
        Gson gson = new Gson();
        String dtoJson = gson.toJson(tokenRefreshResponse);
        return gson.fromJson(dtoJson, new TypeToken<User>() {
        }.getType());
    }

    public static boolean isDataNull(Context context, Object... objects) {
        for (Object object : objects) {
            if (object == null) {
                Utils.showToast(context, "Data fetch failed.");
                return true;
            }
        }
        return false;
    }

    @NonNull
    public static String getFormattedTime(int selectedHour, int selectedMinute) {
        String selectedTime = String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute);
        Date date = null;
        try {
            date = new SimpleDateFormat("HH:mm", Locale.getDefault()).parse(selectedTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        selectedTime = new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(date);
        return selectedTime;
    }

    @NonNull
    public static String getFormattedTime(int inMinutes) {
        String selectedTime = String.format(Locale.getDefault(), "%02d:%02d", inMinutes / 60, inMinutes % 60);
        Date date = null;
        try {
            date = new SimpleDateFormat("HH:mm", Locale.getDefault()).parse(selectedTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        selectedTime = new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(date);
        return selectedTime;
    }

    @NonNull
    public static String getFormattedDate(long timeInMillis) {
        return new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date(timeInMillis));
    }

    @NonNull
    public static String getFormattedTime(long timeInMillis) {
        return new SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.getDefault()).format(new Date(timeInMillis));
    }

    public static String getPrettyTime(long epoch) {
        return new PrettyTime().format(new Date(epoch));
    }

    public static List<DayOfWeek> toDayOfWeekList(List<com.jeuxdevelopers.seekooh.models.DayOfWeek> dayOfWeeks) {
        return dayOfWeeks
                .stream()
                .map(dayOfWeek -> DayOfWeek.of(dayOfWeek.getIndex()))
                .collect(Collectors.toList());
    }

    public static Single<Bitmap> extractFrameFromVideo(@NonNull String filePathOrUrl) {
        return Single.fromCallable(() -> {
                    MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                    try {
                        // Set data source to video file path or URL
                        retriever.setDataSource(filePathOrUrl, new HashMap<>());

                        String duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                        long videoDuration = Long.parseLong(duration);

                        long timeUs = videoDuration / 2 * 1000;

                        // extract the frame at the specified time position
                        Bitmap frameAtTime = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST);
                        retriever.release();
                        return frameAtTime;
                    } catch (RuntimeException e) {
                        e.printStackTrace();
                        throw new RuntimeException(e);
                    } finally {
                        retriever.release();
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public static String getRealPathFromURI(Context context, Uri uri) {
        String filePath = "";
        String scheme = uri.getScheme();

        if (ContentResolver.SCHEME_CONTENT.equals(scheme)) {
            String[] projection = {MediaStore.Video.Media.DATA};
            try (Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
                    filePath = cursor.getString(columnIndex);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ContentResolver.SCHEME_FILE.equals(scheme)) {
            filePath = uri.getPath();
        } else {
            try {
                File file = new File(uri.getPath());
                filePath = file.getAbsolutePath();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return filePath;
    }

    public static File createTempFileFromUri(Context context, Uri uri) {
        File tempFile = null;
        try {
            String extension = getFileExtensionFromUri(context, uri);
            String fileName = "temp_file." + extension;

            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            if (inputStream != null) {
                tempFile = new File(context.getCacheDir(), fileName);
                FileOutputStream outputStream = new FileOutputStream(tempFile);

                byte[] buffer = new byte[1024];
                int read;
                while ((read = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, read);
                }

                outputStream.close();
                inputStream.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tempFile;
    }

    public static String getFileExtensionFromUri(Context context, Uri uri) {
        ContentResolver contentResolver = context.getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        String extension = mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
        if (extension == null) {
            extension = "unknown";
        }
        return extension;
    }

    @SuppressLint("MissingPermission")
    public static Single<Location> getCurrentLocation(Context context) {
        return Single.create(emitter -> {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                emitter.onError(new MissingPermissionException("Location permission missing."));
                return;
            }

            final FusedLocationProviderClient fusedLocationProvider = LocationServices.getFusedLocationProviderClient(context);
            LocationCallback locationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(@NonNull LocationResult locationResult) {
                    emitter.onSuccess(locationResult.getLocations().get(locationResult.getLocations().size() - 1));
                    fusedLocationProvider.removeLocationUpdates(this);
                }
            };
            LocationRequest locationRequest = new LocationRequest.Builder(10000)
                    .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
                    .setIntervalMillis(10000)
                    .setMinUpdateIntervalMillis(5000)
                    .build();
            fusedLocationProvider.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
        });
    }

    public static boolean isImageUri(Uri uri, Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        String mimeType = contentResolver.getType(uri);
        return mimeType != null && mimeType.startsWith("image/");
    }

    public static boolean validatePhoneNumber(String phoneNumber) {
        return Constants.PHONE_NUMBER_PATTERN.matcher(phoneNumber).matches();
    }

    public static String toFirebaseId(@NonNull String userId, @NonNull Role role) {
        return userId + "-" + role.getName().substring("ROLE_".length()).toLowerCase();
    }

    public static boolean isStudent(Role role) {
        return role.getName().equals(Constants.ROLE_STUDENT);
    }

    public static boolean isTutor(Role role) {
        return role.getName().equals(Constants.ROLE_TUTOR);
    }

    public static boolean isInstitute(Role role) {
        return role.getName().equals(Constants.ROLE_INSTITUTE);
    }

    @Nullable
    public static FirebaseUser toFirebaseUser(@NonNull User user) {
        Role selectedRole = user.getAppSettings().getSelectedRole();
        if (isStudent(selectedRole)) {
            return FirebaseUser.builder()
                    .userId(toFirebaseId(user.getSeekoohId(), selectedRole))
                    .fullName(user.getFullName())
                    .profileImgUrl(user.getStudentProfile().getProfileImageUrl())
                    .build();
        } else if (isTutor(selectedRole)) {
            return FirebaseUser.builder()
                    .userId(toFirebaseId(user.getSeekoohId(), selectedRole))
                    .fullName(user.getFullName())
                    .profileImgUrl(user.getTutorProfile().getProfileImageUrl())
                    .build();
        } else if (isInstitute(selectedRole)) {
            return FirebaseUser.builder()
                    .userId(toFirebaseId(user.getSeekoohId(), selectedRole))
                    .fullName(user.getInstituteProfile().getNameOfInstitute())
                    .profileImgUrl(user.getInstituteProfile().getProfileImageUrl())
                    .build();
        }

        return null;
    }

    public static String combineIdChat(String id1, String id2) {
        return id1.compareTo(id2) < 0 ? id1 + id2 : id2 + id1;
    }

    public static String getChatName(@NonNull Chat chat, String currentUserId) {
        List<String> userNames = new ArrayList<>();
        chat.getParticipants().forEach(firebaseUser -> {
            if (firebaseUser.getUserId().equals(currentUserId)) {
                if (chat.getType() != Chat.Type.PRIVATE) {
                    userNames.add("You");
                }
            } else {
                userNames.add(firebaseUser.getFullName());
            }
        });
        return String.join(", ", userNames);
    }

//    public static Boolean isBlockUser(@NonNull Chat chat, String currentUserId) {
//
//        chat.getParticipants().forEach(firebaseUser -> {
//            if (firebaseUser.getUserId().equals(currentUserId)) {
//                if (chat.getType() != Chat.Type.PRIVATE) {
//                    return firebaseUser.isBlock();
//                }
//            }
//        });
//        return false;
//    }


    public static boolean isCurrentUserBlocked(@NonNull Chat chat, String currentUserId) {
        for (FirebaseUser firebaseUser : chat.getParticipants()) {
            if (firebaseUser.getUserId().equals(currentUserId)) {
                if (chat.getType() == Chat.Type.PRIVATE) {
                    return firebaseUser.isBlock();
                }
            }
        }
        return false;
    }

    public static boolean isOtherUserBlocked(@NonNull Chat chat, String currentUserId) {
        for (FirebaseUser firebaseUser : chat.getParticipants()) {
            if (!firebaseUser.getUserId().equals(currentUserId)) {
                if (chat.getType() == Chat.Type.PRIVATE) {
                    return firebaseUser.isBlock();
                }
            }
        }
        return false;
    }


    @Nullable
    public static FirebaseUser getOtherChatUser(Chat chat, String currentUserId) {
        for (FirebaseUser participant : chat.getParticipants()) {
            if (!participant.getUserId().equals(currentUserId)) {
                return participant;
            }
        }
        return null;
    }

    public static String formatCurrency(Object object) {
        return NumberFormat.getNumberInstance().format(object);
    }

    public static String concatStrLists(String delimiter, List<? extends List<String>> strLists) {
        StringJoiner strJoiner = new StringJoiner(delimiter);
        for (List<String> strList : strLists) {
            if (CollectionUtils.isEmpty(strList)) {
                continue;
            }

            strList.forEach(strJoiner::add);
        }
        return strJoiner.toString();
    }

    public static double bytesToMB(long bytes) {
        return (double) bytes / (1024 * 1024);
    }
}
