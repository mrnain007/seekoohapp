package com.jeuxdevelopers.seekooh.models.pagination;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.paging.PagingState;
import androidx.paging.rxjava3.RxPagingSource;

import com.jeuxdevelopers.seekooh.network.SeekoohService;
import com.jeuxdevelopers.seekooh.network.ServiceUtils;
import com.jeuxdevelopers.seekooh.repos.listing.ListingRepo;
import com.jeuxdevelopers.seekooh.utils.NetworkUtils;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class TuitionListingRxPagingSource extends RxPagingSource<Integer, Object> {
    private static final String TAG = "TuitionListingRxPagingS";
    private final ListingRepo listingRepo;
    private final CompositeDisposable disposables;

    private final String search;
    private final Boolean isOnline;
    private final Integer cityId;
    private final Integer genderId;
    private final List<Integer> subjectIds;
    private final List<Integer> gradeIds;
    private final List<Integer> boardExamIds;

    public TuitionListingRxPagingSource(ListingRepo listingRepo, CompositeDisposable disposables, String search, Boolean isOnline, Integer cityId, Integer genderId, List<Integer> subjectIds, List<Integer> gradeIds, List<Integer> boardExamIds) {
        this.listingRepo = listingRepo;
        this.disposables = disposables;
        this.search = search;
        this.isOnline = isOnline;
        this.cityId = cityId;
        this.genderId = genderId;
        this.subjectIds = subjectIds;
        this.gradeIds = gradeIds;
        this.boardExamIds = boardExamIds;
    }

    @NonNull
    @Override
    public Single<LoadResult<Integer, Object>> loadSingle(@NonNull LoadParams<Integer> params) {
        int pageNumber = params.getKey() != null ? params.getKey() : 1;
        int pageSize = params.getLoadSize();
        Log.e(TAG, "loadSingle: pageNumber: " + pageNumber + " pageSize: " + pageSize);

        return ServiceUtils.createSeekoohService(SeekoohService.class)
                .getTuitionListings(pageNumber, pageSize, search, isOnline, cityId, genderId, subjectIds, gradeIds, boardExamIds)
                .map(getTuitionsListingResponse -> {
                    if (NetworkUtils.isValidResponse(getTuitionsListingResponse)) {
                        return getTuitionsListingResponse.getData();
                    } else {
                        throw new Exception(getTuitionsListingResponse.getMessage("Failed to fetch tuitions list."));
                    }
                }).map(listSeekoohResponse -> {
                    return toLoadResult(listSeekoohResponse
                            .stream()
                            .map(tuitionListing -> (Object) tuitionListing)
                            .collect(Collectors.toList()), pageNumber, pageSize);
                }).delay(500, TimeUnit.MILLISECONDS)
                .onErrorReturn(throwable -> {
                    String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch tuitions list.");
                    return new LoadResult.Error<>(new Exception(errorMsg));
                }).subscribeOn(Schedulers.io());
    }

    @Nullable
    @Override
    public Integer getRefreshKey(@NonNull PagingState<Integer, Object> pagingState) {
        return null;
    }

    private LoadResult<Integer, Object> toLoadResult(List<Object> dataList, int pageNumber,
                                                     int pageSize) {
        // Convert the list of data into a LoadResult object
        boolean hasMore = dataList.size() == pageSize;
        Integer nextKey = hasMore ? pageNumber + 1 : null;
        Integer prevKey = pageNumber == 1 ? null : pageNumber - 1;
        return new LoadResult.Page<>(dataList, prevKey, nextKey);
    }
}

