package com.jeuxdevelopers.seekooh.ui.shared.views.stepview;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.GridLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.StepViewLayoutBinding;

import java.util.ArrayList;
import java.util.List;

public class StepView extends FrameLayout {

    private StepViewLayoutBinding binding;
    private List<StepViewItem> stepViewItemList = new ArrayList<>();
    private boolean isActiveInclusive;
    private int columnCount;

    public StepView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        setAttrs(context, attrs);
        init(context, attrs);
    }

    public StepView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setAttrs(context, attrs);
        init(context, attrs);
    }

    private void setAttrs(Context context, AttributeSet attrs) {
        TypedArray typedArray = context.getTheme().obtainStyledAttributes(attrs, R.styleable.step_view, 0, 0);

        isActiveInclusive = typedArray.getBoolean(R.styleable.step_view_sv_active_inclusive, true);
        columnCount = typedArray.getInteger(R.styleable.step_view_sv_columns, 2);
        typedArray.recycle();
    }

    private void init(Context context, AttributeSet attrs) {
        binding = StepViewLayoutBinding.inflate(LayoutInflater.from(context), this, true);
        binding.gridLayout.setColumnCount(columnCount);
        setClickable(true);
        setFocusable(true);
        setSteps("Subjects & Grades", "Location", "Specifics", "Other Details");
        setActiveStep(1);
    }

    public void setSteps(String... steps) {
        stepViewItemList.clear();
        binding.gridLayout.removeAllViewsInLayout();

        int count = 0;
        for (String step : steps) {
            StepViewItem stepViewItem = new StepViewItem(getContext(), count + 1, step);
            stepViewItemList.add(stepViewItem);

            GridLayout.LayoutParams params = new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            binding.gridLayout.addView(stepViewItem, params);
            count++;
        }
    }

    public void setActiveStep(int stepNumber) {
        if (stepNumber > stepViewItemList.size()) {
            return;
        }
        if (isActiveInclusive) {
            for (int i = 0; i < stepViewItemList.size(); i++) {
                stepViewItemList.get(i).setActive(i <= (stepNumber - 1));
            }
        } else {
            for (int i = 0; i < stepViewItemList.size(); i++) {
                stepViewItemList.get(i).setActive(i < (stepNumber - 1));
            }
        }
    }

    public void setColumnCount(int columns) {
        binding.gridLayout.setColumnCount(columns);
    }
}
