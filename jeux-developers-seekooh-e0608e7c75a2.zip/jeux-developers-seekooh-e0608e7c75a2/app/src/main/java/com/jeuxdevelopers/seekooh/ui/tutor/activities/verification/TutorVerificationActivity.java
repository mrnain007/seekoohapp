package com.jeuxdevelopers.seekooh.ui.tutor.activities.verification;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.NavGraph;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityTutorVerificationBinding;
import com.jeuxdevelopers.seekooh.models.dto.VerificationStatusResponse;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.tutor.fragments.verification.TutorVerificationDocumentFragment;
import com.jeuxdevelopers.seekooh.ui.tutor.fragments.verification.TutorVerificationViewModel;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.PrefsUtils;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class TutorVerificationActivity extends AppCompatActivity {

    private ActivityTutorVerificationBinding binding;
    private TutorVerificationViewModel viewModel;
    private NavController navController;
    private WaitingDialog waitingDialog;
    private VerificationStatusResponse statusData;
    private boolean isResubmission = false;
    private boolean firstTime = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTutorVerificationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        firstTime = getIntent().getBooleanExtra("firstTime", false);
        viewModel = new ViewModelProvider(this).get(TutorVerificationViewModel.class);
        initNavController();
        initViews();
        initObservers();
        fetchData();
    }

    private void fetchData() {
        viewModel.getTutorVerificationStatus();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(this);
    }

    private void initNavController() {
        final NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_container_view);
        navController = navHostFragment.getNavController();
    }

    private void initObservers() {
        viewModel.verificationStatusLiveData
                .observe(this, verificationStatusResponse -> {
                    switch (verificationStatusResponse.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(this, verificationStatusResponse.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(verificationStatusResponse.getMessage());
                            break;
                        case SUCCESS:
                            statusData = verificationStatusResponse.getData();
                            String status = statusData.getStatus();
                            isResubmission = status.equals(Constants.UserVerificationStatus.RESUBMISSION_REQUESTED.name());
                            initFragment();
                            waitingDialog.dismiss();
                            break;
                    }
                });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (PrefsUtils.getBoolean(this,Constants.FIRST_TIME, false)) {
            PrefsUtils.putBoolean(this, Constants.FIRST_TIME, false);
            startActivity(new Intent(this, MainActivity.class));
            finishAffinity();
        } else {
            finish();
        }
    }

    private void initFragment() {
        NavGraph navGraph = navController.getNavInflater().inflate(R.navigation.tutor_verification_navigation);
        String status = statusData.getStatus();
        Bundle args = new Bundle();
        if (status.equals(Constants.UserVerificationStatus.DOCUMENTS_REQUIRED.name())) {
            navGraph.setStartDestination(R.id.tutorVerifyNowFragment);
        } else if (status.equals(Constants.UserVerificationStatus.PAYMENT_PENDING.name())) {
            navGraph.setStartDestination(R.id.tutorVerificationPaymentFragment);
        } else if (status.equals(Constants.UserVerificationStatus.RESUBMISSION_REQUESTED.name())) {
            args.putBoolean(Constants.UserVerificationStatus.RESUBMISSION_REQUESTED.name(), true);
            navGraph.setStartDestination(R.id.tutorVerificationDocumentFragment);
        } else if (status.equals(Constants.UserVerificationStatus.UNDER_REVIEW.name())
                || status.equals(Constants.UserVerificationStatus.VERIFICATION_COMPLETE.name())) {
            navGraph.setStartDestination(R.id.tutorVerificationStatusFragment);
        }
        navController.setGraph(navGraph, args);
    }
}