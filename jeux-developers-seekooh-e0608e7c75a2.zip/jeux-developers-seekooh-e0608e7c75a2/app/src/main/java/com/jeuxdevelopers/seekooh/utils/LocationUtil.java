package com.jeuxdevelopers.seekooh.utils;

public class LocationUtil {
    private android.location.Location currentLocation;
}
