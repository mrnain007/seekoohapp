package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TeachingJobApplicationRequest {
    @SerializedName("coverLetter")
    @Expose
    private String coverLetter;

    public TeachingJobApplicationRequest() {
    }

    public TeachingJobApplicationRequest(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    private TeachingJobApplicationRequest(Builder builder) {
        setCoverLetter(builder.coverLetter);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getCoverLetter() {
        return coverLetter;
    }

    public void setCoverLetter(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    public static final class Builder {
        private String coverLetter;

        private Builder() {
        }

        public Builder coverLetter(String coverLetter) {
            this.coverLetter = coverLetter;
            return this;
        }

        public TeachingJobApplicationRequest build() {
            return new TeachingJobApplicationRequest(this);
        }
    }
}
