package com.jeuxdevelopers.seekooh.repos.app;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Course;
import com.jeuxdevelopers.seekooh.models.CourseListing;
import com.jeuxdevelopers.seekooh.models.CourseReview;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.InstituteDetails;
import com.jeuxdevelopers.seekooh.models.InstituteListing;
import com.jeuxdevelopers.seekooh.models.InstituteReview;
import com.jeuxdevelopers.seekooh.models.InstituteType;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.SalaryType;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TeachingJob;
import com.jeuxdevelopers.seekooh.models.TeachingJobListing;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.TutorDetails;
import com.jeuxdevelopers.seekooh.models.TutorReview;
import com.jeuxdevelopers.seekooh.models.dto.AdSettingsResponse;
import com.jeuxdevelopers.seekooh.models.dto.CourseEnrollmentResponse;
import com.jeuxdevelopers.seekooh.models.dto.CreateCourseRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateCourseReviewRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateInstituteReviewRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateTeachingJobRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateTuitionRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateTutorReviewRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditCourseRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditPrivacySettingsRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditTeachingJobRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditTuitionRequest;
import com.jeuxdevelopers.seekooh.models.dto.GetProfileResponse;
import com.jeuxdevelopers.seekooh.models.dto.PrivacySettingsResponse;
import com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationRequest;
import com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationRequest;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationResponse;
import com.jeuxdevelopers.seekooh.models.dto.UpdateInstituteProfileRequest;
import com.jeuxdevelopers.seekooh.models.dto.UpdateStudentProfileRequest;
import com.jeuxdevelopers.seekooh.models.dto.UpdateTutorProfileRequest;
import com.jeuxdevelopers.seekooh.models.dto.VerificationFeeResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenRequest;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationStatusResponse;

import java.net.URI;
import java.util.List;

import io.reactivex.rxjava3.core.Observable;
import retrofit2.http.Body;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface AppRepo {
    Observable<Resource<List<Board>>> getBoards();

    Observable<Resource<List<City>>> getCities();

    Observable<Resource<List<Grade>>> getGrades();

    Observable<Resource<List<Subject>>> getSubjects();

    Observable<Resource<List<InstituteType>>> getInstituteTypes();

    Observable<Resource<List<SalaryType>>> getSalaryTypes();

    Observable<Resource<TutorDetails>> getTutorDetails(@NonNull Integer tutorId);

    Observable<Resource<List<TutorReview>>> getTutorReviews(@Path("tutorId") @NonNull Integer tutorId);

    Observable<Resource<TutorReview>> createTutorReview(@NonNull Integer tutorId, @NonNull CreateTutorReviewRequest createTutorReviewRequest);

    Observable<Resource<GetProfileResponse>> getProfile();

    Observable<Resource<GetProfileResponse>> updateStudentProfile(@Nullable URI studentProfileImageUri, @NonNull UpdateStudentProfileRequest updateStudentProfileRequest);

    Observable<Resource<GetProfileResponse>> updateTutorProfile(@Nullable URI tutorProfileImageUri, @Nullable URI tutorProfileVideoUri, @NonNull UpdateTutorProfileRequest updateTutorProfileRequest);

    Observable<Resource<GetProfileResponse>> updateInstituteProfile(@Nullable URI instituteProfileImageUri, @NonNull UpdateInstituteProfileRequest updateInstituteProfileRequest);

    Observable<Resource<Tuition>> createTuition(@NonNull CreateTuitionRequest createTuitionRequest);

    Observable<Resource<Tuition>> getTuitionById(@Path("tuitionId") @NonNull Integer tuitionId);

    Observable<Resource<List<Tuition>>> getMyTuitions();

    Observable<Resource<Tuition>> editTuition(@Path("tuitionId") @NonNull Integer tuitionId, @NonNull EditTuitionRequest editTuitionRequest);

    Observable<Resource<Void>> deleteTuition(@Path("tuitionId") @NonNull Integer tuitionId);

    Observable<Resource<TuitionApplicationResponse>> applyToTuition(@NonNull Integer tuitionId, @NonNull TuitionApplicationRequest tuitionApplicationRequest);

    Observable<Resource<Void>> deleteTuitionApplication(@Path("tuitionId") @NonNull Integer tuitionId);

    Observable<Resource<List<TuitionApplicationResponse>>> getAppliedTuitions();

    Observable<Resource<Course>> createCourse(@NonNull CreateCourseRequest createCourseRequest);

    Observable<Resource<List<Course>>> getMyCourses();

    Observable<Resource<Course>> editCourse(@NonNull Integer courseId, @NonNull EditCourseRequest editCourseRequest);

    Observable<Resource<Void>> deleteCourse(@NonNull Integer courseId);

    Observable<Resource<Course>> getCourseDetailsById(@NonNull Integer courseId);

    Observable<Resource<CourseListing>> getCourseListingDetails(@NonNull Integer courseId);

    Observable<Resource<CourseReview>> createCoursesReview(@NonNull Integer courseId, @NonNull CreateCourseReviewRequest createCourseReviewRequest);

    Observable<Resource<List<CourseReview>>> getCourseReviews(@NonNull Integer courseId);

    Observable<Resource<CourseEnrollmentResponse>> courseEnrollment(@NonNull Integer courseId);

    Observable<Resource<VerificationStatusResponse>> submitTutorVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI degreeUri);

    Observable<Resource<VerificationStatusResponse>> resubmitTutorVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI degreeUri);

    Observable<Resource<VerificationStatusResponse>> getTutorVerificationStatus();

    Observable<Resource<VerificationPaymentTokenResponse>> getTutorVerificationPaymentToken(@NonNull VerificationPaymentTokenRequest verificationPaymentTokenRequest);

    Observable<Resource<VerificationFeeResponse>> getTutorVerificationFee();

    Observable<Resource<VerificationStatusResponse>> submitInstituteVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI proofDocUri);

    Observable<Resource<VerificationStatusResponse>> resubmitInstituteVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI proofDocUri);

    Observable<Resource<VerificationStatusResponse>> getInstituteVerificationStatus();

    Observable<Resource<VerificationPaymentTokenResponse>> getInstituteVerificationPaymentToken(@NonNull VerificationPaymentTokenRequest verificationPaymentTokenRequest);

    Observable<Resource<VerificationFeeResponse>> getInstituteVerificationFee();

    Observable<Resource<InstituteDetails>> getInstituteListingDetails(@NonNull Integer instituteId);

    Observable<Resource<List<InstituteReview>>> getInstituteReviews(@NonNull Integer instituteId);

    Observable<Resource<InstituteReview>> createInstituteReview(@NonNull Integer instituteId, @NonNull CreateInstituteReviewRequest createInstituteReviewRequest);

    Observable<Resource<TeachingJob>> createTeachingJob(@NonNull CreateTeachingJobRequest createTeachingJobRequest);

    Observable<Resource<TeachingJob>> editTeachingJob(@NonNull Integer jobId, @NonNull EditTeachingJobRequest editTeachingJobRequest);

    Observable<Resource<Void>> deleteTeachingJob(@NonNull Integer jobId);

    Observable<Resource<TeachingJob>> getTeachingJobById(@Path("jobId") @NonNull Integer jobId);

    Observable<Resource<List<TeachingJob>>> getMyTeachingJobs();

    Observable<Resource<TeachingJobApplicationResponse>> applyToTeachingJob(@NonNull Integer jobId, @NonNull TeachingJobApplicationRequest jobApplicationRequest);

    Observable<Resource<Void>> deleteJobApplication(@Path("jobId") @NonNull Integer jobId);

    Observable<Resource<List<TeachingJobApplicationResponse>>> getAppliedTeachingJobs();

    Observable<Resource<List<TuitionApplicationResponse>>> getTuitionApplications(@Path("tuitionId") @NonNull Integer tuitionId);

    Observable<Resource<List<TeachingJobApplicationResponse>>> getJobApplications(@Path("jobId") @NonNull Integer jobId);

    Observable<Resource<List<CourseEnrollmentResponse>>> getCourseEnrollments(@Path("courseId") @NonNull Integer courseId);

    Observable<Resource<AdSettingsResponse>> getAdSettings();

    Observable<Resource<PrivacySettingsResponse>> getPrivacySettings();

    Observable<Resource<PrivacySettingsResponse>> editPrivacySettings(@NonNull EditPrivacySettingsRequest editPrivacySettingsRequest);
}
