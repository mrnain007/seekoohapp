package com.jeuxdevelopers.seekooh.ui.shared.fragments.notifications.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.paging.PagingDataAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.ItemListingAdBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemNotificationBinding;
import com.jeuxdevelopers.seekooh.models.AdModel;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Notification;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.updates.UpdatedAdModel;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class NotificationAdapter extends PagingDataAdapter<Object, RecyclerView.ViewHolder> {
    private List<Integer> bgColorList = new ArrayList<>();

    private final Listener listener;
    private static int adPosition = 0;
    private static final DiffUtil.ItemCallback<Object> DIFF_CALLBACK = new DiffUtil.ItemCallback<Object>() {
        @Override
        public boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof Notification && newItem instanceof Notification) {
                return ((Notification) oldItem).getId().equals(((Notification) newItem).getId());
            }
            return false;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof Notification && newItem instanceof Notification) {
                return ((Notification) oldItem).equals(((Notification) newItem));
            }
            return false;
        }
    };

    public NotificationAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
        initBgColors();
    }

    private void initBgColors() {
        bgColorList.add(R.color.alice_blue);
        bgColorList.add(R.color.lemon_Chiffon);
        bgColorList.add(R.color.lavender_blush);
    }

    @Override
    public int getItemViewType(int position) {
        int itemCount = getItemCount();

        if (position < getItemCount()) {
            Object object = getItem(position);
            if (object instanceof AdModel) {
                return ViewType.AD_VIEW.ordinal();
            }
            return ViewType.NORMAL_VIEW.ordinal();
        }
        return ViewType.LOADING_VIEW.ordinal();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == ViewType.AD_VIEW.ordinal()) {
            ItemListingAdBinding itemListingAdBinding = ItemListingAdBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new AdViewHolder(itemListingAdBinding);
        }
        ItemNotificationBinding binding = ItemNotificationBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new NotificationViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof NotificationViewHolder) {
            NotificationViewHolder notificationViewHolder = ((NotificationViewHolder) holder);

            notificationViewHolder.bind(getItem(position));

            Context context = notificationViewHolder.binding.getRoot().getContext();
            notificationViewHolder.binding.getRoot().setCardBackgroundColor(ContextCompat.getColor(context, bgColorList.get(new Random().nextInt(bgColorList.size()))));

            if (getItem(position) instanceof Notification) {
                notificationViewHolder.binding.getRoot().setOnClickListener(v -> {
                    listener.onItemClicked(position, (Notification) getItem(position));
                });
            }
        } else if (holder instanceof AdViewHolder) {
            AdViewHolder adViewHolder = ((AdViewHolder) holder);
            adViewHolder.bind(getItem(position));
        }
    }

    public static class NotificationViewHolder extends RecyclerView.ViewHolder {
        private final ItemNotificationBinding binding;

        public NotificationViewHolder(ItemNotificationBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(Object model) {
            if (!(model instanceof Notification)) {
                return;
            }
            Notification data = (Notification) model;
            if (!TextUtils.isEmpty(data.getImageUrl())) {
                Glide.with(binding.getRoot()
                                .getContext())
                        .load(data.getImageUrl())
                        .placeholder(R.drawable.profile_image_placeholder)
                        .into(binding.img);
                binding.profileImgFl.setVisibility(View.VISIBLE);
            } else {
                binding.profileImgFl.setVisibility(View.GONE);
            }

            binding.titleTv.setText(data.getTitle());
            binding.timeTv.setText(Utils.getPrettyTime(data.getCreatedAt()));
            binding.bodyTv.setText(data.getBody());
        }
    }

    public static class AdViewHolder extends RecyclerView.ViewHolder {
        private final ItemListingAdBinding binding;

        public AdViewHolder(ItemListingAdBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Object model) {
            if (model instanceof AdModel) {
                AdModel adModel = (AdModel) model;
                if (adPosition >= App.updatedAdModelList.size()) {
                    adPosition = 0;
                }
                try {
                    UpdatedAdModel updatedAdModel = App.updatedAdModelList.get(adPosition++);
                    if (updatedAdModel.getBannerImage() != null) {
                        Glide.with(binding.getRoot().getContext()).load(updatedAdModel.getBannerImage()).into(binding.getRoot());
                    }
                    if (updatedAdModel.getUrl() != null) {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = updatedAdModel.getUrl();
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    } else {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = "https://www.seekooh.com";
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    }
                } catch (Exception e) {
                    Log.e("TAG", "bind: ", e);
                }
            }
        }
    }

    public interface Listener {
        void onItemClicked(int position, Notification notification);
    }

    public enum ViewType {
        LOADING_VIEW, NORMAL_VIEW, AD_VIEW
    }
}
