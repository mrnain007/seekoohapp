package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PrivacySettingsResponse {
    @SerializedName("phoneVisibility")
    @Expose
    private Boolean phoneVisibility;

    public PrivacySettingsResponse() {
    }

    public PrivacySettingsResponse(Boolean phoneVisibility) {
        this.phoneVisibility = phoneVisibility;
    }

    public Boolean getPhoneVisibility() {
        return phoneVisibility;
    }

    public void setPhoneVisibility(Boolean phoneVisibility) {
        this.phoneVisibility = phoneVisibility;
    }
}
