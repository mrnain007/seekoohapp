package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

public class TutorProfile {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("reviewCount")
    @Expose
    private Integer reviewCount;
    @SerializedName("profileImageUrl")
    @Expose
    private String profileImageUrl;
    @SerializedName("profileVideoUrl")
    @Expose
    private String profileVideoUrl;
    @SerializedName("tagLine")
    @Expose
    private String tagLine;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("isVerified")
    @Expose
    private Boolean isVerified;
    @SerializedName("teachOnline")
    @Expose
    private Boolean teachOnline;
    @SerializedName("teachAtLocation")
    @Expose
    private Boolean teachAtLocation;
    @SerializedName("city")
    @Expose
    private City city;
    @SerializedName("address")
    @Expose
    private Address address;
    @SerializedName("qualifications")
    @Expose
    private List<Qualification> qualifications;
    @SerializedName("experiences")
    @Expose
    private List<Experience> experiences;
    @SerializedName("teachesSubjects")
    @Expose
    private List<Subject> teachesSubjects;
    @SerializedName("teachesClasses")
    @Expose
    private List<Grade> teachesClasses;
    @SerializedName("teachesBoardExams")
    @Expose
    private List<Board> teachesBoardExams;
    @SerializedName("timeSlots")
    @Expose
    private List<TutorTimeSlot> timeSlots;
    @SerializedName("availableDays")
    @Expose
    private List<DayOfWeek> availableDays;

    public TutorProfile() {
    }

    public TutorProfile(Integer id, Double rating, Integer reviewCount, String profileImageUrl, String profileVideoUrl, String tagLine, String description, Boolean isVerified, Boolean teachOnline, Boolean teachAtLocation, City city, Address address, List<Qualification> qualifications, List<Experience> experiences, List<Subject> teachesSubjects, List<Grade> teachesClasses, List<Board> teachesBoardExams, List<TutorTimeSlot> timeSlots, List<DayOfWeek> availableDays) {
        this.id = id;
        this.rating = rating;
        this.reviewCount = reviewCount;
        this.profileImageUrl = profileImageUrl;
        this.profileVideoUrl = profileVideoUrl;
        this.tagLine = tagLine;
        this.description = description;
        this.isVerified = isVerified;
        this.teachOnline = teachOnline;
        this.teachAtLocation = teachAtLocation;
        this.city = city;
        this.address = address;
        this.qualifications = qualifications;
        this.experiences = experiences;
        this.teachesSubjects = teachesSubjects;
        this.teachesClasses = teachesClasses;
        this.teachesBoardExams = teachesBoardExams;
        this.timeSlots = timeSlots;
        this.availableDays = availableDays;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProfileImageUrl() {
        return profileImageUrl;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

    public String getProfileVideoUrl() {
        return profileVideoUrl;
    }

    public void setProfileVideoUrl(String profileVideoUrl) {
        this.profileVideoUrl = profileVideoUrl;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Integer getReviewCount() {
        return reviewCount;
    }

    public void setReviewCount(Integer reviewCount) {
        this.reviewCount = reviewCount;
    }

    public String getTagLine() {
        return tagLine;
    }

    public void setTagLine(String tagLine) {
        this.tagLine = tagLine;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getVerified() {
        return isVerified;
    }

    public void setVerified(Boolean verified) {
        isVerified = verified;
    }

    public Boolean getTeachOnline() {
        return teachOnline;
    }

    public void setTeachOnline(Boolean teachOnline) {
        this.teachOnline = teachOnline;
    }

    public Boolean getTeachAtLocation() {
        return teachAtLocation;
    }

    public void setTeachAtLocation(Boolean teachAtLocation) {
        this.teachAtLocation = teachAtLocation;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public List<Qualification> getQualifications() {
        return qualifications;
    }

    public void setQualifications(List<Qualification> qualifications) {
        this.qualifications = qualifications;
    }

    public List<Experience> getExperiences() {
        return experiences;
    }

    public void setExperiences(List<Experience> experiences) {
        this.experiences = experiences;
    }

    public List<Subject> getTeachesSubjects() {
        return teachesSubjects;
    }

    public void setTeachesSubjects(List<Subject> teachesSubjects) {
        this.teachesSubjects = teachesSubjects;
    }

    public List<Grade> getTeachesClasses() {
        return teachesClasses;
    }

    public void setTeachesClasses(List<Grade> teachesClasses) {
        this.teachesClasses = teachesClasses;
    }

    public List<Board> getTeachesBoardExams() {
        return teachesBoardExams;
    }

    public void setTeachesBoardExams(List<Board> teachesBoardExams) {
        this.teachesBoardExams = teachesBoardExams;
    }

    public List<TutorTimeSlot> getTimeSlots() {
        return timeSlots;
    }

    public void setTimeSlots(List<TutorTimeSlot> timeSlots) {
        this.timeSlots = timeSlots;
    }

    public List<DayOfWeek> getAvailableDays() {
        return availableDays;
    }

    public void setAvailableDays(List<DayOfWeek> availableDays) {
        this.availableDays = availableDays;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TutorProfile that = (TutorProfile) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (rating != null ? !rating.equals(that.rating) : that.rating != null) return false;
        if (reviewCount != null ? !reviewCount.equals(that.reviewCount) : that.reviewCount != null)
            return false;
        if (profileImageUrl != null ? !profileImageUrl.equals(that.profileImageUrl) : that.profileImageUrl != null)
            return false;
        if (profileVideoUrl != null ? !profileVideoUrl.equals(that.profileVideoUrl) : that.profileVideoUrl != null)
            return false;
        if (tagLine != null ? !tagLine.equals(that.tagLine) : that.tagLine != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null)
            return false;
        if (isVerified != null ? !isVerified.equals(that.isVerified) : that.isVerified != null)
            return false;
        if (teachOnline != null ? !teachOnline.equals(that.teachOnline) : that.teachOnline != null)
            return false;
        if (teachAtLocation != null ? !teachAtLocation.equals(that.teachAtLocation) : that.teachAtLocation != null)
            return false;
        if (city != null ? !city.equals(that.city) : that.city != null) return false;
        if (address != null ? !address.equals(that.address) : that.address != null) return false;
        if (qualifications != null ? !qualifications.equals(that.qualifications) : that.qualifications != null)
            return false;
        if (experiences != null ? !experiences.equals(that.experiences) : that.experiences != null)
            return false;
        if (teachesSubjects != null ? !teachesSubjects.equals(that.teachesSubjects) : that.teachesSubjects != null)
            return false;
        if (teachesClasses != null ? !teachesClasses.equals(that.teachesClasses) : that.teachesClasses != null)
            return false;
        if (teachesBoardExams != null ? !teachesBoardExams.equals(that.teachesBoardExams) : that.teachesBoardExams != null)
            return false;
        if (timeSlots != null ? !timeSlots.equals(that.timeSlots) : that.timeSlots != null)
            return false;
        return availableDays != null ? availableDays.equals(that.availableDays) : that.availableDays == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (rating != null ? rating.hashCode() : 0);
        result = 31 * result + (reviewCount != null ? reviewCount.hashCode() : 0);
        result = 31 * result + (profileImageUrl != null ? profileImageUrl.hashCode() : 0);
        result = 31 * result + (profileVideoUrl != null ? profileVideoUrl.hashCode() : 0);
        result = 31 * result + (tagLine != null ? tagLine.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (isVerified != null ? isVerified.hashCode() : 0);
        result = 31 * result + (teachOnline != null ? teachOnline.hashCode() : 0);
        result = 31 * result + (teachAtLocation != null ? teachAtLocation.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (address != null ? address.hashCode() : 0);
        result = 31 * result + (qualifications != null ? qualifications.hashCode() : 0);
        result = 31 * result + (experiences != null ? experiences.hashCode() : 0);
        result = 31 * result + (teachesSubjects != null ? teachesSubjects.hashCode() : 0);
        result = 31 * result + (teachesClasses != null ? teachesClasses.hashCode() : 0);
        result = 31 * result + (teachesBoardExams != null ? teachesBoardExams.hashCode() : 0);
        result = 31 * result + (timeSlots != null ? timeSlots.hashCode() : 0);
        result = 31 * result + (availableDays != null ? availableDays.hashCode() : 0);
        return result;
    }
}
