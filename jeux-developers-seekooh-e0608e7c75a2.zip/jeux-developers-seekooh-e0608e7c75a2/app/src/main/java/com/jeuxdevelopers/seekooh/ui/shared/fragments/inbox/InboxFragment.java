package com.jeuxdevelopers.seekooh.ui.shared.fragments.inbox;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.gson.Gson;
import com.jeuxdevelopers.seekooh.databinding.FragmentInboxBinding;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.chat.Chat;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;
import com.jeuxdevelopers.seekooh.ui.shared.activities.chat.ChatActivity;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.inbox.adapters.InboxAdapter;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Scheduler;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class InboxFragment extends Fragment implements InboxAdapter.Listener {

    private final CompositeDisposable disposables = new CompositeDisposable();

    private FragmentInboxBinding binding;
    private InboxAdapter inboxAdapter;
    private FirebaseFirestore firestore;
    private User user;
    private FirebaseUser myFb;

    @Override
    public void onDestroy() {
        disposables.dispose();
        super.onDestroy();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentInboxBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initHelpers();
        initRecycler();
    }

    private void initHelpers() {
        firestore = FirebaseFirestore.getInstance();
        user = UserPrefs.getUser(requireContext());
        if (user == null) {
            Utils.showToast(requireContext(), "Only Logged in user can access this.");
            return;
        }
        myFb = Utils.toFirebaseUser(user);
        initListener();
    }

    private void initListener() {
        CollectionReference conversationsRef = firestore.collection(Constants.Firebase.CHAT);

        Query query = conversationsRef
                .whereArrayContains(Constants.Firebase.PARTICIPANT_IDS, myFb.getUserId())
                .orderBy("updatedAt", Query.Direction.DESCENDING);

        query.addSnapshotListener((value, error) -> {
            if (error != null) {
                error.printStackTrace();
                return;
            }

            int size = value.size();

            List<Chat> chats = value.toObjects(Chat.class);
            disposables.add(filterEmptyChats(chats)
                    .subscribe(filteredChats -> {
                        inboxAdapter.submitList(filteredChats);
                    }, throwable -> {
                        Utils.showToast(requireContext(), throwable.getMessage());
                    }));
        });
    }

    private Single<List<Chat>> filterEmptyChats(List<Chat> chats) {
        return Single.fromCallable(() -> {
                    List<Chat> filteredChats = null;
                    try {
                        filteredChats = chats.stream()
                                .filter(chat -> chat.getLastMessage() != null)
                                .collect(Collectors.toList());
                        return filteredChats;
                    } catch (Exception e) {
                        throw new RuntimeException("Failed to filter empty chats " + e.getMessage());
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    private void initRecycler() {
        // Listing Rcv
        inboxAdapter = new InboxAdapter(requireContext(), this);
        binding.inboxRcv.setAdapter(inboxAdapter);
        inboxAdapter.submitList(new ArrayList<>());
    }

    @Override
    public void onItemClicked(int position, Chat chat) {

        // TODO : Fetch user from firebase
        Intent intent = new Intent(requireContext(), ChatActivity.class);
        intent.putExtra(Constants.Firebase.CHAT_ID, chat.getId());
        startActivity(intent);
    }
}