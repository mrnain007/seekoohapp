package com.jeuxdevelopers.seekooh.ui.tutor.fragments.jobs.adapters;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.paging.PagingDataAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.ItemJobListingBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemListingAdBinding;
import com.jeuxdevelopers.seekooh.models.AdModel;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TeachingJobListing;
import com.jeuxdevelopers.seekooh.models.updates.UpdatedAdModel;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class JobListingAdapter extends PagingDataAdapter<Object, RecyclerView.ViewHolder> {

    private final Listener listener;
    private static int adPosition = 0;
    private static final DiffUtil.ItemCallback<Object> DIFF_CALLBACK = new DiffUtil.ItemCallback<Object>() {
        @Override
        public boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof TeachingJobListing && newItem instanceof TeachingJobListing) {
                return ((TeachingJobListing) oldItem).getId().equals(((TeachingJobListing) newItem).getId());
            }
            return false;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof TeachingJobListing && newItem instanceof TeachingJobListing) {
                return ((TeachingJobListing) oldItem).equals(((TeachingJobListing) newItem));
            }
            return false;
        }
    };

    public JobListingAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        int itemCount = getItemCount();

        if (position < getItemCount()) {
            Object object = getItem(position);
            if (object instanceof AdModel) {
                return ViewType.AD_VIEW.ordinal();
            }
            return ViewType.NORMAL_VIEW.ordinal();
        }
        return ViewType.LOADING_VIEW.ordinal();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == ViewType.AD_VIEW.ordinal()) {
            ItemListingAdBinding itemListingAdBinding = ItemListingAdBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new AdViewHolder(itemListingAdBinding);
        }
        ItemJobListingBinding binding = ItemJobListingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new JobListingViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof JobListingViewHolder) {
            JobListingViewHolder jobListingViewHolder = ((JobListingViewHolder) holder);

            jobListingViewHolder.bind(getItem(position));
            if (getItem(position) instanceof TeachingJobListing) {
                jobListingViewHolder.binding.applyBtn.setOnClickListener(v -> {
                    listener.onItemClicked(position, (TeachingJobListing) getItem(position));
                });
            }
        } else if (holder instanceof AdViewHolder) {
            AdViewHolder adViewHolder = ((AdViewHolder) holder);
            adViewHolder.bind(getItem(position));
        }
    }

    public static class JobListingViewHolder extends RecyclerView.ViewHolder {
        private final ItemJobListingBinding binding;

        public JobListingViewHolder(ItemJobListingBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(Object model) {
            if (!(model instanceof TeachingJobListing)) {
                return;
            }
            TeachingJobListing data = (TeachingJobListing) model;
            Glide.with(binding.getRoot()
                            .getContext())
                    .load(data.getInstitute().getProfileImageUrl())
                    .placeholder(R.drawable.profile_image_placeholder)
                    .into(binding.profileImg);
            binding.userNameTv.setText(data.getInstitute().getNameOfInstitute());
            binding.postTimeTv.setText(Utils.getPrettyTime(data.getCreatedAt()));
            binding.descriptionTv.setText(data.getJobDescription());
            binding.classTypeTv.setText(data.getOnline() ? "Online classes" : "On-site classes");
            binding.subjectsValuesTv.setText(String.join(", ", Utils.toStringList(data.getSubjects(), Subject::getName)));
            binding.gradesValuesTv.setText(String.join(", ", Utils.toStringList(data.getGrades(), Grade::getName)));
//            binding.genderDetailsTv.setText(data.getTutorGender() != null ? data.getTutorGender().getName() : "Doesn't matter");
            binding.locationValuesTv.setText(data.getCity().getName());
            binding.verifiedTv.setVisibility(data.getVerifiedTutorsOnly() ? View.VISIBLE : View.GONE);
            binding.salaryTv.setText(Utils.formatCurrency(data.getSalaryAmount()));
            binding.qualificationTv.setText(data.getQualification().getDegreeCertName());
            binding.jobTypeTv.setText("Type: " + data.getContractType().name());
            binding.genderDetailsTv.setText("Gender: " + (data.getTutorGender() != null ? data.getTutorGender().getName() : "Doesn't matter"));
            binding.jobTitleTv.setText(data.getJobTitle());
            if (TextUtils.isEmpty(data.getLanguageSkills())) {
                binding.languageTv.setVisibility(View.GONE);
                binding.languageDetailsTv.setVisibility(View.GONE);
            } else {
                binding.languageDetailsTv.setText(data.getLanguageSkills());
                binding.languageTv.setVisibility(View.VISIBLE);
                binding.languageDetailsTv.setVisibility(View.VISIBLE);
            }

            if (TextUtils.isEmpty(data.getExpertise())) {
                binding.expertiseTv.setVisibility(View.GONE);
                binding.expertiseDetailsTv.setVisibility(View.GONE);
            } else {
                binding.expertiseDetailsTv.setText(data.getExpertise());
                binding.expertiseTv.setVisibility(View.VISIBLE);
                binding.expertiseDetailsTv.setVisibility(View.VISIBLE);
            }

            if (TextUtils.isEmpty(data.getExperience().getExpDetails())) {
                binding.experienceTv.setVisibility(View.GONE);
                binding.experienceDetailsTv.setVisibility(View.GONE);
            } else {
                binding.experienceDetailsTv.setText(data.getExperience().getExpDetails());
                binding.experienceTv.setVisibility(View.VISIBLE);
                binding.experienceDetailsTv.setVisibility(View.VISIBLE);
            }
        }
    }

    public static class AdViewHolder extends RecyclerView.ViewHolder {
        private final ItemListingAdBinding binding;

        public AdViewHolder(ItemListingAdBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Object model) {
            if (model instanceof AdModel) {
                AdModel adModel = (AdModel) model;
                if (adPosition >= App.updatedAdModelList.size()) {
                    adPosition = 0;
                }
                try {
                    UpdatedAdModel updatedAdModel = App.updatedAdModelList.get(adPosition++);
                    if (updatedAdModel.getBannerImage() != null) {
                        Glide.with(binding.getRoot().getContext()).load(updatedAdModel.getBannerImage()).into(binding.getRoot());
                    }
                    if (updatedAdModel.getUrl() != null) {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = updatedAdModel.getUrl();
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    } else {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = "https://www.seekooh.com";
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    }
                } catch (Exception e) {
                    Log.e("TAG", "bind: ", e);
                }
            }
        }
    }

    public interface Listener {
        void onItemClicked(int position, TeachingJobListing jobListing);
    }

    public enum ViewType {
        LOADING_VIEW, NORMAL_VIEW, AD_VIEW
    }
}
