package com.jeuxdevelopers.seekooh.firebase;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.RemoteViews;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.Gson;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.models.Notification;
import com.jeuxdevelopers.seekooh.ui.shared.activities.chat.ChatActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.splash.SplashActivity;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.NotificationUtils;
import com.jeuxdevelopers.seekooh.utils.PrefsUtils;

import java.util.Map;

public class FirebaseMessageReceiver extends FirebaseMessagingService {

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        PrefsUtils.putString(getApplicationContext(), Constants.Firebase.FCM_TOKEN, token);
    }

    // Override onMessageReceived() method to extract the
    // title and
    // body from the message passed in FCM
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // First case when notifications are received via
        // data event
        // Here, 'title' and 'message' are the assumed names
        // of JSON
        // attributes. Since here we do not have any data
        // payload, This section is commented out. It is
        // here only for reference purposes.
        if (remoteMessage.getData().size() > 0) {
            Map<String, String> map = remoteMessage.getData();
            String title = map.get("title");
            String message = map.get("body");
            String chatId = map.get("chatId");
            String type = map.get("type");
            String imageUrl = map.get("imageUrl");
            if (title != null) {
                Log.e("TAG", "onMessageReceived: " + title + " " + message + " " + chatId + " " + type + " " + imageUrl);
                FcmNotification fcmNotification = new FcmNotification();
                fcmNotification.setTitle(title);
                fcmNotification.setBody(message);
                fcmNotification.setChatId(chatId);
                fcmNotification.setType(Notification.Type.valueOf(type));
                fcmNotification.setImageUrl(imageUrl);
                showNotification(fcmNotification.getTitle(), fcmNotification.getBody(), fcmNotification.getImageUrl(), fcmNotification);
            } else {
                String fcmNotificationJson = remoteMessage.getData().get("Notification");
                if (fcmNotificationJson == null) {
                    Log.e("TAG", "onMessageReceived: " + "fcmNotificationJson is null");
                    return;
                }
                Log.e("TAG", "FCM: " + fcmNotificationJson);
                Gson gson = new Gson();
                FcmNotification fcmNotification = gson.fromJson(fcmNotificationJson, FcmNotification.class);
                showNotification(fcmNotification.getTitle(), fcmNotification.getBody(), fcmNotification.getImageUrl(), fcmNotification);
            }

//            String fcmNotificationJson = remoteMessage.getData().toString();
//            if (fcmNotificationJson == null) {
//                Log.e("TAG", "onMessageReceived: " + "fcmNotificationJson is null");
//                return;
//            }
//            Log.e("TAG", "FCM: " + fcmNotificationJson);
//            Gson gson = new Gson();
//            FcmNotification fcmNotification = gson.fromJson(fcmNotificationJson, FcmNotification.class);

        }
    }

    // Method to get the custom Design for the display of
    // notification.
    private RemoteViews getCustomDesign(String title, String message) {
        RemoteViews remoteViews = new RemoteViews(getApplicationContext().getPackageName(), R.layout.notification);
        remoteViews.setTextViewText(R.id.title, title);
        remoteViews.setTextViewText(R.id.message, message);
        remoteViews.setImageViewResource(R.id.icon, R.drawable.logo_clipart);
        return remoteViews;
    }

    // Method to display the notifications
    @SuppressLint("UnspecifiedImmutableFlag")
    public void showNotification(String title, String message, String imageUrl, FcmNotification fcmNotification) {
        // Pass the intent to switch to the MainActivity
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        Intent intent = null;
        if (fcmNotification.getType() == Notification.Type.UNREAD_MESSAGE) {
            String chatId = fcmNotification.getChatId();
            intent = new Intent(this, ChatActivity.class);
            intent.putExtra(Constants.Firebase.CHAT_ID, chatId);
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            mainActivityIntent.putExtra(Constants.GOTO_INBOX, "true");
            stackBuilder.addNextIntent(mainActivityIntent);
            stackBuilder.addNextIntent(intent);
        } else if (fcmNotification.getType() == Notification.Type.TUITION_MATCH) {
            Long tuitionId = fcmNotification.getTuitionId();
            intent = new Intent(this, MainActivity.class);
            intent.putExtra(Constants.SEARCH_TUITION_ID, tuitionId);
            stackBuilder.addNextIntent(intent);
        } else if (fcmNotification.getType() == Notification.Type.JOB_MATCH) {
            Long jobId = fcmNotification.getJobId();
            intent = new Intent(this, MainActivity.class);
            intent.putExtra(Constants.SEARCH_JOB_ID, jobId);
            stackBuilder.addNextIntent(intent);
        } else {
            intent = new Intent(this, SplashActivity.class);
            stackBuilder.addNextIntent(intent);
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = null;
        pendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), NotificationUtils.CHANNEL_ID)
                .setContentIntent(pendingIntent)
                .setSmallIcon(R.drawable.logo_clipart)
                .setAutoCancel(true)
                .setVibrate(new long[]{1000, 1000, 1000, 1000, 1000})
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH);
        android.app.Notification notification = builder.build();

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        NotificationChannel channel = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            channel = new NotificationChannel(NotificationUtils.CHANNEL_ID, NotificationUtils.CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
            notificationManager.notify(100, notification);
        }
    }
}
