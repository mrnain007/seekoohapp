package com.jeuxdevelopers.seekooh.ui.student.fragments.profile;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.dto.GetProfileResponse;
import com.jeuxdevelopers.seekooh.models.dto.UpdateStudentProfileRequest;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.net.URI;
import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class StudentProfileViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<GetProfileResponse>> getProfileLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Board>>> getBoardsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<City>>> getCitiesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Grade>>> getGradesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<GetProfileResponse>> updateStudentProfileLiveData = new MutableLiveData<>();

    public StudentProfileViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getProfile() {
        disposables.add(appRepo.getProfile()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(profileResponseResource -> {
                    getProfileLiveData.setValue(profileResponseResource);
                }, throwable -> {
                    getProfileLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getBoards() {
        disposables.add(appRepo.getBoards()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getBoardsResponseResource -> {
                    getBoardsLiveData.setValue(getBoardsResponseResource);
                }, throwable -> {
                    getBoardsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getCities() {
        disposables.add(appRepo.getCities()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getCitiesResponseResource -> {
                    getCitiesLiveData.setValue(getCitiesResponseResource);
                }, throwable -> {
                    getCitiesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getGrades() {
        disposables.add(appRepo.getGrades()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getGradesResponseResource -> {
                    getGradesLiveData.setValue(getGradesResponseResource);
                }, throwable -> {
                    getGradesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void updateStudentProfile(URI studentProfileImageUri, UpdateStudentProfileRequest updateStudentProfileRequest) {
        disposables.add(appRepo.updateStudentProfile(studentProfileImageUri, updateStudentProfileRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(updateStudentProfileResource -> {
                    updateStudentProfileLiveData.setValue(updateStudentProfileResource);
                }, throwable -> {
                    updateStudentProfileLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
