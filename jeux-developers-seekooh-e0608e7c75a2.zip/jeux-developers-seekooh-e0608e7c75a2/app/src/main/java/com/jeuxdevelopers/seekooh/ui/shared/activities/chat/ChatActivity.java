package com.jeuxdevelopers.seekooh.ui.shared.activities.chat;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.appcompat.widget.PopupMenu;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.gson.Gson;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityChatBinding;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.chat.Chat;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;
import com.jeuxdevelopers.seekooh.models.chat.Message;
import com.jeuxdevelopers.seekooh.ui.shared.activities.chat.adapters.ChatAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class ChatActivity extends AppCompatActivity {

    private boolean isChatListenerEnabled = false;
    private boolean chatExist = false;

    private final CompositeDisposable disposables = new CompositeDisposable();

    private ActivityChatBinding binding;
    private ChatViewModel viewModel;
    private ChatAdapter chatAdapter;
    private WaitingDialog waitingDialog;
    private FirebaseFirestore firestore;
    private String chatId;
    private FirebaseUser otherUserFb;
    private FirebaseUser myFb;
    private User user;
    private Chat chat;
    private boolean isOtherUserBlocked, isCurrentUserBlocked;

    @Override
    protected void onDestroy() {
        disposables.dispose();
        super.onDestroy();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        viewModel = new ViewModelProvider(this).get(ChatViewModel.class);
        String checkedPreconditions = checkPreconditions();
        if (checkedPreconditions != null) {
            waitingDialog.showError(checkedPreconditions);
        }
        initHelpers();
        initViews();
        getArgs();
        initClickListeners();
        initRecycler();
        initObservers();

    }

    private void initObservers() {
        viewModel.createPrivateChatLiveData.observe(this, createPrivateChatResponse -> {
            switch (createPrivateChatResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(this, createPrivateChatResponse.getMessage());
                    break;
                case LOADING:
//                    waitingDialog.show(createPrivateChatResponse.getMessage());
                    break;
                case SUCCESS:
                    chatId = createPrivateChatResponse.getData();
                    waitingDialog.dismiss();
                    break;
            }
        });

        viewModel.createPrivateChatAndSendLiveData.observe(this, createPrivateChatAndMsgResponse -> {
            switch (createPrivateChatAndMsgResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(this, createPrivateChatAndMsgResponse.getMessage());
                    break;
                case LOADING:
//                    waitingDialog.show(createPrivateChatResponse.getMessage());
                    break;
                case SUCCESS:
                    chatId = createPrivateChatAndMsgResponse.getData();
                    waitingDialog.dismiss();
                    break;
            }
        });

        viewModel.sendMessageLiveData.observe(this, sendMsgResponse -> {
            switch (sendMsgResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(this, sendMsgResponse.getMessage());
                    break;
                case LOADING:
//                    waitingDialog.show(createPrivateChatResponse.getMessage());
                    break;
                case SUCCESS:
                    sendDeviceNotification(sendMsgResponse.getData());
                    binding.msgTl.getEditText().setText("");
                    waitingDialog.dismiss();
                    break;
            }
        });

        viewModel.markSeenLiveData.observe(this, markSeenResponse -> {
            switch (markSeenResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(this, markSeenResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    break;
            }
        });

        viewModel.userBlockLiveData.observe(this, userBlockResponse -> {
            switch (userBlockResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(this, userBlockResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    Utils.showToast(this, "This user has been blocked.");
                    break;
            }
        });
        viewModel.userUnBlockLiveData.observe(this, userBlockResponse -> {
            switch (userBlockResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(this, userBlockResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    Utils.showToast(this, "This user has been unBlocked.");
                    break;
            }
        });
    }

    private void sendDeviceNotification(Message data) {
        viewModel.sendNotification(this, chat, data);
    }

    private String checkPreconditions() {
        user = UserPrefs.getUser(this);
        if (user == null) {
            return "Current user null.";
        }
        myFb = Utils.toFirebaseUser(user);
        FirebaseFirestore.getInstance().collection(Constants.Firebase.USERS).document(myFb.getUserId()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                myFb.setFcm(documentSnapshot.get("fcm").toString());
            }
        });
        if (myFb == null) {
            return "Failure converting to firebase user.";
        }
        return null;
    }

    private void initHelpers() {
        firestore = FirebaseFirestore.getInstance();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(this, this::onBackPressed);
        initTextWatcher();
    }

    private void initTextWatcher() {
        binding.sendChatBtn.setEnabled(false);
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                validateInput();
            }
        };
        binding.msgTl.getEditText().addTextChangedListener(textWatcher);
    }

    private void validateInput() {
        String text = binding.msgTl.getEditText().getText().toString().trim();
        binding.sendChatBtn.setEnabled(!TextUtils.isEmpty(text));
//        binding.sendChatBtn.setClickable(!TextUtils.isEmpty(text));
    }

    private void getArgs() {
        chatId = getIntent().getStringExtra(Constants.Firebase.CHAT_ID);
        String firebaseUserJson = getIntent().getStringExtra(Constants.Firebase.FIREBASE_USER);

        if (chatId != null) {
            initMsgListener();
            initChatListener();
        } else if (firebaseUserJson != null) {
            otherUserFb = new Gson().fromJson(firebaseUserJson, FirebaseUser.class);
            chatId = Utils.combineIdChat(otherUserFb.getUserId(), myFb.getUserId());
            binding.userNameTv.setText(otherUserFb.getFullName());

            Log.i("CHAT_ACTIVITY", "chaId " + chatId + " | " + firebaseUserJson);

            initMsgListener();
            initChatListener();
        } else {
            waitingDialog.showError("Args null.");
        }


    }

    private void initChatListener() {
        firestore.collection(Constants.Firebase.CHAT).document(chatId)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        // if error occurred during listener init.
                        if (!isChatListenerEnabled) {
                            Utils.showToast(this, "Chat listener failed due to " + error.getMessage());
                            waitingDialog.showError(error.getMessage());
                        }
                        return;
                    }

                    if (value.exists()) {
                        chat = value.toObject(Chat.class);
                        if (!chat.getSeenBy().contains(myFb.getUserId())) {
                            viewModel.markSeen(chat.getId(), myFb.getUserId());
                        }
                        isChatListenerEnabled = true;
                        chatExist = true;
                        setData();
                    } else {
                        chatExist = false;
                        if (otherUserFb != null) {
                            viewModel.createPrivateChat(otherUserFb, myFb);
                        }
                    }
                });
    }

    private void setData() {
        binding.userNameTv.setText(Utils.getChatName(chat, myFb.getUserId()));
        isOtherUserBlocked = Utils.isOtherUserBlocked(chat, myFb.getUserId());
        isCurrentUserBlocked = Utils.isCurrentUserBlocked(chat, myFb.getUserId());
        Log.d("CHAT_ACTIVITY", "chaId " + chat);
    }

    /*private Single<String> createNewConversation() {
        return Single.fromCallable(() -> {
                    DocumentReference conversationRef = firestore.collection(Constants.Firebase.CHAT).document(Utils.combineIdChat(otherUserFb.getUserId(), myFb.getUserId()));

                    DocumentReference myProfileRef = firestore.collection(Constants.Firebase.USERS)
                            .document(myFb.getUserId());

                    DocumentReference otherUserRef = firestore.collection(Constants.Firebase.USERS).document(otherUserFb.getUserId());

                    Task<String> conversationTask = firestore.runTransaction(transaction -> {
                        boolean myProfileExist = transaction.get(myProfileRef).exists();
                        boolean otherUsrExist = transaction.get(otherUserRef).exists();

                        // If profile not exist create a new one.
                        if (!myProfileExist) {
                            myProfileRef.set(myFb);
                        }

                        // If profile not exist create a new one.
                        if (!otherUsrExist) {
                            otherUserRef.set(otherUserFb);
                        }

                        // Create new chat
                        Chat chatData = Chat.builder()
                                .id(conversationRef.getId())
                                .participants(Arrays.asList(otherUserFb.getUserId(), myFb.getUserId()))
                                .senderId(myFb.getUserId())
                                .senderName(myFb.getFullName())
                                .senderImgUrl(myFb.getProfileImgUrl())
                                .receiverId(otherUserFb.getUserId())
                                .receiverName(otherUserFb.getFullName())
                                .receiverImgUrl(otherUserFb.getProfileImgUrl())
                                .type(Chat.Type.PRIVATE)
                                .build();

                        conversationRef.set(chatData);

                        return conversationRef.getId();
                    });

                    String convId = Tasks.await(conversationTask);
                    if (!conversationTask.isSuccessful()) {
                        throw conversationTask.getException();
                    }

                    return convId;
                }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }*/

    private void initMsgListener() {
        firestore.collection(Constants.Firebase.MESSAGES)
                .whereEqualTo(Constants.Firebase.CHAT_ID, chatId)
                .orderBy(Constants.Firebase.CREATED_AT, Query.Direction.ASCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Utils.showToast(this, error.getMessage());
                        return;
                    }

                    List<Message> messages = value.toObjects(Message.class);
                    chatAdapter.submitList(messages, () -> {
                        binding.chatRcv.smoothScrollToPosition(chatAdapter.getItemCount());
                    });
                });
    }

    private void initClickListeners() {
        binding.backBtn.setOnClickListener(v -> onBackPressed());
        binding.sendChatBtn.setOnClickListener(v -> {
            if (isOtherUserBlocked) {
                Utils.showToast(ChatActivity.this, "You have blocked this contact. Please unblock it first.");
            } else if (isCurrentUserBlocked) {
                Utils.showToast(ChatActivity.this, "You have been blocked.");
            } else {

                DocumentReference msgRef = firestore.collection(Constants.Firebase.MESSAGES).document();
                String text = binding.msgTl.getEditText().getText().toString().trim();

                Message message = Message.builder()
                        .id(msgRef.getId())
                        .chatId(chatId)
                        .type(Message.Type.TEXT)
                        .content(text)
                        .senderId(myFb.getUserId())
                        .build();

                if (!chatExist) {
                    if (otherUserFb == null) {
                        waitingDialog.showError("Failed to create chat.");
                        return;
                    }
                    viewModel.createPrivateChatAndSend(otherUserFb, myFb, message);
                    return;
                }

                Log.i("Message", "Sending...");
                viewModel.sendMessage(message);

            }

        });

        binding.reportChatBtn.setOnClickListener(v -> {
            showPopup();
        });
    }

    private void showPopup() {
        ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(ChatActivity.this, R.style.role_popup_menu);
        PopupMenu popup = new PopupMenu(contextThemeWrapper, binding.reportChatBtn);
        popup.setGravity(Gravity.END);
        MenuItem menuItem;
        if (isOtherUserBlocked)
            menuItem = popup.getMenu().add(Menu.NONE, Menu.NONE, Menu.NONE, "Unblock");
        else menuItem = popup.getMenu().add(Menu.NONE, Menu.NONE, Menu.NONE, "Block");

        menuItem.setOnMenuItemClickListener(item -> {
            blockUser();
            return false;
        });

        popup.show();
    }

    private void blockUser() {
        if (chat != null) {
            List<FirebaseUser> list = chat.getParticipants();

            for (int index = 0; index < list.size(); index++) {
                FirebaseUser firebaseUser = list.get(index);

                if (!firebaseUser.getUserId().equals(myFb.getUserId())) {

                    // Return from the method to stop the iteration
                    if (isOtherUserBlocked) {
                        firebaseUser.setBlock(false);
                        list.set(index, firebaseUser);
                        viewModel.unBlockUser(list, chat.getId());
                    } else {
                        firebaseUser.setBlock(true);
                        list.set(index, firebaseUser);
                        viewModel.blockUser(list, chat.getId());
                    }

                    return;
                }
            }
        }
    }


    private Task<Boolean> sendMessage(Message message) {
        TaskCompletionSource<Boolean> taskCompletionSource = new TaskCompletionSource<>();

        firestore.collection(Constants.Firebase.MESSAGES).document(message.getId())
                .set(message)
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        taskCompletionSource.setException(task.getException());
                        return;
                    }
                    binding.msgTl.getEditText().setText("");
                    taskCompletionSource.setResult(true);
                });
        return taskCompletionSource.getTask();
    }

    private void initRecycler() {
        // Listing Rcv
        chatAdapter = new ChatAdapter(this);
        chatAdapter.submitList(new ArrayList<>());
        binding.chatRcv.setAdapter(chatAdapter);
    }
}