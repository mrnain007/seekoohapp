package com.jeuxdevelopers.seekooh.ui.tutor.fragments.courses.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.jeuxdevelopers.seekooh.databinding.ItemMyCoursesBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemMyTuitionsBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemTvMyTuitionsBinding;
import com.jeuxdevelopers.seekooh.models.Course;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.Locale;

public class PostedCoursesAdapter extends ListAdapter<Course, PostedCoursesAdapter.PostedTuitionViewHolder> {
    private static final DiffUtil.ItemCallback<Course> DIFF_CALLBACK = new DiffUtil.ItemCallback<Course>() {
        @Override
        public boolean areItemsTheSame(@NonNull Course oldItem, @NonNull Course newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Course oldItem, @NonNull Course newItem) {
            return oldItem.equals(newItem);
        }
    };

    private Listener listener;

    public PostedCoursesAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @NonNull
    @Override
    public PostedTuitionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemMyCoursesBinding binding = ItemMyCoursesBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new PostedTuitionViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PostedTuitionViewHolder holder, int position) {
        holder.bind(getItem(position));
        holder.binding.viewApplicantsBtn.setOnClickListener(v -> listener.onViewApplicantsBtnClicked(position));
        holder.binding.editBtn.setOnClickListener(v -> listener.onEditBtnClicked(position));
        holder.binding.deleteBtn.setOnClickListener(v -> listener.onDeleteBtnClicked(position));
    }

    public static class PostedTuitionViewHolder extends RecyclerView.ViewHolder {
        private final ItemMyCoursesBinding binding;

        public PostedTuitionViewHolder(ItemMyCoursesBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(Course model) {
            Context context = binding.getRoot().getContext();
            if (Utils.isDataNull(context, model)) {
                return;
            }
            /*switch (model.getStatus()) {
                case PENDING:
                    binding.tuitionStatusShortTv.setText("Pending Approval");
                    break;
                case APPROVED:
                    binding.tuitionStatusShortTv.setText("Approved");
                    binding.tuitionStatusLongTv.setText("Congratulations! Your request has been approved.");
                    break;
                case REJECTED:
                    binding.tuitionStatusShortTv.setText("Rejected");
                    binding.tuitionStatusLongTv.setText("Sorry, your request has been rejected.");
                    break;
                default:
                    binding.tuitionStatusShortTv.setText("Status NA");
                    binding.tuitionStatusLongTv.setText("Sorry, the status is currently unavailable due to an error.");
                    break;
            }*/
            binding.courseTitleTv.setText(model.getTitle());
            binding.startDateTv.setText("Starts: " + Utils.getFormattedDate(model.getStartDate()));
            binding.ratingBar.setRating(model.getRating().floatValue());
            binding.ratingCountTv.setText(model.getReviewCount() == 0 ? "(no ratings)" : "(" + model.getReviewCount() + ")");
            binding.enrolmentCountTv.setText("" + model.getEnrolmentCount() + " students enrolled");
        }
    }

    public interface Listener {
        void onViewApplicantsBtnClicked(int position);
        void onEditBtnClicked(int position);
        void onDeleteBtnClicked(int position);
    }
}
