package com.jeuxdevelopers.seekooh.ui.shared.fragments.settings;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.jeuxdevelopers.seekooh.databinding.FragmentSettingsBinding;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.ui.institute.activities.verification.InstituteVerificationActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.manualPayment.ManualPaymentActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.tuitions.AppliedTuitionsActivity;
import com.jeuxdevelopers.seekooh.ui.tutor.activities.verification.TutorVerificationActivity;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class SettingsFragment extends Fragment {

    private FragmentSettingsBinding binding;
    private NavController navController;
    private User user;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentSettingsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);
        initClickListeners();
        initRoleOptions();
        getArgs();
    }

    private void getArgs() {
        MainActivity mainActivity = (MainActivity) requireActivity();
        if (mainActivity.searchJobId != null) {
            navController.navigate(SettingsFragmentDirections.actionSettingsFragmentToJobsListingFragment());
        }
    }

    private void initRoleOptions() {
        user = UserPrefs.getUser(requireContext());
        if (user == null) {
            binding.appliedTuitionsBtn.setVisibility(View.GONE);
            binding.jobsBoardBtn.setVisibility(View.GONE);
            binding.getVerifiedBtn.setVisibility(View.GONE);
            binding.userProfileBtn.setVisibility(View.GONE);
            binding.accountSettingsBtn.setVisibility(View.GONE);
            return;
        }

        Role selectedRole = user.getAppSettings().getSelectedRole();
        switch (selectedRole.getName()) {
            case Constants.ROLE_STUDENT:
                binding.getVerifiedBtn.setVisibility(View.GONE);
                binding.jobsBoardBtn.setVisibility(View.GONE);
                binding.appliedTuitionsBtn.setVisibility(View.GONE);
                binding.accountPrivacyBtn.setVisibility(View.GONE);
                break;
            case Constants.ROLE_TUTOR:
                Boolean isTutorVerified = user.getTutorProfile().getVerified();
                binding.getVerifiedBtn.setVisibility(isTutorVerified ? View.GONE : View.VISIBLE);
                binding.sherePaymentSlip.setVisibility(isTutorVerified ? View.GONE : View.VISIBLE);
                binding.jobsBoardBtn.setVisibility(View.VISIBLE);
                binding.appliedTuitionsBtn.setVisibility(View.VISIBLE);
                binding.accountPrivacyBtn.setVisibility(View.VISIBLE);
                break;
            case Constants.ROLE_INSTITUTE:
                Boolean isInstituteVerified = user.getInstituteProfile().getVerified();
                binding.getVerifiedBtn.setVisibility(isInstituteVerified ? View.GONE : View.VISIBLE);
                binding.sherePaymentSlip.setVisibility(isInstituteVerified ? View.GONE : View.VISIBLE);
                binding.jobsBoardBtn.setVisibility(View.VISIBLE);
                binding.appliedTuitionsBtn.setVisibility(View.GONE);
                binding.accountPrivacyBtn.setVisibility(View.GONE);
                break;
        }
    }

    private void initClickListeners() {
        binding.accountSettingsBtn.setOnClickListener(v -> {
            navController.navigate(SettingsFragmentDirections.actionSettingsFragmentToAccountSettingsFragment());
        });
        binding.accountPrivacyBtn.setOnClickListener(v -> {
            navController.navigate(SettingsFragmentDirections.actionSettingsFragmentToAccountSettingsFragment());
        });
        binding.userProfileBtn.setOnClickListener(v -> {
            Role selectedRole = UserPrefs.getSelectedRole(requireContext());
            if (selectedRole != null) {
                switch (selectedRole.getName()) {
                    case Constants.ROLE_STUDENT:
                        navController.navigate(SettingsFragmentDirections.actionSettingsFragmentToStudentProfileFragment());
                        break;
                    case Constants.ROLE_TUTOR:
                        navController.navigate(SettingsFragmentDirections.actionSettingsFragmentToTutorProfileFragment());
                        break;
                    case Constants.ROLE_INSTITUTE:
                        navController.navigate(SettingsFragmentDirections.actionSettingsFragmentToInstituteProfileFragment());
                        break;
                }
            } else {
                Utils.showToast(requireContext(), "Please select current role from settings.");
            }
        });
        binding.accountPrivacyBtn.setOnClickListener(v -> {
            navController.navigate(SettingsFragmentDirections.actionSettingsFragmentToAccountPrivacyFragment());
        });
        binding.getVerifiedBtn.setOnClickListener(v -> {
            if (user == null) {
                Utils.showToast(requireContext(), "Only Logged in can access this.");
                return;
            }

            Role selectedRole = user.getAppSettings().getSelectedRole();
            switch (selectedRole.getName()) {
                case Constants.ROLE_TUTOR:
                    startActivity(new Intent(requireContext(), TutorVerificationActivity.class));
                    break;
                case Constants.ROLE_INSTITUTE:
                    startActivity(new Intent(requireContext(), InstituteVerificationActivity.class));
                    break;
            }
        });
        binding.sherePaymentSlip.setOnClickListener(v -> {
            if (user == null) {
                Utils.showToast(requireContext(), "Only Logged in can access this.");
                return;
            }

            Role selectedRole = user.getAppSettings().getSelectedRole();
            switch (selectedRole.getName()) {
                case Constants.ROLE_TUTOR:
                    startActivity(new Intent(requireContext(), ManualPaymentActivity.class));
                    break;
                case Constants.ROLE_INSTITUTE:
                    startActivity(new Intent(requireContext(), ManualPaymentActivity.class));
                    break;
            }
        });
        binding.helpBtn.setOnClickListener(v -> {
            navController.navigate(SettingsFragmentDirections.actionSettingsFragmentToHelpFragment());
        });
        binding.jobsBoardBtn.setOnClickListener(v -> {
            navController.navigate(SettingsFragmentDirections.actionSettingsFragmentToJobsListingFragment());
        });
        binding.appliedTuitionsBtn.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), AppliedTuitionsActivity.class));
        });
        binding.becomeStudentBtn.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AuthActivity.class);
            intent.putExtra(Constants.AUTH_ACTIVITY_MODE, AuthActivity.Mode.BECOME_STUDENT.name());
            startActivity(intent);
        });
        binding.becomeTutorBtn.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AuthActivity.class);
            intent.putExtra(Constants.AUTH_ACTIVITY_MODE, AuthActivity.Mode.BECOME_TUTOR.name());
            startActivity(intent);
        });
        binding.becomeInstituteBtn.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AuthActivity.class);
            intent.putExtra(Constants.AUTH_ACTIVITY_MODE, AuthActivity.Mode.BECOME_INSTITUTE.name());
            startActivity(intent);
        });
    }
}