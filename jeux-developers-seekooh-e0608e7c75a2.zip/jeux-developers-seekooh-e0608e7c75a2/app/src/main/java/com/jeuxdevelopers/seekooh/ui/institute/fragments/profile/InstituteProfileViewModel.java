package com.jeuxdevelopers.seekooh.ui.institute.fragments.profile;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.InstituteType;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.dto.GetProfileResponse;
import com.jeuxdevelopers.seekooh.models.dto.UpdateInstituteProfileRequest;
import com.jeuxdevelopers.seekooh.models.dto.UpdateTutorProfileRequest;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.net.URI;
import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class InstituteProfileViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<GetProfileResponse>> getProfileLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Board>>> getBoardsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Grade>>> getGradesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Subject>>> getSubjectsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<City>>> getCitiesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<InstituteType>>> getInstituteTypesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<GetProfileResponse>> updateInstituteProfileLiveData = new MutableLiveData<>();

    public InstituteProfileViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getProfile() {
        disposables.add(appRepo.getProfile()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(profileResponseResource -> {
                    getProfileLiveData.setValue(profileResponseResource);
                }, throwable -> {
                    getProfileLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getBoards() {
        disposables.add(appRepo.getBoards()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getBoardsResponseResource -> {
                    getBoardsLiveData.setValue(getBoardsResponseResource);
                }, throwable -> {
                    getBoardsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getGrades() {
        disposables.add(appRepo.getGrades()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getGradesResponseResource -> {
                    getGradesLiveData.setValue(getGradesResponseResource);
                }, throwable -> {
                    getGradesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getSubjects() {
        disposables.add(appRepo.getSubjects()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getSubjectsResource -> {
                    getSubjectsLiveData.setValue(getSubjectsResource);
                }, throwable -> {
                    getSubjectsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getCities() {
        disposables.add(appRepo.getCities()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getCitiesResponseResource -> {
                    getCitiesLiveData.setValue(getCitiesResponseResource);
                }, throwable -> {
                    getCitiesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getInstituteTypes() {
        disposables.add(appRepo.getInstituteTypes()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getInstituteTypesResponseResource -> {
                    getInstituteTypesLiveData.setValue(getInstituteTypesResponseResource);
                }, throwable -> {
                    getInstituteTypesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void updateInstituteProfile(@Nullable URI instituteProfileImageUri, @NonNull UpdateInstituteProfileRequest updateInstituteProfileRequest) {
        disposables.add(appRepo.updateInstituteProfile(instituteProfileImageUri, updateInstituteProfileRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(updateInstituteProfileResource -> {
                    updateInstituteProfileLiveData.setValue(updateInstituteProfileResource);
                }, throwable -> {
                    updateInstituteProfileLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}

