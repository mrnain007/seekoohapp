package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Qualification {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("degreeCertName")
    @Expose
    private String degreeCertName;
    @SerializedName("year")
    @Expose
    private Integer year;
    @SerializedName("marks")
    @Expose
    private Double marks;

    public Qualification() {
    }

    public Qualification(Integer id, String degreeCertName, Integer year, Double marks) {
        this.id = id;
        this.degreeCertName = degreeCertName;
        this.year = year;
        this.marks = marks;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDegreeCertName() {
        return degreeCertName;
    }

    public void setDegreeCertName(String degreeCertName) {
        this.degreeCertName = degreeCertName;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Double getMarks() {
        return marks;
    }

    public void setMarks(Double marks) {
        this.marks = marks;
    }
}
