package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SendPasswordResetResponse {
    @SerializedName("retryInSeconds")
    @Expose
    private Integer retryInSeconds;
    @SerializedName("verificationType")
    @Expose
    private SendPasswordResetRequest.VerificationType verificationType;

    public SendPasswordResetResponse() {
    }

    private SendPasswordResetResponse(Builder builder) {
        setRetryInSeconds(builder.retryInSeconds);
        setVerificationType(builder.verificationType);
    }

    public static Builder builder() {
        return new Builder();
    }

    public Integer getRetryInSeconds() {
        return retryInSeconds;
    }

    public void setRetryInSeconds(Integer retryInSeconds) {
        this.retryInSeconds = retryInSeconds;
    }

    public SendPasswordResetRequest.VerificationType getVerificationType() {
        return verificationType;
    }

    public void setVerificationType(SendPasswordResetRequest.VerificationType verificationType) {
        this.verificationType = verificationType;
    }

    public static final class Builder {
        private Integer retryInSeconds;
        private SendPasswordResetRequest.VerificationType verificationType;

        private Builder() {
        }

        public Builder retryInSeconds(Integer retryInSeconds) {
            this.retryInSeconds = retryInSeconds;
            return this;
        }

        public Builder verificationType(SendPasswordResetRequest.VerificationType verificationType) {
            this.verificationType = verificationType;
            return this;
        }

        public SendPasswordResetResponse build() {
            return new SendPasswordResetResponse(this);
        }
    }
}
