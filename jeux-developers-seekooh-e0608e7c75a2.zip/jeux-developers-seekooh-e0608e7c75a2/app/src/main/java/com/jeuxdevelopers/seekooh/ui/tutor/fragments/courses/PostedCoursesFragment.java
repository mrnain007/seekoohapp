package com.jeuxdevelopers.seekooh.ui.tutor.fragments.courses;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.google.android.gms.common.util.CollectionUtils;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.FragmentPostedCoursesBinding;
import com.jeuxdevelopers.seekooh.models.Course;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.DeleteDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions.PostedTuitionsFragmentDirections;
import com.jeuxdevelopers.seekooh.ui.tutor.fragments.courses.adapters.PostedCoursesAdapter;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.List;

public class PostedCoursesFragment extends Fragment {

    private FragmentPostedCoursesBinding binding;
    private NavController navController;
    private PostedCoursesViewModel viewModel;
    private PostedCoursesAdapter postedCoursesAdapter;
    private List<Course> data;
    private WaitingDialog waitingDialog;
    private DeleteDialog deleteDialog;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentPostedCoursesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);
        viewModel = new ViewModelProvider(this).get(PostedCoursesViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        fetchData();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext(), () -> {
            requireActivity().onBackPressed();
        });
        deleteDialog = new DeleteDialog(requireContext());
        initRecycler();
    }

    private void initClickListeners() {
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            viewModel.getMyCourses();
        });
        binding.postCourseBtn.setOnClickListener(v -> {
            navController.navigate(PostedCoursesFragmentDirections.actionPostedCoursesFragmentToCreateCourseFragment());
        });
        binding.btnBack.setOnClickListener(v -> {
            requireActivity().onBackPressed();
        });
    }

    private void initRecycler() {
        postedCoursesAdapter = new PostedCoursesAdapter(new PostedCoursesAdapter.Listener() {
            @Override
            public void onViewApplicantsBtnClicked(int position) {
                Course course = data.get(position);
                navController.navigate(PostedCoursesFragmentDirections
                        .actionPostedCoursesFragmentToCourseEnrollmentsFragment(course.getId()));
            }

            @Override
            public void onEditBtnClicked(int position) {
                Course course = data.get(position);
                navController.navigate(PostedCoursesFragmentDirections
                        .actionPostedCoursesFragmentToEditCourseFragment(course.getId()));
            }

            @Override
            public void onDeleteBtnClicked(int position) {
                deleteDialog.show("Delete Course", "Are you sure you want to delete course?", new DeleteDialog.Listener() {
                    @Override
                    public void onPositiveBtnClicked() {
                        Course course = data.get(position);
                        viewModel.deleteCourse(course.getId());
                        deleteDialog.dismiss();
                    }

                    @Override
                    public void onNegativeBtnClicked() {
                        deleteDialog.dismiss();
                    }
                });
            }
        });
        binding.postedCoursesRcv.setAdapter(postedCoursesAdapter);
    }

    private void fetchData() {
        viewModel.getMyCourses();
    }

    @SuppressLint("SetTextI18n")
    private void initObservers() {
        viewModel.getMyCoursesLiveData.observe(getViewLifecycleOwner(), getMyTuitionsResponse -> {
            switch (getMyTuitionsResponse.getStatus()) {
                case ERROR:
                    binding.noContentLayout.getRoot().setVisibility(View.GONE);
                    Utils.showToast(requireContext(), getMyTuitionsResponse.getMessage());
                    binding.shimmer.setVisibility(View.GONE);
                    binding.swipeRefreshLayout.setRefreshing(false);
                    break;
                case LOADING:
                    binding.noContentLayout.getRoot().setVisibility(View.GONE);
                    binding.shimmer.setVisibility(View.VISIBLE);
                    break;
                case SUCCESS:
                    data = getMyTuitionsResponse.getData();
                    binding.noContentLayout.getRoot().setVisibility(CollectionUtils.isEmpty(data) ? View.VISIBLE : View.GONE);
                    postedCoursesAdapter.submitList(data);
                    binding.swipeRefreshLayout.setRefreshing(false);
                    binding.shimmer.setVisibility(View.GONE);
                    break;
            }
        });

        viewModel.deleteCourseLiveData.observe(getViewLifecycleOwner(), deleteTuitionResponse -> {
            switch (deleteTuitionResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), deleteTuitionResponse.getMessage());
                    waitingDialog.dismiss();
                    break;
                case LOADING:
                    waitingDialog.show(deleteTuitionResponse.getMessage());
                    break;
                case SUCCESS:
                    Utils.showToast(requireContext(), deleteTuitionResponse.getMessage());
                    waitingDialog.dismiss();
                    viewModel.getMyCourses();
                    break;
            }
        });
    }
}