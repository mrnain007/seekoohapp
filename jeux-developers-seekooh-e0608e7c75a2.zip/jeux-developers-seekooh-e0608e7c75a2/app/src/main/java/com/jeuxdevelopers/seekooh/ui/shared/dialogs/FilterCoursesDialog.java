package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.jeuxdevelopers.seekooh.databinding.DialogFilterCoursesBinding;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.ui.shared.views.MultiSelectionView;

import java.util.List;

public class FilterCoursesDialog extends Dialog {

    private DialogFilterCoursesBinding binding;
    private Listener listener;

    private MultiSelectionView.Data<Subject> subjectData;

    public FilterCoursesDialog(@NonNull Context context) {
        super(context);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogFilterCoursesBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));

        initDialog();
    }

    public FilterCoursesDialog(@NonNull Context context, @NonNull Listener listener) {
        super(context);
        this.listener = listener;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogFilterCoursesBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));

        initDialog();
    }

    private void initDialog() {
        binding.btnBack.setOnClickListener(v -> {
            dismiss();
        });
        binding.searchBtn.setOnClickListener(v -> {
            if (listener == null) {
                return;
            }

            Boolean isOnlineClass = binding.onlineClassSw.isChecked() ? binding.onlineClassSw.isChecked() : null;
            listener.onSearchClicked(isOnlineClass, subjectData.getSelectedItemsList());
        });
        binding.resetBtn.setOnClickListener(v -> {
            if (listener == null) {
                return;
            }

            resetUserData();
            listener.onResetClicked();
        });
    }

    private void resetUserData() {
        binding.onlineClassSw.setChecked(false);
        binding.subjectsMsv.clearSelectedItems();
    }

    @Override
    public void show() {
    }

    public void show(List<Subject> subjectList) {
        if (binding != null) {
            setData(subjectList);
        }
        super.show();
    }

    private void setData(List<Subject> subjectsList) {
        subjectData = new MultiSelectionView.Data<>(subjectsList, Subject::getName);
        binding.subjectsMsv.setData("Select subjects?", subjectData);
    }

    public interface Listener {
        void onSearchClicked(Boolean isOnlineClass, List<Subject> subjectList);

        void onResetClicked();
    }
}
