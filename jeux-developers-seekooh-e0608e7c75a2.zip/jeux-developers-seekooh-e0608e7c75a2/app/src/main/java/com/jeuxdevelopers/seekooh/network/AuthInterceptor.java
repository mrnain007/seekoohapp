package com.jeuxdevelopers.seekooh.network;

import android.content.Context;

import androidx.annotation.NonNull;

import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class AuthInterceptor implements Interceptor {
    private final Context context;
    private final User user;

    public AuthInterceptor() {
        this.context = App.getContext();
        user = UserPrefs.getUser(context);
    }

    @NonNull
    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        Request.Builder builder = chain.request().newBuilder();
        if (user != null) {
            String accessToken = user.getAccessToken();
            if (accessToken != null) {
                builder.addHeader("Authorization", "Bearer " + accessToken);
            }
        }
        Request request = builder.build();
        return chain.proceed(request);
    }
}
