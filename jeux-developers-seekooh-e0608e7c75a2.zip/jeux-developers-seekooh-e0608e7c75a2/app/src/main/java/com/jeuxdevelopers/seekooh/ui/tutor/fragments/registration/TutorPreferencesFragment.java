package com.jeuxdevelopers.seekooh.ui.tutor.fragments.registration;

import android.Manifest;
import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;

import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.FragmentTutorPreferencesBinding;
import com.jeuxdevelopers.seekooh.models.AppSettings;
import com.jeuxdevelopers.seekooh.models.InstituteProfile;
import com.jeuxdevelopers.seekooh.models.Location;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.TutorTimeSlot;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationResponse;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.MultiChoiceDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.tutor.activities.verification.TutorVerificationActivity;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.PrefsUtils;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.format.TextStyle;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

import timber.log.Timber;

public class TutorPreferencesFragment extends DialogFragment {

    private static final int LOCATION_REQ_CODE = 1001;
    private final int PROFILE_IMAGE_REQUEST_CODE = 1000;
    private boolean isTextWatcherEnabled = false;
    private FragmentTutorPreferencesBinding binding;
    private NavController navController;
    private WaitingDialog waitingDialog;
    private TextWatcher textWatcher;
    private TutorRegistrationViewModel viewModel;
    private FusedLocationProviderClient fusedLocationProvider;
    private LocationCallback locationCallback;
    private int startTimeInMinutes;
    private int endTimeInMinutes;
    private MultiChoiceDialog<DayOfWeek> daysMultiChoiceDialog;
    private android.location.Location currentLocation;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.FullScreenDialogStyle);
        fusedLocationProvider = LocationServices.getFusedLocationProviderClient(requireContext());
    }

    @Override
    public void onResume() {
        super.onResume();
        startLocationUpdates();
    }

    @Override
    public void onPause() {
        super.onPause();
        stopLocationUpdates();
    }

    private void stopLocationUpdates() {
        fusedLocationProvider.removeLocationUpdates(locationCallback);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentTutorPreferencesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(requireActivity()).get(TutorRegistrationViewModel.class);
        navController = NavHostFragment.findNavController(this);
        initLocationService();
        initViews();
        initClickListeners();
        initObservers();
        fetchData();
    }

    private void fetchData() {
        binding.profileImg.setImageURI(viewModel.profileImageUri);
    }

    private void initObservers() {
        viewModel.tutorRegistrationLiveData.observe(getViewLifecycleOwner(), tutorRegistrationResponse -> {
            Log.e("DebugCode", "initObservers: " + tutorRegistrationResponse.getStatus());
            switch (tutorRegistrationResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), tutorRegistrationResponse.getMessage());
                    break;
                case LOADING:
                    waitingDialog.show(tutorRegistrationResponse.getMessage());
                    break;
                case SUCCESS:
                    Log.e("DebugCode", "initObservers: " + viewModel.tutorRegistrationRequest.getEmail()+" , "+viewModel.tutorRegistrationRequest.getPassword());
                    viewModel.loginTutor(viewModel.tutorRegistrationRequest.getEmail(), viewModel.tutorRegistrationRequest.getPassword());
//                    waitingDialog.dismiss();
//                    navController.navigate(TutorPreferencesFragmentDirections.actionTutorPreferencesFragmentToAuthFragment());
                    Utils.showToast(requireContext(), tutorRegistrationResponse.getMessage());
                    break;
            }
        });

        viewModel.authenticationLiveData
                .observe(getViewLifecycleOwner(), authenticationResource -> {
                    switch (authenticationResource.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), authenticationResource.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(authenticationResource.getMessage());
                            break;
                        case SUCCESS:
                            AuthenticationResponse authenticationResponse = authenticationResource.getData();
                            Role tutorRole = authenticationResponse.getRoles()
                                    .stream()
                                    .filter(role -> role.getName().equals(Constants.ROLE_TUTOR))
                                    .findFirst()
                                    .orElse(null);
                            if (tutorRole == null) {
                                Utils.showToast(requireContext(), "User not registered as tutor.");
                                waitingDialog.dismiss();
                                return;
                            }
                            User user = Utils.dtoToUser(authenticationResponse);
                            if (user.getAppSettings() == null) {
                                user.setAppSettings(new AppSettings());
                            }
                            user.getAppSettings().setSelectedRole(tutorRole);
                            UserPrefs.saveUser(requireContext(), user);
                            Utils.showToast(requireContext(), authenticationResource.getMessage());
                            waitingDialog.dismiss();
                            PrefsUtils.putBoolean(requireContext(), Constants.FIRST_TIME, true);
                            startActivity(new Intent(requireContext(), TutorVerificationActivity.class));

                            String message = Optional.ofNullable(user.getFullName())
                                    .orElseGet(() -> Optional.ofNullable(user.getInstituteProfile())
                                            .map(InstituteProfile::getNameOfInstitute)
                                            .orElse("Welcome"));
                            Utils.showToast(requireContext(), message);
                            App.syncPresence();
                            requireActivity().finishAffinity();
                            break;
                    }
                });

    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext());
        initDaysDialog();
        initTextWatcher();
    }

    private void initTextWatcher() {
        textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateInputs();
                }
            }
        };

        binding.locationTl.getEditText().addTextChangedListener(textWatcher);
        binding.timingFromTl.getEditText().addTextChangedListener(textWatcher);
        binding.timingToTl.getEditText().addTextChangedListener(textWatcher);
        binding.areaTl.getEditText().addTextChangedListener(textWatcher);
        binding.daysTl.getEditText().addTextChangedListener(textWatcher);
    }

    private void initDaysDialog() {
        List<DayOfWeek> daysOfWeek = Arrays.asList(DayOfWeek.values());
        MultiChoiceDialog.Options options = MultiChoiceDialog.Options.builder()
                .sortList(false)
                .build();
        daysMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                options,
                daysOfWeek,
                dayOfWeek -> dayOfWeek.getDisplayName(TextStyle.FULL, Locale.getDefault()),
                selectedItemNames -> {
                    binding.daysAcTv.setText(selectedItemNames);
                    List<DayOfWeek> selectedItemsList = daysMultiChoiceDialog.getSelectedItemsList();
                });
    }

    private void initClickListeners() {
        binding.timingFromTl.getEditText().setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                    (view, selectedHour, selectedMinute) -> {
                        String formattedTime = Utils.getFormattedTime(selectedHour, selectedMinute);
                        binding.timingFromTl.getEditText().setText(formattedTime);
                        startTimeInMinutes = selectedHour * 60 + selectedMinute;
                    }, hour, minute, false);
            timePickerDialog.show();
        });
        binding.timingToTl.getEditText().setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                    (view, selectedHour, selectedMinute) -> {
                        String formattedTime = Utils.getFormattedTime(selectedHour, selectedMinute);
                        binding.timingToTl.getEditText().setText(formattedTime);
                        endTimeInMinutes = selectedHour * 60 + selectedMinute;
                    }, hour, minute, false);
            timePickerDialog.show();
        });
        binding.daysAcTv.setOnClickListener(v -> {
            daysMultiChoiceDialog.show("Preferred days of teaching?");
        });
        binding.submitBtn.setOnClickListener(v -> {
            if (validateInputs()) {
                boolean teachAtLocation = binding.teachAtLocationSw.isChecked();
                boolean teachOnline = binding.teachOnlineSw.isChecked();
                String area = binding.areaTl.getEditText().getText().toString().trim();
                List<DayOfWeek> selectedDaysList = daysMultiChoiceDialog.getSelectedItemsList();

                viewModel.tutorRegistrationRequest.getTutorProfile().setTeachAtLocation(teachAtLocation);
                viewModel.tutorRegistrationRequest.getTutorProfile().setTeachOnline(teachOnline);
                viewModel.tutorRegistrationRequest.getTutorProfile().getAddress().setLatitude(currentLocation.getLatitude());
                viewModel.tutorRegistrationRequest.getTutorProfile().getAddress().setLongitude(currentLocation.getLongitude());
                viewModel.tutorRegistrationRequest.getTutorProfile().getAddress().setArea(area);
                viewModel.tutorRegistrationRequest.getTutorProfile().setTimeSlots(Collections.singletonList(new TutorTimeSlot(null, startTimeInMinutes, endTimeInMinutes)));
                viewModel.tutorRegistrationRequest.getTutorProfile().setAvailableDayValues(Utils.toIdList(selectedDaysList, DayOfWeek::getValue));

                viewModel.registerTutor(viewModel.profileImageUri, viewModel.tutorRegistrationRequest);
            }
        });
        binding.pickImgBtn.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(1024).maxResultSize(1920, 1920).crop(1, 1).start(PROFILE_IMAGE_REQUEST_CODE);
        });
    }

    private boolean validateInputs() {
        isTextWatcherEnabled = true;
        boolean isValid = true;

        String location = binding.locationTl.getEditText().getText().toString().trim();
        String timingFrom = binding.timingFromTl.getEditText().getText().toString().trim();
        String timingTo = binding.timingToTl.getEditText().getText().toString().trim();
        String area = binding.areaTl.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(location)) {
            binding.locationTl.setError("Please enable location access.");
            isValid = false;
        } else {
            binding.locationTl.setError(null);
        }

        if (TextUtils.isEmpty(timingFrom)) {
            binding.timingFromTl.setError("Please select starting time.");
            isValid = false;
        } else {
            binding.timingFromTl.setError(null);
        }

        if (TextUtils.isEmpty(timingTo)) {
            binding.timingToTl.setError("Please select ending time.");
            isValid = false;
        } else {
            binding.timingToTl.setError(null);
        }

        if (TextUtils.isEmpty(area)) {
            binding.areaTl.setError("Please enter your area.");
            isValid = false;
        } else {
            binding.areaTl.setError(null);
        }

        if (daysMultiChoiceDialog.getSelectedItemsList() == null || daysMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.daysTl.setError("Please select your preferred days.");
            isValid = false;
        } else {
            binding.daysTl.setError(null);
        }
        return isValid;
    }

    private void initLocationService() {
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                currentLocation = locationResult.getLocations().get(locationResult.getLocations().size() - 1);
                binding.locationTl.getEditText().setText(Utils.getAddressFromLatLng(requireContext(), currentLocation.getLatitude(), currentLocation.getLongitude()));
                stopLocationUpdates();
            }
        };
    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestLocationPermissions();
            return;
        }
        LocationRequest locationRequest = new LocationRequest.Builder(10000)
                .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
                .setIntervalMillis(10000)
                .setMinUpdateIntervalMillis(5000)
                .build();
        fusedLocationProvider.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
    }

    private void requestLocationPermissions() {
        ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQ_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PROFILE_IMAGE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                viewModel.profileImageUri = data.getData();
                binding.profileImg.setImageURI(viewModel.profileImageUri);
            } else if (resultCode == ImagePicker.RESULT_ERROR) {
                Utils.showToast(requireContext(), ImagePicker.getError(data));
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQ_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startLocationUpdates();
            } else {
                startLocationUpdates();
            }
        }
    }
}