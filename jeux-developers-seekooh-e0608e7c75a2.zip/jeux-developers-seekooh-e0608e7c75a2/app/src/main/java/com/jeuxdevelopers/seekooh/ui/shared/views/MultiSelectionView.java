package com.jeuxdevelopers.seekooh.ui.shared.views;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;

import com.google.android.gms.common.util.CollectionUtils;
import com.google.android.material.chip.Chip;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.DdChipLayoutBinding;
import com.jeuxdevelopers.seekooh.databinding.MultiSelectionViewLayoutBinding;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;

public class MultiSelectionView extends FrameLayout {
    private static final String TAG = "MultiSelectionView";
    private MultiSelectionViewLayoutBinding binding;
    private Listener listener;
    private Context context;
    private Data<?> data;
    private AlertDialog.Builder dialog;

    public MultiSelectionView(Context context) {
        super(context);
        this.context = context;
        initViews();
        setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
    }

    public MultiSelectionView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        initViews();
        setAttrs(context, attrs);
    }

    public MultiSelectionView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
        initViews();
        setAttrs(context, attrs);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
        this.context = getContext();
    }

    private void initViews() {
        this.data = new Data<>(new ArrayList<>(), Object::toString);
        binding = MultiSelectionViewLayoutBinding.inflate(LayoutInflater.from(context), this, true);
        setClickable(true);
        setFocusable(true);
        initClickListeners();
    }

    private void initClickListeners() {
        binding.ddBtn.setOnClickListener(v -> {
            if (dialog == null) {
                Utils.showToast(context, "Dialog not initialized.");
                return;
            }
            dialog.show();
        });
        binding.getRoot().setOnClickListener(v -> {
            if (dialog == null) {
                Utils.showToast(context, "Dialog not initialized.");
                return;
            }
            dialog.show();
        });
    }

    public void setError(String error) {
        if (error == null) {
            binding.errorTv.setVisibility(GONE);
            binding.errorImg.setVisibility(GONE);
            binding.ddBtn.setVisibility(VISIBLE);
            return;
        }

        binding.errorTv.setText(error);
        binding.ddBtn.setVisibility(GONE);
        binding.errorTv.setVisibility(VISIBLE);
        binding.errorImg.setVisibility(VISIBLE);
    }

    private void setAttrs(Context context, AttributeSet attrs) {
        TypedArray typedArray = context.getTheme().obtainStyledAttributes(attrs, R.styleable.multi_selection_view, 0, 0);

        String hintText = typedArray.getString(R.styleable.multi_selection_view_msv_hint_text);
        typedArray.recycle();

        if (!TextUtils.isEmpty(hintText)) {
            binding.hintTv.setText(hintText);
        }
    }

    /*public <T> void setData(String title, Data<T> data) {
        this.data = data;
        dialog = new AlertDialog.Builder(context).setTitle(title)
                .setMultiChoiceItems(Utils.toStringList(data.itemsList, data.toString).toArray(new String[0]), data.selectedItems, (dialog, which, isChecked) -> data.selectedItems[which] = isChecked)
                .setPositiveButton("Ok", (dialog, which) -> {
                    data.updateSelectedItemsList();
                    binding.chipGroup.removeAllViews();
                    if (listener != null) {
                        if (listener.onSelectedItemsChanged()) {
                            return;
                        }
                    }
                    // Show selectedItems data
                    for (int i = 0; i < data.selectedItems.length; i++) {
                        if (data.selectedItems[i]) {
                            T t = data.itemsList.get(i);
                            Chip chip = DdChipLayoutBinding.inflate(LayoutInflater.from(context)).getRoot();
                            chip.setText(data.toString.apply(t));
                            int finalI = i;
                            chip.setOnCloseIconClickListener(v -> {
                                data.selectedItems[finalI] = false;
                                data.selectedItemsList.remove(t);
                                binding.chipGroup.removeView(chip);
                            });
                            binding.chipGroup.addView(chip);
                        }
                    }
                    // Show suggestedItems data
                    for (int i = 0; i < data.suggestedItems.size(); i++) {
                        String itemName = data.suggestedItems.get(i);
                        Chip chip = DdChipLayoutBinding.inflate(LayoutInflater.from(context)).getRoot();
                        chip.setText(itemName);
                        int finalI = i;
                        chip.setOnCloseIconClickListener(v -> {
                            data.suggestedItems.remove(itemName);
                            binding.chipGroup.removeView(chip);
                        });
                        binding.chipGroup.addView(chip);
                    }
                }).setNegativeButton("Cancel", (dialog, which) -> {
                    *//*if (onNegativeBtnClicked != null)
                        onNegativeBtnClicked.onNegativeBtnClicked();*//*
                });
    }*/

    public <T> void setData(String title, Data<T> data) {
        this.data = data;
        if (!CollectionUtils.isEmpty(data.selectedItemsList) && data.toId != null) {
            Set<Integer> selectedIds = new HashSet<>();
            for (T selectedItem : data.selectedItemsList) {
                selectedIds.add(data.toId.apply(selectedItem));
            }
            for (int i = 0; i < data.itemsList.size(); i++) {
                T item = data.itemsList.get(i);
                if (selectedIds.contains(data.toId.apply(item))) {
                    data.selectedItems[i] = true;
                }
            }
            showData(data);
        }
        dialog = new AlertDialog.Builder(context).setTitle(title)
                .setMultiChoiceItems(Utils.toStringList(data.itemsList, data.toString).toArray(new String[0]), data.selectedItems, (dialog, which, isChecked) -> data.selectedItems[which] = isChecked)
                .setPositiveButton("Ok", (dialog, which) -> {
                    data.updateSelectedItemsList();
                    binding.chipGroup.removeAllViews();
                    if (listener != null) {
                        if (listener.onSelectedItemsChanged()) {
                            return;
                        }
                    }
                    // Show selectedItems data
                    showData(data);
                }).setNegativeButton("Cancel", (dialog, which) -> {
                    /*if (onNegativeBtnClicked != null)
                        onNegativeBtnClicked.onNegativeBtnClicked();*/
                });
    }

    private <T> void showData(Data<T> data) {
        // Show selectedItems data
        for (int i = 0; i < data.selectedItems.length; i++) {
            if (data.selectedItems[i]) {
                T t = data.itemsList.get(i);
                Chip chip = DdChipLayoutBinding.inflate(LayoutInflater.from(context)).getRoot();
                chip.setText(data.toString.apply(t));
                int finalI = i;
                chip.setOnCloseIconClickListener(v -> {
                    data.selectedItems[finalI] = false;
                    data.selectedItemsList.remove(t);
                    binding.chipGroup.removeView(chip);
                });
                binding.chipGroup.addView(chip);
            }
        }
        // Show suggestedItems data
        for (int i = 0; i < data.suggestedItems.size(); i++) {
            String itemName = data.suggestedItems.get(i);
            Chip chip = DdChipLayoutBinding.inflate(LayoutInflater.from(context)).getRoot();
            chip.setText(itemName);
            int finalI = i;
            chip.setOnCloseIconClickListener(v -> {
                data.suggestedItems.remove(itemName);
                binding.chipGroup.removeView(chip);
            });
            binding.chipGroup.addView(chip);
        }
    }

    public void clearSelectedItems() {
        if (data == null) {
            return;
        }
        data.selectedItemsList.clear();
        data.selectedItems = new boolean[data.itemsList.size()];
        data.suggestedItems.clear();
        binding.chipGroup.removeAllViews();
    }

    public Data<?> getData() {
        return data;
    }

    public void addSuggestedItem(String itemName) {
        data.suggestedItems.add(itemName);
        Chip chip = DdChipLayoutBinding.inflate(LayoutInflater.from(context)).getRoot();
        chip.setText(itemName);
        chip.setOnCloseIconClickListener(v -> {
            data.suggestedItems.remove(itemName);
            binding.chipGroup.removeView(chip);
        });
        binding.chipGroup.addView(chip);
    }

    public interface Listener {
        boolean onSelectedItemsChanged();
    }

    public static class Data<T> {
        private boolean isSorted = true;
        private List<T> itemsList = new ArrayList<>();
        private List<T> selectedItemsList = new ArrayList<>();
        private Function<T, String> toString;
        private Function<T, Integer> toId;
        private boolean[] selectedItems;
        private List<String> suggestedItems = new ArrayList<>();

        public Data(List<T> itemsList, Function<T, String> toString) {
            this.itemsList = itemsList;
            this.toString = toString;
            init();
        }

        public Data(List<T> itemsList, Function<T, String> toString, List<T> selectedItemsList, Function<T, Integer> toId) {
            this.itemsList = itemsList;
            this.toString = toString;
            this.selectedItemsList = selectedItemsList;
            this.toId = toId;
            init();
        }

        public Data(boolean isSorted, List<T> itemsList, Function<T, String> toString) {
            this.isSorted = isSorted;
            this.itemsList = itemsList;
            this.toString = toString;
            init();
        }

        private void init() {
            if (isSorted) {
                Collections.sort(itemsList, Comparator.comparing(toString));
                Collections.sort(selectedItemsList, Comparator.comparing(toString));
            }
            selectedItems = new boolean[itemsList.size()];
        }

        private void updateSelectedItemsList() {
            selectedItemsList.clear();
            for (int i = 0; i < selectedItems.length; i++) {
                if (selectedItems[i]) {
                    selectedItemsList.add(itemsList.get(i));
                }
            }
        }

        public List<T> getSelectedItemsList() {
            return selectedItemsList;
        }

        public List<String> getSuggestedItems() {
            return suggestedItems;
        }
    }
}
