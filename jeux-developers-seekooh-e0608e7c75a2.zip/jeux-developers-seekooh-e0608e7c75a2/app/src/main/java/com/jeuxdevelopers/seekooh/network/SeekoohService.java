package com.jeuxdevelopers.seekooh.network;

import androidx.annotation.NonNull;

import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Course;
import com.jeuxdevelopers.seekooh.models.CourseListing;
import com.jeuxdevelopers.seekooh.models.CourseReview;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.InstituteDetails;
import com.jeuxdevelopers.seekooh.models.InstituteListing;
import com.jeuxdevelopers.seekooh.models.InstituteReview;
import com.jeuxdevelopers.seekooh.models.InstituteType;
import com.jeuxdevelopers.seekooh.models.Notification;
import com.jeuxdevelopers.seekooh.models.SalaryType;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TeachingJob;
import com.jeuxdevelopers.seekooh.models.TeachingJobListing;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.TuitionListing;
import com.jeuxdevelopers.seekooh.models.TutorDetails;
import com.jeuxdevelopers.seekooh.models.TutorListing;
import com.jeuxdevelopers.seekooh.models.TutorReview;
import com.jeuxdevelopers.seekooh.models.dto.AdSettingsResponse;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationRequest;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationResponse;
import com.jeuxdevelopers.seekooh.models.dto.CourseEnrollmentResponse;
import com.jeuxdevelopers.seekooh.models.dto.CreateCourseRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateCourseReviewRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateInstituteReviewRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateTeachingJobRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateTuitionRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateTutorReviewRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditCourseRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditPrivacySettingsRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditTeachingJobRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditTuitionRequest;
import com.jeuxdevelopers.seekooh.models.dto.InstituteRegistrationRequest;
import com.jeuxdevelopers.seekooh.models.dto.InstituteRegistrationResponse;
import com.jeuxdevelopers.seekooh.models.dto.GetProfileResponse;
import com.jeuxdevelopers.seekooh.models.dto.PrivacySettingsResponse;
import com.jeuxdevelopers.seekooh.models.dto.SendPasswordResetRequest;
import com.jeuxdevelopers.seekooh.models.dto.SendPasswordResetResponse;
import com.jeuxdevelopers.seekooh.models.dto.SocialLoginRequest;
import com.jeuxdevelopers.seekooh.models.dto.StudentRegistrationRequest;
import com.jeuxdevelopers.seekooh.models.dto.StudentRegistrationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationRequest;
import com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TokenRefreshRequest;
import com.jeuxdevelopers.seekooh.models.dto.TokenRefreshResponse;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationRequest;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TutorRegistrationRequest;
import com.jeuxdevelopers.seekooh.models.dto.TutorRegistrationResponse;
import com.jeuxdevelopers.seekooh.models.dto.UpdateInstituteProfileRequest;
import com.jeuxdevelopers.seekooh.models.dto.UpdateStudentProfileRequest;
import com.jeuxdevelopers.seekooh.models.dto.UpdateTutorProfileRequest;
import com.jeuxdevelopers.seekooh.models.dto.VerificationFeeResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenRequest;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationStatusResponse;
import com.jeuxdevelopers.seekooh.models.other.SeekoohResponse;

import java.util.List;

import io.reactivex.rxjava3.core.Single;
import okhttp3.MultipartBody;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface SeekoohService {

    @POST("/api/v1/users/authenticate")
    Single<SeekoohResponse<AuthenticationResponse>> authenticate(@Body AuthenticationRequest authenticationRequest);

    @POST("/api/v1/auth/refresh")
    Single<SeekoohResponse<TokenRefreshResponse>> tokenRefresh(@Body TokenRefreshRequest tokenRefreshRequest);

    @POST("/api/v1/auth/social-login")
    Single<SeekoohResponse<AuthenticationResponse>> socialLogin(@Body SocialLoginRequest socialLoginRequest);

    @POST("/api/v1/auth/request-password-reset")
    Single<SeekoohResponse<SendPasswordResetResponse>> requestPasswordReset(@Body SendPasswordResetRequest sendPasswordResetRequest);

    @Multipart
    @POST("/api/v1/students/register")
    Single<SeekoohResponse<StudentRegistrationResponse>> registerStudent(@Part MultipartBody.Part image, @Part("studentRegistrationRequestDto") StudentRegistrationRequest studentRegistrationRequest);

    @GET("/api/v1/boards")
    Single<SeekoohResponse<List<Board>>> getBoards();

    @GET("/api/v1/cities")
    Single<SeekoohResponse<List<City>>> getCities();

    @GET("/api/v1/grades")
    Single<SeekoohResponse<List<Grade>>> getGrades();

    @GET("/api/v1/subjects")
    Single<SeekoohResponse<List<Subject>>> getSubjects();

    @GET("/api/v1/institute-types")
    Single<SeekoohResponse<List<InstituteType>>> getInstituteTypes();

    @Multipart
    @POST("/api/v1/tutors/register")
    Single<SeekoohResponse<TutorRegistrationResponse>> registerTutor(@Part MultipartBody.Part image, @Part("tutorRegistrationRequestDto") TutorRegistrationRequest tutorRegistrationRequest);

    @Multipart
    @POST("/api/v1/institutes/register")
    Single<SeekoohResponse<InstituteRegistrationResponse>> registerInstitute(@Part MultipartBody.Part image, @Part("instituteRegistrationRequestDto") InstituteRegistrationRequest instituteRegistrationRequest);

    @GET("/api/v1/tutors/listings")
    Single<SeekoohResponse<List<TutorListing>>> getTutorListings(@Query("page") Integer page, @Query("size") Integer size, @Query("search") String search, @Query("isVerified") Boolean isVerified, @Query("teachesOnline") Boolean teachesOnline, @Query("teachesInPerson") Boolean teachesInPerson, @Query("cityId") Integer cityId, @Query("genderId") Integer genderId, @Query("subjectIds") List<Integer> subjectIds, @Query("gradeIds") List<Integer> gradeIds, @Query("boardExamIds") List<Integer> boardExamIds);

    @GET("/api/v1/tutors/listings/{tutorId}")
    Single<SeekoohResponse<TutorDetails>> getTutorListingDetails(@Path("tutorId") @NonNull Integer tutorId);

    @GET("/api/v1/tutors/{tutorId}/reviews?page=1&size=1000")
    Single<SeekoohResponse<List<TutorReview>>> getTutorReviews(@Path("tutorId") @NonNull Integer tutorId);

    @POST("/api/v1/tutors/{tutorId}/reviews")
    Single<SeekoohResponse<TutorReview>> createTutorReview(@Path("tutorId") @NonNull Integer tutorId, @Body CreateTutorReviewRequest createTutorReviewRequest);

    @GET("/api/v1/account/profile")
    Single<SeekoohResponse<GetProfileResponse>> getProfile();

    @Multipart
    @PUT("/api/v1/account/profile")
    Single<SeekoohResponse<GetProfileResponse>> updateStudentProfile(@Part MultipartBody.Part studentProfileImage, @Part("editProfileRequestDto") UpdateStudentProfileRequest updateStudentProfileRequest);

    @Multipart
    @PUT("/api/v1/account/profile/")
    Single<SeekoohResponse<GetProfileResponse>> updateTutorProfile(@Part MultipartBody.Part tutorProfileImage, @Part MultipartBody.Part tutorProfileVideo, @Part("editProfileRequestDto") UpdateTutorProfileRequest updateTutorProfileRequest);

    @Multipart
    @PUT("/api/v1/account/profile")
    Single<SeekoohResponse<GetProfileResponse>> updateInstituteProfile(@Part MultipartBody.Part instituteProfileImage, @Part("editProfileRequestDto") UpdateInstituteProfileRequest updateInstituteProfileRequest);

    @GET("/api/v1/salary-types")
    Single<SeekoohResponse<List<SalaryType>>> getSalaryTypes();

    @POST("/api/v1/tuitions")
    Single<SeekoohResponse<Tuition>> createTuition(@Body CreateTuitionRequest createTuitionRequest);

    @GET("/api/v1/tuitions/{tuitionId}")
    Single<SeekoohResponse<Tuition>> getTuitionById(@Path("tuitionId") @NonNull Integer tuitionId);

    @GET("/api/v1/account/my-tuitions?page=1&size=10000")
    Single<SeekoohResponse<List<Tuition>>> getMyTuitions();

    @PUT("/api/v1/tuitions/{tuitionId}")
    Single<SeekoohResponse<Tuition>> editTuition(@Path("tuitionId") @NonNull Integer tuitionId, @Body EditTuitionRequest editTuitionRequest);

    @DELETE("/api/v1/tuitions/{tuitionId}")
    Single<SeekoohResponse<Void>> deleteTuition(@Path("tuitionId") @NonNull Integer tuitionId);

    @POST("/api/v1/tuitions/{tuitionId}/apply")
    Single<SeekoohResponse<TuitionApplicationResponse>> applyToTuition(@Path("tuitionId") @NonNull Integer tuitionId, @Body TuitionApplicationRequest tuitionApplicationRequest);

    @DELETE("/api/v1/tuitions/{tuitionId}/withdraw")
    Single<SeekoohResponse<Void>> deleteTuitionApplication(@Path("tuitionId") @NonNull Integer tuitionId);

    @GET("/api/v1/account/applied-tuitions?page=1&size=10000")
    Single<SeekoohResponse<List<TuitionApplicationResponse>>> getAppliedTuitions();

    @GET("/api/v1/tuitions/listings")
    Single<SeekoohResponse<List<TuitionListing>>> getTuitionListings(@Query("page") Integer page, @Query("size") Integer size, @Query("search") String search, @Query("isOnline") Boolean isOnline, @Query("cityId") Integer cityId, @Query("genderId") Integer genderId, @Query("subjectIds") List<Integer> subjectIds, @Query("gradeIds") List<Integer> gradeIds, @Query("boardExamIds") List<Integer> boardExamIds);

    @POST("/api/v1/courses")
    Single<SeekoohResponse<Course>> createCourse(@Body CreateCourseRequest createCourseRequest);

    @GET("/api/v1/account/my-courses?page=1&size=1000")
    Single<SeekoohResponse<List<Course>>> getMyCourses();

    @PUT("/api/v1/courses/{courseId}")
    Single<SeekoohResponse<Course>> editCourse(@Path("courseId") @NonNull Integer courseId, @Body EditCourseRequest editCourseRequest);

    @DELETE("/api/v1/courses/{courseId}")
    Single<SeekoohResponse<Void>> deleteCourse(@Path("courseId") @NonNull Integer courseId);

    @GET("/api/v1/courses/{courseId}")
    Single<SeekoohResponse<Course>> getCourseById(@Path("courseId") @NonNull Integer courseId);

    @GET("/api/v1/courses/listings")
    Single<SeekoohResponse<List<CourseListing>>> getCourseListings(@Query("page") Integer page, @Query("size") Integer size, @Query("search") String search, @Query("isOnline") Boolean isOnline, @Query("subjectIds") List<Integer> subjectIds);

    @GET("/api/v1/courses/listings/{courseId}")
    Single<SeekoohResponse<CourseListing>> getCourseListingDetails(@Path("courseId") @NonNull Integer courseId);

    @POST("/api/v1/courses/{courseId}/reviews")
    Single<SeekoohResponse<CourseReview>> createCoursesReview(@Path("courseId") @NonNull Integer courseId, @Body CreateCourseReviewRequest createCourseReviewRequest);

    @GET("/api/v1/courses/{courseId}/reviews?page=1&size=1000")
    Single<SeekoohResponse<List<CourseReview>>> getCourseReviews(@Path("courseId") @NonNull Integer courseId);

    @POST("/api/v1/courses/{courseId}/enroll")
    Single<SeekoohResponse<CourseEnrollmentResponse>> courseEnrollment(@Path("courseId") @NonNull Integer courseId);

    @Multipart
    @POST("/api/v1/tutors/verification")
    Single<SeekoohResponse<VerificationStatusResponse>> submitTutorVerificationRequest(@NonNull @Part MultipartBody.Part cnicFront, @NonNull @Part MultipartBody.Part cnicBack, @NonNull @Part MultipartBody.Part degree);

    @Multipart
    @PUT("/api/v1/tutors/verification")
    Single<SeekoohResponse<VerificationStatusResponse>> resubmitTutorVerificationRequest(@NonNull @Part MultipartBody.Part cnicFront, @NonNull @Part MultipartBody.Part cnicBack, @NonNull @Part MultipartBody.Part degree);

    @GET("/api/v1/tutors/verification/status")
    Single<SeekoohResponse<VerificationStatusResponse>> getTutorVerificationStatus();

    @GET("/api/v1/tutors/verification/payment-token")
    Single<SeekoohResponse<VerificationPaymentTokenResponse>> getTutorVerificationPaymentToken();

    @GET("/api/v1/tutors/verification/fee")
    Single<SeekoohResponse<VerificationFeeResponse>> getTutorVerificationFee();

    @Multipart
    @POST("/api/v1/institutes/verification")
    Single<SeekoohResponse<VerificationStatusResponse>> submitInstituteVerificationRequest(@NonNull @Part MultipartBody.Part cnicFront, @NonNull @Part MultipartBody.Part cnicBack, @NonNull @Part MultipartBody.Part proofDoc);

    @Multipart
    @PUT("/api/v1/institutes/verification")
    Single<SeekoohResponse<VerificationStatusResponse>> resubmitInstituteVerificationRequest(@NonNull @Part MultipartBody.Part cnicFront, @NonNull @Part MultipartBody.Part cnicBack, @NonNull @Part MultipartBody.Part proofDoc);

    @GET("/api/v1/institutes/verification/status")
    Single<SeekoohResponse<VerificationStatusResponse>> getInstituteVerificationStatus();

    @GET("/api/v1/institutes/verification/payment-token")
    Single<SeekoohResponse<VerificationPaymentTokenResponse>> getInstituteVerificationPaymentToken();

    @GET("/api/v1/institutes/verification/fee")
    Single<SeekoohResponse<VerificationFeeResponse>> getInstituteVerificationFee();

    @GET("/api/v1/institutes/listings")
    Single<SeekoohResponse<List<InstituteListing>>> getInstituteListings(@Query("page") Integer page, @Query("size") Integer size, @Query("search") String search, @Query("isVerified") Boolean isVerified, @Query("cityId") Integer cityId);

    @GET("/api/v1/institutes/listings/{instituteId}")
    Single<SeekoohResponse<InstituteDetails>> getInstituteListingDetails(@Path("instituteId") @NonNull Integer instituteId);

    @GET("/api/v1/institutes/{instituteId}/reviews?page=1&size=1000")
    Single<SeekoohResponse<List<InstituteReview>>> getInstituteReviews(@Path("instituteId") @NonNull Integer instituteId);

    @POST("/api/v1/institutes/{instituteId}/reviews")
    Single<SeekoohResponse<InstituteReview>> createInstituteReview(@Path("instituteId") @NonNull Integer instituteId, @Body CreateInstituteReviewRequest createInstituteReviewRequest);

    @POST("/api/v1/teaching-jobs")
    Single<SeekoohResponse<TeachingJob>> createTeachingJob(@Body CreateTeachingJobRequest createTeachingJobRequest);

    @PUT("/api/v1/teaching-jobs/{jobId}")
    Single<SeekoohResponse<TeachingJob>> editTeachingJob(@Path("jobId") @NonNull Integer jobId, @Body EditTeachingJobRequest editTeachingJobRequest);

    @DELETE("/api/v1/teaching-jobs/{jobId}")
    Single<SeekoohResponse<Void>> deleteTeachingJob(@Path("jobId") @NonNull Integer jobId);

    @GET("/api/v1/teaching-jobs/{jobId}")
    Single<SeekoohResponse<TeachingJob>> getTeachingJobById(@Path("jobId") @NonNull Integer jobId);

    @GET("/api/v1/account/my-teaching-jobs?page=1&size=10000")
    Single<SeekoohResponse<List<TeachingJob>>> getMyTeachingJobs();

    @GET("/api/v1/teaching-jobs/listings")
    Single<SeekoohResponse<List<TeachingJobListing>>> getTeachingJobListings(@Query("page") Integer page, @Query("size") Integer size,  @Query("search") String search, @Query("isOnline") Boolean isOnline, @Query("isInPerson") Boolean isInPerson, @Query("cityId") Integer cityId, @Query("subjectIds") List<Integer> subjectIds, @Query("gradeIds") List<Integer> gradeIds);

    @POST("/api/v1/teaching-jobs/{jobId}/apply")
    Single<SeekoohResponse<TeachingJobApplicationResponse>> applyToTeachingJob(@Path("jobId") @NonNull Integer jobId, @Body TeachingJobApplicationRequest teachingJobApplicationRequest);

    @DELETE("/api/v1/teaching-jobs/{jobId}/withdraw")
    Single<SeekoohResponse<Void>> deleteJobApplication(@Path("jobId") @NonNull Integer jobId);

    @GET("/api/v1/account/applied-teaching-jobs?page=1&size=10000")
    Single<SeekoohResponse<List<TeachingJobApplicationResponse>>> getAppliedTeachingJobs();

    @GET("/api/v1/account/notifications")
    Single<SeekoohResponse<List<Notification>>> getMyNotifications(@Query("page") Integer page, @Query("size") Integer size);

    @GET("/api/v1/tuitions/{tuitionId}/applications?page=1&size=10000")
    Single<SeekoohResponse<List<TuitionApplicationResponse>>> getTuitionApplications(@Path("tuitionId") @NonNull Integer tuitionId);

    @GET("/api/v1/teaching-jobs/{jobId}/applications?page=1&size=10000")
    Single<SeekoohResponse<List<TeachingJobApplicationResponse>>> getJobApplications(@Path("jobId") @NonNull Integer jobId);

    @GET("/api/v1/courses/{courseId}/enrollments?page=1&size=10000")
    Single<SeekoohResponse<List<CourseEnrollmentResponse>>> getCourseEnrollments(@Path("courseId") @NonNull Integer courseId);

    @GET("/api/v1/app-settings/ads")
    Single<SeekoohResponse<AdSettingsResponse>> getAdSettings();

    @GET("/api/v1/account/privacy-settings")
    Single<SeekoohResponse<PrivacySettingsResponse>> getPrivacySettings();

    @PUT("/api/v1/account/privacy-settings")
    Single<SeekoohResponse<PrivacySettingsResponse>> editPrivacySettings(@Body EditPrivacySettingsRequest editPrivacySettingsRequest);
}
