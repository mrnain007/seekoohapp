package com.jeuxdevelopers.seekooh.ui.institute.fragments.verification;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.dto.VerificationFeeResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenRequest;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationStatusResponse;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.net.URI;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class InstituteVerificationViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<VerificationStatusResponse>> submitRequestLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<VerificationStatusResponse>> resubmitRequestLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<VerificationStatusResponse>> verificationStatusLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<VerificationPaymentTokenResponse>> verificationPaymentTokenLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<VerificationFeeResponse>> verificationFeeLiveData = new MutableLiveData<>();

    public InstituteVerificationViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void submitVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI proofDocUri) {
        disposables.add(appRepo.submitInstituteVerificationRequest(cnicFrontUri, cnicBackUri, proofDocUri)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(verificationResource -> {
                    submitRequestLiveData.setValue(verificationResource);
                }, throwable -> {
                    submitRequestLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void resubmitVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI proofDocUri) {
        disposables.add(appRepo.resubmitInstituteVerificationRequest(cnicFrontUri, cnicBackUri, proofDocUri)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(verificationResource -> {
                    resubmitRequestLiveData.setValue(verificationResource);
                }, throwable -> {
                    resubmitRequestLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getInstituteVerificationStatus() {
        disposables.add(appRepo.getInstituteVerificationStatus()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(verificationStatusResource -> {
                    verificationStatusLiveData.setValue(verificationStatusResource);
                }, throwable -> {
                    verificationStatusLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getInstituteVerificationPaymentToken(@NonNull VerificationPaymentTokenRequest verificationPaymentTokenRequest) {
        disposables.add(appRepo.getInstituteVerificationPaymentToken(verificationPaymentTokenRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(paymentTokenResource -> {
                    verificationPaymentTokenLiveData.setValue(paymentTokenResource);
                }, throwable -> {
                    verificationPaymentTokenLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getInstituteVerificationFee() {
        disposables.add(appRepo.getInstituteVerificationFee()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(verificationFeeResource -> {
                    verificationFeeLiveData.setValue(verificationFeeResource);
                }, throwable -> {
                    verificationFeeLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
