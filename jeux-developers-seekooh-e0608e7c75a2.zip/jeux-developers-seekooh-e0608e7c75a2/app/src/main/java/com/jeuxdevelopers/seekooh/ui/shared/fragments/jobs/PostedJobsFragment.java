package com.jeuxdevelopers.seekooh.ui.shared.fragments.jobs;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.google.android.gms.common.util.CollectionUtils;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.FragmentPostedJobsBinding;
import com.jeuxdevelopers.seekooh.models.TeachingJob;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.DeleteDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.jobs.adapters.PostedJobsAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions.PostedTuitionsFragmentDirections;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.List;

public class PostedJobsFragment extends Fragment {

    private FragmentPostedJobsBinding binding;
    private NavController navController;
    private PostedJobsViewModel viewModel;
    private PostedJobsAdapter postedTuitionsAdapter;
    private List<TeachingJob> data;
    private WaitingDialog waitingDialog;
    private DeleteDialog deleteDialog;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentPostedJobsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);
        viewModel = new ViewModelProvider(this).get(PostedJobsViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        fetchData();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext(), () -> {
            requireActivity().onBackPressed();
        });
        deleteDialog = new DeleteDialog(requireContext());
        initRecycler();
    }

    private void initClickListeners() {
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            viewModel.getMyJobs();
        });
        binding.postJobBtn.setOnClickListener(v -> {
            navController.navigate(PostedJobsFragmentDirections.actionPostedJobsFragmentToPostJobAdFragment());
        });
    }

    private void initRecycler() {
        postedTuitionsAdapter = new PostedJobsAdapter(new PostedJobsAdapter.Listener() {
            @Override
            public void onViewApplicantsBtnClicked(int position) {
                TeachingJob job = data.get(position);
                navController.navigate(PostedJobsFragmentDirections
                        .actionPostedJobsFragmentToJobApplicationsFragment(job.getId()));
            }

            @Override
            public void onEditBtnClicked(int position) {
                TeachingJob job = data.get(position);
                navController.navigate(PostedJobsFragmentDirections
                        .actionPostedJobsFragmentToEditJobAdFragment(job.getId()));
            }

            @Override
            public void onDeleteBtnClicked(int position) {
                deleteDialog.show("Delete Job", "Are you sure you want to delete job?", new DeleteDialog.Listener() {
                    @Override
                    public void onPositiveBtnClicked() {
                        TeachingJob job = data.get(position);
                        viewModel.deleteJob(job.getId());
                        deleteDialog.dismiss();
                    }

                    @Override
                    public void onNegativeBtnClicked() {
                        deleteDialog.dismiss();
                    }
                });
            }
        });
        binding.postedJobsRcv.setAdapter(postedTuitionsAdapter);
    }

    private void fetchData() {
        viewModel.getMyJobs();
    }

    @SuppressLint("SetTextI18n")
    private void initObservers() {
        viewModel.getMyJobsLiveData.observe(getViewLifecycleOwner(), getMyTuitionsResponse -> {
            switch (getMyTuitionsResponse.getStatus()) {
                case ERROR:
                    binding.noContentLayout.getRoot().setVisibility(View.GONE);
                    Utils.showToast(requireContext(), getMyTuitionsResponse.getMessage());
                    binding.shimmer.setVisibility(View.GONE);
                    binding.swipeRefreshLayout.setRefreshing(false);
                    break;
                case LOADING:
                    binding.noContentLayout.getRoot().setVisibility(View.GONE);
                    binding.shimmer.setVisibility(View.VISIBLE);
                    break;
                case SUCCESS:
                    data = getMyTuitionsResponse.getData();
                    binding.noContentLayout.getRoot().setVisibility(CollectionUtils.isEmpty(data) ? View.VISIBLE : View.GONE);
                    postedTuitionsAdapter.submitList(data);
                    binding.swipeRefreshLayout.setRefreshing(false);
                    binding.shimmer.setVisibility(View.GONE);
                    break;
            }
        });

        viewModel.deleteJobLiveData.observe(getViewLifecycleOwner(), deleteTuitionResponse -> {
            switch (deleteTuitionResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), deleteTuitionResponse.getMessage());
                    waitingDialog.dismiss();
                    break;
                case LOADING:
                    waitingDialog.show(deleteTuitionResponse.getMessage());
                    break;
                case SUCCESS:
                    Utils.showToast(requireContext(), deleteTuitionResponse.getMessage());
                    waitingDialog.dismiss();
                    viewModel.getMyJobs();
                    break;
            }
        });
    }
}