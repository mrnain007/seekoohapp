package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TutorReview {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("reviewerName")
    @Expose
    private String reviewerName;
    @SerializedName("reviewerImageUrl")
    @Expose
    private String reviewerImageUrl;
    @SerializedName("reviewerId")
    @Expose
    private Integer reviewerId;
    @SerializedName("reviewerRole")
    @Expose
    private Role reviewerRole;
    @SerializedName("tutorId")
    @Expose
    private Integer tutorId;

    public TutorReview() {
    }

    public TutorReview(Integer id, Double rating, String title, String description, String reviewerName, String reviewerImageUrl, Integer reviewerId, Role reviewerRole, Integer tutorId) {
        this.id = id;
        this.rating = rating;
        this.title = title;
        this.description = description;
        this.reviewerName = reviewerName;
        this.reviewerImageUrl = reviewerImageUrl;
        this.reviewerId = reviewerId;
        this.reviewerRole = reviewerRole;
        this.tutorId = tutorId;
    }

    private TutorReview(Builder builder) {
        setId(builder.id);
        setRating(builder.rating);
        setTitle(builder.title);
        setDescription(builder.description);
        setReviewerName(builder.reviewerName);
        setReviewerImageUrl(builder.reviewerImageUrl);
        setReviewerId(builder.reviewerId);
        setReviewerRole(builder.reviewerRole);
        tutorId = builder.tutorId;
    }

    public static Builder builder() {
        return new Builder();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getReviewerName() {
        return reviewerName;
    }

    public void setReviewerName(String reviewerName) {
        this.reviewerName = reviewerName;
    }

    public String getReviewerImageUrl() {
        return reviewerImageUrl;
    }

    public void setReviewerImageUrl(String reviewerImageUrl) {
        this.reviewerImageUrl = reviewerImageUrl;
    }

    public Integer getReviewerId() {
        return reviewerId;
    }

    public void setReviewerId(Integer reviewerId) {
        this.reviewerId = reviewerId;
    }

    public Role getReviewerRole() {
        return reviewerRole;
    }

    public void setReviewerRole(Role reviewerRole) {
        this.reviewerRole = reviewerRole;
    }

    public Integer getTutorId() {
        return tutorId;
    }

    public void setTutorId(Integer tutorId) {
        this.tutorId = tutorId;
    }

    public static final class Builder {
        private Integer id;
        private Double rating;
        private String title;
        private String description;
        private String reviewerName;
        private String reviewerImageUrl;
        private Integer reviewerId;
        private Role reviewerRole;
        private Integer tutorId;

        private Builder() {
        }

        public Builder id(Integer id) {
            this.id = id;
            return this;
        }

        public Builder rating(Double rating) {
            this.rating = rating;
            return this;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder reviewerName(String reviewerName) {
            this.reviewerName = reviewerName;
            return this;
        }

        public Builder reviewerImageUrl(String reviewerImageUrl) {
            this.reviewerImageUrl = reviewerImageUrl;
            return this;
        }

        public Builder reviewerId(Integer reviewerId) {
            this.reviewerId = reviewerId;
            return this;
        }

        public Builder reviewerRole(Role reviewerRole) {
            this.reviewerRole = reviewerRole;
            return this;
        }

        public Builder tutorId(Integer tutorId) {
            this.tutorId = tutorId;
            return this;
        }

        public TutorReview build() {
            return new TutorReview(this);
        }
    }
}
