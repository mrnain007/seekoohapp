package com.jeuxdevelopers.seekooh.ui.tutor.fragments.courses.adapters;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ItemStudentListingBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemTutorListingBinding;
import com.jeuxdevelopers.seekooh.models.Qualification;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TutorListing;
import com.jeuxdevelopers.seekooh.models.dto.CourseEnrollmentResponse;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.List;

public class CourseEnrollmentsAdapter extends ListAdapter<CourseEnrollmentResponse, CourseEnrollmentsAdapter.CourseEnrollmentViewHolder> {
    private static final DiffUtil.ItemCallback<CourseEnrollmentResponse> DIFF_CALLBACK = new DiffUtil.ItemCallback<com.jeuxdevelopers.seekooh.models.dto.CourseEnrollmentResponse>() {
        @Override
        public boolean areItemsTheSame(@NonNull CourseEnrollmentResponse oldItem, @NonNull CourseEnrollmentResponse newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull CourseEnrollmentResponse oldItem, @NonNull CourseEnrollmentResponse newItem) {
            return oldItem.equals(newItem);
        }
    };

    private Listener listener;

    public CourseEnrollmentsAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @NonNull
    @Override
    public CourseEnrollmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemStudentListingBinding binding = ItemStudentListingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new CourseEnrollmentViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseEnrollmentViewHolder holder, int position) {
        holder.binding.getRoot().setOnClickListener(v -> {
            listener.onItemClicked(position, (CourseEnrollmentResponse) getItem(position));
        });
        holder.binding.viewContactBtn.setOnClickListener(v -> {
            listener.onViewContactClicked(position, (CourseEnrollmentResponse) getItem(position));
        });
        holder.binding.sendMsgBtn.setOnClickListener(v -> {
            listener.onSendMessageClicked(position, (CourseEnrollmentResponse) getItem(position));
        });
        holder.bind(getItem(position));
    }

    public static class CourseEnrollmentViewHolder extends RecyclerView.ViewHolder {
        private final ItemStudentListingBinding binding;

        public CourseEnrollmentViewHolder(ItemStudentListingBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(CourseEnrollmentResponse model) {

            CourseEnrollmentResponse.Student data = model.getStudent();
            Glide.with(binding.getRoot()
                            .getContext())
                    .load(data.getProfileImageUrl())
                    .placeholder(R.drawable.profile_image_placeholder)
                    .into(binding.profileImg);
            binding.studentName.setText(data.getFullName());
            binding.locationTv.setText(data.getCity().getName());
//            binding.phoneTv.setText(data.getPhoneNumber());
            binding.boardValuesTv.setText(data.getBoardExam().getName());

            if (data.getOnline() != null && data.getOnline()) {
                binding.lastActiveTv.setText("Active " + Utils.getPrettyTime(System.currentTimeMillis()));
                binding.lastActiveTv.setVisibility(View.VISIBLE);
            } else if (data.getLastSeen() != null) {
                binding.lastActiveTv.setText("Active " + Utils.getPrettyTime(data.getLastSeen()));
                binding.lastActiveTv.setVisibility(View.VISIBLE);
            } else {
                binding.lastActiveTv.setVisibility(View.INVISIBLE);
            }
        }
    }

    public interface Listener {
        void onItemClicked(int position, CourseEnrollmentResponse courseEnrollmentResponse);
        void onViewContactClicked(int position, CourseEnrollmentResponse courseEnrollmentResponse);
        void onSendMessageClicked(int position, CourseEnrollmentResponse courseEnrollmentResponse);
    }
}
