package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TuitionTimeSlot {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("fromTime")
    @Expose
    private Integer fromTime;
    @SerializedName("toTime")
    @Expose
    private Integer toTime;

    public TuitionTimeSlot() {
    }

    public TuitionTimeSlot(Integer id, Integer fromTime, Integer toTime) {
        this.id = id;
        this.fromTime = fromTime;
        this.toTime = toTime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getFromTime() {
        return fromTime;
    }

    public void setFromTime(Integer fromTime) {
        this.fromTime = fromTime;
    }

    public Integer getToTime() {
        return toTime;
    }

    public void setToTime(Integer toTime) {
        this.toTime = toTime;
    }
}
