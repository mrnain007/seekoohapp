package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Subject;

import java.util.List;

public class UpdateInstituteProfileRequest {
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("instituteProfile")
    @Expose
    private InstituteProfile instituteProfile;

    public UpdateInstituteProfileRequest() {
    }

    public UpdateInstituteProfileRequest(String phoneNumber, InstituteProfile instituteProfile) {
        this.phoneNumber = phoneNumber;
        this.instituteProfile = instituteProfile;
    }

    private UpdateInstituteProfileRequest(Builder builder) {
        setPhoneNumber(builder.phoneNumber);
        setInstituteProfile(builder.instituteProfile);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public InstituteProfile getInstituteProfile() {
        return instituteProfile;
    }

    public void setInstituteProfile(InstituteProfile instituteProfile) {
        this.instituteProfile = instituteProfile;
    }

    public static final class Builder {
        private String phoneNumber;
        private InstituteProfile instituteProfile;

        private Builder() {
        }

        public Builder phoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }

        public Builder instituteProfile(InstituteProfile instituteProfile) {
            this.instituteProfile = instituteProfile;
            return this;
        }

        public UpdateInstituteProfileRequest build() {
            return new UpdateInstituteProfileRequest(this);
        }
    }

    public static class InstituteProfile {
        @SerializedName("nameOfInstitute")
        @Expose
        private String nameOfInstitute;
        @SerializedName("description")
        @Expose
        private String description;
        @SerializedName("instituteTypeId")
        @Expose
        private Integer instituteTypeId;
        @SerializedName("isRegistered")
        @Expose
        private Boolean isRegistered;
        @SerializedName("cityId")
        @Expose
        private Integer cityId;
        @SerializedName("subjectIds")
        @Expose
        private List<Integer> subjectIds;
        @SerializedName("classIds")
        @Expose
        private List<Integer> classIds;
        @SerializedName("boardExamIds")
        @Expose
        private List<Integer> boardExamIds;

        public InstituteProfile() {
        }

        private InstituteProfile(Builder builder) {
            setNameOfInstitute(builder.nameOfInstitute);
            setDescription(builder.description);
            setInstituteTypeId(builder.instituteTypeId);
            isRegistered = builder.isRegistered;
            setCityId(builder.cityId);
            setSubjectIds(builder.subjectIds);
            setClassIds(builder.classIds);
            setBoardExamIds(builder.boardExamIds);
        }

        public static Builder builder() {
            return new Builder();
        }

        public String getNameOfInstitute() {
            return nameOfInstitute;
        }

        public void setNameOfInstitute(String nameOfInstitute) {
            this.nameOfInstitute = nameOfInstitute;
        }

        public Integer getInstituteTypeId() {
            return instituteTypeId;
        }

        public void setInstituteTypeId(Integer instituteTypeId) {
            this.instituteTypeId = instituteTypeId;
        }

        public Boolean getRegistered() {
            return isRegistered;
        }

        public void setRegistered(Boolean registered) {
            isRegistered = registered;
        }

        public Integer getCityId() {
            return cityId;
        }

        public void setCityId(Integer cityId) {
            this.cityId = cityId;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public List<Integer> getSubjectIds() {
            return subjectIds;
        }

        public void setSubjectIds(List<Integer> subjectIds) {
            this.subjectIds = subjectIds;
        }

        public List<Integer> getClassIds() {
            return classIds;
        }

        public void setClassIds(List<Integer> classIds) {
            this.classIds = classIds;
        }

        public List<Integer> getBoardExamIds() {
            return boardExamIds;
        }

        public void setBoardExamIds(List<Integer> boardExamIds) {
            this.boardExamIds = boardExamIds;
        }

        public static final class Builder {
            private String nameOfInstitute;
            private String description;
            private Integer instituteTypeId;
            private Boolean isRegistered;
            private Integer cityId;
            private List<Integer> subjectIds;
            private List<Integer> classIds;
            private List<Integer> boardExamIds;

            private Builder() {
            }

            public Builder nameOfInstitute(String nameOfInstitute) {
                this.nameOfInstitute = nameOfInstitute;
                return this;
            }

            public Builder description(String description) {
                this.description = description;
                return this;
            }

            public Builder instituteTypeId(Integer instituteTypeId) {
                this.instituteTypeId = instituteTypeId;
                return this;
            }

            public Builder isRegistered(Boolean isRegistered) {
                this.isRegistered = isRegistered;
                return this;
            }

            public Builder cityId(Integer cityId) {
                this.cityId = cityId;
                return this;
            }

            public Builder subjectIds(List<Integer> subjectIds) {
                this.subjectIds = subjectIds;
                return this;
            }

            public Builder classIds(List<Integer> classIds) {
                this.classIds = classIds;
                return this;
            }

            public Builder boardExamIds(List<Integer> boardExamIds) {
                this.boardExamIds = boardExamIds;
                return this;
            }

            public InstituteProfile build() {
                return new InstituteProfile(this);
            }
        }
    }
}
