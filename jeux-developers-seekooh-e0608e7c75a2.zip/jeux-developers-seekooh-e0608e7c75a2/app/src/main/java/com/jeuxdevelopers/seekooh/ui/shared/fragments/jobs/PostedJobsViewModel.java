package com.jeuxdevelopers.seekooh.ui.shared.fragments.jobs;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.TeachingJob;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class PostedJobsViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<List<TeachingJob>>> getMyJobsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Void>> deleteJobLiveData = new MutableLiveData<>();

    public PostedJobsViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getMyJobs() {
        disposables.add(appRepo.getMyTeachingJobs()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getMyJobsResource -> {
                    getMyJobsLiveData.setValue(getMyJobsResource);
                }, throwable -> {
                    getMyJobsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void deleteJob(@NonNull Integer jobId) {
        disposables.add(appRepo.deleteTeachingJob(jobId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(deleteJobResource -> {
                    deleteJobLiveData.setValue(deleteJobResource);
                }, throwable -> {
                    deleteJobLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
