package com.jeuxdevelopers.seekooh.ui.shared.fragments.auth.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.jeuxdevelopers.seekooh.ui.institute.fragments.login.InstituteLoginFragment;
import com.jeuxdevelopers.seekooh.ui.student.fragments.login.StudentLoginFragment;
import com.jeuxdevelopers.seekooh.ui.tutor.fragments.login.TutorLoginFragment;

public class AuthPagerAdapter extends FragmentStateAdapter {
    public AuthPagerAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new StudentLoginFragment();
            case 1:
                return new TutorLoginFragment();
            case 2:
                return new InstituteLoginFragment();
        }
        return null;
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
