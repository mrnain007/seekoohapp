package com.jeuxdevelopers.seekooh.ui.shared.activities.chat;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.chat.Chat;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;
import com.jeuxdevelopers.seekooh.models.chat.Message;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;
import com.jeuxdevelopers.seekooh.repos.chat.ChatRepo;
import com.jeuxdevelopers.seekooh.repos.chat.ChatRepoImpl;

import java.util.List;
import java.util.concurrent.Callable;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.functions.BiFunction;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class ChatViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;
    private final ChatRepo chatRepo;

    public MutableLiveData<Resource<String>> createPrivateChatAndSendLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Boolean>> userBlockLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Boolean>> userUnBlockLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<String>> createPrivateChatLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Message>> sendMessageLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Boolean>> markSeenLiveData = new MutableLiveData<>();

    public ChatViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
        this.chatRepo = new ChatRepoImpl();
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void createPrivateChatAndSend(@NonNull FirebaseUser user01, @NonNull FirebaseUser user02, @NonNull Message message) {
        disposables.add(Single.fromCallable(() -> {
                    String chatId = chatRepo.createPrivateChat(user01, user02).blockingGet();
                    createPrivateChatAndSendLiveData.postValue(Resource.success("Chat created successfully.", chatId));
                    return chatRepo.sendMessage(message).blockingGet();
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(sentMessage -> {
                    sendMessageLiveData.postValue(Resource.success("Message sent.", sentMessage));
                }, throwable -> {
                    createPrivateChatAndSendLiveData.postValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void blockUser(@NonNull List<FirebaseUser> list, String documentId) {
        disposables.add(chatRepo.blockUser(list, documentId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(userBlockResponse -> {
                    userBlockLiveData.setValue(Resource.success("User Blocked successfully.", userBlockResponse));
                }, throwable -> {
                    userBlockLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void unBlockUser(@NonNull List<FirebaseUser> list, String documentId) {
        disposables.add(chatRepo.unBlockUser(list, documentId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(userUnBlockResponse -> {
                    userUnBlockLiveData.setValue(Resource.success("User has been successfully unblocked.", userUnBlockResponse));
                }, throwable -> {
                    userUnBlockLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void createPrivateChat(@NonNull FirebaseUser user01, @NonNull FirebaseUser user02) {
        disposables.add(chatRepo.createPrivateChat(user01, user02)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(createChatResponse -> {
                    createPrivateChatLiveData.setValue(Resource.success("Chat created successfully.", createChatResponse));
                }, throwable -> {
                     createPrivateChatLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void sendMessage(@NonNull Message message) {
        disposables.add(chatRepo.sendMessage(message)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(createChatResponse -> {
                    sendMessageLiveData.setValue(Resource.success("Message sent successfully.", message));
                }, throwable -> {
                    sendMessageLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void markSeen(@NonNull String chatId, @NonNull String currentUserId) {
        disposables.add(chatRepo.markSeen(chatId, currentUserId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(markSeenResponse -> {
                    markSeenLiveData.setValue(Resource.success("Chat marked as seen successfully.", markSeenResponse));
                }, throwable -> {
                    markSeenLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void sendNotification(Context context, Chat chat, Message data) {
        chatRepo.sendNotification(context, chat, data);
    }
}
