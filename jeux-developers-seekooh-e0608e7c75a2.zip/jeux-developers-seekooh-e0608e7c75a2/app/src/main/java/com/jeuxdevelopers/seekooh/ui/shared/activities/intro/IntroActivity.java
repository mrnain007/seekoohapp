package com.jeuxdevelopers.seekooh.ui.shared.activities.intro;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.jeuxdevelopers.seekooh.databinding.ActivityIntroBinding;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;

public class IntroActivity extends AppCompatActivity implements View.OnClickListener {

    private ActivityIntroBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityIntroBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initClickListeners();
    }

    private void initClickListeners() {
        binding.getStartedBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == binding.getStartedBtn.getId()) {
            startActivity(new Intent(this, AuthActivity.class));
        }
    }
}