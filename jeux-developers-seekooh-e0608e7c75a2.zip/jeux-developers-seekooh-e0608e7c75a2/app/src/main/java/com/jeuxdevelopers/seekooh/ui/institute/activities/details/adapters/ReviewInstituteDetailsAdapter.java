package com.jeuxdevelopers.seekooh.ui.institute.activities.details.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ItemReviewInstituteDetailsBinding;
import com.jeuxdevelopers.seekooh.models.InstituteReview;

public class ReviewInstituteDetailsAdapter extends ListAdapter<InstituteReview, ReviewInstituteDetailsAdapter.ReviewViewHolder> {

    private static final DiffUtil.ItemCallback<InstituteReview> DIFF_CALLBACK = new DiffUtil.ItemCallback<InstituteReview>() {
        @Override
        public boolean areItemsTheSame(@NonNull InstituteReview oldItem, @NonNull InstituteReview newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull InstituteReview oldItem, @NonNull InstituteReview newItem) {
            return oldItem.equals(newItem);
        }
    };

    public ReviewInstituteDetailsAdapter() {
        super(DIFF_CALLBACK);
    }

    @NonNull
    @Override
    public ReviewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemReviewInstituteDetailsBinding binding = ItemReviewInstituteDetailsBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ReviewViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ReviewViewHolder holder, int position) {
        holder.bind(getItem(position));
    }

    public static class ReviewViewHolder extends RecyclerView.ViewHolder {
        private final ItemReviewInstituteDetailsBinding binding;

        public ReviewViewHolder(ItemReviewInstituteDetailsBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(InstituteReview model) {
            Glide.with(binding.getRoot().getContext())
                    .load(model.getReviewerImageUrl())
                    .placeholder(R.drawable.profile_image_placeholder)
                    .into(binding.reviewerProfileImg);
            binding.ratingBar.setRating(model.getRating().floatValue());
            binding.reviewerName.setText(model.getReviewerName());
            binding.reviewTitleTv.setText(model.getTitle());
            binding.reviewDescTv.setText(model.getDescription());
        }
    }
}
