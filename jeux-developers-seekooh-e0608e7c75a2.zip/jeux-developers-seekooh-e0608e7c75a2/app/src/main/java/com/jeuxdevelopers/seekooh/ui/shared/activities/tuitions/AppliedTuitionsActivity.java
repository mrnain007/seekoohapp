package com.jeuxdevelopers.seekooh.ui.shared.activities.tuitions;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.common.util.CollectionUtils;
import com.jeuxdevelopers.seekooh.databinding.ActivityAppliedTuitionsBinding;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationResponse;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.DeleteDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions.adapters.AppliedTuitionsAdapter;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class AppliedTuitionsActivity extends AppCompatActivity {

    private ActivityAppliedTuitionsBinding binding;
    private AppliedTuitionViewModel viewModel;
    private AppliedTuitionsAdapter appliedTuitionsAdapter;
    private WaitingDialog waitingDialog;
    private DeleteDialog deleteDialog;
    private List<TuitionApplicationResponse> data;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAppliedTuitionsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        viewModel = new ViewModelProvider(this).get(AppliedTuitionViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        fetchData();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(this, this::onBackPressed);
        deleteDialog = new DeleteDialog(this);
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            viewModel.getAppliedTuitions();
        });
        initRecycler();
    }

    private void fetchData() {
        viewModel.getAppliedTuitions();
    }

    private void initObservers() {
        viewModel.appliedTuitionsLiveData.observe(this, appliedTuitionsResponse -> {
            switch (appliedTuitionsResponse.getStatus()) {
                case ERROR:
                    binding.noContentLayout.getRoot().setVisibility(View.GONE);
                    Utils.showToast(this, appliedTuitionsResponse.getMessage());
                    binding.shimmer.setVisibility(View.GONE);
                    binding.swipeRefreshLayout.setRefreshing(false);
                    break;
                case LOADING:
                    binding.noContentLayout.getRoot().setVisibility(View.GONE);
                    binding.shimmer.setVisibility(View.VISIBLE);
                    break;
                case SUCCESS:
                    data = appliedTuitionsResponse.getData();
                    binding.noContentLayout.getRoot().setVisibility(CollectionUtils.isEmpty(data) ? View.VISIBLE : View.GONE);
                    appliedTuitionsAdapter.submitList(data);
                    binding.swipeRefreshLayout.setRefreshing(false);
                    binding.shimmer.setVisibility(View.GONE);
                    break;
            }
        });

        viewModel.deleteTuitionApplicationLiveData.observe(this, withdrawalResponse -> {
            switch (withdrawalResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(this, withdrawalResponse.getMessage());
                    waitingDialog.dismiss();
                    break;
                case LOADING:
                    waitingDialog.show(withdrawalResponse.getMessage());
                    break;
                case SUCCESS:
                    Utils.showToast(this, withdrawalResponse.getMessage());
                    waitingDialog.dismiss();
                    viewModel.getAppliedTuitions();
                    break;
            }
        });
    }

    private void initClickListeners() {
        binding.backBtn.setOnClickListener(v -> {
            onBackPressed();
        });
    }

    private void initRecycler() {
        // Listing Rcv
        appliedTuitionsAdapter = new AppliedTuitionsAdapter(binding.appliedTuitionsRcv, position -> {
            deleteDialog.show("Delete Application", "Are you sure you want to delete?", new DeleteDialog.Listener() {
                @Override
                public void onPositiveBtnClicked() {
                    TuitionApplicationResponse tuitionApplicationResponse = AppliedTuitionsActivity.this.data.get(position);
                    viewModel.deleteTuitionApplication(tuitionApplicationResponse.getTuition().getId());
                    deleteDialog.dismiss();
                }

                @Override
                public void onNegativeBtnClicked() {
                    deleteDialog.dismiss();
                }
            });
        });
        binding.appliedTuitionsRcv.setAdapter(appliedTuitionsAdapter);
        appliedTuitionsAdapter.submitList(new ArrayList<>());

        binding.appliedTuitionsRcv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING) {
                    LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
                    if (layoutManager == null) {
                        return;
                    }
                    int firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition();
                    int lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition();

                    for (int i = firstVisibleItemPosition; i <= lastVisibleItemPosition; i++) {
                        View view = layoutManager.findViewByPosition(i);
                        MotionLayout ml = (MotionLayout) view;
                        if (ml == null) {
                            continue;
                        }
                        ml.transitionToStart();
                    }
                }
            }
        });

    }
}