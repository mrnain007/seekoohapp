package com.jeuxdevelopers.seekooh.ui.tutor.activities.details;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.TutorDetails;
import com.jeuxdevelopers.seekooh.models.TutorReview;
import com.jeuxdevelopers.seekooh.models.dto.CreateTutorReviewRequest;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class TutorDetailsViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<TutorDetails>> tutorDetailsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<TutorReview>>> tutorReviewsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<TutorReview>> createTutorReviewLiveData = new MutableLiveData<>();

    public TutorDetailsViewModel() {
        appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getTutorDetails(@NonNull Integer tutorId) {
        disposables.add(appRepo.getTutorDetails(tutorId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(tutorDetailsResource -> {
                    tutorDetailsLiveData.setValue(tutorDetailsResource);
                }, throwable -> {
                    tutorDetailsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getTutorReviews(@NonNull Integer tutorId) {
        disposables.add(appRepo.getTutorReviews(tutorId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getTutorReviewsResource -> {
                    tutorReviewsLiveData.setValue(getTutorReviewsResource);
                }, throwable -> {
                    tutorReviewsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void createTutorReview(@NonNull Integer tutorId, @NonNull CreateTutorReviewRequest createTutorReviewRequest) {
        disposables.add(appRepo.createTutorReview(tutorId, createTutorReviewRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(createTutorReviewResource -> {
                    createTutorReviewLiveData.setValue(createTutorReviewResource);
                }, throwable -> {
                    createTutorReviewLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
