package com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.SalaryType;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.dto.CreateTuitionRequest;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class PostedTuitionsViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<List<Tuition>>> getMyTuitionsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Void>> deleteTuitionLiveData = new MutableLiveData<>();

    public PostedTuitionsViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getMyTuitions() {
        disposables.add(appRepo.getMyTuitions()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getMyTuitionsResource -> {
                    getMyTuitionsLiveData.setValue(getMyTuitionsResource);
                }, throwable -> {
                    getMyTuitionsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void deleteTuition(@NonNull Integer tuitionId) {
        disposables.add(appRepo.deleteTuition(tuitionId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(editTuitionResource -> {
                    deleteTuitionLiveData.setValue(editTuitionResource);
                }, throwable -> {
                    deleteTuitionLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
