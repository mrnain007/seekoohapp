package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.bumptech.glide.util.Util;
import com.google.android.gms.common.util.CollectionUtils;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;

public class MultiChoiceDialog<T> {
    private static final String TAG = "MultiChoiceDialog";
    private Context context;
    private Options options;
    private List<T> itemsList;
    private Function<T, String> toString;
    private List<String> itemsStringList;
    private OnPositiveBtnClicked onPositiveBtnClicked;
    private OnNegativeBtnClicked onNegativeBtnClicked;

    private boolean[] selectedItems;
    private String selectedItemNames = "";
    private List<T> selectedItemsList = new ArrayList<>();

    public MultiChoiceDialog(Context context, List<T> itemsList, Function<T, String> toString, OnPositiveBtnClicked onPositiveBtnClicked) {
        this.context = context;
        this.itemsList = itemsList;
        this.toString = toString;
        this.onPositiveBtnClicked = onPositiveBtnClicked;
        init();
    }

    public MultiChoiceDialog(Context context, List<T> itemsList, List<String> itemsStringList, OnPositiveBtnClicked onPositiveBtnClicked, OnNegativeBtnClicked onNegativeBtnClicked) {
        this.context = context;
        this.options = options;
        this.itemsList = itemsList;
        this.itemsStringList = itemsStringList;
        this.onPositiveBtnClicked = onPositiveBtnClicked;
        this.onNegativeBtnClicked = onNegativeBtnClicked;
        init();
    }

    public MultiChoiceDialog(Context context, Options options, List<T> itemsList, Function<T, String> toString, OnPositiveBtnClicked onPositiveBtnClicked) {
        this.context = context;
        this.options = options;
        this.itemsList = itemsList;
        this.toString = toString;
        this.onPositiveBtnClicked = onPositiveBtnClicked;
        init();
    }

    public MultiChoiceDialog(Context context, Options options, List<T> itemsList, List<String> itemsStringList, OnPositiveBtnClicked onPositiveBtnClicked, OnNegativeBtnClicked onNegativeBtnClicked) {
        this.context = context;
        this.options = options;
        this.itemsList = itemsList;
        this.itemsStringList = itemsStringList;
        this.onPositiveBtnClicked = onPositiveBtnClicked;
        this.onNegativeBtnClicked = onNegativeBtnClicked;
        init();
    }

    public List<T> getSelectedItemsList() {
        return selectedItemsList;
    }

    public void setSelectedItemsList(List<T> selectedItemsList, Function<T, Integer> toId) {
        this.selectedItemsList = selectedItemsList;

        Set<Integer> selectedIds = new HashSet<>();
        for (T selectedItem : selectedItemsList) {
            selectedIds.add(toId.apply(selectedItem));
        }
        for (int i = 0; i < itemsList.size(); i++) {
            T item = itemsList.get(i);
            if (selectedIds.contains(toId.apply(item))) {
                selectedItems[i] = true;
            }
        }
    }

    @NonNull
    public String getSelectedItemNames(Function<T, String> toString) {
        return String.join(", ", Utils.toStringList(getSelectedItemsList(), toString));
    }

    private void init() {
        itemsStringList = Utils.toStringList(itemsList, toString);
        setOptions();
        selectedItems = new boolean[itemsStringList.size()];
    }

    private void setOptions() {
        if (options == null) {
            options = Options.builder().build();
        }
        if (options.isSortList()) {
            Collections.sort(this.itemsList, Comparator.comparing(toString));
            Collections.sort(this.itemsStringList);
        }
    }

    public void setItemsList(List<T> itemsList) {
        this.itemsList = itemsList;
        itemsStringList = Utils.toStringList(itemsList, toString);
        setOptions();
        selectedItems = new boolean[itemsStringList.size()];
    }

    private void updateSelectedItemsList() {
        selectedItemsList.clear();
        for (int i = 0; i < selectedItems.length; i++) {
            if (selectedItems[i]) {
                selectedItemsList.add(itemsList.get(i));
            }
        }
    }

    public void show(String title) {
        new AlertDialog.Builder(context).setTitle(title)
                .setMultiChoiceItems(itemsStringList.toArray(new String[0]), selectedItems, (dialog, which, isChecked) -> selectedItems[which] = isChecked)
                .setPositiveButton("Ok", (dialog, which) -> {
                    updateSelectedItemsList();
                    selectedItemNames = String.join(", ", Utils.toStringList(selectedItemsList, toString));
                    onPositiveBtnClicked.onPositiveBtnClicked(selectedItemNames);
                }).setNegativeButton("Cancel", (dialog, which) -> {
                    if (onNegativeBtnClicked != null)
                        onNegativeBtnClicked.onNegativeBtnClicked();
                }).show();
    }

    public void show(String title, List<T> itemsList) {
        setItemsList(itemsList);
        new AlertDialog.Builder(context).setTitle(title)
                .setMultiChoiceItems(itemsStringList.toArray(new String[0]), selectedItems, (dialog, which, isChecked) -> selectedItems[which] = isChecked)
                .setPositiveButton("Ok", (dialog, which) -> {
                    updateSelectedItemsList();
                    selectedItemNames = String.join(", ", Utils.toStringList(selectedItemsList, toString));
                    onPositiveBtnClicked.onPositiveBtnClicked(selectedItemNames);
                }).setNegativeButton("Cancel", (dialog, which) -> {
                    if (onNegativeBtnClicked != null)
                        onNegativeBtnClicked.onNegativeBtnClicked();
                }).show();
    }

    public interface OnPositiveBtnClicked {
        void onPositiveBtnClicked(@NonNull String selectedItemNames);
    }

    public interface OnNegativeBtnClicked {
        void onNegativeBtnClicked();
    }

    public static class Options {
        private boolean sortList = true;

        public Options(boolean sortList) {
            this.sortList = sortList;
        }

        private Options(Builder builder) {
            setSortList(builder.sortList);
        }

        public static Builder builder() {
            return new Builder();
        }

        public boolean isSortList() {
            return sortList;
        }

        public void setSortList(boolean sortList) {
            this.sortList = sortList;
        }

        public static final class Builder {
            private boolean sortList;

            private Builder() {
            }

            public Builder sortList(boolean sortList) {
                this.sortList = sortList;
                return this;
            }

            public Options build() {
                return new Options(this);
            }
        }
    }
}
