package com.jeuxdevelopers.seekooh.ui.tutor.fragments.profile;

import android.Manifest;
import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.common.util.CollectionUtils;
import com.jaiselrahman.filepicker.activity.FilePickerActivity;
import com.jaiselrahman.filepicker.config.Configurations;
import com.jaiselrahman.filepicker.model.MediaFile;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.ExperienceLgLayoutBinding;
import com.jeuxdevelopers.seekooh.databinding.FragmentTutorProfileBinding;
import com.jeuxdevelopers.seekooh.databinding.QualificationLgLayoutBinding;
import com.jeuxdevelopers.seekooh.exceptions.MissingPermissionException;
import com.jeuxdevelopers.seekooh.models.Address;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Experience;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Qualification;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TutorTimeSlot;
import com.jeuxdevelopers.seekooh.models.dto.GetProfileResponse;
import com.jeuxdevelopers.seekooh.models.dto.UpdateTutorProfileRequest;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.MultiChoiceDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.VideoDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.io.File;
import java.net.URI;
import java.time.DayOfWeek;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;

public class TutorProfileFragment extends Fragment {
    private static final String TAG = "TutorProfileFragment";
    private final CompositeDisposable disposables = new CompositeDisposable();

    private final int PROFILE_IMAGE_REQUEST_CODE = 1000;
    private final int REQUEST_CODE_SELECT_VIDEO = 1001;
    private static final int LOCATION_REQ_CODE = 1002;
    private static final int STORAGE_REQ_CODE = 1003;
    private boolean isTextWatcherEnabled = false;
    private boolean isEditModeEnabled = false;
    private Uri profileImageUri;
    private Uri profileVideoUri;
    private Integer selectedGender;

    private FragmentTutorProfileBinding binding;
    private TutorProfileViewModel viewModel;
    private OnBackPressedCallback callback;
    private WaitingDialog waitingDialog;
    private VideoDialog videoDialog;
    private GetProfileResponse data;

    // Drop downs
    private ArrayAdapter<String> citiesArrayAdapter;
    private List<City> citiesList = new ArrayList<>();
    private City selectedCity;

    private TextWatcher textWatcher;

    private List<QualificationLgLayoutBinding> qualificationLayoutsList = new ArrayList<>();
    private List<ExperienceLgLayoutBinding> experienceLayoutsList = new ArrayList<>();

    private MultiChoiceDialog<Subject> subjectMultiChoiceDialog;
    private MultiChoiceDialog<Grade> gradeMultiChoiceDialog;
    private MultiChoiceDialog<Board> boardMultiChoiceDialog;
    private MultiChoiceDialog<DayOfWeek> daysMultiChoiceDialog;

    // Location
    private android.location.Location currentLocation;

    private int startTimeInMinutes = -1;
    private int endTimeInMinutes = -1;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (!isEditModeEnabled) {
                    setEnabled(false);
                    requireActivity().onBackPressed();
                } else {
                    setEditMode(false);
                }
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentTutorProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(TutorProfileViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        initProfile();
    }

    @Override
    public void onDestroy() {
        disposables.dispose();
        super.onDestroy();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext());
        videoDialog = new VideoDialog(requireContext());
        initDaysDialog();
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO}, STORAGE_REQ_CODE);
        } else {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_REQ_CODE);
        }
    }

    private boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED;
        } else {
            return ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestLocationPermissions() {
        ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQ_CODE);
    }

    private boolean isLocationPermissionGranted() {
        return ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void initDaysDialog() {
        List<DayOfWeek> daysOfWeek = Arrays.asList(DayOfWeek.values());
        MultiChoiceDialog.Options options = MultiChoiceDialog.Options.builder()
                .sortList(false)
                .build();
        daysMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                options,
                daysOfWeek,
                dayOfWeek -> dayOfWeek.getDisplayName(TextStyle.FULL, Locale.getDefault()),
                selectedItemNames -> {
                    binding.daysAcTv.setText(selectedItemNames);
                });
    }

    private void initTextWatcher() {
        textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateUserInput();
                }
            }
        };

        binding.nameTl.getEditText().addTextChangedListener(textWatcher);
        binding.phoneTl.getEditText().addTextChangedListener(textWatcher);
        binding.addressTl.getEditText().addTextChangedListener(textWatcher);
        binding.tagLineTl.getEditText().addTextChangedListener(textWatcher);
        binding.qualificationEtLayout.degreeNameTl.getEditText().addTextChangedListener(textWatcher);
        binding.qualificationEtLayout.yearTl.getEditText().addTextChangedListener(textWatcher);
        binding.qualificationEtLayout.marksTl.getEditText().addTextChangedListener(textWatcher);
        binding.experienceEtLayout.experienceDurationTl.getEditText().addTextChangedListener(textWatcher);
        binding.experienceEtLayout.experienceDetailsTl.getEditText().addTextChangedListener(textWatcher);
        binding.subjectTl.getEditText().addTextChangedListener(textWatcher);
        binding.classesTl.getEditText().addTextChangedListener(textWatcher);
        binding.boardTl.getEditText().addTextChangedListener(textWatcher);
        binding.citiesTl.getEditText().addTextChangedListener(textWatcher);
        binding.locationTl.getEditText().addTextChangedListener(textWatcher);
        binding.timingFromTl.getEditText().addTextChangedListener(textWatcher);
        binding.timingToTl.getEditText().addTextChangedListener(textWatcher);
        binding.areaTl.getEditText().addTextChangedListener(textWatcher);
        binding.daysTl.getEditText().addTextChangedListener(textWatcher);
    }

    private void setCitiesDropDown() {
        citiesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(citiesList, City::getName));
        binding.citiesAcTv.setAdapter(citiesArrayAdapter);
        binding.citiesAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = citiesList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void initClickListeners() {
        initTextWatcher();
        binding.timingFromTl.getEditText().setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                    (view, selectedHour, selectedMinute) -> {
                        String formattedTime = Utils.getFormattedTime(selectedHour, selectedMinute);
                        binding.timingFromTl.getEditText().setText(formattedTime);
                        startTimeInMinutes = selectedHour * 60 + selectedMinute;
                    }, hour, minute, false);
            timePickerDialog.show();
        });
        binding.timingToTl.getEditText().setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                    (view, selectedHour, selectedMinute) -> {
                        String formattedTime = Utils.getFormattedTime(selectedHour, selectedMinute);
                        binding.timingToTl.getEditText().setText(formattedTime);
                        endTimeInMinutes = selectedHour * 60 + selectedMinute;
                    }, hour, minute, false);
            timePickerDialog.show();
        });
        binding.daysAcTv.setOnClickListener(v -> {
            daysMultiChoiceDialog.show("Preferred days of teaching?");
        });
        binding.classesAcTv.setOnClickListener(v -> {
            gradeMultiChoiceDialog.show("Select classes you teach?");
        });
        binding.subjectAcTv.setOnClickListener(v -> {
            subjectMultiChoiceDialog.show("Select subjects you teach?");
        });
        binding.boardExamAcTv.setOnClickListener(v -> {
            boardMultiChoiceDialog.show("Select board/exam you teach?");
        });
        binding.addMoreQualificationBtn.setOnClickListener(v -> {
            QualificationLgLayoutBinding view = QualificationLgLayoutBinding.inflate(getLayoutInflater());
            view.degreeNameTl.getEditText().addTextChangedListener(textWatcher);
            view.yearTl.getEditText().addTextChangedListener(textWatcher);
            view.marksTl.getEditText().addTextChangedListener(textWatcher);
            qualificationLayoutsList.add(view);
            int lastEtIndex = binding.qualificationDetailsLl.indexOfChild(binding.addMoreQualificationBtn);

            view.removeBtn.setOnClickListener(v1 -> {
                view.degreeNameTl.getEditText().removeTextChangedListener(textWatcher);
                view.yearTl.getEditText().removeTextChangedListener(textWatcher);
                view.marksTl.getEditText().removeTextChangedListener(textWatcher);
                qualificationLayoutsList.remove(view);
                binding.qualificationDetailsLl.removeView(view.getRoot());
            });
            view.removeBtn.setVisibility(View.VISIBLE);
            binding.qualificationDetailsLl.addView(view.getRoot(), lastEtIndex);
        });
        binding.addMoreExperienceBtn.setOnClickListener(v -> {
            ExperienceLgLayoutBinding view = ExperienceLgLayoutBinding.inflate(getLayoutInflater());
            view.experienceDurationTl.getEditText().addTextChangedListener(textWatcher);
            view.experienceDetailsTl.getEditText().addTextChangedListener(textWatcher);
            experienceLayoutsList.add(view);
            int lastEtIndex = binding.qualificationDetailsLl.indexOfChild(binding.addMoreExperienceBtn);
            view.removeBtn.setOnClickListener(v1 -> {
                view.experienceDurationTl.getEditText().removeTextChangedListener(textWatcher);
                view.experienceDetailsTl.getEditText().removeTextChangedListener(textWatcher);
                experienceLayoutsList.remove(view);
                binding.qualificationDetailsLl.removeView(view.getRoot());
            });
            view.removeBtn.setVisibility(View.VISIBLE);
            binding.qualificationDetailsLl.addView(view.getRoot(), lastEtIndex);
        });
        binding.profileImg.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(1024).maxResultSize(1920, 1920).crop(1, 1).start(PROFILE_IMAGE_REQUEST_CODE);
        });
        binding.profileImgPickerBtn.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(1024).maxResultSize(1920, 1920).crop(1, 1).start(PROFILE_IMAGE_REQUEST_CODE);
        });
        binding.logoutBtn.setOnClickListener(v -> {
            UserPrefs.clearUser(requireContext());
            startActivity(new Intent(requireContext(), AuthActivity.class));
            App.syncPresence();
            requireActivity().finishAffinity();
        });
        binding.genderRg.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == binding.radioMale.getId()) {
                selectedGender = 1;
            } else if (checkedId == binding.radioFemale.getId()) {
                selectedGender = 2;
            }
        });
        binding.addVideoBtn.setOnClickListener(v -> {
            /*Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("video/*");
            startActivityForResult(intent, REQUEST_CODE_SELECT_VIDEO);*/
//            pickVideo();

            if (isStoragePermissionGranted()) {
//                launchVideoPicker();
                pickVideo();
            } else {
                requestStoragePermissions();
            }
        });
        binding.locationTl.getEditText().setOnClickListener(v -> {
            if (isLocationPermissionGranted()) {
                getCurrentLocation();
            } else {
                requestLocationPermissions();
            }
        });

        binding.editBtn.setOnClickListener(v -> {
            if (isEditModeEnabled) {
                if (validateUserInput()) {
                    String name = binding.nameTl.getEditText().getText().toString().trim();
                    String phone = binding.phoneTl.getEditText().getText().toString().trim();
                    String address = binding.addressTl.getEditText().getText().toString().trim();
                    String tagLine = binding.tagLineTl.getEditText().getText().toString().trim();
                    String desc = binding.descriptionTl.getEditText().getText().toString().trim();
                    String degreeNameField = binding.qualificationEtLayout.degreeNameTl.getEditText().getText().toString().trim();
                    String yearField = binding.qualificationEtLayout.yearTl.getEditText().getText().toString().trim();
                    String marksField = binding.qualificationEtLayout.marksTl.getEditText().getText().toString().trim();
                    String experienceDuration = binding.experienceEtLayout.experienceDurationTl.getEditText().getText().toString().trim();
                    String experienceDetails = binding.experienceEtLayout.experienceDetailsTl.getEditText().getText().toString().trim();
                    String area = binding.areaTl.getEditText().getText().toString().trim();
                    List<DayOfWeek> selectedDaysList = daysMultiChoiceDialog.getSelectedItemsList();

                    List<Qualification> qualificationList = new ArrayList<>();
                    qualificationList.add(new Qualification(null, degreeNameField, Integer.valueOf(yearField), Double.valueOf(marksField)));
                    List<Experience> experienceList = new ArrayList<>();
                    experienceList.add(new Experience(null, experienceDuration, experienceDetails));
                    List<Subject> selectedSubjects = subjectMultiChoiceDialog.getSelectedItemsList();
                    List<Grade> selectedClasses = gradeMultiChoiceDialog.getSelectedItemsList();
                    List<Board> selectedBoardExams = boardMultiChoiceDialog.getSelectedItemsList();

                    for (QualificationLgLayoutBinding qualificationEditTextLayoutBinding : qualificationLayoutsList) {
                        String degreeName = qualificationEditTextLayoutBinding.degreeNameTl.getEditText().getText().toString().trim();
                        String year = qualificationEditTextLayoutBinding.yearTl.getEditText().getText().toString().trim();
                        String marks = qualificationEditTextLayoutBinding.marksTl.getEditText().getText().toString().trim();
                        qualificationList.add(new Qualification(null, degreeName, Integer.valueOf(year), Double.valueOf(marks)));
                    }

                    for (ExperienceLgLayoutBinding experienceLayoutBinding : experienceLayoutsList) {
                        String duration = experienceLayoutBinding.experienceDurationTl.getEditText().getText().toString().trim();
                        String details = experienceLayoutBinding.experienceDetailsTl.getEditText().getText().toString().trim();
                        experienceList.add(new Experience(null, duration, details));
                    }

                    Address oldAddress = data.getTutorProfile().getAddress();

                    UpdateTutorProfileRequest.TutorProfile tutorProfile = UpdateTutorProfileRequest.TutorProfile.builder()
                            .address(new Address(null, currentLocation == null ? oldAddress.getLatitude() : currentLocation.getLatitude(),
                                    currentLocation == null ? oldAddress.getLongitude() : currentLocation.getLongitude(),
                                    address, area))
                            .tagLine(tagLine)
                            .description(TextUtils.isEmpty(desc) ? null : desc)
                            .qualifications(qualificationList)
                            .experiences(experienceList)
                            .subjectIds(Utils.toIdList(selectedSubjects, Subject::getId))
                            .boardExamIds(Utils.toIdList(selectedBoardExams, Board::getId))
                            .availableDayValues(Utils.toIdList(selectedDaysList, DayOfWeek::getValue))
                            .cityId(selectedCity.getId())
                            .classIds(Utils.toIdList(selectedClasses, Grade::getId))
                            .teachOnline(binding.teachOnlineSw.isChecked())
                            .teachAtLocation(binding.teachAtLocationSw.isChecked())
                            .timeSlots(Collections.singletonList(new TutorTimeSlot(null, startTimeInMinutes, endTimeInMinutes)))
                            .build();


                    UpdateTutorProfileRequest updateTutorProfileRequest = UpdateTutorProfileRequest.builder()
                            .fullName(name)
                            .phoneNumber(phone)
                            .genderId(selectedGender)
                            .tutorProfile(tutorProfile)
                            .build();

                    viewModel.updateTutorProfile(profileImageUri == null ? null : URI.create(profileImageUri.toString()), profileVideoUri == null ? null : URI.create(profileVideoUri.toString()), updateTutorProfileRequest);
                }
            } else {
                setEditMode(true);
            }
        });
    }

    private void pickVideo() {
        Intent intent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("video/*");
        } else {
            intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
        }

        startActivityForResult(intent, REQUEST_CODE_SELECT_VIDEO);
    }

    private void launchVideoPicker() {
        Intent intent = new Intent(requireContext(), FilePickerActivity.class);
        intent.putExtra(FilePickerActivity.CONFIGS, new Configurations.Builder()
                .setCheckPermission(true)
                .setShowVideos(true)
                .setShowFiles(false)
                .setSingleChoiceMode(true)
                .enableVideoCapture(false)
                .build());

        startActivityForResult(intent, REQUEST_CODE_SELECT_VIDEO);
    }

    private void getCurrentLocation() {
        disposables.add(Utils.getCurrentLocation(requireContext())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(location -> {
                    currentLocation = location;
                    binding.locationTl.getEditText().setText(Utils.getAddressFromLatLng(requireContext(), currentLocation.getLatitude(), currentLocation.getLongitude()));
                }, throwable -> {
                    Utils.showToast(requireContext(), throwable.getMessage());
                    if (throwable instanceof MissingPermissionException) {
                        requestLocationPermissions();
                    }
                }));
    }

    private void initObservers() {
        viewModel.getProfileLiveData
                .observe(getViewLifecycleOwner(), profileResponseResource -> {
                    waitingDialog.dismiss();
                    switch (profileResponseResource.getStatus()) {
                        case ERROR:
                            Utils.showToast(requireContext(), profileResponseResource.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(profileResponseResource.getMessage());
                            break;
                        case SUCCESS:
                            Utils.showToast(requireContext(), profileResponseResource.getMessage());
                            data = profileResponseResource.getData();
                            fetchData();
                            setData();
                            break;
                    }
                });

        viewModel.getSubjectsLiveData.observe(getViewLifecycleOwner(), getSubjectsResponse -> {
            switch (getSubjectsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSubjectsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Subject> subjectsList = getSubjectsResponse.getData();
                    subjectMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            subjectsList,
                            Subject::getName,
                            selectedItemNames -> binding.subjectAcTv.setText(selectedItemNames));
                    subjectMultiChoiceDialog.setSelectedItemsList(data.getTutorProfile().getTeachesSubjects(), Subject::getId);
                    binding.subjectAcTv.setText(String.join(", ", Utils.toStringList(data.getTutorProfile().getTeachesSubjects(), Subject::getName)));
                    break;
            }
        });

        viewModel.getBoardsLiveData.observe(getViewLifecycleOwner(), getBoardsResponse -> {
            switch (getBoardsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getBoardsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Board> boardsList = getBoardsResponse.getData();
                    boardMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            boardsList,
                            Board::getName,
                            selectedItemNames -> binding.boardExamAcTv.setText(selectedItemNames));
                    boardMultiChoiceDialog.setSelectedItemsList(data.getTutorProfile().getTeachesBoardExams(), Board::getId);
                    binding.boardExamAcTv.setText(String.join(", ", Utils.toStringList(this.data.getTutorProfile().getTeachesBoardExams(), Board::getName)));
                    break;
            }
        });

        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    citiesList = getCitiesResponse.getData();
                    setCitiesDropDown();
                    break;
            }
        });

        viewModel.getGradesLiveData.observe(getViewLifecycleOwner(), getGradesResponse -> {
            switch (getGradesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getGradesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Grade> gradesList = getGradesResponse.getData();
                    gradeMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            gradesList,
                            Grade::getName,
                            selectedItemNames -> binding.classesAcTv.setText(selectedItemNames));
                    gradeMultiChoiceDialog.setSelectedItemsList(data.getTutorProfile().getTeachesClasses(), Grade::getId);
                    binding.classesAcTv.setText(String.join(", ", Utils.toStringList(data.getTutorProfile().getTeachesClasses(), Grade::getName)));
                    break;
            }
        });

        viewModel.updateTutorProfileLiveData
                .observe(getViewLifecycleOwner(), updateTutorProfileResource -> {
                    waitingDialog.dismiss();
                    switch (updateTutorProfileResource.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), updateTutorProfileResource.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(updateTutorProfileResource.getMessage());
                            break;
                        case SUCCESS:
                            Utils.showToast(requireContext(), updateTutorProfileResource.getMessage());
                            data = updateTutorProfileResource.getData();
                            setEditMode(false);
                            setData();
                            waitingDialog.dismiss();
                            break;
                    }
                });
    }

    private void initProfile() {
        viewModel.getProfile();
    }

    private void fetchData() {
        viewModel.getSubjects();
        viewModel.getBoards();
        viewModel.getCities();
        viewModel.getGrades();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PROFILE_IMAGE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                profileImageUri = data.getData();
                binding.profileImg.setImageURI(profileImageUri);
            } else if (resultCode == ImagePicker.RESULT_ERROR) {
                Utils.showToast(requireContext(), ImagePicker.getError(data));
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        } else if (requestCode == REQUEST_CODE_SELECT_VIDEO) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                File file = Utils.createTempFileFromUri(requireContext(), data.getData());
                long videoFileSize = file.length();
                if (Utils.bytesToMB(videoFileSize) > 25.00) {
                    Utils.showToastLong(requireContext(), "Task Cancelled, video size cannot exceed 25mb!");
                    return;
                }
                profileVideoUri = Uri.fromFile(file);
                if (profileVideoUri != null) {
                    Glide.with(requireContext())
                            .load(profileVideoUri)
                            .placeholder(R.color.lotion)
                            .into(binding.uploadVideoFrameImg);
                    binding.profileBg.setOnClickListener(v -> {
                        videoDialog.show(profileVideoUri.toString());
                    });
            /*disposables.add(Utils.extractFrameFromVideo(videoUrl)
                    .subscribe(
                            bitmap -> {
                                binding.uploadVideoFrameImg.setImageBitmap(bitmap);
                                binding.profileBg.setImageBitmap(bitmap);
                                binding.profileBg.setOnClickListener(v -> {
                                    videoDialog.show(videoUrl);
                                });
                            }, throwable -> {
                                Utils.showToast(requireContext(), "Couldn't fetch video thumbnail due to " + throwable.getMessage());
                            }
                    ));*/
                }
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQ_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            } else {
                if (!isLocationPermissionGranted()) {
                    requestLocationPermissions();
                }
            }
        } else if (requestCode == STORAGE_REQ_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                launchVideoPicker();
                pickVideo();
            } else {
                if (!isStoragePermissionGranted()) {
                    requestStoragePermissions();
                }
            }
        }
    }

    private void setData() {
        if (Utils.isDataNull(requireContext(), data) || Utils.isDataNull(requireContext(), data.getTutorProfile())) {
            return;
        }

        Glide.with(requireContext())
                .load(data.getTutorProfile().getProfileImageUrl())
                .placeholder(R.drawable.profile_image_placeholder)
                .into(binding.profileImg);
        binding.seekoohIdTl.getEditText().setText(data.getSeekoohId().toUpperCase());
        binding.nameTl.getEditText().setText(data.getFullName());
        binding.emailTl.getEditText().setText(data.getEmail());
        binding.phoneTl.getEditText().setText(data.getPhoneNumber());
        selectedGender = data.getGender().getId();
        binding.genderRg.check(selectedGender == 2 ? binding.radioFemale.getId() : binding.radioMale.getId());
        selectedCity = data.getTutorProfile().getCity();
        binding.citiesAcTv.setText(data.getTutorProfile().getCity().getName(), false);
        binding.addressTl.getEditText().setText(data.getTutorProfile().getAddress().getAddress());
        binding.tagLineTl.getEditText().setText(data.getTutorProfile().getTagLine());
        binding.descriptionTl.getEditText().setText(data.getTutorProfile().getDescription());
        if (data.getTutorProfile().getProfileVideoUrl() != null) {
            String videoUrl = data.getTutorProfile().getProfileVideoUrl();
            Glide.with(requireContext())
                    .load(videoUrl)
                    .placeholder(R.color.lotion)
                    .into(binding.profileBg);
            Glide.with(requireContext())
                    .load(videoUrl)
                    .placeholder(R.color.lotion)
                    .into(binding.uploadVideoFrameImg);
            binding.profileBg.setOnClickListener(v -> {
                videoDialog.show(videoUrl);
            });
            /*disposables.add(Utils.extractFrameFromVideo(videoUrl)
                    .subscribe(
                            bitmap -> {
                                binding.uploadVideoFrameImg.setImageBitmap(bitmap);
                                binding.profileBg.setImageBitmap(bitmap);
                                binding.profileBg.setOnClickListener(v -> {
                                    videoDialog.show(videoUrl);
                                });
                            }, throwable -> {
                                Utils.showToast(requireContext(), "Couldn't fetch video thumbnail due to " + throwable.getMessage());
                            }
                    ));*/
        }
        Qualification qualification = data.getTutorProfile().getQualifications().get(0);
        if (qualification != null) {
            binding.qualificationEtLayout.degreeNameTl.getEditText().setText(qualification.getDegreeCertName());
            binding.qualificationEtLayout.marksTl.getEditText().setText("" + qualification.getMarks());
            binding.qualificationEtLayout.yearTl.getEditText().setText("" + qualification.getYear());
        }
        qualificationLayoutsList.forEach(view -> {
            view.degreeNameTl.getEditText().removeTextChangedListener(textWatcher);
            view.yearTl.getEditText().removeTextChangedListener(textWatcher);
            view.marksTl.getEditText().removeTextChangedListener(textWatcher);
            qualificationLayoutsList.remove(view);
            binding.qualificationDetailsLl.removeView(view.getRoot());
        });
        if (data.getTutorProfile().getQualifications().size() > 1) {
            List<Qualification> qualifications = data.getTutorProfile().getQualifications().subList(1, data.getTutorProfile().getQualifications().size());
            qualifications.forEach(qualificationItem -> {
                QualificationLgLayoutBinding view = QualificationLgLayoutBinding.inflate(getLayoutInflater());
                view.degreeNameTl.getEditText().setText(qualificationItem.getDegreeCertName());
                view.yearTl.getEditText().setText(String.valueOf(qualificationItem.getYear()));
                view.marksTl.getEditText().setText(String.valueOf(qualificationItem.getMarks()));
                view.degreeNameTl.getEditText().addTextChangedListener(textWatcher);
                view.yearTl.getEditText().addTextChangedListener(textWatcher);
                view.marksTl.getEditText().addTextChangedListener(textWatcher);
                qualificationLayoutsList.add(view);
                int lastEtIndex = binding.qualificationDetailsLl.indexOfChild(binding.addMoreQualificationBtn);

                view.removeBtn.setOnClickListener(v -> {
                    view.degreeNameTl.getEditText().removeTextChangedListener(textWatcher);
                    view.yearTl.getEditText().removeTextChangedListener(textWatcher);
                    view.marksTl.getEditText().removeTextChangedListener(textWatcher);
                    qualificationLayoutsList.remove(view);
                    binding.qualificationDetailsLl.removeView(view.getRoot());
                });
                view.removeBtn.setVisibility(View.VISIBLE);
                binding.qualificationDetailsLl.addView(view.getRoot(), lastEtIndex);
            });
        }
        Experience experience = data.getTutorProfile().getExperiences().get(0);
        if (experience != null) {
            binding.experienceEtLayout.experienceDetailsTl.getEditText().setText(experience.getExpDetails());
            binding.experienceEtLayout.experienceDurationTl.getEditText().setText(experience.getExpDuration());
        }
        experienceLayoutsList.forEach(view -> {
            view.experienceDurationTl.getEditText().removeTextChangedListener(textWatcher);
            view.experienceDetailsTl.getEditText().removeTextChangedListener(textWatcher);
            experienceLayoutsList.remove(view);
            binding.qualificationDetailsLl.removeView(view.getRoot());
        });
        if (data.getTutorProfile().getExperiences().size() > 1) {
            List<Experience> experiences = data.getTutorProfile().getExperiences().subList(1, data.getTutorProfile().getExperiences().size());
            experiences.forEach(experienceItem -> {
                ExperienceLgLayoutBinding view = ExperienceLgLayoutBinding.inflate(getLayoutInflater());
                view.experienceDurationTl.getEditText().setText(experienceItem.getExpDuration());
                view.experienceDetailsTl.getEditText().setText(experienceItem.getExpDetails());
                view.experienceDurationTl.getEditText().addTextChangedListener(textWatcher);
                view.experienceDetailsTl.getEditText().addTextChangedListener(textWatcher);
                experienceLayoutsList.add(view);
                int lastEtIndex = binding.qualificationDetailsLl.indexOfChild(binding.addMoreExperienceBtn);

                view.removeBtn.setOnClickListener(v -> {
                    view.experienceDurationTl.getEditText().removeTextChangedListener(textWatcher);
                    view.experienceDetailsTl.getEditText().removeTextChangedListener(textWatcher);
                    experienceLayoutsList.remove(view);
                    binding.qualificationDetailsLl.removeView(view.getRoot());
                });
                view.removeBtn.setVisibility(View.VISIBLE);
                binding.qualificationDetailsLl.addView(view.getRoot(), lastEtIndex);
            });
        }
        binding.teachOnlineSw.setChecked(data.getTutorProfile().getTeachOnline());
        binding.teachAtLocationSw.setChecked(data.getTutorProfile().getTeachAtLocation());
        if (data.getTutorProfile().getAddress() != null) {
            Address address = data.getTutorProfile().getAddress();
            binding.areaTl.getEditText().setText(address.getArea());
            if (address.getLatitude() != null
                    && address.getLatitude() != null) {
                binding.locationTl.getEditText().setText(Utils.getAddressFromLatLng(requireContext(), address.getLatitude(), address.getLongitude()));
            }
        }
        if (!CollectionUtils.isEmpty(data.getTutorProfile().getTimeSlots())) {
            TutorTimeSlot tutorTimeSlot = data.getTutorProfile().getTimeSlots().get(0);
            startTimeInMinutes = tutorTimeSlot.getFromTime();
            endTimeInMinutes = tutorTimeSlot.getToTime();
            binding.timingFromTl.getEditText().setText(Utils.getFormattedTime(tutorTimeSlot.getFromTime()));
            binding.timingToTl.getEditText().setText(Utils.getFormattedTime(tutorTimeSlot.getToTime()));
        }
        binding.daysAcTv.setText(String.join(", ", Utils.toStringList(data.getTutorProfile().getAvailableDays(), com.jeuxdevelopers.seekooh.models.DayOfWeek::getName)));
        daysMultiChoiceDialog.setSelectedItemsList(Utils.toDayOfWeekList(data.getTutorProfile().getAvailableDays()), DayOfWeek::getValue);
        setEditMode(false);
        binding.mainContainerLl.setVisibility(View.VISIBLE);
    }

    private void setEditMode(boolean enabled) {
        if (!enabled) {
            isEditModeEnabled = false;
            binding.nameTl.setEnabled(false);
            binding.phoneTl.setEnabled(false);
            binding.citiesTl.setEnabled(false);
            binding.addressTl.setEnabled(false);
            binding.radioMale.setEnabled(false);
            binding.radioFemale.setEnabled(false);
            binding.tagLineTl.setEnabled(false);
            binding.descriptionTl.setEnabled(false);
            binding.addVideoBtn.setEnabled(false);
            binding.qualificationEtLayout.degreeNameTl.setEnabled(false);
            binding.qualificationEtLayout.marksTl.setEnabled(false);
            binding.qualificationEtLayout.yearTl.setEnabled(false);
            binding.addMoreQualificationBtn.setEnabled(false);
            binding.experienceEtLayout.experienceDetailsTl.setEnabled(false);
            binding.experienceEtLayout.experienceDurationTl.setEnabled(false);
            binding.addMoreExperienceBtn.setEnabled(false);
            binding.subjectTl.setEnabled(false);
            binding.classesTl.setEnabled(false);
            binding.boardTl.setEnabled(false);
            binding.teachOnlineSw.setEnabled(false);
            binding.teachAtLocationSw.setEnabled(false);
            binding.locationTl.setEnabled(false);
            binding.timingFromTl.setEnabled(false);
            binding.timingToTl.setEnabled(false);
            binding.areaTl.setEnabled(false);
            binding.daysTl.setEnabled(false);
            qualificationLayoutsList.forEach(view -> {
                view.degreeNameTl.setEnabled(false);
                view.marksTl.setEnabled(false);
                view.yearTl.setEnabled(false);
                view.removeBtn.setEnabled(false);
            });
            experienceLayoutsList.forEach(view -> {
                view.experienceDetailsTl.setEnabled(false);
                view.experienceDurationTl.setEnabled(false);
                view.removeBtn.setEnabled(false);
            });
            binding.editBtn.setText("Edit");
            return;
        }
        isEditModeEnabled = true;
        binding.nameTl.setEnabled(true);
        binding.phoneTl.setEnabled(true);
        binding.citiesTl.setEnabled(true);
        binding.addressTl.setEnabled(true);
        binding.radioMale.setEnabled(true);
        binding.radioFemale.setEnabled(true);
        binding.tagLineTl.setEnabled(true);
        binding.descriptionTl.setEnabled(true);
        binding.addVideoBtn.setEnabled(true);
        binding.qualificationEtLayout.degreeNameTl.setEnabled(true);
        binding.qualificationEtLayout.marksTl.setEnabled(true);
        binding.qualificationEtLayout.yearTl.setEnabled(true);
        binding.addMoreQualificationBtn.setEnabled(true);
        binding.experienceEtLayout.experienceDetailsTl.setEnabled(true);
        binding.experienceEtLayout.experienceDurationTl.setEnabled(true);
        binding.addMoreExperienceBtn.setEnabled(true);
        binding.subjectTl.setEnabled(true);
        binding.classesTl.setEnabled(true);
        binding.boardTl.setEnabled(true);
        binding.teachOnlineSw.setEnabled(true);
        binding.teachAtLocationSw.setEnabled(true);
        binding.locationTl.setEnabled(true);
        binding.timingFromTl.setEnabled(true);
        binding.timingToTl.setEnabled(true);
        binding.areaTl.setEnabled(true);
        binding.daysTl.setEnabled(true);
        qualificationLayoutsList.forEach(view -> {
            view.degreeNameTl.setEnabled(true);
            view.marksTl.setEnabled(true);
            view.yearTl.setEnabled(true);
            view.removeBtn.setEnabled(true);
        });
        experienceLayoutsList.forEach(view -> {
            view.experienceDetailsTl.setEnabled(true);
            view.experienceDurationTl.setEnabled(true);
            view.removeBtn.setEnabled(true);
        });
        binding.editBtn.setText("Update");
    }

    private boolean validateUserInput() {
        isTextWatcherEnabled = true;
        boolean isValid = true;
        String name = binding.nameTl.getEditText().getText().toString().trim();
        String phone = binding.phoneTl.getEditText().getText().toString().trim();
        String address = binding.addressTl.getEditText().getText().toString().trim();
        String tagLine = binding.tagLineTl.getEditText().getText().toString().trim();
        String degreeNameField = binding.qualificationEtLayout.degreeNameTl.getEditText().getText().toString().trim();
        String yearField = binding.qualificationEtLayout.yearTl.getEditText().getText().toString().trim();
        String marksField = binding.qualificationEtLayout.marksTl.getEditText().getText().toString().trim();
        String experienceDuration = binding.experienceEtLayout.experienceDurationTl.getEditText().getText().toString().trim();
        String experienceDetails = binding.experienceEtLayout.experienceDetailsTl.getEditText().getText().toString().trim();
        String timingFrom = binding.timingFromTl.getEditText().getText().toString().trim();
        String timingTo = binding.timingToTl.getEditText().getText().toString().trim();
        String area = binding.areaTl.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            binding.nameTl.setError("Please enter your name?");
            isValid = false;
        } else {
            binding.nameTl.setError(null);
        }

        if (TextUtils.isEmpty(phone)) {
            binding.phoneTl.setError("Please enter your phone number?");
            isValid = false;
        } else if (!Utils.validatePhoneNumber(phone)) {
            binding.phoneTl.setError("Please enter a valid phone number?");
            isValid = false;
        } else {
            binding.phoneTl.setError(null);
        }

        if (TextUtils.isEmpty(address)) {
            binding.addressTl.setError("Please enter your address?");
            isValid = false;
        } else {
            binding.addressTl.setError(null);
        }

        if (TextUtils.isEmpty(tagLine)) {
            binding.tagLineTl.setError("Please enter a tag line?");
            isValid = false;
        } else {
            binding.tagLineTl.setError(null);
        }

        if (selectedCity == null) {
            binding.citiesTl.setError("Please select your city?");
            isValid = false;
        } else {
            binding.citiesTl.setError(null);
        }

        if (TextUtils.isEmpty(degreeNameField)) {
            binding.qualificationEtLayout.degreeNameTl.setError("Required field");
            isValid = false;
        } else {
            binding.qualificationEtLayout.degreeNameTl.setError(null);
        }

        if (TextUtils.isEmpty(yearField)) {
            binding.qualificationEtLayout.yearTl.setError("Required field");
            isValid = false;
        } else {
            binding.qualificationEtLayout.yearTl.setError(null);
        }

        if (TextUtils.isEmpty(marksField)) {
            binding.qualificationEtLayout.marksTl.setError("Required field");
            isValid = false;
        } else {
            binding.qualificationEtLayout.marksTl.setError(null);
        }

        if (TextUtils.isEmpty(experienceDuration)) {
            binding.experienceEtLayout.experienceDurationTl.setError("Required field");
            isValid = false;
        } else {
            binding.experienceEtLayout.experienceDurationTl.setError(null);
        }

        if (TextUtils.isEmpty(experienceDetails)) {
            binding.experienceEtLayout.experienceDetailsTl.setError("Required field");
            isValid = false;
        } else {
            binding.experienceEtLayout.experienceDetailsTl.setError(null);
        }

        for (QualificationLgLayoutBinding qualificationLayoutBinding : qualificationLayoutsList) {
            String degreeName = qualificationLayoutBinding.degreeNameTl.getEditText().getText().toString().trim();
            String year = qualificationLayoutBinding.yearTl.getEditText().getText().toString().trim();
            String marks = qualificationLayoutBinding.marksTl.getEditText().getText().toString().trim();
            if (degreeName.isEmpty()) {
                qualificationLayoutBinding.degreeNameTl.setError("Required field!");
                isValid = false;
            } else {
                qualificationLayoutBinding.degreeNameTl.setError(null);
            }

            if (year.isEmpty()) {
                qualificationLayoutBinding.yearTl.setError("Required field!");
                isValid = false;
            } else {
                qualificationLayoutBinding.yearTl.setError(null);
            }

            if (marks.isEmpty()) {
                qualificationLayoutBinding.marksTl.setError("Required field!");
                isValid = false;
            } else {
                qualificationLayoutBinding.marksTl.setError(null);
            }
        }
        for (ExperienceLgLayoutBinding experienceLayoutBinding : experienceLayoutsList) {
            String duration = experienceLayoutBinding.experienceDurationTl.getEditText().getText().toString().trim();
            String details = experienceLayoutBinding.experienceDetailsTl.getEditText().getText().toString().trim();
            if (duration.isEmpty()) {
                experienceLayoutBinding.experienceDurationTl.setError("Required field!");
                isValid = false;
            } else {
                experienceLayoutBinding.experienceDurationTl.setError(null);
            }

            if (details.isEmpty()) {
                experienceLayoutBinding.experienceDetailsTl.setError("Required field!");
                isValid = false;
            } else {
                experienceLayoutBinding.experienceDetailsTl.setError(null);
            }
        }

        if (subjectMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.subjectTl.setError("Please select subjects you teach");
            isValid = false;
        } else {
            binding.subjectTl.setError(null);
        }

        if (gradeMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.classesTl.setError("Please select classes you teach");
            isValid = false;
        } else {
            binding.classesTl.setError(null);
        }

        if (boardMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.boardTl.setError("Please select board/exam you teach");
            isValid = false;
        } else {
            binding.boardTl.setError(null);
        }

        if (TextUtils.isEmpty(timingFrom)) {
            binding.timingFromTl.setError("Please select starting time.");
            isValid = false;
        } else {
            binding.timingFromTl.setError(null);
        }

        if (TextUtils.isEmpty(timingTo)) {
            binding.timingToTl.setError("Please select ending time.");
            isValid = false;
        } else {
            binding.timingToTl.setError(null);
        }

        if (TextUtils.isEmpty(area)) {
            binding.areaTl.setError("Please enter your area.");
            isValid = false;
        } else {
            binding.areaTl.setError(null);
        }

        if (CollectionUtils.isEmpty(daysMultiChoiceDialog.getSelectedItemsList())) {
            binding.daysTl.setError("Please select your preferred days.");
            isValid = false;
        } else {
            binding.daysTl.setError(null);
        }

        return isValid;
    }
}