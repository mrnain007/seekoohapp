package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class StudentRegistrationRequest {
    @SerializedName("fullName")
    @Expose
    private String fullName;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("facebookId")
    @Expose
    private String facebookId;
    @SerializedName("genderId")
    @Expose
    private Integer genderId;
    @SerializedName("studentProfile")
    @Expose
    private StudentProfile studentProfile;

    public StudentRegistrationRequest() {
    }

    private StudentRegistrationRequest(Builder builder) {
        setFullName(builder.fullName);
        setEmail(builder.email);
        setPassword(builder.password);
        setPhoneNumber(builder.phoneNumber);
        setFacebookId(builder.facebookId);
        setGenderId(builder.genderId);
        setStudentProfile(builder.studentProfile);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getFacebookId() {
        return facebookId;
    }

    public void setFacebookId(String facebookId) {
        this.facebookId = facebookId;
    }

    public Integer getGenderId() {
        return genderId;
    }

    public void setGenderId(Integer genderId) {
        this.genderId = genderId;
    }

    public StudentProfile getStudentProfile() {
        return studentProfile;
    }

    public void setStudentProfile(StudentProfile studentProfile) {
        this.studentProfile = studentProfile;
    }

    public static class StudentProfile {
        @SerializedName("boardExamId")
        @Expose
        private Integer boardExamId;
        @SerializedName("cityId")
        @Expose
        private Integer cityId;
        @SerializedName("gradeId")
        @Expose
        private Integer gradeId;

        public StudentProfile() {
        }

        public StudentProfile(Integer boardExamId, Integer cityId, Integer gradeId) {
            this.boardExamId = boardExamId;
            this.cityId = cityId;
            this.gradeId = gradeId;
        }

        private StudentProfile(Builder builder) {
            setBoardExamId(builder.boardExamId);
            setCityId(builder.cityId);
            setGradeId(builder.gradeId);
        }

        public static Builder builder() {
            return new Builder();
        }

        public Integer getBoardExamId() {
            return boardExamId;
        }

        public void setBoardExamId(Integer boardExamId) {
            this.boardExamId = boardExamId;
        }

        public Integer getCityId() {
            return cityId;
        }

        public void setCityId(Integer cityId) {
            this.cityId = cityId;
        }

        public Integer getGradeId() {
            return gradeId;
        }

        public void setGradeId(Integer gradeId) {
            this.gradeId = gradeId;
        }


        public static final class Builder {
            private Integer boardExamId;
            private Integer cityId;
            private Integer gradeId;

            private Builder() {
            }

            public Builder boardExamId(Integer boardExamId) {
                this.boardExamId = boardExamId;
                return this;
            }

            public Builder cityId(Integer cityId) {
                this.cityId = cityId;
                return this;
            }

            public Builder gradeId(Integer gradeId) {
                this.gradeId = gradeId;
                return this;
            }

            public StudentProfile build() {
                return new StudentProfile(this);
            }
        }
    }

    public static final class Builder {
        private String fullName;
        private String email;
        private String password;
        private String phoneNumber;
        private String facebookId;
        private Integer genderId;
        private StudentProfile studentProfile;

        private Builder() {
        }

        public Builder fullName(String fullName) {
            this.fullName = fullName;
            return this;
        }

        public Builder email(String email) {
            this.email = email;
            return this;
        }

        public Builder password(String password) {
            this.password = password;
            return this;
        }

        public Builder phoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }

        public Builder facebookId(String facebookId) {
            this.facebookId = facebookId;
            return this;
        }

        public Builder genderId(Integer genderId) {
            this.genderId = genderId;
            return this;
        }

        public Builder studentProfile(StudentProfile studentProfile) {
            this.studentProfile = studentProfile;
            return this;
        }

        public StudentRegistrationRequest build() {
            return new StudentRegistrationRequest(this);
        }
    }
}