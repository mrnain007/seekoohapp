package com.jeuxdevelopers.seekooh.repos.auth;

import android.net.Uri;

import androidx.annotation.NonNull;

import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.InstituteType;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationRequest;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationResponse;
import com.jeuxdevelopers.seekooh.models.dto.InstituteRegistrationRequest;
import com.jeuxdevelopers.seekooh.models.dto.InstituteRegistrationResponse;
import com.jeuxdevelopers.seekooh.models.dto.SendPasswordResetRequest;
import com.jeuxdevelopers.seekooh.models.dto.SendPasswordResetResponse;
import com.jeuxdevelopers.seekooh.models.dto.SocialLoginRequest;
import com.jeuxdevelopers.seekooh.models.dto.StudentRegistrationRequest;
import com.jeuxdevelopers.seekooh.models.dto.StudentRegistrationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TokenRefreshRequest;
import com.jeuxdevelopers.seekooh.models.dto.TokenRefreshResponse;
import com.jeuxdevelopers.seekooh.models.dto.TutorRegistrationRequest;
import com.jeuxdevelopers.seekooh.models.dto.TutorRegistrationResponse;
import com.jeuxdevelopers.seekooh.network.SeekoohService;
import com.jeuxdevelopers.seekooh.utils.NetworkUtils;

import java.net.URI;
import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;
import retrofit2.http.Body;

public interface AuthRepo {
    Observable<Resource<AuthenticationResponse>> authenticate(@NonNull AuthenticationRequest authenticationRequest);

    Observable<Resource<TokenRefreshResponse>> tokenRefresh(@NonNull TokenRefreshRequest tokenRefreshRequest);

    Observable<Resource<AuthenticationResponse>> socialLogin(@NonNull SocialLoginRequest socialLoginRequest);

    Observable<Resource<SendPasswordResetResponse>> requestPasswordReset(@NonNull SendPasswordResetRequest sendPasswordResetRequest);

    Observable<Resource<StudentRegistrationResponse>> registerStudent(@NonNull URI profileImageUri, @NonNull StudentRegistrationRequest studentRegistrationRequest);

    Observable<Resource<TutorRegistrationResponse>> registerTutor(@NonNull Uri profileImageUri, @NonNull TutorRegistrationRequest tutorRegistrationRequest);

    Observable<Resource<InstituteRegistrationResponse>> registerInstitute(@NonNull URI profileImageUri, @NonNull InstituteRegistrationRequest instituteRegistrationRequest);
}
