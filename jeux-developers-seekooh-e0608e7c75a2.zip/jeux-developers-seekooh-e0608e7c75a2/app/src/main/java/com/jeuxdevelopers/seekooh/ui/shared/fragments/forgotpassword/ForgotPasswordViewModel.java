package com.jeuxdevelopers.seekooh.ui.shared.fragments.forgotpassword;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.dto.SendPasswordResetRequest;
import com.jeuxdevelopers.seekooh.models.dto.SendPasswordResetResponse;
import com.jeuxdevelopers.seekooh.repos.auth.AuthRepo;
import com.jeuxdevelopers.seekooh.repos.auth.AuthRepoImpl;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class ForgotPasswordViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AuthRepo authRepo;

    public MutableLiveData<Resource<SendPasswordResetResponse>> requestPasswordResetLiveData = new MutableLiveData<>();

    public ForgotPasswordViewModel() {
        this.authRepo = new AuthRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void requestPasswordReset(@NonNull SendPasswordResetRequest sendPasswordResetRequest) {
        disposables.add(authRepo.requestPasswordReset(sendPasswordResetRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(requestPasswordResetResource -> {
                    requestPasswordResetLiveData.setValue(requestPasswordResetResource);
                }, throwable -> {
                    requestPasswordResetLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
