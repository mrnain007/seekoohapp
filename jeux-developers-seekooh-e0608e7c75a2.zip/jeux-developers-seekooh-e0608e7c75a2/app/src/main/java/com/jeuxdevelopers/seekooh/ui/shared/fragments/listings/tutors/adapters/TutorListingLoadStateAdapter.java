package com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tutors.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.paging.LoadState;
import androidx.paging.LoadStateAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.jeuxdevelopers.seekooh.databinding.ItemRcvLoadingBinding;
import com.jeuxdevelopers.seekooh.utils.Utils;

import org.jetbrains.annotations.NotNull;

public class TutorListingLoadStateAdapter extends LoadStateAdapter<TutorListingLoadStateAdapter.LoadStateViewHolder> {
    // Define Retry Callback
    private View.OnClickListener mRetryCallback;

    public TutorListingLoadStateAdapter(View.OnClickListener retryCallback) {
        // Init Retry Callback
        mRetryCallback = retryCallback;
    }

    @NotNull
    @Override
    public LoadStateViewHolder onCreateViewHolder(@NotNull ViewGroup parent, @NotNull LoadState loadState) {
        // Return new LoadStateViewHolder object
        return new LoadStateViewHolder(ItemRcvLoadingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false), mRetryCallback);
    }

    @Override
    public void onBindViewHolder(@NotNull LoadStateViewHolder holder, @NotNull LoadState loadState) {
        // Call Bind Method to bind visibility  of views
        holder.bind(loadState);
    }

    public static class LoadStateViewHolder extends RecyclerView.ViewHolder {
        ItemRcvLoadingBinding binding;

        LoadStateViewHolder(@NonNull ItemRcvLoadingBinding binding, @NonNull View.OnClickListener retryCallback) {
            super(binding.getRoot());
            this.binding = binding;

//            mRetry.setOnClickListener(retryCallback);
        }

        public void bind(LoadState loadState) {
            // Check load state
            /*if (loadState instanceof LoadState.Error) {
                // Get the error
                LoadState.Error loadStateError = (LoadState.Error) loadState;
                // Set text of Error message
//                mErrorMsg.setText(loadStateError.getError().getLocalizedMessage());
                Utils.showToast(binding.getRoot().getContext(), loadStateError.getError().getMessage());
                Utils.showToast(binding.getRoot().getContext(), "loadState Error");
            } else if (loadState instanceof LoadState.Loading) {
                LoadState.Loading loadStateLoading = (LoadState.Loading) loadState;
                Utils.showToast(binding.getRoot().getContext(), "loadState Loading");
            } else if (loadState instanceof LoadState.NotLoading) {
                LoadState.NotLoading loadStateNotLoading = (LoadState.NotLoading) loadState;
                Utils.showToast(binding.getRoot().getContext(), "loadState NotLoading");
            }*/
            // set visibility of widgets based on LoadState
//            binding.progressBar.setVisibility(loadState instanceof LoadState.Loading ? View.VISIBLE : View.GONE);
            binding.shimmerLl.setVisibility(loadState instanceof LoadState.Loading ? View.VISIBLE : View.GONE);
            /*mRetry.setVisibility(loadState instanceof LoadState.Error ? View.VISIBLE : View.GONE);
            mErrorMsg.setVisibility(loadState instanceof LoadState.Error ? View.VISIBLE : View.GONE);*/
        }
    }
}