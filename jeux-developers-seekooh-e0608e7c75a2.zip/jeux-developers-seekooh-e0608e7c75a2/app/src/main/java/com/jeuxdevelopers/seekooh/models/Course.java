package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Course {
    @Expose
    @SerializedName("id")
    private Integer id;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("reviewCount")
    @Expose
    private Integer reviewCount;
    @SerializedName("enrolmentCount")
    @Expose
    private Integer enrolmentCount;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("learningGoals")
    @Expose
    private String learningGoals;
    @SerializedName("minRequirements")
    @Expose
    private List<String> minRequirements;
    @SerializedName("targetAudience")
    @Expose
    private String targetAudience;
    @SerializedName("startMinutes")
    @Expose
    private Integer startMinutes;
    @SerializedName("endMinutes")
    @Expose
    private Integer endMinutes;
    @SerializedName("startDate")
    @Expose
    private Long startDate;
    @SerializedName("endDate")
    @Expose
    private Long endDate;
    @SerializedName("isOnline")
    @Expose
    private Boolean isOnline;
    @SerializedName("isInPerson")
    @Expose
    private Boolean isInPerson;
    @SerializedName("status")
    @Expose
    private Status status;
    @SerializedName("days")
    @Expose
    private List<DayOfWeek> days;
    @SerializedName("subjects")
    @Expose
    private List<Subject> subjects;
    @SerializedName("createdAt")
    @Expose
    private Long createdAt;
    @SerializedName("updatedAt")
    @Expose
    private Long updatedAt;

    public Course() {
    }

    public Course(Integer id, String title, Double rating, Integer reviewCount, Integer enrolmentCount, String description, String learningGoals, List<String> minRequirements, String targetAudience, Integer startMinutes, Integer endMinutes, Long startDate, Long endDate, Boolean isOnline, Boolean isInPerson, Status status, List<DayOfWeek> days, List<Subject> subjects, Long createdAt, Long updatedAt) {
        this.id = id;
        this.title = title;
        this.rating = rating;
        this.reviewCount = reviewCount;
        this.enrolmentCount = enrolmentCount;
        this.description = description;
        this.learningGoals = learningGoals;
        this.minRequirements = minRequirements;
        this.targetAudience = targetAudience;
        this.startMinutes = startMinutes;
        this.endMinutes = endMinutes;
        this.startDate = startDate;
        this.endDate = endDate;
        this.isOnline = isOnline;
        this.isInPerson = isInPerson;
        this.status = status;
        this.days = days;
        this.subjects = subjects;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    private Course(Builder builder) {
        setId(builder.id);
        setTitle(builder.title);
        setRating(builder.rating);
        setReviewCount(builder.reviewCount);
        setEnrolmentCount(builder.enrolmentCount);
        setDescription(builder.description);
        setLearningGoals(builder.learningGoals);
        setMinRequirements(builder.minRequirements);
        setTargetAudience(builder.targetAudience);
        setStartMinutes(builder.startMinutes);
        setEndMinutes(builder.endMinutes);
        setStartDate(builder.startDate);
        setEndDate(builder.endDate);
        isOnline = builder.isOnline;
        isInPerson = builder.isInPerson;
        setStatus(builder.status);
        setDays(builder.days);
        setSubjects(builder.subjects);
        setCreatedAt(builder.createdAt);
        setUpdatedAt(builder.updatedAt);
    }

    public static Builder builder() {
        return new Builder();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Integer getReviewCount() {
        return reviewCount;
    }

    public void setReviewCount(Integer reviewCount) {
        this.reviewCount = reviewCount;
    }

    public Integer getEnrolmentCount() {
        return enrolmentCount;
    }

    public void setEnrolmentCount(Integer enrolmentCount) {
        this.enrolmentCount = enrolmentCount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLearningGoals() {
        return learningGoals;
    }

    public void setLearningGoals(String learningGoals) {
        this.learningGoals = learningGoals;
    }

    public List<String> getMinRequirements() {
        return minRequirements;
    }

    public void setMinRequirements(List<String> minRequirements) {
        this.minRequirements = minRequirements;
    }

    public String getTargetAudience() {
        return targetAudience;
    }

    public void setTargetAudience(String targetAudience) {
        this.targetAudience = targetAudience;
    }

    public Integer getStartMinutes() {
        return startMinutes;
    }

    public void setStartMinutes(Integer startMinutes) {
        this.startMinutes = startMinutes;
    }

    public Integer getEndMinutes() {
        return endMinutes;
    }

    public void setEndMinutes(Integer endMinutes) {
        this.endMinutes = endMinutes;
    }

    public Long getStartDate() {
        return startDate;
    }

    public void setStartDate(Long startDate) {
        this.startDate = startDate;
    }

    public Long getEndDate() {
        return endDate;
    }

    public void setEndDate(Long endDate) {
        this.endDate = endDate;
    }

    public Boolean getOnline() {
        return isOnline;
    }

    public void setOnline(Boolean online) {
        isOnline = online;
    }

    public Boolean getInPerson() {
        return isInPerson;
    }

    public void setInPerson(Boolean inPerson) {
        isInPerson = inPerson;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public List<DayOfWeek> getDays() {
        return days;
    }

    public void setDays(List<DayOfWeek> days) {
        this.days = days;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Long updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Course course = (Course) o;

        if (id != null ? !id.equals(course.id) : course.id != null) return false;
        if (title != null ? !title.equals(course.title) : course.title != null) return false;
        if (rating != null ? !rating.equals(course.rating) : course.rating != null) return false;
        if (reviewCount != null ? !reviewCount.equals(course.reviewCount) : course.reviewCount != null)
            return false;
        if (enrolmentCount != null ? !enrolmentCount.equals(course.enrolmentCount) : course.enrolmentCount != null)
            return false;
        if (description != null ? !description.equals(course.description) : course.description != null)
            return false;
        if (learningGoals != null ? !learningGoals.equals(course.learningGoals) : course.learningGoals != null)
            return false;
        if (minRequirements != null ? !minRequirements.equals(course.minRequirements) : course.minRequirements != null)
            return false;
        if (targetAudience != null ? !targetAudience.equals(course.targetAudience) : course.targetAudience != null)
            return false;
        if (startMinutes != null ? !startMinutes.equals(course.startMinutes) : course.startMinutes != null)
            return false;
        if (endMinutes != null ? !endMinutes.equals(course.endMinutes) : course.endMinutes != null)
            return false;
        if (startDate != null ? !startDate.equals(course.startDate) : course.startDate != null)
            return false;
        if (endDate != null ? !endDate.equals(course.endDate) : course.endDate != null)
            return false;
        if (isOnline != null ? !isOnline.equals(course.isOnline) : course.isOnline != null)
            return false;
        if (isInPerson != null ? !isInPerson.equals(course.isInPerson) : course.isInPerson != null)
            return false;
        if (status != null ? !status.equals(course.status) : course.status != null) return false;
        if (days != null ? !days.equals(course.days) : course.days != null) return false;
        if (subjects != null ? !subjects.equals(course.subjects) : course.subjects != null)
            return false;
        if (createdAt != null ? !createdAt.equals(course.createdAt) : course.createdAt != null)
            return false;
        return updatedAt != null ? updatedAt.equals(course.updatedAt) : course.updatedAt == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (title != null ? title.hashCode() : 0);
        result = 31 * result + (rating != null ? rating.hashCode() : 0);
        result = 31 * result + (reviewCount != null ? reviewCount.hashCode() : 0);
        result = 31 * result + (enrolmentCount != null ? enrolmentCount.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (learningGoals != null ? learningGoals.hashCode() : 0);
        result = 31 * result + (minRequirements != null ? minRequirements.hashCode() : 0);
        result = 31 * result + (targetAudience != null ? targetAudience.hashCode() : 0);
        result = 31 * result + (startMinutes != null ? startMinutes.hashCode() : 0);
        result = 31 * result + (endMinutes != null ? endMinutes.hashCode() : 0);
        result = 31 * result + (startDate != null ? startDate.hashCode() : 0);
        result = 31 * result + (endDate != null ? endDate.hashCode() : 0);
        result = 31 * result + (isOnline != null ? isOnline.hashCode() : 0);
        result = 31 * result + (isInPerson != null ? isInPerson.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (days != null ? days.hashCode() : 0);
        result = 31 * result + (subjects != null ? subjects.hashCode() : 0);
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        return result;
    }

    public enum Status {
        PENDING,
        APPROVED,
        REJECTED
    }

    public static final class Builder {
        private Integer id;
        private String title;
        private Double rating;
        private Integer reviewCount;
        private Integer enrolmentCount;
        private String description;
        private String learningGoals;
        private List<String> minRequirements;
        private String targetAudience;
        private Integer startMinutes;
        private Integer endMinutes;
        private Long startDate;
        private Long endDate;
        private Boolean isOnline;
        private Boolean isInPerson;
        private Status status;
        private List<DayOfWeek> days;
        private List<Subject> subjects;
        private Long createdAt;
        private Long updatedAt;

        private Builder() {
        }

        public Builder id(Integer id) {
            this.id = id;
            return this;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder rating(Double rating) {
            this.rating = rating;
            return this;
        }

        public Builder reviewCount(Integer reviewCount) {
            this.reviewCount = reviewCount;
            return this;
        }

        public Builder enrolmentCount(Integer enrolmentCount) {
            this.enrolmentCount = enrolmentCount;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder learningGoals(String learningGoals) {
            this.learningGoals = learningGoals;
            return this;
        }

        public Builder minRequirements(List<String> minRequirements) {
            this.minRequirements = minRequirements;
            return this;
        }

        public Builder targetAudience(String targetAudience) {
            this.targetAudience = targetAudience;
            return this;
        }

        public Builder startMinutes(Integer startMinutes) {
            this.startMinutes = startMinutes;
            return this;
        }

        public Builder endMinutes(Integer endMinutes) {
            this.endMinutes = endMinutes;
            return this;
        }

        public Builder startDate(Long startDate) {
            this.startDate = startDate;
            return this;
        }

        public Builder endDate(Long endDate) {
            this.endDate = endDate;
            return this;
        }

        public Builder isOnline(Boolean isOnline) {
            this.isOnline = isOnline;
            return this;
        }

        public Builder isInPerson(Boolean isInPerson) {
            this.isInPerson = isInPerson;
            return this;
        }

        public Builder status(Status status) {
            this.status = status;
            return this;
        }

        public Builder days(List<DayOfWeek> days) {
            this.days = days;
            return this;
        }

        public Builder subjects(List<Subject> subjects) {
            this.subjects = subjects;
            return this;
        }

        public Builder createdAt(Long createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public Builder updatedAt(Long updatedAt) {
            this.updatedAt = updatedAt;
            return this;
        }

        public Course build() {
            return new Course(this);
        }
    }
}
