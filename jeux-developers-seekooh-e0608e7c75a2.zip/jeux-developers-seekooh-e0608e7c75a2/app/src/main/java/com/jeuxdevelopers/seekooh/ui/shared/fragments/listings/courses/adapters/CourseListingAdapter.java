package com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.courses.adapters;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.paging.PagingDataAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.ItemCourseListingBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemListingAdBinding;
import com.jeuxdevelopers.seekooh.models.AdModel;
import com.jeuxdevelopers.seekooh.models.CourseListing;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.updates.UpdatedAdModel;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.List;

public class CourseListingAdapter extends PagingDataAdapter<Object, RecyclerView.ViewHolder> {

    private final Listener listener;
    private User user;
    private static int adPosition = 0;
    private static final DiffUtil.ItemCallback<Object> DIFF_CALLBACK = new DiffUtil.ItemCallback<Object>() {
        @Override
        public boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof CourseListing && newItem instanceof CourseListing) {
                return ((CourseListing) oldItem).getId().equals(((CourseListing) newItem).getId());
            }
            return false;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof CourseListing && newItem instanceof CourseListing) {
                return ((CourseListing) oldItem).equals(((CourseListing) newItem));
            }
            return false;
        }
    };

    public CourseListingAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        int itemCount = getItemCount();

        if (position < getItemCount()) {
            Object object = getItem(position);
            if (object instanceof AdModel) {
                return ViewType.AD_VIEW.ordinal();
            }
            return ViewType.NORMAL_VIEW.ordinal();
        }
        return ViewType.LOADING_VIEW.ordinal();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == ViewType.AD_VIEW.ordinal()) {
            ItemListingAdBinding itemListingAdBinding = ItemListingAdBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new AdViewHolder(itemListingAdBinding);
        }
        ItemCourseListingBinding binding = ItemCourseListingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new CourseListingViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof CourseListingViewHolder) {
            CourseListingViewHolder courseListingViewHolder = ((CourseListingViewHolder) holder);

            courseListingViewHolder.bind(getItem(position));
            if (getItem(position) instanceof CourseListing) {
                courseListingViewHolder.binding.viewCourseBtn.setOnClickListener(v -> {
                    listener.onViewDetailsClicked(position, (CourseListing) getItem(position));
                });
                courseListingViewHolder.binding.enrollBtn.setOnClickListener(v -> {
                    listener.onEnrolClicked(position, (CourseListing) getItem(position));
                });
            }
        } else if (holder instanceof AdViewHolder) {
            AdViewHolder adViewHolder = ((AdViewHolder) holder);
            adViewHolder.bind(getItem(position));
        }
    }

    public static class CourseListingViewHolder extends RecyclerView.ViewHolder {
        private final ItemCourseListingBinding binding;

        public CourseListingViewHolder(ItemCourseListingBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(Object model) {
            if (!(model instanceof CourseListing)) {
                return;
            }

            String role = UserPrefs.getSelectedRole(itemView.getContext()).getName();
            CourseListing data = (CourseListing) model;
            if (!role.contains("ROLE_STUDENT")) {
                binding.enrollBtn.setVisibility(View.GONE);
            }


            Glide.with(binding.getRoot()
                            .getContext())
                    .load(data.getTutorDetails().getProfileImageUrl())
                    .placeholder(R.drawable.profile_image_placeholder)
                    .into(binding.profileImg);
            binding.courseTitleTv.setText(data.getTitle());
            binding.tutorNameTv.setText(data.getTutorDetails().getFullName());
            binding.ratingBar.setRating(data.getTutorDetails().getRating().floatValue());
            binding.reviewCountTv.setText(data.getTutorDetails().getReviewCount() == 0 ? "" : "" + data.getRating() + "  /  " + data.getReviewCount() + " students");
            binding.startingDateTv.setText("Starts: " + Utils.getFormattedDate(data.getStartDate()));
            binding.classTypeTv.setText(data.getOnline() ? "Online Lectures" : "" + (data.getInPerson() ? ", In Person" : ""));
            binding.timingsTv.setText("Timings: " + Utils.getFormattedTime(data.getStartMinutes()) + " to " + Utils.getFormattedTime(data.getEndMinutes()));
            binding.enrolmentCountTv.setText("" + data.getEnrolmentCount() + " Enrolled Students");
            binding.descriptionTv.setText(data.getDescription());
        }
    }

    public static class AdViewHolder extends RecyclerView.ViewHolder {
        private final ItemListingAdBinding binding;

        public AdViewHolder(ItemListingAdBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Object model) {
            if (model instanceof AdModel) {
                AdModel adModel = (AdModel) model;
                if (adPosition >= App.updatedAdModelList.size()) {
                    adPosition = 0;
                }
                try {
                    UpdatedAdModel updatedAdModel = App.updatedAdModelList.get(adPosition++);
                    if (updatedAdModel.getBannerImage() != null) {
                        Glide.with(binding.getRoot().getContext()).load(updatedAdModel.getBannerImage()).into(binding.getRoot());
                    }
                    if (updatedAdModel.getUrl() != null) {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = updatedAdModel.getUrl();
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    } else {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = "https://www.seekooh.com";
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    }
                } catch (Exception e) {
                    Log.e("TAG", "bind: ", e);
                }
            }
        }
    }

    public interface Listener {
        void onViewDetailsClicked(int position, CourseListing courseListing);

        void onEnrolClicked(int position, CourseListing courseListing);
    }

    public enum ViewType {
        LOADING_VIEW, NORMAL_VIEW, AD_VIEW
    }
}
