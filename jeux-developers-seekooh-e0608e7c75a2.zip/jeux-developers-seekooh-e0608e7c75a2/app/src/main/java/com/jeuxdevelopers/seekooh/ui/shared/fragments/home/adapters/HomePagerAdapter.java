package com.jeuxdevelopers.seekooh.ui.shared.fragments.home.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.courses.CourseListingFragment;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.institutes.InstituteListingFragment;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tuitions.TuitionListingFragment;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tutors.TutorListingFragment;

public class HomePagerAdapter extends FragmentStateAdapter {
    public HomePagerAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new TutorListingFragment();
            case 1:
                return new TuitionListingFragment();
            case 2:
                return new InstituteListingFragment();
            case 3:
                return new CourseListingFragment();
        }
        return null;
    }

    @Override
    public int getItemCount() {
        return 4;
    }
}
