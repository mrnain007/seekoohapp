package com.jeuxdevelopers.seekooh.models;

public class Resource<T> {
    private Status status;
    private T data;
    private String message;

    public enum Status {SUCCESS, ERROR, LOADING}

    public Resource(Status status, T data, String message) {
        this.status = status;
        this.data = data;
        this.message = message;
    }

    public static <T> Resource<T> success(String msg, T data) {
        return new Resource<>(Status.SUCCESS, data, msg);
    }

    public static <T> Resource<T> error(String msg, T data) {
        return new Resource<>(Status.ERROR, data, msg);
    }

    public static <T> Resource<T> loading(String msg, T data) {
        return new Resource<>(Status.LOADING, data, msg);
    }

    public Status getStatus() {
        return status;
    }

    public T getData() {
        return data;
    }

    public String getMessage() {
        return message;
    }
}

