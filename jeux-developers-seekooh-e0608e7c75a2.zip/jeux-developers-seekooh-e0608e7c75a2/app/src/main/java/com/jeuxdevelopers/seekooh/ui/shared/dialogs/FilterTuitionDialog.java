package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.jeuxdevelopers.seekooh.databinding.DialogFilterTuitionBinding;
import com.jeuxdevelopers.seekooh.databinding.DialogFilterTutorsBinding;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.ui.shared.views.MultiSelectionView;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FilterTuitionDialog extends Dialog {

    private DialogFilterTuitionBinding binding;
    private Listener listener;

    // Gender
    private Integer selectedGender;

    // Drop downs
    private ArrayAdapter<String> citiesArrayAdapter;
    private List<City> citiesList = new ArrayList<>();
    private City selectedCity;

    private ArrayAdapter<String> boardArrayAdapter;
    private List<Board> boardsList = new ArrayList<>();
    private Board selectedBoard;

    private ArrayAdapter<String> modeArrayAdapter;
    private Boolean isOnline;

    private MultiSelectionView.Data<Subject> subjectData;
    private MultiSelectionView.Data<Grade> gradeData;

    public FilterTuitionDialog(@NonNull Context context) {
        super(context);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogFilterTuitionBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));

        initDialog();
    }

    public FilterTuitionDialog(@NonNull Context context, @NonNull Listener listener) {
        super(context);
        this.listener = listener;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogFilterTuitionBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));

        initDialog();
    }

    private void initDialog() {
        binding.btnBack.setOnClickListener(v -> {
            dismiss();
        });
        binding.genderRg.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == binding.radioMale.getId()) {
                selectedGender = 1;
            } else if (checkedId == binding.radioFemale.getId()) {
                selectedGender = 2;
            } else if (checkedId == binding.radioDoesNotMatter.getId()) {
                selectedGender = null;
            }
        });
        setModeDropDown();
        binding.searchBtn.setOnClickListener(v -> {
            if (listener == null) {
                return;
            }

            listener.onSearchClicked(isOnline, selectedGender, selectedCity, subjectData.getSelectedItemsList(), gradeData.getSelectedItemsList(), selectedBoard);
        });
        binding.resetBtn.setOnClickListener(v -> {
            if (listener == null) {
                return;
            }

            resetUserData();
            listener.onResetClicked();
        });
    }

    private void resetUserData() {
        isOnline = null;
        selectedGender = null;
        binding.genderRg.check(binding.radioDoesNotMatter.getId());
        selectedCity = null;
        binding.cityAcTv.setText("", false);
        binding.boardAcTv.setText("", false);
        binding.modesAcTv.setText("", false);
        binding.subjectsMsv.clearSelectedItems();
        binding.gradesMsv.clearSelectedItems();
    }

    @Override
    public void show() {
    }

    public void show(List<City> citiesList, List<Subject> subjectList, List<Grade> gradeList, List<Board> boardList) {
        if (binding != null) {
            setData(citiesList, subjectList, gradeList, boardList);
        }
        super.show();
    }

    private void setData(List<City> citiesList, List<Subject> subjectsList, List<Grade> gradeList, List<Board> boardsList) {
        this.citiesList = citiesList;
        setCitiesDropDown();
        this.boardsList = boardsList;
        setBoardsDropDown();
        subjectData = new MultiSelectionView.Data<>(subjectsList, Subject::getName);
        binding.subjectsMsv.setData("Select subjects?", subjectData);
        gradeData = new MultiSelectionView.Data<>(gradeList, Grade::getName);
        binding.gradesMsv.setData("Select grade?", gradeData);
    }

    private void setCitiesDropDown() {
        citiesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(citiesList, City::getName));
        binding.cityAcTv.setAdapter(citiesArrayAdapter);
        binding.cityAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = citiesList.get(position);
        });
    }

    private void setBoardsDropDown() {
        boardArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(boardsList, Board::getName));
        binding.boardAcTv.setAdapter(boardArrayAdapter);
        binding.boardAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedBoard = boardsList.get(position);
        });
    }

    private void setModeDropDown() {
        modeArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Arrays.asList("Online", "In-person"));
        binding.modesAcTv.setAdapter(modeArrayAdapter);
        binding.modesAcTv.setOnItemClickListener((parent, view, position, id) -> {
            if (position == 0) {
                isOnline = true;
            } else if (position == 1) {
                isOnline = false;
            }
        });
    }

    public interface Listener {
        void onSearchClicked(Boolean isOnline, Integer selectedGenderId, City selectedCity, List<Subject> subjectList, List<Grade> gradeList, Board selectedBoard);

        void onResetClicked();
    }
}
