package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AppSettings {
    @SerializedName("selectedRole")
    @Expose
    private com.jeuxdevelopers.seekooh.models.Role selectedRole;

    public AppSettings() {
    }

    public com.jeuxdevelopers.seekooh.models.Role getSelectedRole() {
        return selectedRole;
    }

    public void setSelectedRole(com.jeuxdevelopers.seekooh.models.Role selectedRole) {
        this.selectedRole = selectedRole;
    }
}
