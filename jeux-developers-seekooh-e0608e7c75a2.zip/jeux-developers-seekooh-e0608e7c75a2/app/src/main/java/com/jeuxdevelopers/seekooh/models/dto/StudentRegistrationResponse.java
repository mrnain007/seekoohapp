package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.Gender;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.StudentProfile;

import java.util.ArrayList;
import java.util.List;

public class StudentRegistrationResponse {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("seekoohId")
    @Expose
    private String seekoohId;
    @SerializedName("fullName")
    @Expose
    private String fullName;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("gender")
    @Expose
    private Gender gender;
    @SerializedName("roles")
    @Expose
    private List<Role> roles = new ArrayList<>();
    @SerializedName("studentProfile")
    @Expose
    private StudentProfile studentProfile;

    public StudentRegistrationResponse() {
    }

    public StudentRegistrationResponse(Integer id, String seekoohId, String fullName, String email, String phoneNumber, Gender gender, List<Role> roles, StudentProfile studentProfile) {
        this.id = id;
        this.seekoohId = seekoohId;
        this.fullName = fullName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.gender = gender;
        this.roles = roles;
        this.studentProfile = studentProfile;
    }

    private StudentRegistrationResponse(Builder builder) {
        setId(builder.id);
        setFullName(builder.fullName);
        setEmail(builder.email);
        setPhoneNumber(builder.phoneNumber);
        setGender(builder.gender);
        setRoles(builder.roles);
        setStudentProfile(builder.studentProfile);
    }

    public static Builder builder() {
        return new Builder();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSeekoohId() {
        return seekoohId;
    }

    public void setSeekoohId(String seekoohId) {
        this.seekoohId = seekoohId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    public StudentProfile getStudentProfile() {
        return studentProfile;
    }

    public void setStudentProfile(StudentProfile studentProfile) {
        this.studentProfile = studentProfile;
    }

    public static final class Builder {
        private Integer id;
        private String fullName;
        private String email;
        private String phoneNumber;
        private Gender gender;
        private List<Role> roles;
        private StudentProfile studentProfile;

        private Builder() {
        }

        public Builder id(Integer id) {
            this.id = id;
            return this;
        }

        public Builder fullName(String fullName) {
            this.fullName = fullName;
            return this;
        }

        public Builder email(String email) {
            this.email = email;
            return this;
        }

        public Builder phoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }

        public Builder gender(Gender gender) {
            this.gender = gender;
            return this;
        }

        public Builder roles(List<Role> roles) {
            this.roles = roles;
            return this;
        }

        public Builder studentProfile(StudentProfile studentProfile) {
            this.studentProfile = studentProfile;
            return this;
        }

        public StudentRegistrationResponse build() {
            return new StudentRegistrationResponse(this);
        }
    }
}
