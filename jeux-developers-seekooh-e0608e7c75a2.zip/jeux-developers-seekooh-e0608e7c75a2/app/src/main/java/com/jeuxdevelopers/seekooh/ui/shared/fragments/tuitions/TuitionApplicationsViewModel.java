package com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationResponse;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;
import retrofit2.http.Path;

public class TuitionApplicationsViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<List<TuitionApplicationResponse>>> getTuitionApplicationsLiveData = new MutableLiveData<>();

    public TuitionApplicationsViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getTuitionApplications(@NonNull Integer tuitionId) {
        disposables.add(appRepo.getTuitionApplications(tuitionId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(tuitionApplicationsResource -> {
                    getTuitionApplicationsLiveData.setValue(tuitionApplicationsResource);
                }, throwable -> {
                    getTuitionApplicationsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
