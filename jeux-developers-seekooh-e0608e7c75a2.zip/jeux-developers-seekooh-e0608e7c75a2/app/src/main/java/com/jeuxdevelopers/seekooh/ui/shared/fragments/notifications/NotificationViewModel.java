package com.jeuxdevelopers.seekooh.ui.shared.fragments.notifications;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.paging.Pager;
import androidx.paging.PagingConfig;
import androidx.paging.PagingData;
import androidx.paging.PagingLiveData;

import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationRequest;
import com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationResponse;
import com.jeuxdevelopers.seekooh.models.pagination.JobListingRxPagingSource;
import com.jeuxdevelopers.seekooh.models.pagination.NotificationRxPagingSource;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;
import com.jeuxdevelopers.seekooh.repos.listing.ListingRepo;
import com.jeuxdevelopers.seekooh.repos.listing.ListingRepoImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class NotificationViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final ListingRepo listingRepo;
    private final AppRepo appRepo;

    public LiveData<PagingData<Object>> pagingLiveData = new MutableLiveData<>();

    public NotificationViewModel() {
        listingRepo = new ListingRepoImpl(disposables);
        appRepo = new AppRepoImpl(disposables);
        init();
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void init() {
        PagingConfig pagingConfig = new PagingConfig(1000, 1000 * 2, false, 1000);
        Pager<Integer, Object> pager = new Pager<>(
                pagingConfig,
                () -> new NotificationRxPagingSource(listingRepo, disposables));
        pagingLiveData = PagingLiveData.cachedIn(PagingLiveData.getLiveData(pager), this);
    }
}
