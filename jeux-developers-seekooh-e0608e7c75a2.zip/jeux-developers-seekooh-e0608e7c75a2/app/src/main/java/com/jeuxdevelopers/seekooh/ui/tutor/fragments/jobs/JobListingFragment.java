package com.jeuxdevelopers.seekooh.ui.tutor.fragments.jobs;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.paging.LoadState;

import com.jeuxdevelopers.seekooh.databinding.FragmentJobListingBinding;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationRequest;
import com.jeuxdevelopers.seekooh.ui.shared.activities.jobs.PostJobActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.ApplyJobDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.FilterJobDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.FilterTutorsDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.home.HomeFragmentDirections;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tuitions.adapters.TuitionListingLoadStateAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tutors.adapters.TutorFiltersAdapter;
import com.jeuxdevelopers.seekooh.ui.tutor.fragments.jobs.adapters.JobListingAdapter;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.List;
import java.util.stream.Collectors;

public class JobListingFragment extends Fragment {

    // Search
    private final Handler handler = new Handler();
    private Runnable delayedAction = null;
    private final int SEARCH_DELAY_MS = 1000;
    private TextWatcher searchTextWatcher;

    private FragmentJobListingBinding binding;
    private JobListingViewModel viewModel;
    private JobListingAdapter jobListingAdapter;
    private FilterJobDialog filterJobDialog;
    private ApplyJobDialog applyJobDialog;
    private WaitingDialog waitingDialog;
    private List<City> cityList;
    private List<Subject> subjectList;
    private List<Grade> gradeList;
    private User user;
    private boolean isTutorProfileVerified = false;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        viewModel = new ViewModelProvider(this).get(JobListingViewModel.class);
        binding = FragmentJobListingBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews();
        initObservers();
        fetchData();
        initRoleOptions();
        getArgs();
    }

    private void getArgs() {
        MainActivity mainActivity = (MainActivity) requireActivity();
        if (mainActivity.searchJobId != null) {
            viewModel.search = String.valueOf(mainActivity.searchJobId);
            mainActivity.searchJobId = null;
            setSearchText(viewModel.search);
            jobListingAdapter.refresh();
        }
    }

    private void initRoleOptions() {
        user = UserPrefs.getUser(requireContext());
        if (user == null) {
            return;
        }

        boolean hasInstituteRole = user.getRoles().stream()
                .anyMatch(role -> role.getName().equals(Constants.ROLE_INSTITUTE));

        if (hasInstituteRole) {
            binding.postJobBtn.setVisibility(View.VISIBLE);
        } else {
            binding.postJobBtn.setVisibility(View.GONE);
        }

        if (user.getTutorProfile() != null && user.getTutorProfile().getVerified()) {
            isTutorProfileVerified = true;
        }
    }

    private void initViews() {
        initSearchListener();
        applyJobDialog = new ApplyJobDialog(requireContext());
        filterJobDialog = new FilterJobDialog(requireContext(), new FilterJobDialog.Listener() {
            @Override
            public void onSearchClicked(Boolean isOnline, Boolean isInPerson, City selectedCity, List<Subject> subjectList, List<Grade> gradeList) {
                viewModel.isOnline = isOnline;
                viewModel.isInPerson = isInPerson;
                viewModel.cityId = selectedCity == null ? null : selectedCity.getId();
                viewModel.subjectIds.clear();
                viewModel.subjectIds.addAll(Utils.toIdList(subjectList, Subject::getId));
                viewModel.gradeIds.clear();
                viewModel.gradeIds.addAll(Utils.toIdList(gradeList, Grade::getId));
                jobListingAdapter.refresh();
                filterJobDialog.dismiss();
            }

            @Override
            public void onResetClicked() {
                setSearchText("");
                viewModel.search = null;
                viewModel.isOnline = null;
                viewModel.isInPerson = null;
                viewModel.cityId = null;
                viewModel.subjectIds.clear();
                viewModel.gradeIds.clear();
                jobListingAdapter.refresh();
                filterJobDialog.dismiss();
            }
        });
        waitingDialog = new WaitingDialog(requireContext());
        initClickListeners();
        initRecycler();
    }

    private void initSearchListener() {
        searchTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                searchText(s.toString().trim());
            }
        };
        binding.searchEt.addTextChangedListener(searchTextWatcher);
    }

    private void searchText(String newText) {
        if (delayedAction != null) {
            handler.removeCallbacks(delayedAction);
        }

        delayedAction = () -> {
            viewModel.search = newText;
            jobListingAdapter.refresh();
        };

        handler.postDelayed(delayedAction, SEARCH_DELAY_MS);
    }

    private void setSearchText(String text) {
        binding.searchEt.removeTextChangedListener(searchTextWatcher);
        binding.searchEt.setText(text);
        binding.searchEt.addTextChangedListener(searchTextWatcher);
    }

    private void initObservers() {
        viewModel.pagingLiveData
                .observe(getViewLifecycleOwner(), postPagingData -> {
                    jobListingAdapter.submitData(getLifecycle(), postPagingData);
                });

        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    cityList = getCitiesResponse.getData();
                    break;
            }
        });

        viewModel.getSubjectsLiveData.observe(getViewLifecycleOwner(), getSubjectsResponse -> {
            switch (getSubjectsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSubjectsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    subjectList = getSubjectsResponse.getData();
                    break;
            }
        });

        viewModel.getGradesLiveData.observe(getViewLifecycleOwner(), getGradesResponse -> {
            switch (getGradesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getGradesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    gradeList = getGradesResponse.getData();
                    break;
            }
        });

        viewModel.applyToJobLiveData.observe(getViewLifecycleOwner(), applyToTuitionResponse -> {
            switch (applyToTuitionResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), applyToTuitionResponse.getMessage());
                    waitingDialog.dismiss();
                    break;
                case LOADING:
                    waitingDialog.show(applyToTuitionResponse.getMessage());
                    break;
                case SUCCESS:
                    Utils.showToast(requireContext(), applyToTuitionResponse.getMessage());
                    applyJobDialog.dismiss();
                    waitingDialog.dismiss();
                    break;
            }
        });
    }

    private void fetchData() {
        viewModel.init();
        viewModel.getCities();
        viewModel.getSubjects();
        viewModel.getGrades();
    }

    private void initClickListeners() {
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            jobListingAdapter.refresh();
        });
        binding.postJobBtn.setOnClickListener(v -> {
            if (UserPrefs.isInstituteProfileVerified(requireContext())) {
                startActivity(new Intent(requireContext(), PostJobActivity.class));
            } else {
                Utils.showToast(requireContext(), "Only verified institutes can post jobs!");
            }
        });
        binding.filterBtn.setOnClickListener(v -> {
            if (cityList == null || subjectList == null || gradeList == null) {
                return;
            }
            filterJobDialog.show(cityList, subjectList, gradeList);
        });
    }

    private void initRecycler() {
        // Listing Rcv
        jobListingAdapter = new JobListingAdapter((position, jobListing) -> {
            if (!isTutorProfileVerified) {
                Utils.showToast(requireContext(), "Only verified tutors can apply!");
                return;
            }
            applyJobDialog.show(jobListing, new ApplyJobDialog.Listener() {
                @Override
                public void onPositiveBtnClicked(String coverLetter, Integer jobId) {
                    viewModel.applyToTeachingJob(jobId, new TeachingJobApplicationRequest(coverLetter));
                }

                @Override
                public void onNegativeBtnClicked() {
                    applyJobDialog.dismiss();
                }
            });
        });

        binding.jobListingRcv.setAdapter(jobListingAdapter.withLoadStateFooter(
                new TuitionListingLoadStateAdapter(v -> {

                })
        ));

        jobListingAdapter.addLoadStateListener(combinedLoadStates -> {
            if (combinedLoadStates.getRefresh() instanceof LoadState.Error) {
                LoadState.Error error = (LoadState.Error) combinedLoadStates.getRefresh();

                Utils.showToast(requireContext(), error.getError().getLocalizedMessage());
                binding.shimmer.setVisibility(View.GONE);
                binding.noContentLayout.getRoot().setVisibility(View.VISIBLE);
                binding.jobListingRcv.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.Loading) {
                binding.shimmer.setVisibility(View.VISIBLE);
                binding.noContentLayout.getRoot().setVisibility(View.GONE);
                binding.jobListingRcv.setVisibility(View.GONE);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.NotLoading) {
                binding.jobListingRcv.setVisibility(View.VISIBLE);
                binding.shimmer.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
                binding.noContentLayout.getRoot().setVisibility(jobListingAdapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
            }
            return null;
        });
    }
}