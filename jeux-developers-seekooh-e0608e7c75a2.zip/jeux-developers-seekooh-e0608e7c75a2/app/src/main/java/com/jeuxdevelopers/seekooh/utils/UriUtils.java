package com.jeuxdevelopers.seekooh.utils;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import androidx.annotation.RequiresApi;

public class UriUtils {

    public static Uri convertContentUriToFileUri(Context context, Uri contentUri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return convertContentUriToFileUriAboveQ(context, contentUri);
        } else {
            return convertContentUriToFileUriBelowQ(context, contentUri);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private static Uri convertContentUriToFileUriAboveQ(Context context, Uri contentUri) {
        String filePath = null;
        try {
            filePath = getFilePathForContentUriAboveQ(context, contentUri);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (filePath != null) {
            return Uri.parse("file://" + filePath);
        }
        return null;
    }

    private static Uri convertContentUriToFileUriBelowQ(Context context, Uri contentUri) {
        String filePath = null;
        try {
            filePath = getFilePathForContentUriBelowQ(context, contentUri);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (filePath != null) {
            return Uri.parse("file://" + filePath);
        }
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private static String getFilePathForContentUriAboveQ(Context context, Uri contentUri) {
        String filePath = null;
        try {
            if (DocumentsContract.isDocumentUri(context, contentUri)) {
                String documentId = DocumentsContract.getDocumentId(contentUri);
                if (isExternalStorageDocument(contentUri)) {
                    String[] split = documentId.split(":");
                    String type = split[0];

                    if ("primary".equalsIgnoreCase(type)) {
                        return context.getExternalFilesDir(null) + "/" + split[1];
                    }
                } else if (isDownloadsDocument(contentUri)) {
                    Uri downloadUri = Uri.parse("content://downloads/public_downloads");
                    Uri downloadUriWithId = Uri.withAppendedPath(downloadUri, documentId);
                    filePath = getDataColumn(context, downloadUriWithId, null, null);
                } else if (isMediaDocument(contentUri)) {
                    String[] split = documentId.split(":");
                    String type = split[0];

                    Uri mediaUri = null;
                    if ("image".equals(type)) {
                        mediaUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    } else if ("video".equals(type)) {
                        mediaUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    } else if ("audio".equals(type)) {
                        mediaUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    }

                    String selection = "_id=?";
                    String[] selectionArgs = new String[]{split[1]};
                    filePath = getDataColumn(context, mediaUri, selection, selectionArgs);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return filePath;
    }

    private static String getFilePathForContentUriBelowQ(Context context, Uri contentUri) {
        String filePath = null;
        try {
            String[] projection = {MediaStore.MediaColumns.DATA};
            filePath = getDataColumn(context, contentUri, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return filePath;
    }

    private static String getDataColumn(Context context, Uri uri, String selection, String[] selectionArgs) {
        String[] projection = {MediaStore.MediaColumns.DATA};
        try {
            Cursor cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs, null);
            if (cursor != null && cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
                return cursor.getString(columnIndex);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    private static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    private static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }
}
