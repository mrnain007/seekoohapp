package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.DialogCreateInstituteReviewBinding;
import com.jeuxdevelopers.seekooh.databinding.DialogCreateTutorReviewBinding;
import com.jeuxdevelopers.seekooh.models.InstituteDetails;
import com.jeuxdevelopers.seekooh.models.TutorDetails;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class CreateInstituteReviewDialog extends Dialog {

    public DialogCreateInstituteReviewBinding binding;
    private boolean isTextWatcherEnabled = false;
    private Listener listener;

    public CreateInstituteReviewDialog(@NonNull Context context) {
        super(context);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogCreateInstituteReviewBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));

        initDialog();
    }

    public CreateInstituteReviewDialog(@NonNull Context context, Listener listener) {
        super(context);
        this.listener = listener;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogCreateInstituteReviewBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));

        initDialog();
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    private void initDialog() {
        binding.btnBack.setOnClickListener(v -> {
            dismiss();
        });
        initTextWatcher();
    }

    private void initTextWatcher() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateUserInput();
                }
            }
        };

        binding.reviewTitleTl.getEditText().addTextChangedListener(textWatcher);
        binding.reviewDescTv.getEditText().addTextChangedListener(textWatcher);
    }

    @Override
    public void dismiss() {
        if (binding != null) {
            binding.reviewTitleTl.getEditText().setText("");
            binding.reviewDescTv.getEditText().setText("");
            binding.ratingBar.setRating(0);
        }
        super.dismiss();
    }

    public void show(InstituteDetails instituteDetails) {
        if (binding != null) {
            setData(instituteDetails);
        }
        show();
    }

    private void setData(InstituteDetails data) {
        Glide.with(getContext())
                .load(data.getProfileImageUrl())
                .placeholder(R.drawable.profile_image_placeholder)
                .into(binding.profileImg);
        binding.verifiedBadge.setVisibility(data.getVerified() ? View.VISIBLE : View.GONE);
        binding.instituteName.setText(data.getNameOfInstitute());
        if (data.getDescription() == null) {
            binding.description.setVisibility(View.GONE);
        } else {
            binding.description.setText(data.getDescription());
        }
        binding.submitReviewBtn.setOnClickListener(v1 -> {
            if (binding.ratingBar.getRating() == 0) {
                Utils.showToast(getContext(), "Please select the rating!");
                return;
            }

            if (validateUserInput() && listener != null) {
                String title = binding.reviewTitleTl.getEditText().getText().toString().trim();
                String desc = binding.reviewDescTv.getEditText().getText().toString().trim();
                listener.onSubmitClicked(title, desc, (double) binding.ratingBar.getRating());
            }
        });
    }

    private boolean validateUserInput() {
        isTextWatcherEnabled = true;
        boolean isValid = true;
        String title = binding.reviewTitleTl.getEditText().getText().toString().trim();
        String desc = binding.reviewDescTv.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(title)) {
            binding.reviewTitleTl.setError("Please enter review title?");
            isValid = false;
        } else {
            binding.reviewTitleTl.setError(null);
        }

        if (TextUtils.isEmpty(desc)) {
            binding.reviewDescTv.setError("Please enter review description?");
            isValid = false;
        } else {
            binding.reviewDescTv.setError(null);
        }

        if (binding.ratingBar.getRating() == 0) {
            isValid = false;
        }

        return isValid;
    }

    public interface Listener {
        void onSubmitClicked(@NonNull String title, @NonNull String description, @NonNull Double rating);
    }
}
