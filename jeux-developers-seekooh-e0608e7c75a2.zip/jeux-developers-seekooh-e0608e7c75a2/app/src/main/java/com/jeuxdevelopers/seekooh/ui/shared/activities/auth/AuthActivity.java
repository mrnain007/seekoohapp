package com.jeuxdevelopers.seekooh.ui.shared.activities.auth;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavGraph;
import androidx.navigation.NavOptions;
import androidx.navigation.fragment.NavHostFragment;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityAuthBinding;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import dagger.hilt.android.AndroidEntryPoint;

public class AuthActivity extends AppCompatActivity {
    private static final String TAG = "AuthActivity";
    private ActivityAuthBinding binding;
    public Mode mode;
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAuthBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initNavController();
        getArgs();
    }

    private void initNavController() {
        final NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_container_view);
        navController = navHostFragment.getNavController();
    }

    private void getArgs() {
        String modeStr = getIntent().getStringExtra(Constants.AUTH_ACTIVITY_MODE);
        if (modeStr != null) {
            try {
                mode = Mode.valueOf(modeStr);
            } catch (IllegalArgumentException e) {
                Utils.showToast(this, "Invalid auth arg!");
            }
            setMode();
        }
    }

    private void setMode() {
        if (mode != null) {
            switch (mode) {
                case BECOME_STUDENT:
                    navController.navigate(R.id.studentRegistrationFragment, null, new NavOptions.Builder()
                            .setPopUpTo(navController.getGraph().getStartDestinationId(), true)
                            .build());
                    break;
                case BECOME_TUTOR:
                    navController.navigate(R.id.tutorRegistrationFragment, null, new NavOptions.Builder()
                            .setPopUpTo(navController.getGraph().getStartDestinationId(), true)
                            .build());
                    break;
                case BECOME_INSTITUTE:
                    navController.navigate(R.id.instituteRegistrationFragment, null, new NavOptions.Builder()
                            .setPopUpTo(navController.getGraph().getStartDestinationId(), true)
                            .build());
                    break;
            }
        }
    }

    public void switchToPasswordResetFragment() {
        navController.navigate(R.id.forgotPasswordFragment, null,
                new NavOptions.Builder()
                        .setPopUpTo(navController.getGraph().getStartDestinationId(), true)
                        .build());
    }

    private void themeChanges() {
        Window window = getWindow();
        window.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
    }

    public enum Mode {
        BECOME_STUDENT, BECOME_TUTOR, BECOME_INSTITUTE
    }
}