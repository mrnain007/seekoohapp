package com.jeuxdevelopers.seekooh.ui.tutor.activities.details.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ItemRcvSliderBinding;

public class RcvSliderAdapter extends ListAdapter<RcvSliderAdapter.SliderItem, RcvSliderAdapter.SliderItemViewHolder> {
    private static final DiffUtil.ItemCallback<SliderItem> DIFF_CALLBACK = new DiffUtil.ItemCallback<SliderItem>() {
        @Override
        public boolean areItemsTheSame(@NonNull SliderItem oldItem, @NonNull SliderItem newItem) {
            return oldItem.getUrl().equals(newItem.url);
        }

        @Override
        public boolean areContentsTheSame(@NonNull SliderItem oldItem, @NonNull SliderItem newItem) {
            return oldItem.equals(newItem);
        }
    };

    private final Listener listener;

    public RcvSliderAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @NonNull
    @Override
    public SliderItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemRcvSliderBinding binding = ItemRcvSliderBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new SliderItemViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull SliderItemViewHolder holder, int position) {
        holder.bind(getItem(position));
        holder.binding.getRoot().setOnClickListener(v -> listener.onItemClicked(getItem(position), position));
    }

    public static class SliderItemViewHolder extends RecyclerView.ViewHolder {
        private final ItemRcvSliderBinding binding;

        public SliderItemViewHolder(ItemRcvSliderBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(SliderItem model) {
            Context context = binding.getRoot().getContext();
            Glide.with(context)
                    .load(model.url)
                    .placeholder(R.color.lotion)
                    .into(binding.sliderImg);
            if (model.type == SliderItem.Type.VIDEO) {
                binding.videoPlayIconImg.setVisibility(View.VISIBLE);
            } else {
                binding.videoPlayIconImg.setVisibility(View.GONE);
            }
        }
    }

    public interface Listener {
        void onItemClicked(SliderItem data, int position);
    }

    public static class SliderItem {
        private String description = "";
        private String url;
        private Type type = Type.IMAGE;

        public SliderItem(String description, String url) {
            this.description = description;
            this.url = url;
        }

        public SliderItem(String description, String url, Type type) {
            this.description = description;
            this.url = url;
            this.type = type;
        }

        private SliderItem(Builder builder) {
            setDescription(builder.description);
            setUrl(builder.url);
            type = builder.type;
        }

        public static Builder builder() {
            return new Builder();
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public Type getType() {
            return type;
        }

        public void setType(Type type) {
            this.type = type;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            SliderItem that = (SliderItem) o;

            if (description != null ? !description.equals(that.description) : that.description != null)
                return false;
            if (url != null ? !url.equals(that.url) : that.url != null) return false;
            return type == that.type;
        }

        @Override
        public int hashCode() {
            int result = description != null ? description.hashCode() : 0;
            result = 31 * result + (url != null ? url.hashCode() : 0);
            result = 31 * result + (type != null ? type.hashCode() : 0);
            return result;
        }

        public enum Type {
            IMAGE, VIDEO
        }

        public static final class Builder {
            private String description;
            private String url;
            private Type type;

            private Builder() {
            }

            public Builder description(String description) {
                this.description = description;
                return this;
            }

            public Builder url(String url) {
                this.url = url;
                return this;
            }

            public Builder type(Type type) {
                this.type = type;
                return this;
            }

            public SliderItem build() {
                return new SliderItem(this);
            }
        }
    }
}
