package com.jeuxdevelopers.seekooh.ui.institute.fragments.profile;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.common.util.CollectionUtils;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.ExperienceLgLayoutBinding;
import com.jeuxdevelopers.seekooh.databinding.FragmentInstituteProfileBinding;
import com.jeuxdevelopers.seekooh.databinding.QualificationLgLayoutBinding;
import com.jeuxdevelopers.seekooh.models.Address;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.InstituteType;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TutorTimeSlot;
import com.jeuxdevelopers.seekooh.models.dto.GetProfileResponse;
import com.jeuxdevelopers.seekooh.models.dto.UpdateInstituteProfileRequest;
import com.jeuxdevelopers.seekooh.models.dto.UpdateTutorProfileRequest;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.MultiChoiceDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.net.URI;
import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.reactivex.rxjava3.disposables.CompositeDisposable;

public class InstituteProfileFragment extends Fragment {
    private static final String TAG = "InstituteProfileFragmen";
    private final CompositeDisposable disposables = new CompositeDisposable();

    private final int PROFILE_IMAGE_REQUEST_CODE = 1000;

    private boolean isTextWatcherEnabled = false;
    private boolean isEditModeEnabled = false;
    private Uri profileImageUri;

    private FragmentInstituteProfileBinding binding;
    private InstituteProfileViewModel viewModel;
    private OnBackPressedCallback callback;
    private WaitingDialog waitingDialog;
    private GetProfileResponse data;

    private MultiChoiceDialog<Subject> subjectMultiChoiceDialog;
    private MultiChoiceDialog<Grade> gradeMultiChoiceDialog;
    private MultiChoiceDialog<Board> boardMultiChoiceDialog;

    // Drop downs
    private ArrayAdapter<String> citiesArrayAdapter;
    private List<City> citiesList = new ArrayList<>();
    private City selectedCity;

    private ArrayAdapter<String> instituteTypesArrayAdapter;
    private List<InstituteType> instituteTypeList = new ArrayList<>();
    private InstituteType selectedInstituteType;

    private boolean isRegistered = true;

    private TextWatcher textWatcher;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (!isEditModeEnabled) {
                    setEnabled(false);
                    requireActivity().onBackPressed();
                } else {
                    setEditMode(false);
                }
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentInstituteProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(InstituteProfileViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        initProfile();
    }

    @Override
    public void onDestroy() {
        disposables.dispose();
        super.onDestroy();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext());
    }

    private void initTextWatcher() {
        textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateUserInput();
                }
            }
        };

        binding.nameTl.getEditText().addTextChangedListener(textWatcher);
        binding.phoneTl.getEditText().addTextChangedListener(textWatcher);
        binding.instituteTypeTl.getEditText().addTextChangedListener(textWatcher);
        binding.citiesTl.getEditText().addTextChangedListener(textWatcher);
        binding.subjectTl.getEditText().addTextChangedListener(textWatcher);
        binding.classesTl.getEditText().addTextChangedListener(textWatcher);
        binding.boardTl.getEditText().addTextChangedListener(textWatcher);
    }

    private void setCitiesDropDown() {
        citiesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(citiesList, City::getName));
        binding.citiesAcTv.setAdapter(citiesArrayAdapter);
        binding.citiesAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = citiesList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void setInstituteTypesDropDown() {
        instituteTypesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(instituteTypeList, InstituteType::getName));
        binding.instituteTypeAcTv.setAdapter(instituteTypesArrayAdapter);
        binding.instituteTypeAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedInstituteType = instituteTypeList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    /*private void setIsRegisteredDropDown() {
        List<String> isRegisteredStringList = Arrays.asList("Unregistered", "Registered");
        ArrayAdapter<String> isRegisteredArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, isRegisteredStringList);
        binding.registeredAcTv.setAdapter(isRegisteredArrayAdapter);
        binding.registeredAcTv.setOnItemClickListener((parent, view, position, id) -> {
            isRegistered = position != 0;
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }*/

    private void initClickListeners() {
        initTextWatcher();
        binding.profileImg.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(1024).maxResultSize(1920, 1920).crop(1, 1).start(PROFILE_IMAGE_REQUEST_CODE);
        });
        binding.profileImgPickerBtn.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(1024).maxResultSize(1920, 1920).crop(1, 1).start(PROFILE_IMAGE_REQUEST_CODE);
        });
        binding.logoutBtn.setOnClickListener(v -> {
            UserPrefs.clearUser(requireContext());
            startActivity(new Intent(requireContext(), AuthActivity.class));
            App.syncPresence();
            requireActivity().finishAffinity();
        });
        binding.editBtn.setOnClickListener(v -> {
            if (isEditModeEnabled) {
                if (validateUserInput()) {
                    String name = binding.nameTl.getEditText().getText().toString().trim();
                    String phone = binding.phoneTl.getEditText().getText().toString().trim();
                    String description = TextUtils.isEmpty(binding.descTv.getEditText().getText().toString().trim()) ? null : binding.descTv.getEditText().getText().toString().trim();
                    List<Subject> selectedSubjects = subjectMultiChoiceDialog.getSelectedItemsList();
                    List<Grade> selectedClasses = gradeMultiChoiceDialog.getSelectedItemsList();
                    List<Board> selectedBoardExams = boardMultiChoiceDialog.getSelectedItemsList();

                    UpdateInstituteProfileRequest.InstituteProfile instituteProfile = UpdateInstituteProfileRequest.InstituteProfile.builder()
                            .nameOfInstitute(name)
                            .description(description)
                            .cityId(selectedCity.getId())
                            .instituteTypeId(selectedInstituteType.getId())
                            .subjectIds(Utils.toIdList(selectedSubjects, Subject::getId))
                            .classIds(Utils.toIdList(selectedClasses, Grade::getId))
                            .boardExamIds(Utils.toIdList(selectedBoardExams, Board::getId))
                            .build();

                    UpdateInstituteProfileRequest updateInstituteProfileRequest = UpdateInstituteProfileRequest.builder()
                            .phoneNumber(phone)
                            .instituteProfile(instituteProfile)
                            .build();

                    viewModel.updateInstituteProfile(profileImageUri == null ? null : URI.create(profileImageUri.toString()), updateInstituteProfileRequest);
                }
            } else {
                setEditMode(true);
            }
        });
        binding.classesAcTv.setOnClickListener(v -> {
            gradeMultiChoiceDialog.show("Select classes your institute teaches?");
        });
        binding.subjectAcTv.setOnClickListener(v -> {
            subjectMultiChoiceDialog.show("Select subjects your institute teaches?");
        });
        binding.boardExamAcTv.setOnClickListener(v -> {
            boardMultiChoiceDialog.show("Select board/exam your institute teaches?");
        });
    }

    private void initObservers() {
        viewModel.getProfileLiveData
                .observe(getViewLifecycleOwner(), profileResponseResource -> {
                    waitingDialog.dismiss();
                    switch (profileResponseResource.getStatus()) {
                        case ERROR:
                            Utils.showToast(requireContext(), profileResponseResource.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(profileResponseResource.getMessage());
                            break;
                        case SUCCESS:
                            Utils.showToast(requireContext(), profileResponseResource.getMessage());
                            data = profileResponseResource.getData();
                            fetchData();
                            setData();
                            break;
                    }
                });

        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    citiesList = getCitiesResponse.getData();
                    setCitiesDropDown();
                    break;
            }
        });

        viewModel.getInstituteTypesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    instituteTypeList = getCitiesResponse.getData();
                    setInstituteTypesDropDown();
                    break;
            }
        });

        viewModel.updateInstituteProfileLiveData
                .observe(getViewLifecycleOwner(), updateTutorProfileResource -> {
                    switch (updateTutorProfileResource.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), updateTutorProfileResource.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(updateTutorProfileResource.getMessage());
                            break;
                        case SUCCESS:
                            Utils.showToast(requireContext(), updateTutorProfileResource.getMessage());
                            data = updateTutorProfileResource.getData();
                            setEditMode(false);
                            setData();
                            waitingDialog.dismiss();
                            break;
                    }
                });

        viewModel.getSubjectsLiveData.observe(getViewLifecycleOwner(), getSubjectsResponse -> {
            switch (getSubjectsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSubjectsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Subject> subjectsList = getSubjectsResponse.getData();
                    subjectMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            subjectsList,
                            Subject::getName,
                            selectedItemNames -> binding.subjectAcTv.setText(selectedItemNames));
                    subjectMultiChoiceDialog.setSelectedItemsList(data.getInstituteProfile().getTeachesSubjects(), Subject::getId);
                    binding.subjectAcTv.setText(String.join(", ", Utils.toStringList(data.getInstituteProfile().getTeachesSubjects(), Subject::getName)));
                    break;
            }
        });

        viewModel.getBoardsLiveData.observe(getViewLifecycleOwner(), getBoardsResponse -> {
            switch (getBoardsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getBoardsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Board> boardsList = getBoardsResponse.getData();
                    boardMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            boardsList,
                            Board::getName,
                            selectedItemNames -> binding.boardExamAcTv.setText(selectedItemNames));
                    boardMultiChoiceDialog.setSelectedItemsList(data.getInstituteProfile().getTeachesBoardExams(), Board::getId);
                    binding.boardExamAcTv.setText(String.join(", ", Utils.toStringList(this.data.getInstituteProfile().getTeachesBoardExams(), Board::getName)));
                    break;
            }
        });

        viewModel.getGradesLiveData.observe(getViewLifecycleOwner(), getGradesResponse -> {
            switch (getGradesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getGradesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Grade> gradesList = getGradesResponse.getData();
                    gradeMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            gradesList,
                            Grade::getName,
                            selectedItemNames -> binding.classesAcTv.setText(selectedItemNames));
                    gradeMultiChoiceDialog.setSelectedItemsList(data.getInstituteProfile().getTeachesClasses(), Grade::getId);
                    binding.classesAcTv.setText(String.join(", ", Utils.toStringList(data.getInstituteProfile().getTeachesClasses(), Grade::getName)));
                    break;
            }
        });
    }

    private void initProfile() {
        viewModel.getProfile();
    }

    private void fetchData() {
        viewModel.getSubjects();
        viewModel.getBoards();
        viewModel.getGrades();
        viewModel.getCities();
        viewModel.getInstituteTypes();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PROFILE_IMAGE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                profileImageUri = data.getData();
                binding.profileImg.setImageURI(profileImageUri);
            } else if (resultCode == ImagePicker.RESULT_ERROR) {
                Utils.showToast(requireContext(), ImagePicker.getError(data));
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        }

    }

    private void setData() {
        if (Utils.isDataNull(requireContext(), data) || Utils.isDataNull(requireContext(), data.getInstituteProfile())) {
            return;
        }

        Glide.with(requireContext())
                .load(data.getInstituteProfile().getProfileImageUrl())
                .placeholder(R.drawable.profile_image_placeholder)
                .into(binding.profileImg);
        binding.seekoohIdTl.getEditText().setText(data.getSeekoohId().toUpperCase());
        binding.nameTl.getEditText().setText(data.getInstituteProfile().getNameOfInstitute());
        binding.descTv.getEditText().setText(data.getInstituteProfile().getDescription());
        binding.emailTl.getEditText().setText(data.getEmail());
        binding.phoneTl.getEditText().setText(data.getPhoneNumber());
        selectedInstituteType = data.getInstituteProfile().getInstituteType();
        binding.instituteTypeAcTv.setText(data.getInstituteProfile().getInstituteType().getName(), false);
        selectedCity = data.getInstituteProfile().getCity();
        binding.citiesAcTv.setText(data.getInstituteProfile().getCity().getName(), false);
        setEditMode(false);
        binding.mainContainerLl.setVisibility(View.VISIBLE);
    }

    private void setEditMode(boolean enabled) {
        if (!enabled) {
            isEditModeEnabled = false;
            binding.nameTl.setEnabled(false);
            binding.descTv.setEnabled(false);
            binding.phoneTl.setEnabled(false);
            binding.subjectTl.setEnabled(false);
            binding.classesTl.setEnabled(false);
            binding.boardTl.setEnabled(false);
            binding.citiesTl.setEnabled(false);
            binding.instituteTypeTl.setEnabled(false);
            binding.profileImg.setClickable(false);
            binding.editBtn.setText("Edit");
            return;
        }
        isEditModeEnabled = true;
        binding.nameTl.setEnabled(true);
        binding.descTv.setEnabled(true);
        binding.phoneTl.setEnabled(true);
        binding.subjectTl.setEnabled(true);
        binding.classesTl.setEnabled(true);
        binding.boardTl.setEnabled(true);
        binding.citiesTl.setEnabled(true);
        binding.instituteTypeTl.setEnabled(true);
        binding.editBtn.setText("Update");
    }

    private boolean validateUserInput() {
        isTextWatcherEnabled = true;
        boolean isValid = true;
        String name = binding.nameTl.getEditText().getText().toString().trim();
        String phone = binding.phoneTl.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            binding.nameTl.setError("Please enter your name?");
            isValid = false;
        } else {
            binding.nameTl.setError(null);
        }

        if (TextUtils.isEmpty(phone)) {
            binding.phoneTl.setError("Please enter your phone number?");
            isValid = false;
        } else if (!Utils.validatePhoneNumber(phone)) {
            binding.phoneTl.setError("Please enter a valid phone number?");
            isValid = false;
        } else {
            binding.phoneTl.setError(null);
        }

        if (selectedCity == null) {
            binding.citiesTl.setError("Please select your city?");
            isValid = false;
        } else {
            binding.citiesTl.setError(null);
        }

        if (selectedInstituteType == null) {
            binding.instituteTypeTl.setError("Please select institute type?");
            isValid = false;
        } else {
            binding.instituteTypeTl.setError(null);
        }

        if (subjectMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.subjectTl.setError("Please select subjects your institute teaches?");
            isValid = false;
        } else {
            binding.subjectTl.setError(null);
        }

        if (gradeMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.classesTl.setError("Please select classes your institute teaches?");
            isValid = false;
        } else {
            binding.classesTl.setError(null);
        }

        if (boardMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.boardTl.setError("Please select board/exam your institute teaches?");
            isValid = false;
        } else {
            binding.boardTl.setError(null);
        }

        return isValid;
    }
}