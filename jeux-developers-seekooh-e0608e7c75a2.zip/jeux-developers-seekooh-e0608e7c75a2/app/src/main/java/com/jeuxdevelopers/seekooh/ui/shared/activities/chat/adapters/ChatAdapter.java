package com.jeuxdevelopers.seekooh.ui.shared.activities.chat.adapters;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.jeuxdevelopers.seekooh.databinding.ItemChatIncomingBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemChatOutgoingBinding;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;
import com.jeuxdevelopers.seekooh.models.chat.Message;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class ChatAdapter extends ListAdapter<Message, RecyclerView.ViewHolder> {
    private static final DiffUtil.ItemCallback<Message> DIFF_CALLBACK = new DiffUtil.ItemCallback<Message>() {
        @Override
        public boolean areItemsTheSame(@NonNull Message oldItem, @NonNull Message newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Message oldItem, @NonNull Message newItem) {
            return oldItem.equals(newItem);
        }
    };
    private final User user;
    private FirebaseUser myFb;
    private Context context;

    public ChatAdapter(Context context) {
        super(DIFF_CALLBACK);
        this.context = context;
        user = UserPrefs.getUser(context);
        if (user != null && !TextUtils.isEmpty(user.getSeekoohId())) {
            myFb = Utils.toFirebaseUser(user);
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (TextUtils.isEmpty(myFb.getUserId())) {
            return VIEW_TYPE.CHAT_INCOMING.ordinal();
        }

        String senderId = getItem(position).getSenderId();

        if (senderId.equals(myFb.getUserId())) {
            return VIEW_TYPE.CHAT_OUTGOING.ordinal();
        } else {
            return VIEW_TYPE.CHAT_INCOMING.ordinal();
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE.CHAT_OUTGOING.ordinal()) {
            ItemChatOutgoingBinding binding = ItemChatOutgoingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new OutgoingChatViewHolder(binding);
        } else if (viewType == VIEW_TYPE.CHAT_INCOMING.ordinal()) {
            ItemChatIncomingBinding binding = ItemChatIncomingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new IncomingChatViewHolder(binding);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof OutgoingChatViewHolder) {
            ((OutgoingChatViewHolder) holder).bind(getItem(position));
        } else if (holder instanceof IncomingChatViewHolder) {
            ((IncomingChatViewHolder) holder).bind(getItem(position));
        }
    }

    public static class OutgoingChatViewHolder extends RecyclerView.ViewHolder {
        private final ItemChatOutgoingBinding binding;

        public OutgoingChatViewHolder(ItemChatOutgoingBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Message model) {
            binding.msgTv.setText(model.getContent());
            if (model.getCreatedAt() != null) {
                binding.msgTimeTv.setText(Utils.getFormattedTime(model.getCreatedAt().toDate().getTime()));
            }
        }
    }

    public static class IncomingChatViewHolder extends RecyclerView.ViewHolder {
        private final ItemChatIncomingBinding binding;

        public IncomingChatViewHolder(ItemChatIncomingBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Message model) {
            binding.msgTv.setText(model.getContent());
            if (model.getCreatedAt() != null) {
                binding.msgTimeTv.setText(Utils.getFormattedTime(model.getCreatedAt().toDate().getTime()));
            }
        }
    }

    enum VIEW_TYPE {
        CHAT_OUTGOING, CHAT_INCOMING
    }
}
