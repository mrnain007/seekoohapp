package com.jeuxdevelopers.seekooh.ui.tutor.fragments.registration;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.github.dhaval2404.imagepicker.ImagePicker;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ExperienceEditTextLayoutBinding;
import com.jeuxdevelopers.seekooh.databinding.FragmentTutorQualificationBinding;
import com.jeuxdevelopers.seekooh.databinding.QualificationEditTextLayoutBinding;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.Experience;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Qualification;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.MultiChoiceDialog;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class TutorQualificationFragment extends DialogFragment {
    private static final String TAG = "TutorQualificationFragm";
    private final int PROFILE_IMAGE_REQUEST_CODE = 1000;
    private boolean isTextWatcherEnabled = false;

    private FragmentTutorQualificationBinding binding;
    private NavController navController;
    private TutorRegistrationViewModel viewModel;
    private List<QualificationEditTextLayoutBinding> qualificationLayoutsList = new ArrayList<>();
    private List<ExperienceEditTextLayoutBinding> experienceLayoutsList = new ArrayList<>();
    private MultiChoiceDialog<Subject> subjectMultiChoiceDialog;
    private MultiChoiceDialog<Grade> gradeMultiChoiceDialog;
    private MultiChoiceDialog<Board> boardMultiChoiceDialog;
    private TextWatcher textWatcher;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.FullScreenDialogStyle);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentTutorQualificationBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews();
        viewModel = new ViewModelProvider(requireActivity()).get(TutorRegistrationViewModel.class);
        initClickListeners();
        initObservers();
        fetchData();
    }

    private void initObservers() {
        viewModel.getBoardsLiveData.observe(getViewLifecycleOwner(), getBoardsResponse -> {
            switch (getBoardsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getBoardsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Board> boardList = getBoardsResponse.getData();
                    boardMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            boardList,
                            Board::getName,
                            selectedItemNames -> binding.boardExamAcTv.setText(selectedItemNames));
                    break;
            }
        });

        viewModel.getGradesLiveData.observe(getViewLifecycleOwner(), getGradesResponse -> {
            switch (getGradesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getGradesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Grade> gradesList = getGradesResponse.getData();
                    gradeMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            gradesList,
                            Grade::getName,
                            selectedItemNames -> binding.classesAcTv.setText(selectedItemNames));
                    break;
            }
        });

        viewModel.getSubjectsLiveData.observe(getViewLifecycleOwner(), getSubjectsResponse -> {
            switch (getSubjectsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSubjectsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Subject> subjectsList = getSubjectsResponse.getData();
                    subjectMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            subjectsList,
                            Subject::getName,
                            selectedItemNames -> binding.subjectAcTv.setText(selectedItemNames));
                    break;
            }
        });
    }

    private void fetchData() {
        binding.profileImg.setImageURI(viewModel.profileImageUri);
        viewModel.getSubjects();
        viewModel.getGrades();
        viewModel.getBoards();
    }

    private void initViews() {
        navController = NavHostFragment.findNavController(this);
        initTextWatcher();
    }

    private void initClickListeners() {
        binding.addMoreQualificationBtn.setOnClickListener(v -> {
            QualificationEditTextLayoutBinding view = QualificationEditTextLayoutBinding.inflate(getLayoutInflater());
            view.degreeNameTl.getEditText().addTextChangedListener(textWatcher);
            view.yearTl.getEditText().addTextChangedListener(textWatcher);
            view.marksTl.getEditText().addTextChangedListener(textWatcher);
            qualificationLayoutsList.add(view);
            int lastEtIndex = binding.qualificationDetailsLl.indexOfChild(binding.addMoreQualificationBtn);
            binding.qualificationDetailsLl.addView(view.getRoot(), lastEtIndex);
        });
        binding.addMoreExperienceBtn.setOnClickListener(v -> {
            ExperienceEditTextLayoutBinding view = ExperienceEditTextLayoutBinding.inflate(getLayoutInflater());
            view.experienceDurationTl.getEditText().addTextChangedListener(textWatcher);
            view.experienceDetailsTl.getEditText().addTextChangedListener(textWatcher);
            experienceLayoutsList.add(view);
            int lastEtIndex = binding.qualificationDetailsLl.indexOfChild(binding.addMoreExperienceBtn);
            binding.qualificationDetailsLl.addView(view.getRoot(), lastEtIndex);
        });
        binding.nextBtn.setOnClickListener(v -> {
            if (!validateUserInput()) {
                return;
            }

            String degreeNameField = binding.qualificationEtLayout.degreeNameTl.getEditText().getText().toString().trim();
            String yearField = binding.qualificationEtLayout.yearTl.getEditText().getText().toString().trim();
            String marksField = binding.qualificationEtLayout.marksTl.getEditText().getText().toString().trim();
            String experienceDuration = binding.experienceEtLayout.experienceDurationTl.getEditText().getText().toString().trim();
            String experienceDetails = binding.experienceEtLayout.experienceDetailsTl.getEditText().getText().toString().trim();

            List<Qualification> qualificationList = new ArrayList<>();
            qualificationList.add(new Qualification(null, degreeNameField, Integer.valueOf(yearField), Double.valueOf(marksField)));
            List<Experience> experienceList = new ArrayList<>();
            experienceList.add(new Experience(null, experienceDuration, experienceDetails));
            List<Subject> selectedSubjects = subjectMultiChoiceDialog.getSelectedItemsList();
            List<Grade> selectedClasses = gradeMultiChoiceDialog.getSelectedItemsList();
            List<Board> selectedBoardExams = boardMultiChoiceDialog.getSelectedItemsList();

            for (QualificationEditTextLayoutBinding qualificationEditTextLayoutBinding : qualificationLayoutsList) {
                String degreeName = qualificationEditTextLayoutBinding.degreeNameTl.getEditText().getText().toString().trim();
                String year = qualificationEditTextLayoutBinding.yearTl.getEditText().getText().toString().trim();
                String marks = qualificationEditTextLayoutBinding.marksTl.getEditText().getText().toString().trim();
                qualificationList.add(new Qualification(null, degreeName, Integer.valueOf(year), Double.valueOf(marks)));
            }
            for (ExperienceEditTextLayoutBinding experienceEditTextLayoutBinding : experienceLayoutsList) {
                String duration = experienceEditTextLayoutBinding.experienceDurationTl.getEditText().getText().toString().trim();
                String details = experienceEditTextLayoutBinding.experienceDetailsTl.getEditText().getText().toString().trim();
                experienceList.add(new Experience(null, duration, details));
            }

            viewModel.tutorRegistrationRequest.getTutorProfile().setQualifications(qualificationList);
            viewModel.tutorRegistrationRequest.getTutorProfile().setExperiences(experienceList);
            viewModel.tutorRegistrationRequest.getTutorProfile().setSubjectIds(Utils.toIdList(selectedSubjects, Subject::getId));
            viewModel.tutorRegistrationRequest.getTutorProfile().setClassIds(Utils.toIdList(selectedClasses, Grade::getId));
            viewModel.tutorRegistrationRequest.getTutorProfile().setBoardExamIds(Utils.toIdList(selectedBoardExams, Board::getId));

            navController.navigate(TutorQualificationFragmentDirections
                    .actionTutorQualificationFragmentToTutorPreferencesFragment());
        });
        binding.classesAcTv.setOnClickListener(v -> {
            gradeMultiChoiceDialog.show("Select classes you teach?");
        });
        binding.subjectAcTv.setOnClickListener(v -> {
            subjectMultiChoiceDialog.show("Select subjects you teach?");
        });
        binding.boardExamAcTv.setOnClickListener(v -> {
            boardMultiChoiceDialog.show("Select board/exam you teach?");
        });
        binding.pickImgBtn.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(1024).maxResultSize(1920, 1920).crop(1, 1).start(PROFILE_IMAGE_REQUEST_CODE);
        });
    }

    private void initTextWatcher() {
        textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateUserInput();
                }
            }
        };

        binding.qualificationEtLayout.degreeNameTl.getEditText().addTextChangedListener(textWatcher);
        binding.qualificationEtLayout.yearTl.getEditText().addTextChangedListener(textWatcher);
        binding.qualificationEtLayout.marksTl.getEditText().addTextChangedListener(textWatcher);
        binding.experienceEtLayout.experienceDurationTl.getEditText().addTextChangedListener(textWatcher);
        binding.experienceEtLayout.experienceDetailsTl.getEditText().addTextChangedListener(textWatcher);
        binding.subjectTl.getEditText().addTextChangedListener(textWatcher);
        binding.classesTl.getEditText().addTextChangedListener(textWatcher);
        binding.boardTl.getEditText().addTextChangedListener(textWatcher);
    }

    private boolean validateUserInput() {
        isTextWatcherEnabled = true;
        boolean isValid = true;
        String degreeNameField = binding.qualificationEtLayout.degreeNameTl.getEditText().getText().toString().trim();
        String yearField = binding.qualificationEtLayout.yearTl.getEditText().getText().toString().trim();
        String marksField = binding.qualificationEtLayout.marksTl.getEditText().getText().toString().trim();
        String experienceDuration = binding.experienceEtLayout.experienceDurationTl.getEditText().getText().toString().trim();
        String experienceDetails = binding.experienceEtLayout.experienceDetailsTl.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(degreeNameField)) {
            binding.qualificationEtLayout.degreeNameTl.setError("Required field");
            isValid = false;
        } else {
            binding.qualificationEtLayout.degreeNameTl.setError(null);
        }

        if (TextUtils.isEmpty(yearField)) {
            binding.qualificationEtLayout.yearTl.setError("Required field");
            isValid = false;
        } else {
            binding.qualificationEtLayout.yearTl.setError(null);
        }

        if (TextUtils.isEmpty(marksField)) {
            binding.qualificationEtLayout.marksTl.setError("Required field");
            isValid = false;
        } else {
            binding.qualificationEtLayout.marksTl.setError(null);
        }

        if (TextUtils.isEmpty(experienceDuration)) {
            binding.experienceEtLayout.experienceDurationTl.setError("Required field");
            isValid = false;
        } else {
            binding.experienceEtLayout.experienceDurationTl.setError(null);
        }

        if (TextUtils.isEmpty(experienceDetails)) {
            binding.experienceEtLayout.experienceDetailsTl.setError("Required field");
            isValid = false;
        } else {
            binding.experienceEtLayout.experienceDetailsTl.setError(null);
        }

        for (QualificationEditTextLayoutBinding qualificationEditTextLayoutBinding : qualificationLayoutsList) {
            String degreeName = qualificationEditTextLayoutBinding.degreeNameTl.getEditText().getText().toString().trim();
            String year = qualificationEditTextLayoutBinding.yearTl.getEditText().getText().toString().trim();
            String marks = qualificationEditTextLayoutBinding.marksTl.getEditText().getText().toString().trim();
            if (degreeName.isEmpty()) {
                qualificationEditTextLayoutBinding.degreeNameTl.setError("Required field!");
                isValid = false;
            } else {
                qualificationEditTextLayoutBinding.degreeNameTl.setError(null);
            }

            if (year.isEmpty()) {
                qualificationEditTextLayoutBinding.yearTl.setError("Required field!");
                isValid = false;
            } else {
                qualificationEditTextLayoutBinding.yearTl.setError(null);
            }

            if (marks.isEmpty()) {
                qualificationEditTextLayoutBinding.marksTl.setError("Required field!");
                isValid = false;
            } else {
                qualificationEditTextLayoutBinding.marksTl.setError(null);
            }
        }
        for (ExperienceEditTextLayoutBinding experienceEditTextLayoutBinding : experienceLayoutsList) {
            String duration = experienceEditTextLayoutBinding.experienceDurationTl.getEditText().getText().toString().trim();
            String details = experienceEditTextLayoutBinding.experienceDetailsTl.getEditText().getText().toString().trim();
            if (duration.isEmpty()) {
                experienceEditTextLayoutBinding.experienceDurationTl.setError("Required field!");
                isValid = false;
            } else {
                experienceEditTextLayoutBinding.experienceDurationTl.setError(null);
            }

            if (details.isEmpty()) {
                experienceEditTextLayoutBinding.experienceDetailsTl.setError("Required field!");
                isValid = false;
            } else {
                experienceEditTextLayoutBinding.experienceDetailsTl.setError(null);
            }
        }

        if (subjectMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.subjectTl.setError("Please select subjects you teach");
            isValid = false;
        } else {
            binding.subjectTl.setError(null);
        }

        if (gradeMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.classesTl.setError("Please select classes you teach");
            isValid = false;
        } else {
            binding.classesTl.setError(null);
        }

        if (boardMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.boardTl.setError("Please select board/exam you teach");
            isValid = false;
        } else {
            binding.boardTl.setError(null);
        }

        return isValid;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PROFILE_IMAGE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                viewModel.profileImageUri = data.getData();
                binding.profileImg.setImageURI(viewModel.profileImageUri);
            } else if (resultCode == ImagePicker.RESULT_ERROR) {
                Utils.showToast(requireContext(), ImagePicker.getError(data));
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        }
    }
}