package com.jeuxdevelopers.seekooh.ui.shared.activities.course.details;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityCourseDetailsBinding;
import com.jeuxdevelopers.seekooh.models.CourseListing;
import com.jeuxdevelopers.seekooh.models.DayOfWeek;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.dto.CreateCourseReviewRequest;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.CreateCourseReviewDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.tutor.activities.details.TutorDetailsActivity;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.stream.Collectors;

public class CourseDetailsActivity extends AppCompatActivity {

    private ActivityCourseDetailsBinding binding;
    private CourseDetailsViewModel viewModel;
    private ReviewCourseDetailsAdapter reviewCourseDetailsAdapter;
    private WaitingDialog waitingDialog;
    private CreateCourseReviewDialog createCourseReviewDialog;
    private CourseListing data;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCourseDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        viewModel = new ViewModelProvider(this).get(CourseDetailsViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        fetchData();
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(this, this::onBackPressed);
        createCourseReviewDialog = new CreateCourseReviewDialog(this, (title, description, rating) -> {
            if (!UserPrefs.isLoggedIn(this) || UserPrefs.getUser(this) == null) {
                Utils.showToast(this, "Only logged in users can create review!");
                return;
            }
            User user = UserPrefs.getUser(this);

            Role selectedRole = UserPrefs.getSelectedRole(this);

            viewModel.createCoursesReview(data.getId(), new CreateCourseReviewRequest(rating, title, description, selectedRole.getId()));
        });
        String role = UserPrefs.getSelectedRole(this).getName();
        if (!role.contains("ROLE_STUDENT")) {
            binding.joinCourseBtn.setVisibility(View.GONE);
        }
        initClickListeners();
        initRecycler();
    }

    private void initClickListeners() {
        binding.btnBack.setOnClickListener(v -> {
            onBackPressed();
        });
        binding.submitRatingBtn.setOnClickListener(v -> {
//            submitRatingOnly();
            createCourseReviewDialog.show(data);
        });
        binding.addReviewTv.setOnClickListener(v -> {
            createCourseReviewDialog.show(data);
        });
        binding.joinCourseBtn.setOnClickListener(v -> {
            viewModel.courseEnrollment(data.getId());
        });

        binding.tutorNameTopTv.setOnClickListener(v -> {
            Intent intent = new Intent(this, TutorDetailsActivity.class);
            intent.putExtra(Constants.TUTOR_ID, data.getTutorDetails().getId());
            startActivity(intent);
        });
    }

    private void submitRatingOnly() {
        float rating = binding.addRatingBarCourse.getRating();
        if (rating == 0) {
            Utils.showToast(this, "Please choose your rating by using rating bar.");
            return;
        }

        if (!UserPrefs.isLoggedIn(this) || UserPrefs.getUser(this) == null) {
            Utils.showToast(this, "Only logged in users can create review!");
            return;
        }
        User user = UserPrefs.getUser(this);
        Role selectedRole = UserPrefs.getSelectedRole(this);
        viewModel.createCoursesReview(data.getId(), new CreateCourseReviewRequest((double) rating, "", "", selectedRole.getId()));
    }

    private void fetchData() {
        int courseId = getIntent().getIntExtra(Constants.COURSE_ID, -1);
        if (courseId != -1) {
            viewModel.getCourseListingDetails(courseId);
            viewModel.getCourseReviews(courseId);
        } else {
            waitingDialog.showError("Error parsing tutorId!");
        }
    }

    private void initObservers() {
        viewModel.courseListingDetailsLiveData.observe(this, getCourseDetailsResponse -> {
            switch (getCourseDetailsResponse.getStatus()) {
                case ERROR:
                    String errorMsg = getCourseDetailsResponse.getMessage();
                    waitingDialog.showError(errorMsg);
                    Utils.showToast(this, errorMsg);
                    break;
                case LOADING:
                    waitingDialog.show(getCourseDetailsResponse.getMessage());
                    break;
                case SUCCESS:
                    waitingDialog.dismiss();
                    data = getCourseDetailsResponse.getData();
                    setData();
                    break;
            }
        });

        viewModel.courseReviewsLiveData.observe(this, getCourseReviewsResponse -> {
            switch (getCourseReviewsResponse.getStatus()) {
                case ERROR:
                    String errorMsg = getCourseReviewsResponse.getMessage();
                    Utils.showToast(this, errorMsg);
                    break;
                case LOADING:
                    binding.shimmer.setVisibility(View.VISIBLE);
                    break;
                case SUCCESS:
                    binding.shimmer.setVisibility(View.GONE);
                    reviewCourseDetailsAdapter.submitList(getCourseReviewsResponse.getData());
                    break;
            }
        });

        viewModel.createCourseReviewLiveData.observe(this, createCourseReviewResponse -> {
            switch (createCourseReviewResponse.getStatus()) {
                case ERROR:
                    String errorMsg = createCourseReviewResponse.getMessage();
                    waitingDialog.dismiss();
                    Utils.showToast(this, errorMsg);
                    break;
                case LOADING:
                    waitingDialog.show(createCourseReviewResponse.getMessage());
                    break;
                case SUCCESS:
                    binding.addRatingBarCourse.setRating(0);
                    createCourseReviewDialog.dismiss();
                    Utils.showToast(this, createCourseReviewResponse.getMessage());
                    viewModel.getCourseReviews(data.getId());
                    viewModel.getCourseListingDetails(data.getId());
                    waitingDialog.dismiss();
                    break;
            }
        });

        viewModel.enrollmentRequestLiveData.observe(this, enrollmentResponse -> {
            switch (enrollmentResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(this, enrollmentResponse.getMessage());
                    break;
                case LOADING:
                    waitingDialog.show(enrollmentResponse.getMessage());
                    break;
                case SUCCESS:
                    Utils.showToast(this, enrollmentResponse.getMessage());
                    waitingDialog.dismiss();
                    break;
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void setData() {
        if (Utils.isDataNull(this, data)) {
            return;
        }
//        Glide.with(this)
//                .load(data.getTutorDetails().getProfileImageUrl())
//                .placeholder(R.drawable.profile_image_placeholder)
//                .into(binding.profileImg);
        binding.courseTitleTv.setText(data.getTitle());
        binding.tutorNameTopTv.setText(getString(R.string.course_details_tutor_name, data.getTutorDetails().getFullName()));
        binding.courseRatingBarTop.setRating(data.getRating().floatValue());
        binding.courseDescTv.setText(data.getDescription());
        binding.minReqTv.setText(data.getMinRequirements()
                .stream()
                .map(s -> "• " + s + "\n")
                .collect(Collectors.joining()));
//        binding.instructorName.setText(data.getTutorDetails().getFullName());
        binding.ratingBarInstructorSection.setRating(data.getTutorDetails().getRating().floatValue());
        binding.ratingTvTutorScore.setText("(" + data.getTutorDetails().getReviewCount() + " ratings) TutorScore");
        binding.timingsTv.setText(getString(R.string.course_details_timings, Utils.getFormattedTime(data.getStartMinutes()) + " to " + Utils.getFormattedTime(data.getEndMinutes())));
        binding.daysTv.setText(getString(R.string.course_details_days, String.join(", ", Utils.toStringList(data.getDays(), DayOfWeek::getName))));
        binding.startDateTv.setText(getString(R.string.course_details_start_date, Utils.getFormattedDate(data.getStartDate())));
        binding.endDateTv.setText(getString(R.string.course_details_end_date, Utils.getFormattedDate(data.getEndDate())));
        binding.classTypeTv.setText(data.getOnline() ? "Online Lectures" : "" + (data.getInPerson() ? ", In Person" : ""));
        binding.courseRatingTvBottom.setText("" + data.getRating());
        binding.ratingBarCourseRatingBottom.setRating(data.getRating().floatValue());
        binding.courseReviewCountBottom.setText(data.getReviewCount() == 0 ? "No ratings" : "" + data.getReviewCount() + " ratings");
        binding.getRoot().setVisibility(View.VISIBLE);
    }

    private void initRecycler() {
        // Listing Rcv
        reviewCourseDetailsAdapter = new ReviewCourseDetailsAdapter();
        binding.reviewsRcv.setAdapter(reviewCourseDetailsAdapter);
    }
}