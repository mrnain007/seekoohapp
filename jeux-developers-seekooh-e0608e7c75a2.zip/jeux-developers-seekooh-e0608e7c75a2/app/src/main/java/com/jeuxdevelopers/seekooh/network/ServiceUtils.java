package com.jeuxdevelopers.seekooh.network;


import com.google.gson.GsonBuilder;
import com.jeuxdevelopers.seekooh.models.TeachingJob;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.network.deserializers.TuitionStatusDeserializer;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava3.RxJava3CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class ServiceUtils {
//        private static final String SEEKOOH_BASE_URL = "http://35.154.223.94";
    private static final String SEEKOOH_BASE_URL = "https://api.seekooh.com";
//    private static final String SEEKOOH_BASE_URL = "http://seekooh.jeuxtesting.com:443";
//    private static final String SEEKOOH_BASE_URL = "http://192.168.0.104:80";

    public static <T> T createService(Class<T> serviceClass) {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder().connectTimeout(20 * 1000, TimeUnit.MILLISECONDS).writeTimeout(20 * 1000, TimeUnit.MILLISECONDS).readTimeout(20 * 1000, TimeUnit.MILLISECONDS).addInterceptor(interceptor).build();

        Retrofit.Builder builder = new Retrofit.Builder().baseUrl(SEEKOOH_BASE_URL).addConverterFactory(GsonConverterFactory.create());

        Retrofit retrofit = builder.client(client).build();
        return retrofit.create(serviceClass);
    }

    public static <T> T createSeekoohService(Class<T> serviceClass) {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BASIC);
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(20 * 1000, TimeUnit.MILLISECONDS)
                .writeTimeout(20 * 1000, TimeUnit.MILLISECONDS)
                .readTimeout(20 * 1000, TimeUnit.MILLISECONDS)
                .addInterceptor(new AuthInterceptor())
                .addInterceptor(interceptor)
                .build();


        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl(SEEKOOH_BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(new GsonBuilder()
                        .excludeFieldsWithoutExposeAnnotation().create()))
                .addCallAdapterFactory(RxJava3CallAdapterFactory.create());

        return builder
                .client(client)
                .build()
                .create(serviceClass);
    }
}
