package com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tutors.adapters;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.paging.PagingDataAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.ItemListingAdBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemTutorListingBinding;
import com.jeuxdevelopers.seekooh.models.AdModel;
import com.jeuxdevelopers.seekooh.models.Qualification;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TutorListing;
import com.jeuxdevelopers.seekooh.models.TutorProfile;
import com.jeuxdevelopers.seekooh.models.updates.UpdatedAdModel;
import com.jeuxdevelopers.seekooh.utils.Utils;
import com.squareup.picasso.Picasso;

import java.util.List;

public class TutorListingAdapter extends PagingDataAdapter<Object, RecyclerView.ViewHolder> {

    private final Listener listener;
    private static int adPosition = 0;
    private static final DiffUtil.ItemCallback<Object> DIFF_CALLBACK = new DiffUtil.ItemCallback<Object>() {
        @Override
        public boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof TutorListing && newItem instanceof TutorListing) {
                return ((TutorListing) oldItem).getTutorId().equals(((TutorListing) newItem).getTutorId());
            }
            return false;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof TutorListing && newItem instanceof TutorListing) {
                return ((TutorListing) oldItem).equals(((TutorListing) newItem));
            }
            return false;
        }
    };

    public TutorListingAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        int itemCount = getItemCount();

        if (position < getItemCount()) {
            Object object = getItem(position);
            if (object instanceof AdModel) {
                return ViewType.AD_VIEW.ordinal();
            }
            return ViewType.NORMAL_VIEW.ordinal();
        }
        return ViewType.LOADING_VIEW.ordinal();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == ViewType.AD_VIEW.ordinal()) {
            ItemListingAdBinding itemListingAdBinding = ItemListingAdBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new AdViewHolder(itemListingAdBinding);
        }
        ItemTutorListingBinding binding = ItemTutorListingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new TutorListingViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof TutorListingViewHolder) {
            TutorListingViewHolder tutorListingViewHolder = ((TutorListingViewHolder) holder);

            tutorListingViewHolder.bind(getItem(position));
            if (getItem(position) instanceof TutorListing) {
                tutorListingViewHolder.binding.getRoot().setOnClickListener(v -> {
                    listener.onItemClicked(position, (TutorListing) getItem(position));
                });
            }
        } else if (holder instanceof AdViewHolder) {
            AdViewHolder adViewHolder = ((AdViewHolder) holder);
            adViewHolder.bind(getItem(position));
        }
    }

    public static class TutorListingViewHolder extends RecyclerView.ViewHolder {
        private final ItemTutorListingBinding binding;

        public TutorListingViewHolder(ItemTutorListingBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(Object model) {
            if (!(model instanceof TutorListing)) {
                return;
            }
            TutorListing data = (TutorListing) model;
            Glide.with(binding.getRoot()
                            .getContext())
                    .load(data.getProfileImageUrl())
                    .placeholder(R.drawable.profile_image_placeholder)
                    .into(binding.profileImg);
            binding.tutorName.setText(data.getFullName());
            binding.tutorDescription.setText(data.getTagLine());
            Qualification qualification = data.getQualifications().get(0);
            binding.educationTv.setText(qualification.getDegreeCertName() + " in " + qualification.getYear());
            List<Subject> teachesSubjects = data.getTeachesSubjects();
            StringBuilder subjectStr = new StringBuilder();
            teachesSubjects
                    .forEach(subject -> subjectStr.append(subject.getName()).append(" . "));
            binding.tutorSubjects.setText(subjectStr.toString());
            binding.locationTv.setText(data.getCity().getName());
            binding.canTeachOnlineTv.setVisibility(data.getTeachOnline() ? View.VISIBLE : View.GONE);
            binding.verifiedIconImg.setVisibility(data.getVerified() ? View.VISIBLE : View.GONE);
            binding.ratingTv.setText(data.getRating().intValue() + "/5");

            if (data.getOnline() != null && data.getOnline()) {
                binding.lastActiveTv.setText("Active " + Utils.getPrettyTime(System.currentTimeMillis()));
                binding.lastActiveTv.setVisibility(View.VISIBLE);
            } else if (data.getLastSeen() != null) {
                binding.lastActiveTv.setText("Active " + Utils.getPrettyTime(data.getLastSeen()));
                binding.lastActiveTv.setVisibility(View.VISIBLE);
            } else {
                binding.lastActiveTv.setVisibility(View.INVISIBLE);
            }
        }
    }

    public static class AdViewHolder extends RecyclerView.ViewHolder {
        private final ItemListingAdBinding binding;

        public AdViewHolder(ItemListingAdBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Object model) {
            if (model instanceof AdModel) {
                AdModel adModel = (AdModel) model;
                if (adPosition >= App.updatedAdModelList.size()) {
                    adPosition = 0;
                }

                try {
                    UpdatedAdModel updatedAdModel = App.updatedAdModelList.get(adPosition);
                    if (updatedAdModel.getBannerImage() != null) {
                        Glide.with(binding.getRoot().getContext()).load(updatedAdModel.getBannerImage())
                                .dontAnimate().into(binding.getRoot());
                    }
                    if (updatedAdModel.getUrl() != null) {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = updatedAdModel.getUrl();
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    } else {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = "https://www.seekooh.com";
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    }
                } catch (Exception e) {
                    Log.e("Ad Exception", "bind: ", e);
                }
            }
        }
    }

    public interface Listener {
        void onItemClicked(int position, TutorListing tutorListing);
    }

    public enum ViewType {
        LOADING_VIEW, NORMAL_VIEW, AD_VIEW
    }
}
