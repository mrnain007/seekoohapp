package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class InstituteDetails {
    @SerializedName("userId")
    @Expose
    private Integer userId;
    @SerializedName("seekoohId")
    @Expose
    private String seekoohId;
    @SerializedName("nameOfInstitute")
    @Expose
    private String nameOfInstitute;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("instituteId")
    @Expose
    private Integer instituteId;
    @SerializedName("profileImageUrl")
    @Expose
    private String profileImageUrl;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("reviewCount")
    @Expose
    private Integer reviewCount;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("isVerified")
    @Expose
    private Boolean isVerified;
    @SerializedName("isRegistered")
    @Expose
    private Boolean isRegistered;
    @SerializedName("city")
    @Expose
    private City city;
    @SerializedName("instituteType")
    @Expose
    private InstituteType instituteType;
    @SerializedName("teachesSubjects")
    @Expose
    private List<Subject> teachesSubjects;
    @SerializedName("teachesClasses")
    @Expose
    private List<Grade> teachesClasses;
    @SerializedName("teachesBoardExams")
    @Expose
    private List<Board> teachesBoardExams;

    public InstituteDetails() {
    }

    public InstituteDetails(Integer userId, String seekoohId, String nameOfInstitute, String email, String phoneNumber, Integer instituteId, String profileImageUrl, Double rating, Integer reviewCount, String description, Boolean isVerified, Boolean isRegistered, City city, InstituteType instituteType, List<Subject> teachesSubjects, List<Grade> teachesClasses, List<Board> teachesBoardExams) {
        this.userId = userId;
        this.seekoohId = seekoohId;
        this.nameOfInstitute = nameOfInstitute;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.instituteId = instituteId;
        this.profileImageUrl = profileImageUrl;
        this.rating = rating;
        this.reviewCount = reviewCount;
        this.description = description;
        this.isVerified = isVerified;
        this.isRegistered = isRegistered;
        this.city = city;
        this.instituteType = instituteType;
        this.teachesSubjects = teachesSubjects;
        this.teachesClasses = teachesClasses;
        this.teachesBoardExams = teachesBoardExams;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getSeekoohId() {
        return seekoohId;
    }

    public void setSeekoohId(String seekoohId) {
        this.seekoohId = seekoohId;
    }

    public String getNameOfInstitute() {
        return nameOfInstitute;
    }

    public void setNameOfInstitute(String nameOfInstitute) {
        this.nameOfInstitute = nameOfInstitute;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Integer getInstituteId() {
        return instituteId;
    }

    public void setInstituteId(Integer instituteId) {
        this.instituteId = instituteId;
    }

    public String getProfileImageUrl() {
        return profileImageUrl;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Integer getReviewCount() {
        return reviewCount;
    }

    public void setReviewCount(Integer reviewCount) {
        this.reviewCount = reviewCount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getVerified() {
        return isVerified;
    }

    public void setVerified(Boolean verified) {
        isVerified = verified;
    }

    public Boolean getRegistered() {
        return isRegistered;
    }

    public void setRegistered(Boolean registered) {
        isRegistered = registered;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public InstituteType getInstituteType() {
        return instituteType;
    }

    public void setInstituteType(InstituteType instituteType) {
        this.instituteType = instituteType;
    }

    public List<Subject> getTeachesSubjects() {
        return teachesSubjects;
    }

    public void setTeachesSubjects(List<Subject> teachesSubjects) {
        this.teachesSubjects = teachesSubjects;
    }

    public List<Grade> getTeachesClasses() {
        return teachesClasses;
    }

    public void setTeachesClasses(List<Grade> teachesClasses) {
        this.teachesClasses = teachesClasses;
    }

    public List<Board> getTeachesBoardExams() {
        return teachesBoardExams;
    }

    public void setTeachesBoardExams(List<Board> teachesBoardExams) {
        this.teachesBoardExams = teachesBoardExams;
    }
}
