package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.TuitionListing;
import com.jeuxdevelopers.seekooh.models.TutorListing;

public class TuitionApplicationResponse {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("coverLetter")
    @Expose
    private String coverLetter;
    @SerializedName("tutor")
    @Expose
    private TutorListing tutor;
    @SerializedName("tuition")
    @Expose
    private TuitionListing tuition;
    @SerializedName("createdAt")
    @Expose
    private Long createdAt;
    @SerializedName("updatedAt")
    @Expose
    private Long updatedAt;

    public TuitionApplicationResponse() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCoverLetter() {
        return coverLetter;
    }

    public void setCoverLetter(String coverLetter) {
        this.coverLetter = coverLetter;
    }

    public TutorListing getTutor() {
        return tutor;
    }

    public void setTutor(TutorListing tutor) {
        this.tutor = tutor;
    }

    public TuitionListing getTuition() {
        return tuition;
    }

    public void setTuition(TuitionListing tuition) {
        this.tuition = tuition;
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Long updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TuitionApplicationResponse that = (TuitionApplicationResponse) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (coverLetter != null ? !coverLetter.equals(that.coverLetter) : that.coverLetter != null)
            return false;
        if (tutor != null ? !tutor.equals(that.tutor) : that.tutor != null) return false;
        if (tuition != null ? !tuition.equals(that.tuition) : that.tuition != null) return false;
        if (createdAt != null ? !createdAt.equals(that.createdAt) : that.createdAt != null)
            return false;
        return updatedAt != null ? updatedAt.equals(that.updatedAt) : that.updatedAt == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (coverLetter != null ? coverLetter.hashCode() : 0);
        result = 31 * result + (tutor != null ? tutor.hashCode() : 0);
        result = 31 * result + (tuition != null ? tuition.hashCode() : 0);
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        return result;
    }
}
