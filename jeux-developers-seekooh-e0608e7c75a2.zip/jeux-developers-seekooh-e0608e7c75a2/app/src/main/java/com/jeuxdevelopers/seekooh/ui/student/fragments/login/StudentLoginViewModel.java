package com.jeuxdevelopers.seekooh.ui.student.fragments.login;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationRequest;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationResponse;
import com.jeuxdevelopers.seekooh.models.dto.SocialLoginRequest;
import com.jeuxdevelopers.seekooh.repos.auth.AuthRepo;
import com.jeuxdevelopers.seekooh.repos.auth.AuthRepoImpl;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class StudentLoginViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AuthRepo authRepo;

    public MutableLiveData<Resource<AuthenticationResponse>> authenticationLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<AuthenticationResponse>> socialLoginLiveData = new MutableLiveData<>();

    public StudentLoginViewModel() {
        this.authRepo = new AuthRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void loginStudent(@NonNull String email, @NonNull String password) {
        disposables.add(authRepo.authenticate(new AuthenticationRequest(email, password))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(authenticationResponseResource -> {
                    authenticationLiveData.setValue(authenticationResponseResource);
                }, throwable -> {
                    authenticationLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void socialLogin(@NonNull SocialLoginRequest socialLoginRequest) {
        disposables.add(authRepo.socialLogin(socialLoginRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(socialLoginResource -> {
                    socialLoginLiveData.setValue(socialLoginResource);
                }, throwable -> {
                    socialLoginLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
