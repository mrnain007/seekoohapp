package com.jeuxdevelopers.seekooh.ui.tutor.fragments.verification;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.jeuxdevelopers.seekooh.databinding.FragmentTutorVerificationStatusBinding;
import com.jeuxdevelopers.seekooh.models.dto.VerificationStatusResponse;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class TutorVerificationStatusFragment extends Fragment {

    private FragmentTutorVerificationStatusBinding binding;
    private TutorVerificationViewModel viewModel;
    private NavController navController;
    private WaitingDialog waitingDialog;
    private VerificationStatusResponse statusData;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentTutorVerificationStatusBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(TutorVerificationViewModel.class);
        navController = Navigation.findNavController(view);
        initViews();
        initClickListeners();
        initObservers();
        viewModel.getTutorVerificationStatus();
    }

    private void initObservers() {
        viewModel.verificationStatusLiveData
                .observe(getViewLifecycleOwner(), verificationStatusResponse -> {
                    switch (verificationStatusResponse.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), verificationStatusResponse.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(verificationStatusResponse.getMessage());
                            break;
                        case SUCCESS:
                            statusData = verificationStatusResponse.getData();
                            String status = statusData.getStatus();
                            setData(status);
                            waitingDialog.dismiss();
                            break;
                    }
                });
    }

    private void setData(String status) {
        if (status.equals(Constants.UserVerificationStatus.PAYMENT_PENDING.name())) {
            binding.statusTv.setText("Verification fee payment is pending");
        } else if (status.equals(Constants.UserVerificationStatus.UNDER_REVIEW.name())) {
            binding.statusTv.setText("Verification under process");
        } else if (status.equals(Constants.UserVerificationStatus.VERIFICATION_COMPLETE.name())) {
            binding.statusTv.setText("Verification completed");
        } else if (status.equals(Constants.UserVerificationStatus.DOCUMENTS_REQUIRED.name())) {
            binding.statusTv.setText("Verification documents required");
        } else if (status.equals(Constants.UserVerificationStatus.RESUBMISSION_REQUESTED.name())) {
            binding.statusTv.setText("Verification documents resubmission required");
        }
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext());
        initStepView();
    }

    private void initStepView() {
        binding.stepView.setColumnCount(3);
        binding.stepView.setSteps("Payments", "Documents", "Status");
        binding.stepView.setActiveStep(3);
    }

    private void initClickListeners() {
    }
}