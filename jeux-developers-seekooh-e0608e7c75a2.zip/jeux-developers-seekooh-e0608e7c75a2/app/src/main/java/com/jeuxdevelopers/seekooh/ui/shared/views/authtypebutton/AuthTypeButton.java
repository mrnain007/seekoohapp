package com.jeuxdevelopers.seekooh.ui.shared.views.authtypebutton;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.AuthTypeButtonBinding;

public class AuthTypeButton extends FrameLayout {
    private static final String TAG = "AuthTypeButton";
    private AuthTypeButtonBinding binding;

    public AuthTypeButton(Context context) {
        super(context);
        initViews(context);
    }

    public AuthTypeButton(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initViews(context);
        setAttrs(context, attrs);
    }


    public AuthTypeButton(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initViews(context);
    }

    private void initViews(Context context) {
        binding = AuthTypeButtonBinding.inflate(LayoutInflater.from(context), this, true);
        setClickable(true);
        setFocusable(true);
    }

    private void setAttrs(Context context, AttributeSet attrs) {
        TypedArray typedArray = context.getTheme().obtainStyledAttributes(attrs, R.styleable.auth_type_button, 0, 0);

        String primaryText = typedArray.getString(R.styleable.auth_type_button_atb_primary_text);
        String secondaryText = typedArray.getString(R.styleable.auth_type_button_atb_secondary_text);
        int backgroundColor = typedArray.getColor(R.styleable.auth_type_button_atb_background_color, getResources().getColor(R.color.white));
        int iconResourceId = typedArray.getResourceId(R.styleable.auth_type_button_atb_icon, R.drawable.school_icon);
        typedArray.recycle();

        binding.getRoot().setBackgroundTintList(ColorStateList.valueOf(backgroundColor));
        binding.primaryText.setText(primaryText);
        binding.secondaryText.setText(secondaryText);
        binding.iconImage.setImageDrawable(ContextCompat.getDrawable(context, iconResourceId));
    }

    public void setSelectedTab(boolean selectedTab, @Nullable ViewGroup root) {
        binding.getRoot().setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(getContext(), selectedTab ? R.color.water : R.color.white)));

        if (root != null) {
            for (int i = 0; i < root.getChildCount(); i++) {
                View child = root.getChildAt(i);
                // Do something with the child view
                if (child instanceof AuthTypeButton) {
                    AuthTypeButton btn = (AuthTypeButton) child;
                    if (btn.equals(this)) {
                        continue;
                    }

                    btn.setSelectedTab(false, null);
                }
            }
        }
    }
}
