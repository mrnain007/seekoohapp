package com.jeuxdevelopers.seekooh.ui.shared.views.addsuggestion;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.inputmethod.EditorInfo;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.AddSuggestionViewLayoutBinding;

public class AddSuggestionView extends FrameLayout {
    private static final String TAG = "AddSuggestionView";
    private AddSuggestionViewLayoutBinding binding;
    private Listener listener;

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public AddSuggestionView(Context context) {
        super(context);
        initViews(context);
        setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
    }

    public AddSuggestionView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initViews(context);
        setAttrs(context, attrs);
    }

    public AddSuggestionView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initViews(context);
    }

    private void initViews(Context context) {
        binding = AddSuggestionViewLayoutBinding.inflate(LayoutInflater.from(context), this, true);
        setClickable(true);
        setFocusable(true);
        initClickListeners();
    }

    private void initClickListeners() {
        binding.fieldEt.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                // Handle enter key press
                String fieldInput = binding.fieldEt.getText().toString().trim();
                if (!TextUtils.isEmpty(fieldInput)) {
                    if (listener == null) {
                        return true;
                    }
                    listener.onFieldEntered(fieldInput);
                    binding.fieldEt.getText().clear();
                }
                return true;
            }
            return false;
        });
        binding.addSuggestionBtn.setOnClickListener(v -> {
            binding.addSuggestionBtn.setVisibility(GONE);
            binding.fieldGroup.setVisibility(VISIBLE);
        });
        binding.closeBtn.setOnClickListener(v -> {
            binding.fieldGroup.setVisibility(GONE);
            binding.addSuggestionBtn.setVisibility(VISIBLE);
        });
    }

    private void setAttrs(Context context, AttributeSet attrs) {
        TypedArray typedArray = context.getTheme().obtainStyledAttributes(attrs, R.styleable.add_suggestion_view, 0, 0);

        String primaryText = typedArray.getString(R.styleable.add_suggestion_view_asv_primary_text);
        String secondaryText = typedArray.getString(R.styleable.add_suggestion_view_asv_secondary_text);
        String hintText = typedArray.getString(R.styleable.add_suggestion_view_asv_hint_text);
        typedArray.recycle();

        if (!TextUtils.isEmpty(primaryText)) {
            binding.fieldTitleTv.setText(primaryText);
        }
        if (!TextUtils.isEmpty(secondaryText)) {
            binding.fieldDescriptionsTv.setText(secondaryText);
        }
        if (!TextUtils.isEmpty(hintText)) {
            binding.fieldEt.setHint(hintText);
        }
    }

    public interface Listener {
        void onFieldEntered(String fieldValue);
    }
}
