package com.jeuxdevelopers.seekooh.ui.institute.activities.details;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.InstituteDetails;
import com.jeuxdevelopers.seekooh.models.InstituteReview;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.dto.CreateInstituteReviewRequest;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class InstituteDetailsViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<InstituteDetails>> instituteDetailsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<InstituteReview>>> instituteReviewsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<InstituteReview>> createInstituteReviewLiveData = new MutableLiveData<>();

    public InstituteDetailsViewModel() {
        appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getInstituteDetails(@NonNull Integer instituteId) {
        disposables.add(appRepo.getInstituteListingDetails(instituteId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(instituteDetailsResource -> {
                    instituteDetailsLiveData.setValue(instituteDetailsResource);
                }, throwable -> {
                    instituteDetailsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getInstituteReviews(@NonNull Integer instituteId) {
        disposables.add(appRepo.getInstituteReviews(instituteId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getInstituteReviewsResource -> {
                    instituteReviewsLiveData.setValue(getInstituteReviewsResource);
                }, throwable -> {
                    instituteReviewsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void createInstituteReview(@NonNull Integer instituteId, @NonNull CreateInstituteReviewRequest createInstituteReviewRequest) {
        disposables.add(appRepo.createInstituteReview(instituteId, createInstituteReviewRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(createTutorReviewResource -> {
                    createInstituteReviewLiveData.setValue(createTutorReviewResource);
                }, throwable -> {
                    createInstituteReviewLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
