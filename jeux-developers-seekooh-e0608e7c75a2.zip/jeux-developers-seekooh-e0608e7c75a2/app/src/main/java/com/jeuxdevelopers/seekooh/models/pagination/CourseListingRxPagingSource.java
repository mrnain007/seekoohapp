package com.jeuxdevelopers.seekooh.models.pagination;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.paging.PagingState;
import androidx.paging.rxjava3.RxPagingSource;

import com.jeuxdevelopers.seekooh.network.SeekoohService;
import com.jeuxdevelopers.seekooh.network.ServiceUtils;
import com.jeuxdevelopers.seekooh.repos.listing.ListingRepo;
import com.jeuxdevelopers.seekooh.utils.NetworkUtils;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class CourseListingRxPagingSource extends RxPagingSource<Integer, Object> {
    private static final String TAG = "CourseListingRxPagingSo";
    private final ListingRepo listingRepo;
    private final CompositeDisposable disposables;

    private final String search;
    private final Boolean isOnline;
    private final List<Integer> subjectIds;

    public CourseListingRxPagingSource(ListingRepo listingRepo, CompositeDisposable disposables, String search, Boolean isOnline, List<Integer> subjectIds) {
        this.listingRepo = listingRepo;
        this.disposables = disposables;
        this.search = search;
        this.isOnline = isOnline;
        this.subjectIds = subjectIds;
    }

    @NonNull
    @Override
    public Single<LoadResult<Integer, Object>> loadSingle(@NonNull LoadParams<Integer> params) {
        int pageNumber = params.getKey() != null ? params.getKey() : 1;
        int pageSize = params.getLoadSize();
        Log.e(TAG, "loadSingle: pageNumber: " + pageNumber + " pageSize: " + pageSize);

        return ServiceUtils.createSeekoohService(SeekoohService.class)
                .getCourseListings(pageNumber, pageSize, search, isOnline, subjectIds)
                .map(getCourseListingsResponse -> {
                    if (NetworkUtils.isValidResponse(getCourseListingsResponse)) {
                        return getCourseListingsResponse.getData();
                    } else {
                        throw new Exception(getCourseListingsResponse.getMessage("Failed to fetch course list."));
                    }
                }).map(listSeekoohResponse -> {
                    return toLoadResult(listSeekoohResponse
                            .stream()
                            .map(courseListing -> (Object) courseListing)
                            .collect(Collectors.toList()), pageNumber, pageSize);
                }).delay(500, TimeUnit.MILLISECONDS)
                .onErrorReturn(throwable -> {
                    String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch course list.");
                    return new LoadResult.Error<>(new Exception(errorMsg));
                }).subscribeOn(Schedulers.io());
    }

    @Nullable
    @Override
    public Integer getRefreshKey(@NonNull PagingState<Integer, Object> pagingState) {
        return null;
    }

    private LoadResult<Integer, Object> toLoadResult(List<Object> dataList, int pageNumber,
                                                     int pageSize) {
        // Convert the list of data into a LoadResult object
        boolean hasMore = dataList.size() == pageSize;
        Integer nextKey = hasMore ? pageNumber + 1 : null;
        Integer prevKey = pageNumber == 1 ? null : pageNumber - 1;
        return new LoadResult.Page<>(dataList, prevKey, nextKey);
    }
}

