package com.jeuxdevelopers.seekooh.ui.shared.activities.paymob;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MenuItem;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityPaymobWebviewBinding;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;

public class PaymobWebViewActivity extends AppCompatActivity {
    private static final String TAG = "PaymobWebViewActivity";

    private ActivityPaymobWebviewBinding binding;
    private String authenticationUrl;
    private int themeColor;
    private String title;
    private WaitingDialog waitingDialog;
    private Handler handler;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPaymobWebviewBinding.inflate(getLayoutInflater());
        waitingDialog = new WaitingDialog(this);
        setContentView(binding.getRoot());
        handler = new Handler(Looper.getMainLooper());
        this.getThreeDSecureParameters();
        this.linkViews();

        binding.webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress == 100) {
                    waitingDialog.dismiss();
                } else {
                    waitingDialog.show("Processing request");
                }
            }
        });

        binding.webView.setWebViewClient(new WebViewClient() {
            @SuppressLint("LogNotTimber")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Log.d("Accept - NEW URL: ", url);
                if (url.startsWith("https://pakistan.paymob.com/api/acceptance/post_pay")) {
                    Log.d("Accept - SUCCESS_URL", url);
                    Intent intent = new Intent();

                    try {
                        intent.putExtra("raw_pay_response", QueryParamsExtractor.extractQueryParamsAsJson(url));
                        PaymobWebViewActivity.this.setResult(17, intent);
                    } catch (Exception ignored) {
                        Exception ignored1 = ignored;
                    }

                    handler.postDelayed(PaymobWebViewActivity.this::finish, 5000);
                    return true;
                } else {
                    return false;
                }
            }
        });
//        binding.webView.getSettings().setJavaScriptEnabled(true);
        initWebViewSettings();
        binding.webView.loadUrl(this.authenticationUrl);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void initWebViewSettings() {
        binding.webView.getSettings().setJavaScriptEnabled(true);
        binding.webView.getSettings().setDomStorageEnabled(true);
        /*binding.webView.getSettings().setLoadsImagesAutomatically(true);
        binding.webView.getSettings().setAllowContentAccess(true);
        binding.webView.getSettings().setUseWideViewPort(true);
        binding.webView.getSettings().setLoadWithOverviewMode(true);
        binding.webView.clearView();
        binding.webView.setHorizontalScrollBarEnabled(false);
        binding.webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        binding.webView.getSettings().setDatabaseEnabled(true);
        binding.webView.setVerticalScrollBarEnabled(false);
        binding.webView.getSettings().setBuiltInZoomControls(true);
        binding.webView.getSettings().setDisplayZoomControls(false);
        binding.webView.getSettings().setAllowFileAccess(true);
        binding.webView.getSettings().setPluginState(WebSettings.PluginState.OFF);
        binding.webView.setScrollbarFadingEnabled(false);
        binding.webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        binding.webView.getSettings().setDefaultZoom(WebSettings.ZoomDensity.FAR);
        binding.webView.setWebViewClient(new WebViewClient());
        binding.webView.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        binding.webView.setInitialScale(1);*/
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 16908332) {
            this.onCancelPress();
        }

        return super.onOptionsItemSelected(item);
    }

    private void onCancelPress() {
        Intent canceledIntent = new Intent();
        this.setResult(1, canceledIntent);
        this.finish();
    }

    private void resetVariables() {
        this.authenticationUrl = null;
    }

    private void getThreeDSecureParameters() {
        Intent intent = this.getIntent();
        this.authenticationUrl = intent.getStringExtra("three_d_secure_url");
        Log.e(TAG, "getThreeDSecureParameters: " + authenticationUrl);
        this.checkIfPassed("three_d_secure_url", this.authenticationUrl);
        this.themeColor = intent.getIntExtra("theme_color", this.getApplicationContext().getResources().getColor(R.color.white));
    }

    private void linkViews() {
        Intent intent = this.getIntent();
        Window window = this.getWindow();
//        window.addFlags(-2147483648);
//        window.clearFlags(67108864);
        window.setStatusBarColor(this.themeColor);
    }

    private void checkIfPassed(String key, String value) {
        if (value == null) {
            this.abortForNotPassed(key);
        }

    }

    private void abortForNotPassed(String key) {
        Intent errorIntent = new Intent();
        errorIntent.putExtra("missing_argument_value", key);
        this.setResult(2, errorIntent);
        this.finish();
    }
}