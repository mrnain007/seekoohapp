package com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tuitions;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.paging.LoadState;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.FragmentTuitionListingBinding;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationRequest;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.tuitions.PostTuitionActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.ApplyTuitionDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.FilterTuitionDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.FilterTutorsDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tuitions.adapters.TuitionListingAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tuitions.adapters.TuitionListingLoadStateAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tutors.adapters.TutorFiltersAdapter;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.List;
import java.util.stream.Collectors;

public class TuitionListingFragment extends Fragment {

    // Search
    private final Handler handler = new Handler();
    private Runnable delayedAction = null;
    private final int SEARCH_DELAY_MS = 1000;
    private TextWatcher searchTextWatcher;

    private FragmentTuitionListingBinding binding;
    private TuitionListingAdapter tuitionListingAdapter;
    private FilterTuitionDialog filterTuitionDialog;
    private TuitionListingViewModel viewModel;
    private ApplyTuitionDialog applyTuitionDialog;
    private WaitingDialog waitingDialog;

    private List<Board> boardList;
    private List<Grade> gradeList;
    private List<Subject> subjectList;
    private List<City> cityList;
    private User user;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        viewModel = new ViewModelProvider(this).get(TuitionListingViewModel.class);
        binding = FragmentTuitionListingBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews();
        initObservers();
        fetchData();
        initRoleOptions();
        getArgs();
    }

    private void getArgs() {
        MainActivity mainActivity = (MainActivity) requireActivity();
        if (mainActivity.searchTuitionId != null) {
            viewModel.search = String.valueOf(mainActivity.searchTuitionId);
            mainActivity.searchTuitionId = null;
            setSearchText(viewModel.search);
            tuitionListingAdapter.refresh();
        }
    }

    private void initRoleOptions() {
        user = UserPrefs.getUser(requireContext());
        if (user == null) {
            return;
        }

        boolean hasStudentRole = user.getRoles().stream()
                .anyMatch(role -> role.getName().equals(Constants.ROLE_STUDENT));

        if (hasStudentRole) {
            binding.becomeStudentBtn.setVisibility(View.GONE);
            binding.postTuitionBtn.setVisibility(View.VISIBLE);
        } else {
            binding.becomeStudentBtn.setVisibility(View.VISIBLE);
            binding.postTuitionBtn.setVisibility(View.GONE);
        }
    }

    private void initViews() {
        initSearchListener();
        applyTuitionDialog = new ApplyTuitionDialog(requireContext());
        filterTuitionDialog = new FilterTuitionDialog(requireContext(), new FilterTuitionDialog.Listener() {
            @Override
            public void onSearchClicked(Boolean isOnline, Integer selectedGenderId, City selectedCity, List<Subject> subjectList, List<Grade> gradeList, Board selectedBoard) {
                viewModel.isOnline = isOnline;
                viewModel.genderId = selectedGenderId;
                viewModel.cityId = selectedCity == null ? null : selectedCity.getId();
                viewModel.subjectIds.clear();
                viewModel.subjectIds.addAll(Utils.toIdList(subjectList, Subject::getId));
                viewModel.gradeIds.clear();
                viewModel.gradeIds.addAll(Utils.toIdList(gradeList, Grade::getId));
                viewModel.boardExamIds.clear();
                if (selectedBoard != null) {
                    viewModel.boardExamIds.add(selectedBoard.getId());
                }
                tuitionListingAdapter.refresh();
                filterTuitionDialog.dismiss();
            }

            @Override
            public void onResetClicked() {
                setSearchText("");
                viewModel.search = null;
                viewModel.isOnline = null;
                viewModel.genderId = null;
                viewModel.cityId = null;
                viewModel.subjectIds.clear();
                viewModel.gradeIds.clear();
                viewModel.boardExamIds.clear();
                tuitionListingAdapter.refresh();
                filterTuitionDialog.dismiss();
            }
        });
        waitingDialog = new WaitingDialog(requireContext());
        initClickListeners();
        initRecycler();
    }

    private void initSearchListener() {
        searchTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                searchText(s.toString().trim());
            }
        };
        binding.searchEt.addTextChangedListener(searchTextWatcher);
    }

    private void searchText(String newText) {
        if (delayedAction != null) {
            handler.removeCallbacks(delayedAction);
        }

        delayedAction = () -> {
            viewModel.search = newText;
            tuitionListingAdapter.refresh();
        };

        handler.postDelayed(delayedAction, SEARCH_DELAY_MS);
    }

    private void setSearchText(String text) {
        binding.searchEt.removeTextChangedListener(searchTextWatcher);
        binding.searchEt.setText(text);
        binding.searchEt.addTextChangedListener(searchTextWatcher);
    }

    private void initObservers() {
        viewModel.pagingLiveData
                .observe(getViewLifecycleOwner(), postPagingData -> {
                    tuitionListingAdapter.submitData(getLifecycle(), postPagingData);
                });

        viewModel.applyToTuitionLiveData.observe(getViewLifecycleOwner(), applyToTuitionResponse -> {
            switch (applyToTuitionResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), applyToTuitionResponse.getMessage());
                    waitingDialog.dismiss();
                    break;
                case LOADING:
                    waitingDialog.show(applyToTuitionResponse.getMessage());
                    break;
                case SUCCESS:
                    Utils.showToast(requireContext(), applyToTuitionResponse.getMessage());
                    applyTuitionDialog.dismiss();
                    waitingDialog.dismiss();
                    break;
            }
        });

        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    cityList = getCitiesResponse.getData();
                    break;
            }
        });

        viewModel.getSubjectsLiveData.observe(getViewLifecycleOwner(), getSubjectsResponse -> {
            switch (getSubjectsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSubjectsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    subjectList = getSubjectsResponse.getData();
                    break;
            }
        });

        viewModel.getGradesLiveData.observe(getViewLifecycleOwner(), getGradesResponse -> {
            switch (getGradesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getGradesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    gradeList = getGradesResponse.getData();
                    break;
            }
        });

        viewModel.getBoardsLiveData.observe(getViewLifecycleOwner(), getBoardsResponse -> {
            switch (getBoardsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getBoardsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    boardList = getBoardsResponse.getData();
                    break;
            }
        });
    }

    private void fetchData() {
        viewModel.init();
        viewModel.getCities();
        viewModel.getSubjects();
        viewModel.getGrades();
        viewModel.getBoards();
    }

    private void initClickListeners() {
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            tuitionListingAdapter.refresh();
        });
        binding.postTuitionBtn.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), PostTuitionActivity.class));
        });
        binding.filterBtn.setOnClickListener(v -> {
            if (cityList == null || subjectList == null || gradeList == null || boardList == null) {
                return;
            }
            filterTuitionDialog.show(cityList, subjectList, gradeList, boardList);
        });
        binding.becomeStudentBtn.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AuthActivity.class);
            intent.putExtra(Constants.AUTH_ACTIVITY_MODE, AuthActivity.Mode.BECOME_STUDENT.name());
            startActivity(intent);
        });
    }

    private void initRecycler() {
        // Listing Rcv
        tuitionListingAdapter = new TuitionListingAdapter((position, tuitionListing) -> {
            if (!UserPrefs.isTutorProfileVerified(requireContext())) {
                Utils.showToast(requireContext(), "Only verified tutors can apply!");
                return;
            }
            applyTuitionDialog.show(tuitionListing, new ApplyTuitionDialog.Listener() {
                @Override
                public void onPositiveBtnClicked(String coverLetter, Integer tuitionId) {
                    viewModel.applyToTuition(tuitionId, new TuitionApplicationRequest(coverLetter));
                }

                @Override
                public void onNegativeBtnClicked() {
                    applyTuitionDialog.dismiss();
                }
            });
        });

        binding.tuitionListingRcv.setAdapter(tuitionListingAdapter.withLoadStateFooter(
                new TuitionListingLoadStateAdapter(v -> {

                })
        ));

        tuitionListingAdapter.addLoadStateListener(combinedLoadStates -> {
            if (combinedLoadStates.getRefresh() instanceof LoadState.Error) {
                LoadState.Error error = (LoadState.Error) combinedLoadStates.getRefresh();

                Utils.showToast(requireContext(), error.getError().getLocalizedMessage());
                binding.shimmer.setVisibility(View.GONE);
                binding.noContentLayout.getRoot().setVisibility(View.VISIBLE);
                binding.tuitionListingRcv.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.Loading) {
                binding.shimmer.setVisibility(View.VISIBLE);
                binding.noContentLayout.getRoot().setVisibility(View.GONE);
                binding.tuitionListingRcv.setVisibility(View.GONE);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.NotLoading) {
                binding.tuitionListingRcv.setVisibility(View.VISIBLE);
                binding.shimmer.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
                binding.noContentLayout.getRoot().setVisibility(tuitionListingAdapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
            }
            return null;
        });
    }
}