package com.jeuxdevelopers.seekooh.ui.shared.fragments.forgotpassword;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.FragmentForgotPasswordBinding;
import com.jeuxdevelopers.seekooh.models.dto.SendPasswordResetRequest;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.student.fragments.registration.StudentRegistrationFragmentDirections;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class ForgotPasswordFragment extends Fragment {
    private static final String TAG = "ForgotPasswordFragment";
    private boolean isTextWatcherEnabled = false;

    private FragmentForgotPasswordBinding binding;
    private ForgotPasswordViewModel viewModel;
    private WaitingDialog waitingDialog;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentForgotPasswordBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(ForgotPasswordViewModel.class);
        initClickListeners();
        initViews();
        initObservers();
    }

    private void initViews() {
        initTextWatcher();
        waitingDialog = new WaitingDialog(requireContext());
    }

    private void initObservers() {
        viewModel.requestPasswordResetLiveData.observe(getViewLifecycleOwner(), passwordResetResponse -> {
            switch (passwordResetResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), passwordResetResponse.getMessage());
                    break;
                case LOADING:
                    waitingDialog.show(passwordResetResponse.getMessage());
                    break;
                case SUCCESS:
                    waitingDialog.dismiss();
                    binding.sendBtn.setVisibility(View.GONE);
                    binding.emailTl.setVisibility(View.GONE);
                    binding.msgShortTv.setText(passwordResetResponse.getMessage());
                    switch (passwordResetResponse.getData().getVerificationType()) {
                        case EMAIL:
                            binding.msgLongTv.setText(getString(R.string.password_reset_email_success_msg));
                            break;
                        case PHONE:
                            break;
                    }
                    binding.anim.setRepeatCount(0);
                    binding.anim.setAnimation(R.raw.sent);
                    binding.anim.playAnimation();
                    Utils.showToast(requireContext(), passwordResetResponse.getMessage());
                    break;
            }
        });
    }

    private void initTextWatcher() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateInput();
                }
            }
        };

        binding.emailTl.getEditText().addTextChangedListener(textWatcher);
    }

    private void initClickListeners() {
        binding.sendBtn.setOnClickListener(v -> {
            if (validateInput()) {
                String email = binding.emailEt.getText().toString().trim();
                SendPasswordResetRequest passwordResetRequest = SendPasswordResetRequest.builder()
                        .email(email)
                        .verificationType(SendPasswordResetRequest.VerificationType.EMAIL)
                        .build();
                viewModel.requestPasswordReset(passwordResetRequest);
            }
        });
    }

    private boolean validateInput() {
        isTextWatcherEnabled = true;
        boolean isValid = true;

        String email = binding.emailEt.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            binding.emailTl.setError("Please enter your email address associated with your account.");
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.emailTl.setError("Please enter a valid email address.");
            isValid = false;
        } else {
            binding.emailTl.setError(null);
        }

        return isValid;
    }
}