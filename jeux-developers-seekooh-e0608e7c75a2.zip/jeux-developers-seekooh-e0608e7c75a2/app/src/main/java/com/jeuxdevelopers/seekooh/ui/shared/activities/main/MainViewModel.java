package com.jeuxdevelopers.seekooh.ui.shared.activities.main;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationRequest;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TokenRefreshRequest;
import com.jeuxdevelopers.seekooh.models.dto.TokenRefreshResponse;
import com.jeuxdevelopers.seekooh.repos.auth.AuthRepo;
import com.jeuxdevelopers.seekooh.repos.auth.AuthRepoImpl;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class MainViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AuthRepo authRepo;

    public MutableLiveData<Resource<TokenRefreshResponse>> tokenRefreshLiveData = new MutableLiveData<>();

    public MainViewModel() {
        this.authRepo = new AuthRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void tokenRefresh(@NonNull TokenRefreshRequest tokenRefreshRequest) {
        disposables.add(authRepo.tokenRefresh(tokenRefreshRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(tokenRefreshResponseResource -> {
                    tokenRefreshLiveData.setValue(tokenRefreshResponseResource);
                }, throwable -> {
                    tokenRefreshLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
