package com.jeuxdevelopers.seekooh.ui.shared.fragments.notifications.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ItemNotificationBinding;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class NotificationAdapterOld extends ListAdapter<Object, NotificationAdapterOld.NotificationViewHolder> {
    private List<Integer> bgColorList = new ArrayList<>();

    private static final DiffUtil.ItemCallback<Object> DIFF_CALLBACK = new DiffUtil.ItemCallback<Object>() {
        @Override
        public boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
//            return oldItem.getEventId().equals(newItem.getEventId());
            return true;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
//            return oldItem.equals(newItem);
            return true;
        }
    };
    private Listener listener;

    public NotificationAdapterOld(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
        initBgColors();
    }

    private void initBgColors() {
        bgColorList.add(R.color.alice_blue);
        bgColorList.add(R.color.lemon_Chiffon);
        bgColorList.add(R.color.lavender_blush);
    }

    @NonNull
    @Override
    public NotificationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemNotificationBinding binding = ItemNotificationBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new NotificationViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationViewHolder holder, int position) {
        holder.bind(getItem(position));
        holder.binding.getRoot().setOnClickListener(v -> listener.onItemClicked(position));

        Context context = holder.binding.getRoot().getContext();
        holder.binding.getRoot().setCardBackgroundColor(ContextCompat.getColor(context, bgColorList.get(new Random().nextInt(bgColorList.size()))));
    }

    public static class NotificationViewHolder extends RecyclerView.ViewHolder {
        private final ItemNotificationBinding binding;

        public NotificationViewHolder(ItemNotificationBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Object model) {
        }
    }

    public interface Listener {
        void onItemClicked(int position);
    }
}
