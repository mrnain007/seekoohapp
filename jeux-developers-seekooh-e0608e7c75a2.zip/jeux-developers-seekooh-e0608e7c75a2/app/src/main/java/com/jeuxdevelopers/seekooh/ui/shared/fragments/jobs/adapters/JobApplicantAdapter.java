package com.jeuxdevelopers.seekooh.ui.shared.fragments.jobs.adapters;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ItemTutorListingBinding;
import com.jeuxdevelopers.seekooh.models.Qualification;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TutorListing;
import com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationResponse;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.List;

public class JobApplicantAdapter extends ListAdapter<TeachingJobApplicationResponse, JobApplicantAdapter.JobApplicantViewHolder> {
    private static final DiffUtil.ItemCallback<TeachingJobApplicationResponse> DIFF_CALLBACK = new DiffUtil.ItemCallback<com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationResponse>() {
        @Override
        public boolean areItemsTheSame(@NonNull TeachingJobApplicationResponse oldItem, @NonNull TeachingJobApplicationResponse newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull TeachingJobApplicationResponse oldItem, @NonNull TeachingJobApplicationResponse newItem) {
            return oldItem.equals(newItem);
        }
    };

    private Listener listener;

    public JobApplicantAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @NonNull
    @Override
    public JobApplicantViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemTutorListingBinding binding = ItemTutorListingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new JobApplicantViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull JobApplicantViewHolder holder, int position) {
        holder.binding.getRoot().setOnClickListener(v -> {
            listener.onItemClicked(position, (TeachingJobApplicationResponse) getItem(position));
        });
        holder.bind(getItem(position));
    }

    public static class JobApplicantViewHolder extends RecyclerView.ViewHolder {
        private final ItemTutorListingBinding binding;

        public JobApplicantViewHolder(ItemTutorListingBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(TeachingJobApplicationResponse model) {

            TutorListing data = model.getTutor();
            Glide.with(binding.getRoot()
                            .getContext())
                    .load(data.getProfileImageUrl())
                    .placeholder(R.drawable.profile_image_placeholder)
                    .into(binding.profileImg);
            binding.tutorName.setText(data.getFullName());
            binding.tutorDescription.setText(data.getTagLine());
            Qualification qualification = data.getQualifications().get(0);
            binding.educationTv.setText(qualification.getDegreeCertName() + " in " + qualification.getYear());
            List<Subject> teachesSubjects = data.getTeachesSubjects();
            StringBuilder subjectStr = new StringBuilder();
            teachesSubjects
                    .forEach(subject -> subjectStr.append(subject.getName()).append(" . "));
            binding.tutorSubjects.setText(subjectStr.toString());
            binding.locationTv.setText(data.getCity().getName());
            binding.canTeachOnlineTv.setVisibility(data.getTeachOnline() ? View.VISIBLE : View.GONE);
            binding.verifiedIconImg.setVisibility(data.getVerified() ? View.VISIBLE : View.GONE);
            binding.ratingTv.setText(data.getRating().intValue() + "/5");

            if (data.getOnline() != null && data.getOnline()) {
                binding.lastActiveTv.setText("Active " + Utils.getPrettyTime(System.currentTimeMillis()));
                binding.lastActiveTv.setVisibility(View.VISIBLE);
            } else if (data.getLastSeen() != null) {
                binding.lastActiveTv.setText("Active " + Utils.getPrettyTime(data.getLastSeen()));
                binding.lastActiveTv.setVisibility(View.VISIBLE);
            } else {
                binding.lastActiveTv.setVisibility(View.INVISIBLE);
            }
        }
    }

    public interface Listener {
        void onItemClicked(int position, TeachingJobApplicationResponse jobApplicationResponse);
    }
}
