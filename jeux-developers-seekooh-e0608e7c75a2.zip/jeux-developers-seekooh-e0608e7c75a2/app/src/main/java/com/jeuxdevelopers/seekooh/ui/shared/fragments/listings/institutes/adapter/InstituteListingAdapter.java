package com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.institutes.adapter;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.paging.PagingDataAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.ItemInstituteListingBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemListingAdBinding;
import com.jeuxdevelopers.seekooh.models.AdModel;
import com.jeuxdevelopers.seekooh.models.InstituteListing;
import com.jeuxdevelopers.seekooh.models.updates.UpdatedAdModel;

public class InstituteListingAdapter extends PagingDataAdapter<Object, RecyclerView.ViewHolder> {

    private final Listener listener;
    private static int adPosition = 0;
    private static final DiffUtil.ItemCallback<Object> DIFF_CALLBACK = new DiffUtil.ItemCallback<Object>() {
        @Override
        public boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof InstituteListing && newItem instanceof InstituteListing) {
                return ((InstituteListing) oldItem).getInstituteId().equals(((InstituteListing) newItem).getInstituteId());
            }
//            return oldItem.getEventId().equals(newItem.getEventId());
            return false;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof InstituteListing && newItem instanceof InstituteListing) {
                return ((InstituteListing) oldItem).equals(((InstituteListing) newItem));
            }
//            return oldItem.equals(newItem);
            return false;
        }
    };

    public InstituteListingAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        int itemCount = getItemCount();

        if (position < getItemCount()) {
            Object object = getItem(position);
            if (object instanceof AdModel) {
                return ViewType.AD_VIEW.ordinal();
            }
            return ViewType.NORMAL_VIEW.ordinal();
        }
        return ViewType.LOADING_VIEW.ordinal();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == ViewType.AD_VIEW.ordinal()) {
            ItemListingAdBinding itemListingAdBinding = ItemListingAdBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new AdViewHolder(itemListingAdBinding);
        }
        ItemInstituteListingBinding binding = ItemInstituteListingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new InstituteListingViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof InstituteListingViewHolder) {
            InstituteListingViewHolder instituteListingViewHolder = ((InstituteListingViewHolder) holder);

            instituteListingViewHolder.bind(getItem(position));
            if (getItem(position) instanceof InstituteListing) {
                instituteListingViewHolder.binding.getRoot().setOnClickListener(v -> {
                    listener.onItemClicked(position, (InstituteListing) getItem(position));
                });
            }
        } else if (holder instanceof AdViewHolder) {
            AdViewHolder adViewHolder = ((AdViewHolder) holder);
            adViewHolder.bind(getItem(position));
        }
    }

    public static class InstituteListingViewHolder extends RecyclerView.ViewHolder {
        private final ItemInstituteListingBinding binding;

        public InstituteListingViewHolder(ItemInstituteListingBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(Object model) {
            if (!(model instanceof InstituteListing)) {
                return;
            }
            InstituteListing data = (InstituteListing) model;
            Glide.with(binding.getRoot()
                            .getContext())
                    .load(data.getProfileImageUrl())
                    .placeholder(R.drawable.profile_image_placeholder)
                    .into(binding.profileImg);
            binding.instituteName.setText(data.getNameOfInstitute());
            binding.description.setText(data.getDescription() == null ? "" : data.getDescription());
            binding.locationTv.setText(data.getCity().getName());
            binding.instituteTypeTv.setText(data.getInstituteType().getName());
            binding.isRegisteredTv.setVisibility(data.getRegistered() ? View.VISIBLE : View.INVISIBLE);
            binding.verifiedIconImg.setVisibility(data.getVerified() ? View.VISIBLE : View.GONE);
            binding.ratingTv.setText(data.getRating().intValue() + "/5");
        }
    }

    public static class AdViewHolder extends RecyclerView.ViewHolder {
        private final ItemListingAdBinding binding;

        public AdViewHolder(ItemListingAdBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Object model) {
            if (model instanceof AdModel) {
                AdModel adModel = (AdModel) model;
                if (adPosition >= App.updatedAdModelList.size()) {
                    adPosition = 0;
                }
                try {
                    UpdatedAdModel updatedAdModel = App.updatedAdModelList.get(adPosition++);
                    if (updatedAdModel.getBannerImage() != null) {
                        Glide.with(binding.getRoot().getContext()).load(updatedAdModel.getBannerImage()).into(binding.getRoot());
                    }
                    if (updatedAdModel.getUrl() != null) {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = updatedAdModel.getUrl();
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    } else {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = "https://www.seekooh.com";
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    }
                } catch (Exception e) {
                    Log.e("TAG", "bind: ", e);
                }
            }
        }
    }

    public interface Listener {
        void onItemClicked(int position, InstituteListing instituteListing);
    }

    public enum ViewType {
        LOADING_VIEW, NORMAL_VIEW, AD_VIEW
    }
}
