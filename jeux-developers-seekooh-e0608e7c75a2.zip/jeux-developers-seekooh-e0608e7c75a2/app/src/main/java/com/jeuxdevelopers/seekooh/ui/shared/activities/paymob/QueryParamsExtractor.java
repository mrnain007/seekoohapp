package com.jeuxdevelopers.seekooh.ui.shared.activities.paymob;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

public class QueryParamsExtractor {

    /**
     * Extracts query parameters from a given URL and returns them as a Map.
     *
     * @param url the URL to extract query parameters from
     * @return a Map containing the query parameters and their values
     */
    public static Map<String, String> extractQueryParams(String url) {
        Map<String, String> queryParams = new HashMap<>();

        String[] urlParts = url.split("\\?");
        if (urlParts.length > 1) {
            String query = urlParts[1];
            String[] paramPairs = query.split("&");

            try {
                for (String paramPair : paramPairs) {
                    String[] pair = paramPair.split("=");
                    String key = URLDecoder.decode(pair[0], "UTF-8");
                    String value = pair.length > 1 ? URLDecoder.decode(pair[1], "UTF-8") : "";
                    queryParams.put(key, value);
                }
            } catch (UnsupportedEncodingException e) {
                return null;
            }
        }
        return queryParams;
    }

    /**
     * Extracts query parameters from a given URL and returns them as a JSON string.
     *
     * @param url the URL to extract query parameters from
     * @return a JSON string containing the query parameters and their values
     */
    public static String extractQueryParamsAsJson(String url) {
        try {
            JSONObject json = new JSONObject();
            Map<String, String> queryParams = extractQueryParams(url);

            for (String key : queryParams.keySet()) {
                json.put(key, queryParams.get(key));
            }

            return json.toString();
        } catch (JSONException e) {
            return null;
        }
    }
}
