package com.jeuxdevelopers.seekooh.ui.student.fragments.registration;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInStatusCodes;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.FragmentStudentRegistrationBinding;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Gender;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.dto.StudentRegistrationRequest;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.terms.TermsAndPrivacyActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import org.json.JSONException;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import timber.log.Timber;

public class StudentRegistrationFragment extends Fragment {
    private static final String TAG = "StudentRegistrationFrag";
    private static final int RC_SIGN_IN = 1001;
    private final int PROFILE_IMAGE_REQUEST_CODE = 1000;

    private FragmentStudentRegistrationBinding binding;
    private StudentRegistrationViewModel viewModel;
    private NavController navController;
    private Integer selectedGender = 1;
    private Uri profileImageUri;
    private boolean isTextWatcherEnabled = false;
    private WaitingDialog waitingDialog;


    // Drop downs
    private ArrayAdapter<String> boardsArrayAdapter;
    private List<Board> boardsList = new ArrayList<>();
    private Board selectedBoard;

    private ArrayAdapter<String> citiesArrayAdapter;
    private List<City> citiesList = new ArrayList<>();
    private City selectedCity;

    private ArrayAdapter<String> gradesArrayAdapter;
    private List<Grade> gradesList = new ArrayList<>();
    private Grade selectedGrade;

    // Social Auth
    private GoogleSignInOptions googleSignInOptions;
    private GoogleSignInClient googleSignInClient;
    private CallbackManager fbCallbackManager;
    private String facebookId;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentStudentRegistrationBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        initClickListeners();
        initObservers();
        initSocialLogins();
        fetchData();
        checkAuthMode();
    }

    private void checkAuthMode() {
        FragmentActivity fragmentActivity = requireActivity();
        if (fragmentActivity instanceof AuthActivity) {
            AuthActivity authActivity = (AuthActivity) fragmentActivity;
            if (authActivity.mode == AuthActivity.Mode.BECOME_STUDENT) {
                User user = UserPrefs.getUser(requireContext());
                if (user == null || user.getAccessToken() == null) {
                    return;
                }

                if (!TextUtils.isEmpty(user.getFullName())) {
                    binding.nameTl.setEnabled(false);
                    binding.nameTl.getEditText().setText(user.getFullName());
                }
                if (user.getGender() != null) {
                    Gender gender = user.getGender();
                    if (gender.getName().equalsIgnoreCase("male")) {
                        binding.genderRg.check(binding.radioMale.getId());
                    } else {
                        binding.genderRg.check(binding.radioFemale.getId());
                    }
                    binding.radioMale.setEnabled(false);
                    binding.radioFemale.setEnabled(false);
                }
                binding.emailTl.setEnabled(false);
                binding.emailTl.getEditText().setText(user.getEmail());
                binding.passwordTl.setVisibility(View.GONE);
                binding.passwordLabel.setVisibility(View.GONE);
                binding.confirmedPasswordTl.setVisibility(View.GONE);
                binding.confirmPasswordLabel.setVisibility(View.GONE);
                binding.passwordTl.getEditText().setText(user.getEmail());
                binding.confirmedPasswordTl.getEditText().setText(user.getEmail());
                binding.phoneTl.setEnabled(false);
                binding.phoneTl.getEditText().setText(user.getPhoneNumber());
                binding.socialAuthLabelTv.setVisibility(View.GONE);
                binding.socialAuthLl.setVisibility(View.GONE);
                binding.gotoLoginBtn.setVisibility(View.GONE);
                binding.skipBtn.setVisibility(View.GONE);
            }
        }
    }

    private void fetchData() {
        viewModel.getBoards();
        viewModel.getCities();
        viewModel.getGrades();
    }

    private void initSocialLogins() {
        initGoogleLogin();
        initFbLogin();
    }

    private void initFbLogin() {
        disconnectFromFacebook();
        fbCallbackManager = CallbackManager.Factory.create();
        LoginManager.getInstance().registerCallback(fbCallbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                // Get the Access Token
                AccessToken accessToken = loginResult.getAccessToken();
                String token = accessToken.getToken();

                // Get the User ID
                facebookId = accessToken.getUserId();

                // Get the User's Profile
                getFbUserProfile(accessToken);
            }

            @Override
            public void onCancel() {
                // Handle cancel
            }

            @Override
            public void onError(@NonNull FacebookException error) {
                // Handle error
                Log.e(TAG, "initFbLogin onError: " + error.getMessage());
                Utils.showToast(requireContext(), error.getMessage());
            }
        });
    }

    private void getFbUserProfile(AccessToken accessToken) {
        GraphRequest request = GraphRequest.newMeRequest(accessToken, (object, response) -> {
            // Parse the User's Profile information
            if (object != null) {
                try {
                    String name = object.getString("name");
                    String email = object.getString("email");
                    String profilePicUrl = object.getJSONObject("picture").getJSONObject("data").getString("url");

                    binding.nameTl.getEditText().setText(name);
                    binding.emailTl.setEnabled(false);
                    binding.emailTl.getEditText().setText(email);
                    Glide.with(requireContext())
                            .asBitmap()
                            .load(profilePicUrl)
                            .placeholder(R.drawable.profile_image_placeholder)
                            .into(new CustomTarget<Bitmap>() {
                                @Override
                                public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                    profileImageUri = Utils.bitmapToUri(requireContext(), resource);
                                    binding.profileImg.setImageURI(profileImageUri);
                                }

                                @Override
                                public void onLoadCleared(@Nullable Drawable placeholder) {
                                }
                            });

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e(TAG, "onSuccess: Facebook login response null.");
            }
        });

        // Execute the Graph Request
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,email,picture.type(large)");
        request.setParameters(parameters);
        request.executeAsync();
    }

    public void disconnectFromFacebook() {
        if (AccessToken.getCurrentAccessToken() == null) {
            return; // already logged out
        }
        new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/permissions/", null,
                HttpMethod.DELETE, graphResponse -> LoginManager.getInstance().logOut()).executeAsync();
    }

    private void initGoogleLogin() {
        googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()
                .build();
        googleSignInClient = GoogleSignIn.getClient(requireContext(), googleSignInOptions);
        googleSignInClient.signOut();
    }

    private void handleGoogleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            if (account.getPhotoUrl() != null) {
                Glide.with(requireContext())
                        .asBitmap()
                        .load(account.getPhotoUrl())
                        .placeholder(R.drawable.profile_image_placeholder)
                        .into(new CustomTarget<Bitmap>() {
                            @Override
                            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                profileImageUri = Utils.bitmapToUri(requireContext(), resource);
                                binding.profileImg.setImageURI(profileImageUri);
                            }

                            @Override
                            public void onLoadCleared(@Nullable Drawable placeholder) {
                            }
                        });
            }
            if (account.getEmail() != null) {
                binding.emailTl.setEnabled(false);
                binding.emailTl.getEditText().setText(account.getEmail());
            }
            if (account.getDisplayName() != null) {
                binding.nameTl.getEditText().setText(account.getDisplayName());
            }
            facebookId = null;
            Log.e(TAG, "handleGoogleSignInResult: ");
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
            int statusCode = e.getStatusCode();

            switch (statusCode) {
                case GoogleSignInStatusCodes.SIGN_IN_FAILED:
                    Utils.showToast(requireContext(), "Sign-in failed. Please try again later.");
                    break;
                case GoogleSignInStatusCodes.NETWORK_ERROR:
                    Utils.showToast(requireContext(), "Network error. Please check your internet connection and try again.");
                    break;
                default:
                    Utils.showToast(requireContext(), "Sign-in failed. Please try again later. " + statusCode);
                    break;
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PROFILE_IMAGE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                profileImageUri = data.getData();
                binding.profileImg.setImageURI(profileImageUri);
            } else if (resultCode == ImagePicker.RESULT_ERROR) {
                Utils.showToast(requireContext(), ImagePicker.getError(data));
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        } else if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleGoogleSignInResult(task);
        }
    }

    private void setBoardsDropDown() {
        List<String> boardsStringList = new ArrayList<>();
        for (Board board : boardsList) {
            boardsStringList.add(board.getName());
        }
        boardsArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, boardsStringList);
        binding.boardExamAcTv.setAdapter(boardsArrayAdapter);
        binding.boardExamAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedBoard = boardsList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void setCitiesDropDown() {
        List<String> citiesStringList = new ArrayList<>();
        for (City city : citiesList) {
            citiesStringList.add(city.getName());
        }
        citiesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, citiesStringList);
        binding.citiesAcTv.setAdapter(citiesArrayAdapter);
        binding.citiesAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = citiesList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void setGradesDropDown() {
        List<String> gradesStringList = new ArrayList<>();
        for (Grade grade : gradesList) {
            gradesStringList.add(grade.getName());
        }
        gradesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, gradesStringList);
        binding.gradesAcTv.setAdapter(gradesArrayAdapter);
        binding.gradesAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedGrade = gradesList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void initObservers() {
        viewModel.studentRegistrationLiveData.observe(getViewLifecycleOwner(), studentRegistrationResponse -> {
            switch (studentRegistrationResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), studentRegistrationResponse.getMessage());
                    break;
                case LOADING:
                    waitingDialog.show(studentRegistrationResponse.getMessage());
                    break;
                case SUCCESS:
                    waitingDialog.dismiss();
                    navController.navigate(StudentRegistrationFragmentDirections
                            .actionStudentRegistrationFragmentToAuthFragment2());
                    Utils.showToast(requireContext(), studentRegistrationResponse.getMessage());
                    break;
            }
        });

        viewModel.getBoardsLiveData.observe(getViewLifecycleOwner(), getBoardsResponse -> {
            switch (getBoardsResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), getBoardsResponse.getMessage());
                    break;
                case LOADING:
//                    waitingDialog.show(getBoardsResponse.getMessage());
                    break;
                case SUCCESS:
                    waitingDialog.dismiss();
                    boardsList = getBoardsResponse.getData();
                    setBoardsDropDown();
                    break;
            }
        });

        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
//                    waitingDialog.show(getBoardsResponse.getMessage());
                    break;
                case SUCCESS:
                    waitingDialog.dismiss();
                    citiesList = getCitiesResponse.getData();
                    setCitiesDropDown();
                    break;
            }
        });

        viewModel.getGradesLiveData.observe(getViewLifecycleOwner(), getGradesResponse -> {
            switch (getGradesResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), getGradesResponse.getMessage());
                    break;
                case LOADING:
//                    waitingDialog.show(getBoardsResponse.getMessage());
                    break;
                case SUCCESS:
                    waitingDialog.dismiss();
                    gradesList = getGradesResponse.getData();
                    setGradesDropDown();
                    break;
            }
        });
    }

    private void initViews(@NonNull View view) {
        waitingDialog = new WaitingDialog(requireContext());
        navController = Navigation.findNavController(view);
        viewModel = new ViewModelProvider(this).get(StudentRegistrationViewModel.class);
        setSpannableStringOnSignIn();
    }

    private void setSpannableStringOnSignIn() {
        String text = "Already have an account? ";
        String text2 = "Sign In";
        SpannableString spannableString = new SpannableString(text2);
        spannableString.setSpan(new ForegroundColorSpan(Color.RED), 0, text2.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        binding.gotoLoginBtn.setText(TextUtils.concat(text, spannableString));
    }

    private void initClickListeners() {
        initTextWatcher();
        binding.genderRg.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == binding.radioMale.getId()) {
                selectedGender = 1;
            } else if (checkedId == binding.radioFemale.getId()) {
                selectedGender = 2;
            }
        });
        binding.skipBtn.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), MainActivity.class));
        });
        binding.gotoLoginBtn.setOnClickListener(v -> {
            navController.popBackStack();
        });
        binding.pickImgBtn.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(1024).maxResultSize(1920, 1920).crop(1, 1).start(PROFILE_IMAGE_REQUEST_CODE);
        });
        binding.submitBtn.setOnClickListener(v -> {
            if (validateUserInput()) {
                if (profileImageUri == null) {
                    Utils.showToast(requireContext(), "Please pick a profile image.");
                    return;
                }
                String name = binding.nameTl.getEditText().getText().toString().trim();
                String phone = binding.phoneTl.getEditText().getText().toString().trim();
                String email = binding.emailTl.getEditText().getText().toString().trim();
                Integer boardExamId = selectedBoard.getId();
                Integer cityId = selectedCity.getId();
                Integer gradeId = selectedGrade.getId();
                String password = binding.passwordTl.getEditText().getText().toString().trim();

                StudentRegistrationRequest.StudentProfile studentProfile = StudentRegistrationRequest.StudentProfile.builder()
                        .boardExamId(boardExamId)
                        .cityId(cityId)
                        .gradeId(gradeId)
                        .build();
                StudentRegistrationRequest studentRegistrationRequest = StudentRegistrationRequest.builder()
                        .fullName(name)
                        .phoneNumber(phone)
                        .email(email)
                        .password(password)
                        .facebookId(facebookId != null ? facebookId : null)
                        .genderId(selectedGender)
                        .studentProfile(studentProfile)
                        .build();

                viewModel.registerStudent(URI.create(profileImageUri.toString()), studentRegistrationRequest);
            }
        });
        binding.googleBtn.setOnClickListener(v -> {
            Intent signInIntent = googleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, RC_SIGN_IN);
        });
        binding.facebookBtn.setOnClickListener(v -> {
            LoginManager.getInstance().logInWithReadPermissions(this, fbCallbackManager, Arrays.asList("email", "public_profile"));
        });

        // Open Privacy Policy and Terms and Conditions
        binding.tvTermsLink.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), TermsAndPrivacyActivity.class);
            intent.putExtra("type", TermsAndPrivacyActivity.Type.TERMS);
            startActivity(intent);
        });

        binding.tvPrivacyLink.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), TermsAndPrivacyActivity.class);
            intent.putExtra("type", TermsAndPrivacyActivity.Type.PRIVACY);
            startActivity(intent);
        });
    }

    private void initTextWatcher() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateUserInput();
                }
            }
        };

        binding.nameTl.getEditText().addTextChangedListener(textWatcher);
        binding.phoneTl.getEditText().addTextChangedListener(textWatcher);
        binding.emailTl.getEditText().addTextChangedListener(textWatcher);
        binding.passwordTl.getEditText().addTextChangedListener(textWatcher);
        binding.confirmedPasswordTl.getEditText().addTextChangedListener(textWatcher);
    }

    private boolean validateUserInput() {
        isTextWatcherEnabled = true;
        boolean isValid = true;
        String name = binding.nameTl.getEditText().getText().toString().trim();
        String phone = binding.phoneTl.getEditText().getText().toString().trim();
        String email = binding.emailTl.getEditText().getText().toString().trim();
        String password = binding.passwordTl.getEditText().getText().toString().trim();
        String confirmedPassword = binding.confirmedPasswordTl.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            binding.nameTl.setError("Please enter your name?");
            isValid = false;
        } else {
            binding.nameTl.setError(null);
        }

        if (TextUtils.isEmpty(phone)) {
            binding.phoneTl.setError("Please enter your phone number?");
            isValid = false;
        } else if (!Utils.validatePhoneNumber(phone)) {
            binding.phoneTl.setError("Please enter a valid phone number?");
            isValid = false;
        } else {
            binding.phoneTl.setError(null);
        }

        if (TextUtils.isEmpty(email)) {
            binding.emailTl.setError("Please enter your email address?");
            isValid = false;
        } else {
            binding.emailTl.setError(null);
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.emailTl.setError("Please enter a valid email address?");
            isValid = false;
        } else {
            binding.emailTl.setError(null);
        }

        if (selectedBoard == null) {
            binding.boardExamTl.setError("Please select your board/exam?");
            isValid = false;
        } else {
            binding.boardExamTl.setError(null);
        }

        if (selectedCity == null) {
            binding.citiesTl.setError("Please select your city?");
            isValid = false;
        } else {
            binding.citiesTl.setError(null);
        }

        if (selectedGrade == null) {
            binding.gradesTl.setError("Please select your grade?");
            isValid = false;
        } else {
            binding.gradesTl.setError(null);
        }

        if (TextUtils.isEmpty(password)) {
            binding.passwordTl.setError("Please set password for your account");
            isValid = false;
        } else if (password.length() < 8) {
            binding.passwordTl.setError("Password length should be at least 8 character");
            isValid = false;
        } else {
            binding.passwordTl.setError(null);
        }

        if (TextUtils.isEmpty(confirmedPassword)) {
            binding.confirmedPasswordTl.setError("Please confirm your password?");
            isValid = false;
        } else if (!confirmedPassword.equals(password)) {
            binding.confirmedPasswordTl.setError("Password mismatch");
            isValid = false;
        } else {
            binding.confirmedPasswordTl.setError(null);
        }

        return isValid;
    }
}