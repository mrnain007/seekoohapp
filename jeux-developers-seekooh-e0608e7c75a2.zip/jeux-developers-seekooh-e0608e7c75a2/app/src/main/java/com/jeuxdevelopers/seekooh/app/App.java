package com.jeuxdevelopers.seekooh.app;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.firebase.messaging.FirebaseMessaging;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.updates.AdApiResponse;
import com.jeuxdevelopers.seekooh.models.updates.UpdatedAdModel;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.PrefsUtils;
import com.jeuxdevelopers.seekooh.utils.PresenceManager;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;

import java.util.ArrayList;
import java.util.List;

import dagger.hilt.android.HiltAndroidApp;
import io.reactivex.rxjava3.exceptions.Exceptions;
import io.reactivex.rxjava3.exceptions.UndeliverableException;
import io.reactivex.rxjava3.plugins.RxJavaPlugins;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

@HiltAndroidApp
public class App extends Application implements DefaultLifecycleObserver {
    private static final String TAG = "App";
    private static App instance;
    public static List<UpdatedAdModel> updatedAdModelList = new ArrayList<>();

    //    private static List<PresenceManager> presenceManagers = new ArrayList<>();
    private static PresenceManager presenceManager;

    public static App getInstance() {
        return instance;
    }

    public static Context getContext() {
        return instance;
    }

    @Override
    public void onCreate() {
        instance = this;
        super.onCreate();
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        loadUpdatedAds();
        RxJavaPlugins.setErrorHandler(throwable -> {
            if (throwable instanceof UndeliverableException) {
                // handle the exception here
                Log.e(TAG, "onCreate: ", throwable);
                return;
            }
            // rethrow any other type of exception
            throw Exceptions.propagate(throwable);
        });
    }

    interface adServices{

        @GET("api/getAd")
        Call<AdApiResponse> getUpdatedAds();
    }

    private void loadUpdatedAds() {
        Retrofit.Builder builder = new Retrofit.Builder().baseUrl("https://seekoohadmin.jeuxtesting.com")
                .addConverterFactory(GsonConverterFactory.create());
        Retrofit retrofit = builder.build();
        adServices services = retrofit.create(adServices.class);
        Call<AdApiResponse> responseCall = services.getUpdatedAds();
        responseCall.enqueue(new Callback<AdApiResponse>() {
            @Override
            public void onResponse(Call<AdApiResponse> call, Response<AdApiResponse> response) {
                if (response.isSuccessful()) {
                    if (response.body().getStatus().equals("success")) {
                        updatedAdModelList.clear();
                        updatedAdModelList = response.body().getData();
                    }
                }
            }

            @Override
            public void onFailure(Call<AdApiResponse> call, Throwable t) {
                Log.e("Ads Updates",t.getMessage().toString());
            }
        });
    }

    /*public static void initPresence() {
        presenceManagers.forEach(PresenceManager::stop);
        presenceManagers.clear();

        User user = UserPrefs.getUser(getContext());
        if (user == null) {
            return;
        }

        String seekoohId = user.getSeekoohId();

        user.getRoles().forEach(role -> {
            PresenceManager presenceManager = new PresenceManager(Utils.toFirebaseId(seekoohId, role));
            presenceManager.start();
            presenceManagers.add(presenceManager);
        });
    }*/

    public static void syncPresence() {
        User user = UserPrefs.getUser(getContext());
        String fcmToken = PrefsUtils.getString(getContext(), Constants.Firebase.FCM_TOKEN, null);

        if (user == null) {
            if (presenceManager != null) {
                presenceManager.stop(true);
            }
            return;
        }

        if (presenceManager != null) {
            presenceManager.stop(false);
        }

//        String seekoohId = user.getSeekoohId();
        presenceManager = new PresenceManager(user, fcmToken);
        presenceManager.start();
    }

    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onStart(owner);
        syncPresence();
    }
}
