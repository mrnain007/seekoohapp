package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Gender;
import com.jeuxdevelopers.seekooh.models.Grade;

public class AdSettingsResponse {
    @SerializedName("bannerImageUrl")
    @Expose
    private String bannerImageUrl;
    @SerializedName("url")
    @Expose
    private String url;

    public AdSettingsResponse() {
    }

    public AdSettingsResponse(String bannerImageUrl, String url) {
        this.bannerImageUrl = bannerImageUrl;
        this.url = url;
    }

    public String getBannerImageUrl() {
        return bannerImageUrl;
    }

    public void setBannerImageUrl(String bannerImageUrl) {
        this.bannerImageUrl = bannerImageUrl;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AdSettingsResponse that = (AdSettingsResponse) o;

        if (bannerImageUrl != null ? !bannerImageUrl.equals(that.bannerImageUrl) : that.bannerImageUrl != null)
            return false;
        return url != null ? url.equals(that.url) : that.url == null;
    }

    @Override
    public int hashCode() {
        int result = bannerImageUrl != null ? bannerImageUrl.hashCode() : 0;
        result = 31 * result + (url != null ? url.hashCode() : 0);
        return result;
    }
}
