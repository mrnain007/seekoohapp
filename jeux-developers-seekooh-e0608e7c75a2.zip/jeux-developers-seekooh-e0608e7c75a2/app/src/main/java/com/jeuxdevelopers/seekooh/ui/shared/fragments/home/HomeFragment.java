package com.jeuxdevelopers.seekooh.ui.shared.fragments.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.chip.ChipGroup;
import com.jeuxdevelopers.seekooh.databinding.FragmentHomeBinding;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.home.adapters.HomePagerAdapter;

import java.util.List;

public class HomeFragment extends Fragment implements View.OnClickListener {

    private FragmentHomeBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews();
        initClickListeners();
        initViewPager();
        getArgs();
    }

    private void getArgs() {
        MainActivity mainActivity = (MainActivity) requireActivity();
        if (mainActivity.searchTuitionId != null) {
            binding.viewPager.setCurrentItem(1);
        }
    }

    private void initViews() {
        binding.chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            View selectedChip = group.findViewById(checkedIds.get(checkedIds.size() - 1));
            binding.chipsContainerScroll.smoothScrollTo(selectedChip.getLeft(), 0);
        });
    }

    private void initClickListeners() {
        binding.tutorChip.setOnClickListener(this);
        binding.tuitionChip.setOnClickListener(this);
        binding.instituteChip.setOnClickListener(this);
        binding.coursesChip.setOnClickListener(this);
    }

    private void initViewPager() {
        binding.viewPager.setOffscreenPageLimit(3);
        binding.viewPager.setAdapter(new HomePagerAdapter(requireActivity().getSupportFragmentManager(), getLifecycle()));
        binding.viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        binding.tutorChip.setChecked(true);
                        break;
                    case 1:
                        binding.tuitionChip.setChecked(true);
                        break;
                    case 2:
                        binding.instituteChip.setChecked(true);
                        break;
                    case 3:
                        binding.coursesChip.setChecked(true);
                        break;
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == binding.tutorChip.getId()) {
            boolean checked = binding.tutorChip.isChecked();
            binding.viewPager.setCurrentItem(0);
        } else if (v.getId() == binding.tuitionChip.getId()) {
            binding.viewPager.setCurrentItem(1);
        } else if (v.getId() == binding.instituteChip.getId()) {
            binding.viewPager.setCurrentItem(2);
        } else if (v.getId() == binding.coursesChip.getId()) {
            binding.viewPager.setCurrentItem(3);
        }
    }
}