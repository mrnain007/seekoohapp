package com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.SalaryType;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.dto.EditTuitionRequest;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class EditTuitionViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<List<Board>>> getBoardsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<City>>> getCitiesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Grade>>> getGradesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Subject>>> getSubjectsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<SalaryType>>> getSalaryTypesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Tuition>> getTuitionByIdLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Tuition>> editTuitionLiveData = new MutableLiveData<>();

    public EditTuitionViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getBoards() {
        disposables.add(appRepo.getBoards()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getBoardsResponseResource -> {
                    getBoardsLiveData.setValue(getBoardsResponseResource);
                }, throwable -> {
                    getBoardsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getCities() {
        disposables.add(appRepo.getCities()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getCitiesResponseResource -> {
                    getCitiesLiveData.setValue(getCitiesResponseResource);
                }, throwable -> {
                    getCitiesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getGrades() {
        disposables.add(appRepo.getGrades()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getGradesResponseResource -> {
                    getGradesLiveData.setValue(getGradesResponseResource);
                }, throwable -> {
                    getGradesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getSubjects() {
        disposables.add(appRepo.getSubjects()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getSubjectsResponseResource -> {
                    getSubjectsLiveData.setValue(getSubjectsResponseResource);
                }, throwable -> {
                    getSubjectsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getSalaryTypes() {
        disposables.add(appRepo.getSalaryTypes()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getSalaryTypesResource -> {
                    getSalaryTypesLiveData.setValue(getSalaryTypesResource);
                }, throwable -> {
                    getSalaryTypesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getTuitionById(@NonNull Integer tuitionId) {
        disposables.add(appRepo.getTuitionById(tuitionId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getTuitionDetailsResource -> {
                    getTuitionByIdLiveData.setValue(getTuitionDetailsResource);
                }, throwable -> {
                    getTuitionByIdLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void editTuition(@NonNull Integer tuitionId, @NonNull EditTuitionRequest editTuitionRequest) {
        disposables.add(appRepo.editTuition(tuitionId, editTuitionRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(editTuitionResource -> {
                    editTuitionLiveData.setValue(editTuitionResource);
                }, throwable -> {
                    editTuitionLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
