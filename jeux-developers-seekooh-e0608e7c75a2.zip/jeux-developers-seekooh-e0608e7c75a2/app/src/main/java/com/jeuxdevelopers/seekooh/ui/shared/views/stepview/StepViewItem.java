package com.jeuxdevelopers.seekooh.ui.shared.views.stepview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;

import com.jeuxdevelopers.seekooh.R;

public class StepViewItem extends androidx.appcompat.widget.AppCompatButton {
    private static final String TAG = "StepView";

    private float density;
    private int availableSpace;
    private Paint circlePaint;
    private Paint numberTextPaint;
    private Paint nameTextPaint;
    private int stepNumber;
    private String stepName = "Default Step";
    private boolean isActive;

    public StepViewItem(@NonNull Context context, int stepNumber, String stepName) {
        super(context);
        this.stepNumber = stepNumber;
        this.stepName = stepName;
        init(context);
    }

    public StepViewItem(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        setBackground(null);
        density = context.getResources().getDisplayMetrics().density;
        availableSpace = getWidth() - getPaddingLeft() - getPaddingRight();
        circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        numberTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        nameTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        setCircleColor(R.color.quick_silver);

        setNumberTextSize(12);
        setNumberColor(R.color.rich_black);
        setNumberTypeface(R.font.open_sans_semibold);

        setNameTextSize(13);
        setNameColor(R.color.rich_black);
        setNameTypeface(R.font.open_sans_light);
    }

    private void setNumberTypeface(int typeface) {
        Typeface numberTypeface = ResourcesCompat.getFont(getContext(), typeface);
        numberTextPaint.setTypeface(numberTypeface);
    }

    private void setNameTypeface(int typeface) {
        Typeface nameTypeface = ResourcesCompat.getFont(getContext(), typeface);
        nameTextPaint.setTypeface(nameTypeface);
    }

    private void setNumberTextSize(float textSize) {
        numberTextPaint.setTextSize(textSize * density);
    }

    private void setNameTextSize(float textSize) {
        nameTextPaint.setTextSize(textSize * density);
    }

    private void setNumberColor(int color) {
        numberTextPaint.setColor(ContextCompat.getColor(getContext(), color));
    }

    private void setNameColor(int color) {
        nameTextPaint.setColor(ContextCompat.getColor(getContext(), color));
    }

    private void setCircleColor(int color) {
        circlePaint.setColor(ContextCompat.getColor(getContext(), color));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(20 * density, 20 * density, 10 * density, circlePaint);
        canvas.drawText(String.valueOf(stepNumber), 17 * density, 24 * density, numberTextPaint);
        canvas.drawText(stepName, 37 * density, 24 * density, nameTextPaint);
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        if (active) {
            setCircleColor(R.color.crayola);
            setNameTypeface(R.font.open_sans_semibold);
        } else {
            setCircleColor(R.color.quick_silver);
            setNameTypeface(R.font.open_sans_light);
        }
            isActive = active;
        invalidate();
    }

    public void setStep(int stepNumber, String stepName) {
        this.stepNumber = stepNumber;
        this.stepName = stepName;
    }
}
