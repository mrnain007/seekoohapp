package com.jeuxdevelopers.seekooh.models.pagination;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.paging.PagingState;
import androidx.paging.rxjava3.RxPagingSource;

import com.jeuxdevelopers.seekooh.network.SeekoohService;
import com.jeuxdevelopers.seekooh.network.ServiceUtils;
import com.jeuxdevelopers.seekooh.repos.listing.ListingRepo;
import com.jeuxdevelopers.seekooh.utils.NetworkUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class JobListingRxPagingSource extends RxPagingSource<Integer, Object> {
    private static final String TAG = "JobListingRxPagingSourc";
    private final ListingRepo listingRepo;
    private final CompositeDisposable disposables;

    private final String search;
    private final Boolean isOnline;
    private final Boolean isInPerson;
    private final Integer cityId;
    private final List<Integer> subjectIds;
    private final List<Integer> gradeIds;

    public JobListingRxPagingSource(ListingRepo listingRepo, CompositeDisposable disposables, String search, Boolean isOnline, Boolean isInPerson, Integer cityId, List<Integer> subjectIds, List<Integer> gradeIds) {
        this.listingRepo = listingRepo;
        this.disposables = disposables;
        this.search = search;
        this.isOnline = isOnline;
        this.isInPerson = isInPerson;
        this.cityId = cityId;
        this.subjectIds = subjectIds;
        this.gradeIds = gradeIds;
    }

    @NonNull
    @Override
    public Single<LoadResult<Integer, Object>> loadSingle(@NonNull LoadParams<Integer> params) {
        int pageNumber = params.getKey() != null ? params.getKey() : 1;
        int pageSize = params.getLoadSize();
        Log.e(TAG, "loadSingle: pageNumber: " + pageNumber + " pageSize: " + pageSize);

        return ServiceUtils.createSeekoohService(SeekoohService.class)
                .getTeachingJobListings(pageNumber, pageSize, search, isOnline, isInPerson, cityId, subjectIds, gradeIds)
                .map(getJobListingResponse -> {
                    if (NetworkUtils.isValidResponse(getJobListingResponse)) {
                        return getJobListingResponse.getData();
                    } else {
                        throw new Exception(getJobListingResponse.getMessage("Failed to fetch jobs list."));
                    }
                }).map(listSeekoohResponse -> {
                    return toLoadResult(listSeekoohResponse
                            .stream()
                            .map(tuitionListing -> (Object) tuitionListing)
                            .collect(Collectors.toList()), pageNumber, pageSize);
                }).delay(500, TimeUnit.MILLISECONDS)
                .onErrorReturn(throwable -> {
                    String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch jobs list.");
                    return new LoadResult.Error<>(new Exception(errorMsg));
                }).subscribeOn(Schedulers.io());
    }

    @Nullable
    @Override
    public Integer getRefreshKey(@NonNull PagingState<Integer, Object> pagingState) {
        return null;
    }

    private LoadResult<Integer, Object> toLoadResult(List<Object> dataList, int pageNumber,
                                                     int pageSize) {
        // Convert the list of data into a LoadResult object
        boolean hasMore = dataList.size() == pageSize;
        Integer nextKey = hasMore ? pageNumber + 1 : null;
        Integer prevKey = pageNumber == 1 ? null : pageNumber - 1;
        return new LoadResult.Page<>(dataList, prevKey, nextKey);
    }
}

