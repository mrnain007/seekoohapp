package com.jeuxdevelopers.seekooh.repos.chat;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.WriteBatch;
import com.jeuxdevelopers.seekooh.models.Notification;
import com.jeuxdevelopers.seekooh.models.chat.Chat;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;
import com.jeuxdevelopers.seekooh.models.chat.Message;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.Utils;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class ChatRepoImpl implements ChatRepo {

    private final FirebaseFirestore firestore;

    public ChatRepoImpl() {
        firestore = FirebaseFirestore.getInstance();
    }

    @Override
    public Single<String> createPrivateChat(@NonNull FirebaseUser user01, @NonNull FirebaseUser user02) {
        return Single.fromCallable(() -> {
                    DocumentReference chatRef = firestore.collection(Constants.Firebase.CHAT)
                            .document(Utils.combineIdChat(user01.getUserId(), user02.getUserId()));

                    DocumentReference user01Ref = firestore.collection(Constants.Firebase.USERS)
                            .document(user01.getUserId());

                    DocumentReference user02Ref = firestore.collection(Constants.Firebase.USERS)
                            .document(user02.getUserId());

                    Task<String> chatTask = firestore.runTransaction(transaction -> {
                        boolean user01Exist = transaction.get(user01Ref).exists();
                        boolean user02Exist = transaction.get(user02Ref).exists();

                        // If profile not exist create a new one.
                        if (!user01Exist) {
                            user01Ref.set(user01);
                        }

                        // If profile not exist create a new one.
                        if (!user02Exist) {
                            user02Ref.set(user02);
                        }

                        // Create a new chat.
                        Chat chatData = Chat.builder()
                                .id(chatRef.getId())
                                .participantIds(Arrays.asList(user01.getUserId(), user02.getUserId()))
                                .participants(Arrays.asList(user01, user02))
                                .type(Chat.Type.PRIVATE)
                                .build();

                        chatRef.set(chatData);

                        return chatRef.getId();
                    });

                    String chatId = Tasks.await(chatTask);

                    if (!chatTask.isSuccessful()) {
                        throw chatTask.getException();
                    }

                    return chatId;
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }


    @Override
    public Single<Boolean> blockUser(@NonNull List<FirebaseUser> list, String documentId) {
        return Single.fromCallable(() -> {

                    WriteBatch batch = firestore.batch();
                    DocumentReference chatRef = firestore.collection(Constants.Firebase.CHAT)
                            .document(documentId);

                    HashMap<String, Object> hashMap = new HashMap<>();

                    hashMap.put(Constants.PARTICIPANTS, list);

                    batch.update(chatRef, hashMap);

                    Task<Void> task = batch.commit();

                    Tasks.await(task);

                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }

                    return true;
                }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<Boolean> unBlockUser(@NonNull List<FirebaseUser> list, String documentId) {
        return Single.fromCallable(() -> {

                    WriteBatch batch = firestore.batch();
                    DocumentReference chatRef = firestore.collection(Constants.Firebase.CHAT)
                            .document(documentId);

                    HashMap<String, Object> hashMap = new HashMap<>();

                    hashMap.put(Constants.PARTICIPANTS, list);

                    batch.update(chatRef, hashMap);

                    Task<Void> task = batch.commit();

                    Tasks.await(task);

                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }

                    return true;
                }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }
//    @Override
//    public Single<Boolean> blockUser(@NonNull List<FirebaseUser> list, String documentId) {
//        return Single.fromCallable(() -> {
//                    DocumentReference chatRef = firestore.collection(Constants.Firebase.CHAT)
//                            .document(documentId);
//
//                    Task<String> chatTask = firestore.runTransaction(transaction -> {
//
//                        HashMap<String, Object> hashMap = new HashMap<>();
//
//                        hashMap.put(Constants.PARTICIPANTS, list);
//
//                        chatRef.update(hashMap);
//
//                        return chatRef.getId();
//                    });
//
//                    String chatId = Tasks.await(chatTask);
//
//                    if (!chatTask.isSuccessful()) {
//                        throw chatTask.getException();
//                    }
//
//                    return chatId;
//                })
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread());
//    }

    @Override
    public Single<Message> sendMessage(@NonNull Message message) {
        return Single.fromCallable(() -> {
                    WriteBatch batch = firestore.batch();

                    DocumentReference msgRef = firestore.collection(Constants.Firebase.MESSAGES).document(message.getId());
                    DocumentReference chatRef = firestore.collection(Constants.Firebase.CHAT).document(message.getChatId());

                    batch.update(chatRef, Constants.Firebase.LAST_MESSAGE, message.getContent(),
                            Constants.Firebase.LAST_MESSAGE_TYPE, message.getType(),
                            Constants.Firebase.UPDATED_AT, FieldValue.serverTimestamp(),
                            Constants.Firebase.SEEN_BY, Arrays.asList(message.getSenderId()));

                    batch.set(msgRef, message);

                    Task<Void> task = batch.commit();

                    Tasks.await(task);

                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }

                    return message;
                }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public Single<Boolean> markSeen(@NonNull String chatId, @NonNull String currentUserId) {
        return Single.fromCallable(() -> {
                    DocumentReference chatRef = firestore.collection(Constants.Firebase.CHAT).document(chatId);
                    Task<Void> updateTask = chatRef.update(Constants.Firebase.SEEN_BY, FieldValue.arrayUnion(currentUserId));

                    Tasks.await(updateTask);

                    if (!updateTask.isSuccessful()) {
                        throw updateTask.getException();
                    }
                    return true;
                }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public void sendNotification(Context context, Chat chat, Message message) {
        String sender = null;
        List<FirebaseUser> participants = chat.getParticipants();
        for (FirebaseUser user:participants) {
            if (user.getUserId().equals(message.getSenderId())) {
                sender = user.getFullName();
                break;
            }
        }

        for (FirebaseUser user:participants) {
            if (!user.getUserId().equals(message.getSenderId())) {
                String finalSender = sender;
                FirebaseFirestore.getInstance().collection("Users").whereEqualTo("userId", user.getUserId()).get().addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        if (task.getResult() != null) {
                            if (task.getResult().getDocuments().size() > 0) {
                                FirebaseUser firebaseUser = task.getResult().getDocuments().get(0).toObject(FirebaseUser.class);
                                if (firebaseUser != null) {
                                    send(context, finalSender, chat.getId(), message, firebaseUser.getFcm());
                                }
                            }
                        }
                    }
                });

            }
        }
    }

    private void send(Context context, String name, String chatId, Message message, String fcm) {
        JSONObject toSend = new JSONObject();
        JSONObject data = new  JSONObject();

        try {
            data.put("title", name);
            data.put("body", message.getContent());
//            data.put("imageUrl",chat.getParticipants().get(1).getProfileImgUrl().toString());
            data.put("chatId",chatId);
            data.put("type", Notification.Type.UNREAD_MESSAGE);

            toSend.put("to", fcm);
            toSend.put("data", data);

            JsonObjectRequest request = new JsonObjectRequest(
                    Request.Method.POST,
                    Constants.Firebase.NOTIFICATION_URL,
                    toSend,
                    response -> {
                        Log.e("TAG", "sendNotification: " + response.toString());
                    },
                    error -> {
                        Log.e("TAG", "sendNotification: " + error.getMessage());
                    }
            ) {
                @Override
                public HashMap<String, String> getHeaders() {
                    HashMap<String, String> map = new HashMap<>();
                    map.put("Authorization", "key=" + Constants.Firebase.SERVER_KEY);
                    map.put("Content-Type", "application/json");
                    return map;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json";
                }
            };

            RequestQueue queue = Volley.newRequestQueue(context);
            queue.add(request);

        } catch (Exception exception) {
            Log.e("TAG", "sendNotification: " + exception.getMessage());
        }
    }

}
