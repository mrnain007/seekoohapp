package com.jeuxdevelopers.seekooh.utils;

import android.webkit.MimeTypeMap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.jeuxdevelopers.seekooh.models.dto.PaymobResponse;
import com.jeuxdevelopers.seekooh.models.other.SeekoohResponse;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.HttpException;
import retrofit2.Response;

public class NetworkUtils {

    public static Map<String, RequestBody> toRequestBodyMap(Object object) {
        Map<String, RequestBody> requestBodyMap = new HashMap<>();
        Field[] fields = object.getClass().getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);
            try {
                Object fieldValue = field.get(object);
                if (fieldValue != null) {
                    requestBodyMap.put(field.getName(), RequestBody.create(MediaType.parse("text/plain"), fieldValue.toString()));
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return requestBodyMap;
    }

    public static MultipartBody.Part uriToMultipartImage(URI imageUri) {
        File file = new File(imageUri);
        RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpeg"), file);
        return MultipartBody.Part.createFormData("image", file.getName(), requestFile);
    }

    public static MultipartBody.Part uriToMultipartImage(URI imageUri, String fieldName) {
        File file = new File(imageUri);
        RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpeg"), file);
        return MultipartBody.Part.createFormData(fieldName, file.getName(), requestFile);
    }

    public static MultipartBody.Part uriToMultipartVideo(URI videoUri, String fieldName) {
        File file = new File(videoUri);
        RequestBody requestFile = RequestBody.create(MediaType.parse("video/*"), file);
        return MultipartBody.Part.createFormData(fieldName, file.getName(), requestFile);
    }

    public static MultipartBody.Part uriToMultipart(URI uri, String fieldName) {
        File file = new File(uri);
        String fileType = getMimeType(file.getAbsolutePath());
        if (fileType == null) {
            fileType = "application/octet-stream";
        }
        RequestBody requestFile = RequestBody.create(MediaType.parse(fileType), file);
        return MultipartBody.Part.createFormData(fieldName, file.getName(), requestFile);
    }

    @Nullable
    private static String getMimeType(String url) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }

    /*public static String fetchMessageFromResponse(String defaultMsg, Object message) {
        if (message == null) {
            return defaultMsg;
        }

        if (message instanceof JsonObject) {
            JsonObject messageJson = (JsonObject) message;
            Set<Map.Entry<String, JsonElement>> entries = messageJson.entrySet();
            for (Map.Entry<String, JsonElement> entry : entries) {
                String fieldName = entry.getKey();
                JsonElement fieldValue = entry.getValue();
                if (fieldValue.isJsonArray()) {
                    JsonArray fieldArray = fieldValue.getAsJsonArray();
                    JsonElement jsonElement = fieldArray.get(0);
                    return jsonElement.getAsString();
                } else if (fieldValue.isJsonPrimitive()) {
                    JsonPrimitive fieldPrimitive = fieldValue.getAsJsonPrimitive();
                    return fieldPrimitive.getAsString();
                }
            }
        } else if (message instanceof Map) {
            Map<String, Object> messageMap = (Map) message;
            for (Object value : messageMap.values()) {

            }
        }
        else if (message instanceof String) {
            return (String) message;
        }

        return defaultMsg;
    }*/

    public static String fetchMessageFromResponse(String defaultMsg, JsonElement message) {
        if (message == null) {
            return defaultMsg;
        }

        if (message.isJsonObject()) {
            JsonObject messageObject = message.getAsJsonObject();

            for (Map.Entry<String, JsonElement> entry : messageObject.entrySet()) {
                String fieldName = entry.getKey();
                JsonElement errorElement = entry.getValue();
                if (errorElement.isJsonArray()) {
                    return errorElement.getAsJsonArray().get(0).getAsString();
                } else {
                    return errorElement.getAsString();
                }
            }
        } else {
            return message.getAsString();
        }

        return defaultMsg;
    }

    /*public static String fetchMessageFromThrowable(Throwable throwable, String defaultMsg) {
        if (throwable instanceof HttpException) {
            HttpException httpException = (HttpException) throwable;
            Response<?> response = httpException.response();
            ResponseBody errorBody = null;
            if (response != null && response.errorBody() != null) {
                errorBody = response.errorBody();
                Gson gson = new Gson();
                SeekoohResponse seekoohResponse = null;
                try {
                    seekoohResponse = gson.fromJson(errorBody.string(), SeekoohResponse.class);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (seekoohResponse != null) {
                    JsonElement message = seekoohResponse.getMessage();
                    return fetchMessageFromResponse(defaultMsg, message);
                }
            }
        } else if (throwable != null && throwable.getMessage() != null) {
            return throwable.getMessage();
        }
        return defaultMsg;
    }*/

    public static String fetchMessageFromThrowable(Throwable throwable, String defaultMsg) {
        if (throwable instanceof HttpException) {
            HttpException httpException = (HttpException) throwable;
            Response<?> response = httpException.response();
            ResponseBody errorBody = null;
            if (response != null && response.errorBody() != null) {
                errorBody = response.errorBody();
                Gson gson = new Gson();
                SeekoohResponse<?> seekoohResponse = null;
                try {
                    seekoohResponse = gson.fromJson(errorBody.string(), SeekoohResponse.class);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (seekoohResponse != null) {
                    return seekoohResponse.getMessage(defaultMsg);
                }
            }
        } else if (throwable != null && throwable.getMessage() != null) {
            if (throwable.getMessage().contains("Unable to resolve host")) {
                return "Please check your internet connection";
            }
            return throwable.getMessage();
        }
        return defaultMsg;
    }

    public static <T> T parseJson(String json, TypeToken<T> typeToken) {
        return new Gson().fromJson(json, typeToken.getType());
    }

    public static void deserializeNestedJson(Object obj) {
        try {
            Gson gson = new Gson();
            Class<?> clazz = obj.getClass();
            for (Field field : clazz.getDeclaredFields()) {
                field.setAccessible(true);
                String fieldName = field.getName();
                if (fieldName.endsWith("Str")) {
                    // Check if the corresponding field exists without the "Str" suffix
                    String baseFieldName = fieldName.substring(0, fieldName.length() - 3);
                    Field baseField = clazz.getDeclaredField(baseFieldName);
                    baseField.setAccessible(true);
                    // Deserialize the JSON string and set the value of the corresponding field
                    String json = (String) field.get(obj);
                    Object deserializedValue = gson.fromJson(json, baseField.getGenericType());
                    baseField.set(obj, deserializedValue);
                }
            }
        } catch (Exception e) {
            // Handle any exceptions here
            Throwable cause = e.getCause();
        }
    }

    public static boolean isValidResponse(@NonNull SeekoohResponse<?> seekoohResponse) {
        return seekoohResponse.getData() != null;
    }

    public static PaymobResponse rawResponseToPaymob(String rawResponse) {
        Gson gson = new Gson();
        return gson.fromJson(rawResponse, PaymobResponse.class);
    }
}
