package com.jeuxdevelopers.seekooh.ui.institute.activities.details;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.google.android.gms.common.util.CollectionUtils;
import com.google.android.material.chip.Chip;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityInstituteDetailsBinding;
import com.jeuxdevelopers.seekooh.databinding.TutorDetailsSubjectChipBinding;
import com.jeuxdevelopers.seekooh.models.InstituteDetails;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;
import com.jeuxdevelopers.seekooh.models.dto.CreateInstituteReviewRequest;
import com.jeuxdevelopers.seekooh.ui.institute.activities.details.adapters.ReviewInstituteDetailsAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.activities.chat.ChatActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.CreateInstituteReviewDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class InstituteDetailsActivity extends AppCompatActivity {
    private static final String TAG = "InstituteDetailsActivit";

    private ActivityInstituteDetailsBinding binding;
    private ReviewInstituteDetailsAdapter reviewInstituteDetailsAdapter;
    //    private SubjectsInstituteDetailsAdapter subjectsTutorDetailsAdapter;
    private CreateInstituteReviewDialog createInstituteReviewDialog;
    private InstituteDetailsViewModel viewModel;
    private WaitingDialog waitingDialog;
    private InstituteDetails data;
    private User user;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInstituteDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        viewModel = new ViewModelProvider(this).get(InstituteDetailsViewModel.class);
        initData();
        initViews();
        initObservers();
        fetchData();
    }

    private void initData() {
        user = UserPrefs.getUser(this);
    }

    private void fetchData() {
        int instituteId = getIntent().getIntExtra(Constants.INSTITUTE_ID, -1);
        if (instituteId != -1) {
            viewModel.getInstituteDetails(instituteId);
            viewModel.getInstituteReviews(instituteId);
        } else {
            waitingDialog.showError("Error parsing instituteId!");
        }
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(this, this::onBackPressed);
        createInstituteReviewDialog = new CreateInstituteReviewDialog(this, (title, description, rating) -> {
            if (!UserPrefs.isLoggedIn(this) || UserPrefs.getUser(this) == null) {
                Utils.showToast(this, "Only logged in users can create review!");
                return;
            }
            User user = UserPrefs.getUser(this);
            Role selectedRole = UserPrefs.getSelectedRole(this);
            viewModel.createInstituteReview(data.getInstituteId(), new CreateInstituteReviewRequest(rating, title, description, selectedRole.getId()));
        });
        initRecycler();
        initClickListeners();
    }

    private void initObservers() {
        viewModel.instituteDetailsLiveData.observe(this, getInstituteDetailsResponse -> {
            switch (getInstituteDetailsResponse.getStatus()) {
                case ERROR:
                    String errorMsg = getInstituteDetailsResponse.getMessage();
                    waitingDialog.showError(errorMsg);
                    Utils.showToast(this, errorMsg);
                    Log.e(TAG, "initObservers: ERROR ");
                    break;
                case LOADING:
                    Log.e(TAG, "initObservers: LOADING ");
                    waitingDialog.show(getInstituteDetailsResponse.getMessage());
                    break;
                case SUCCESS:
                    Log.e(TAG, "initObservers: SUCCESS ");
                    waitingDialog.dismiss();
                    data = getInstituteDetailsResponse.getData();
                    setData();
                    break;
            }
        });

        viewModel.instituteReviewsLiveData.observe(this, getInstituteReviewsResponse -> {
            switch (getInstituteReviewsResponse.getStatus()) {
                case ERROR:
                    String errorMsg = getInstituteReviewsResponse.getMessage();
                    Utils.showToast(this, errorMsg);
                    break;
                case LOADING:
                    binding.shimmer.setVisibility(View.VISIBLE);
                    break;
                case SUCCESS:
                    binding.shimmer.setVisibility(View.GONE);
                    reviewInstituteDetailsAdapter.submitList(getInstituteReviewsResponse.getData());
                    break;
            }
        });

        viewModel.createInstituteReviewLiveData.observe(this, createInstituteReviewResponse -> {
            switch (createInstituteReviewResponse.getStatus()) {
                case ERROR:
                    String errorMsg = createInstituteReviewResponse.getMessage();
                    waitingDialog.dismiss();
                    Utils.showToast(this, errorMsg);
                    break;
                case LOADING:
                    waitingDialog.show(createInstituteReviewResponse.getMessage());
                    break;
                case SUCCESS:
                    createInstituteReviewDialog.dismiss();
                    Utils.showToast(this, createInstituteReviewResponse.getMessage());
                    viewModel.getInstituteReviews(data.getInstituteId());
                    viewModel.getInstituteDetails(data.getInstituteId());
                    waitingDialog.dismiss();
                    break;
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void setData() {
        Glide.with(this)
                .load(data.getProfileImageUrl())
                .placeholder(R.drawable.profile_image_placeholder)
                .into(binding.profileImg);
        binding.verifiedBtn.setVisibility(data.getVerified() ? View.VISIBLE : View.GONE);
        binding.instituteName.setText(data.getNameOfInstitute());
        binding.seekoohIdTl.getEditText().setText(data.getSeekoohId());
        binding.typeTl.getEditText().setText(data.getInstituteType().getName());
        binding.locationTl.getEditText().setText(data.getCity().getName());
        binding.ratingTv.setText(data.getRating().intValue() + "/5");

        if (!CollectionUtils.isEmpty(data.getTeachesSubjects())) {
            binding.subjectsChipGroup.removeAllViews();
            data.getTeachesSubjects()
                    .forEach(subject -> {
                        Chip chip = TutorDetailsSubjectChipBinding.inflate(LayoutInflater.from(this)).getRoot();
                        chip.setText(subject.getName());
                        binding.subjectsChipGroup.addView(chip);
                    });
            binding.subjectsIndTv.setVisibility(View.VISIBLE);
            binding.subjectsChipGroup.setVisibility(View.VISIBLE);
        } else {
            binding.subjectsIndTv.setVisibility(View.GONE);
            binding.subjectsChipGroup.setVisibility(View.GONE);
        }

        if (!CollectionUtils.isEmpty(data.getTeachesBoardExams())) {
            binding.boardExamChipGroup.removeAllViews();
            data.getTeachesBoardExams()
                    .forEach(boardExam -> {
                        Chip chip = TutorDetailsSubjectChipBinding.inflate(LayoutInflater.from(this)).getRoot();
                        chip.setText(boardExam.getName());
                        binding.boardExamChipGroup.addView(chip);
                    });
            binding.boardExamIndTv.setVisibility(View.VISIBLE);
            binding.boardExamChipGroup.setVisibility(View.VISIBLE);
        } else {
            binding.boardExamIndTv.setVisibility(View.GONE);
            binding.boardExamChipGroup.setVisibility(View.GONE);
        }

        if (!CollectionUtils.isEmpty(data.getTeachesClasses())) {
            StringBuilder strBuilder = new StringBuilder();
            binding.classesTv.setText("");
            data.getTeachesClasses()
                    .forEach(grade -> {
                        strBuilder.append(grade.getName()).append(" . ");
                    });
            binding.classesTv.setText(strBuilder.toString());
            binding.classesLl.setVisibility(View.VISIBLE);
        } else {
            binding.classesLl.setVisibility(View.GONE);
        }

//        binding.verifiedGroup.setVisibility(data.getVerified() ? View.VISIBLE : View.GONE);
        binding.ratingDetailsTv.setText(data.getRating() + " out of 5 based on " + data.getReviewCount() + " ratings");
        binding.ratingBar.setRating(data.getRating().floatValue());

        if (!TextUtils.isEmpty(data.getDescription())) {
            binding.longDescriptionTv.setText(data.getDescription());
            binding.descriptionLayout.setVisibility(View.VISIBLE);
        } else {
            binding.descriptionLayout.setVisibility(View.GONE);
        }

        binding.nestedScroll.setVisibility(View.VISIBLE);
    }

    private void initClickListeners() {
        binding.submitReviewBtn.setOnClickListener(v -> {
            createInstituteReviewDialog.show(data);
        });
        binding.btnBack.setOnClickListener(v -> onBackPressed());
        binding.viewContactBtn.setOnClickListener(v -> {
            if (Utils.isDataNull(this, data, data.getPhoneNumber())) {
                return;
            }
            Intent dialIntent = new Intent(Intent.ACTION_DIAL);
            dialIntent.setData(Uri.parse("tel:" + data.getPhoneNumber()));
            startActivity(dialIntent);
        });
        binding.sendMsgBtn.setOnClickListener(v -> {
            if (user == null) {
                Utils.showToast(this, "Only logged in users can send messages!");
                return;
            }

            String userId = Utils.toFirebaseId(data.getSeekoohId(), Role.builder().name(Constants.ROLE_INSTITUTE).build());

            if (Utils.toFirebaseId(user.getSeekoohId(), user.getAppSettings().getSelectedRole()).equals(userId)) {
                Utils.showToast(this, "Cannot send message to your own profile!");
                return;
            }

            // TODO : Fetch user from firebase
            FirebaseFirestore firestore = FirebaseFirestore.getInstance();
            firestore.collection("Users").whereEqualTo("userId",userId).get().addOnSuccessListener(queryDocumentSnapshots -> {
                if (queryDocumentSnapshots.isEmpty()) {
                    Utils.showToast(this, "User not found!");
                    return;
                }
                FirebaseUser firebaseUser = queryDocumentSnapshots.toObjects(FirebaseUser.class).get(0);
                Intent intent = new Intent(this, ChatActivity.class);
                intent.putExtra(Constants.Firebase.FIREBASE_USER, new Gson().toJson(firebaseUser));
                startActivity(intent);
            }).addOnFailureListener(e -> {
                Utils.showToast(this, "Failed to fetch user!");
            });

//            FirebaseUser firebaseUser = FirebaseUser.builder()
//                    .userId(userId)
//                    .profileImgUrl(data.getProfileImageUrl())
//                    .fullName(data.getNameOfInstitute())
//                    .build();
//
//            Intent intent = new Intent(this, ChatActivity.class);
//            intent.putExtra(Constants.Firebase.FIREBASE_USER, new Gson().toJson(firebaseUser));
//            startActivity(intent);
        });
    }

    private void initRecycler() {
        // Listing Rcv
        reviewInstituteDetailsAdapter = new ReviewInstituteDetailsAdapter();
        binding.reviewsRcv.setAdapter(reviewInstituteDetailsAdapter);
    }
}