package com.jeuxdevelopers.seekooh.repos.chat;

import android.content.Context;

import androidx.annotation.NonNull;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.chat.Chat;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;
import com.jeuxdevelopers.seekooh.models.chat.Message;

import java.util.List;
import java.util.Optional;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.Single;

public interface ChatRepo {

    Single<String> createPrivateChat(@NonNull FirebaseUser user01, @NonNull FirebaseUser user02);

    Single<Boolean> blockUser(@NonNull List<FirebaseUser> list, String documentId);
    Single<Boolean> unBlockUser(@NonNull List<FirebaseUser> list, String documentId);

    Single<Message> sendMessage(@NonNull Message message);

    Single<Boolean> markSeen(@NonNull String chatId, @NonNull String currentUserId);

    void sendNotification(Context context, Chat chat, Message data);
}
