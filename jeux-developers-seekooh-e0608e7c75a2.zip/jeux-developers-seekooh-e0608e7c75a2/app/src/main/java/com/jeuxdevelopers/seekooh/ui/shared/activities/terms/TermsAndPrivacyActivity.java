package com.jeuxdevelopers.seekooh.ui.shared.activities.terms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Html;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ActivityTermsAndPrivacyBinding;

public class TermsAndPrivacyActivity extends AppCompatActivity {
    ActivityTermsAndPrivacyBinding binding;
    String privacy = "<h1>Privacy Policy</h1>\n" +
            "    <p><strong>Clauses of a Privacy Policy:</strong></p>\n" +
            "    <p><strong>Privacy Statement:</strong> We are seekooh.com, the data controller. You can contact our Data Protection Officer (DPO) at info@seekooh.com if you have any questions. This is our Privacy Statement which explains how we obtain, use, and keep your personal data safe in relation to the Seekooh app. Your personal data is data which by itself or with other data available to us can be used to identify you. We are committed to keeping your personal information safe in accordance with applicable laws. Kindly note that the Privacy Policy should read in addition to the Disclaimer and Terms and Conditions for User of www.seekooh.com website.</p>\n" +
            "    \n" +
            "    <p><strong>The types of personal data we collect and use:</strong></p>\n" +
            "    <p>The types of personal data we capture and use will depend on what you are doing on the App. We will use your personal data for some or all of the reasons set out in the Privacy Statement. If you become a member, we will also use it to manage the account, policy or service you have applied for and in relation to that information and it may make publicly available.</p>\n" +
            "    <p>Seekooh may access and use the data as necessary:\n" +
            "    <ul>\n" +
            "        <li>To provide and maintain the services;</li>\n" +
            "        <li>To address and respond to service, security, and customer support issues;</li>\n" +
            "        <li>To detect, prevent or otherwise address fraud, security, illegal or technical issues;</li>\n" +
            "        <li>As required by law;</li>\n" +
            "        <li>To fulfill our contracts;</li>\n" +
            "        <li>To improve and enhance the services;</li>\n" +
            "        <li>To provide analysis or valuable information back to our members.</li>\n" +
            "    </ul>\n" +
            "    For instance, we use your account information:\n" +
            "    <ul>\n" +
            "        <li>Create and administer your account</li>\n" +
            "        <li>Facilitate and improve the usage of the services</li>\n" +
            "        <li>Assess your needs to determine suitable services</li>\n" +
            "        <li>Send you updates, marketing communication and service information.</li>\n" +
            "        <li>Respond to inquiries and support requests</li>\n" +
            "        <li>Conduct research and analysis</li>\n" +
            "        <li>Display content based upon your interests</li>\n" +
            "        <li>Analyze data, including through automated systems and machine learning to improve our services and/or for your experience</li>\n" +
            "        <li>Provide you information about your use of the services and benchmarks, insights, and suggestions for improvements.</li>\n" +
            "    </ul></p>\n" +
            "\n" +
            "    <p><strong>Third Party Disclosure:</strong> Information about our members is an important part of our Services and the personal information you provide to other members who are also subject to this Privacy Notice or follow practices at least as protective as described in this Privacy Notice. Transactions involving Third Parties: We make available to you services or skills provided by third parties for use on or through Seekooh services. We also provide you a platform to show your skills and services.</p>\n" +
            "\n" +
            "    <p><strong>Information Protection:</strong> Information that you share on the App or Website is kept strictly confidential and fully secure. Your encrypted (encoded) information is protected using \"Secure Socket Layers (SSL)\" as it passes between your browser and this App & website. We follow generally accepted industry standards to protect the personal information submitted to us, both during transmission and once we receive it. No method of transmission over the Internet, or method of electronic storage, is 100% secure, however. Therefore, while we strive to use commercially acceptable means to protect your personal information, we cannot guarantee its absolute security. Only authorized persons are permitted to access your personal information. All authorized persons must abide by security, privacy, and confidentiality agreements, rules, and laws.</p>\n" +
            "\n" +
            "    <p><strong>Rights of Users:</strong> If you wish to exercise your individual rights in respect of your personal data please contact our support team at support@seekooh.com. You have the following rights:\n" +
            "    <ul>\n" +
            "        <li><strong>Your legal rights:</strong></li>\n" +
            "        <li><strong>Right to be informed:</strong> If you wish to exercise your individual right in respect of your personal information where we collect your personal data from you (e.g., when you open an account or apply for a service online) and also through privacy notices such as this one.</li>\n" +
            "        <li><strong>Rights of access:</strong> You have the right to access your personal data and details of how we process it. Kindly note that proof of identification is required in order to protect your information.</li>\n" +
            "        <li><strong>Right to rectification:</strong> You have the right to have your personal data rectified if it is inaccurate or incomplete. Seekooh.com will ensure that personal data is kept accurate and up to date as far as is reasonably possible. However, Seekooh.com relies on members to ensure that the information it holds about them is accurate and up-to-date. We encourage members to inform Seekooh.com of any changes to their information (e.g., by updating your account details and information on Seekooh.com App or website).</li>\n" +
            "    </ul></p>\n" +
            "\n" +
            "    <p><strong>Cookies:</strong> Cookies are small text files placed on your computer, smartphone, or other devices and are commonly used on the internet. We use cookies to provide our Services to you and for your interests.</p>\n" +
            "\n" +
            "    <p><strong>Notification of Changes:</strong> We will keep our privacy notice under regular review and place any updates on this web page. This privacy notice was last updated on 13th July 2023.</p>\n" +
            "\n" +
            "    <p><strong>Contact Information:</strong> Find out more and contact us about your rights. For any questions or comments about this policy, speak to our support team by email at support@seekooh.com. You can contact us for advice and support. Customize your online application journey. Some of the information relevant to that is included in this Privacy Statement for consistency. For instance, the personal data we may use in relation to our App or website may include:\n" +
            "    <ul>\n" +
            "        <li>Full name and personal details including contact information (e.g., Home address and address history, email address, home and mobile telephone numbers);</li>\n" +
            "        <li>Date of birth and/or education qualifications (to make sure you are eligible to apply for the service);</li>\n" +
            "        <li>Financial details (e.g., expected salary and details and details of accounts held with other service providers or do you have your own website (URL to be provided)).</li>\n" +
            "    </ul>\n" +
            "    </p>\n" +
            "\n" +
            "    <p><strong>The Information you provide to us-</strong></p>\n" +
            "    <p><strong>Registration:</strong> To create an account, you need to provide data including your name, email address, and/or mobile number and a password. If you register for a Service, you will need to provide payment (e.g., credit card, EasyPaisa, JazzCash, and billing information.)</p>\n" +
            "    <p><strong>Profile:</strong> You have choices about the information on your profile, such as education, work, experience, skills, photo, and city. You don't have to provide additional information on your profile information; however, profile information helps you get more from our Services, including helping members search you. It's your decision to disclose any.</p>";

    String terms = "<h1>Terms & Conditions / Copyright Policy</h1>\n" +
            "    <p><strong>Last updated:</strong> July 13, 2023</p>\n" +
            "    <p>Please read these <strong>Terms and Conditions</strong> (\"Terms\") carefully before using the App or www.seekooh.com website and the SEEKOOH mobile application (together, or individually, the \"Service\") operated by SEEKOOH (\"us\", \"we\", or \"our\").</p>\n" +
            "    <p>Your access to and use of the Service is conditioned upon your acceptance of and compliance with these Terms. These Terms apply to all visitors, users, and others who wish to access or use the Service. By accessing or using the Service, you agree to be bound by these Terms. If you disagree with any part of the terms then you do not have permission to access the Service.</p>\n" +
            "    \n" +
            "    <p><strong>Communications</strong></p>\n" +
            "    <p>By creating an Account on our service, you agree to subscribe to newsletters, marketing, or promotional materials and other information we may send. However, you may opt out of receiving any, or all, of these communications from us by following the unsubscribe link or instructions provided in any email we send.</p>\n" +
            "    \n" +
            "    <p><strong>Subscriptions</strong></p>\n" +
            "    <p>Some parts of the Service are billed on a subscription basis (\"Subscriptions\"). You will be billed in advance on a recurring and periodic basis (\"Billing Cycle\"). Billing cycles are set either on a monthly or annual basis, depending on the type of subscription plan you select when purchasing a Subscription. At the end of each Billing Cycle, your Subscription will automatically renew under the exact same conditions unless you cancel it or SEEKOOH cancels it. You may cancel your Subscription renewal either through your online account management page or by contacting SEEKOOH customer support team. A valid payment method, including credit/debit card or EasyPaisa/JazzCash, is required to process the payment for your Subscription. You shall provide SEEKOOH with accurate and complete billing information including full name, address, state, zip code, telephone number, and a valid payment method information. By submitting such payment information, you automatically authorize SEEKOOH to charge all Subscription fees incurred through your account to any such payment instruments. Should automatic billing fail to occur for any reason, SEEKOOH will issue an electronic invoice indicating that you must proceed manually, within a certain deadline date, with the full payment corresponding to the billing period as indicated on the invoice.</p>\n" +
            "    \n" +
            "    <p><strong>Subscribers Terms & Conditions</strong></p>\n" +
            "    <ul>\n" +
            "        <li>Any Subscription will be valid for the period of 1 year from the date of the payment received. The same shall get terminated automatically on completion of the 1 year period.</li>\n" +
            "        <li>Subscription will go active and live within 48 hours of payment being received.</li>\n" +
            "        <li>Company acts as a platform for job posting to subscribers as per the plan chosen by them during subscription of the service. Company shall provide data & services to the subscribers based on their plans, on which subscribers can act at their own will and discretion, the company does not have any say in making hiring decision by the subscriber and the employee. The company shall not be made responsible or liable for any commitments or agreements not adhered between the subscriber and the employee.</li>\n" +
            "        <li>In the event of an employee being hired by the subscriber, the company shall not be made responsible or liable for any commercial transaction between the subscriber and job post employee.</li>\n" +
            "        <li>If any subscriber is found misusing the company's data made available to them on subscription for use other than their own hiring purpose, the subscriber will be made responsible and will have to face legal implications for the same.</li>\n" +
            "        <li>The Subscriber is prohibited from copying, sharing, selling or distributing the data provided to them on subscription. They will be held liable and responsible and will have to face legal implications or account blockage.</li>\n" +
            "        <li>The Subscriber will be limited to have limited posts live at the same time.</li>\n" +
            "        <li>The company does not guarantee any kind of candidate application on job posts in terms of quality, quantity and its commerciality. The company does not mention or is liable to fulfill any job post in a given time frame.</li>\n" +
            "        <li>Any Employee active on the platform will apply on the post and it is not the company's responsibility regarding the application and its relevance to the subscriber.</li>\n" +
            "        <li>The company does not have any refund policy. Once the payment is received and subscription goes active and live the same shall not be refunded under any circumstances.</li>\n" +
            "    </ul>\n" +
            "    \n" +
            "    <p><strong>Copyright Policy</strong></p>\n" +
            "    <p>We respect the intellectual property rights of others. It is our policy to respond to any claim that Content posted on the Service infringes on the copyright or other intellectual property rights (\"Infringement\") of any person or entity. If you are a copyright owner, or authorized on behalf of one, and you believe that the copyrighted work has been copied in a way that constitutes copyright infringement, please submit your claim via email to info@seekooh.com, with the subject line: \"Copyright Infringement\" and include in your claim a detailed description of the alleged Infringement as detailed below, under \"DMCA Notice and Procedure for Copyright Infringement Claims\" You may be held accountable for damages (including costs and attorneys' fees) for misrepresentation or bad-faith claims on the infringement of any Content found on and/or through the Service on your copyright.</p>";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTermsAndPrivacyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        if (getIntent().getExtras() != null) {
            Type type = (Type) getIntent().getExtras().getSerializable("type");
            if (type == Type.PRIVACY) {
                binding.tvTitle.setText("Privacy Policy");
                binding.tvContent.setText(Html.fromHtml(privacy));
            } else {
                binding.tvTitle.setText("Terms & Conditions");
                binding.tvContent.setText(Html.fromHtml(terms));
            }
        }
    }

    public enum Type {
        PRIVACY, TERMS

    }
}