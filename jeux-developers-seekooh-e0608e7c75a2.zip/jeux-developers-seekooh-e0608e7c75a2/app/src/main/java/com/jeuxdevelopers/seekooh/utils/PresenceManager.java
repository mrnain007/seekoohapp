package com.jeuxdevelopers.seekooh.utils;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.jeuxdevelopers.seekooh.models.PresenceModel;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;

public class PresenceManager {
    private DatabaseReference userRef;
    private DocumentReference documentReference;
    private ValueEventListener mConnectedListener;
    private final String fcmToken;
    User user;

    public PresenceManager(User user, String fcmToken) {
        // Get a reference to the user node in the database
        userRef = FirebaseDatabase.getInstance().getReference("users/" + user.getSeekoohId());
        String userId = Utils.toFirebaseId(user.getSeekoohId(), user.getRoles().get(0));
        documentReference = FirebaseFirestore.getInstance().collection("Users").document(userId);
        this.fcmToken = fcmToken;
        this.user = user;
    }

    public void start() {
        // Add a listener to the user's connection state
        mConnectedListener = FirebaseDatabase.getInstance().getReference(".info/connected").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Boolean connected = snapshot.getValue(Boolean.class);
                if (connected == null) {
                    return;
                }
                if (connected) {
                    userRef.onDisconnect().setValue(PresenceModel.builder()
                            .presence(false)
                            .lastSeen(ServerValue.TIMESTAMP)
                            .fcmToken(fcmToken)
                            .build());

                    documentReference.update("fcm", fcmToken);
                    String userId = Utils.toFirebaseId(user.getSeekoohId(), user.getRoles().get(0));
                    FirebaseUser newUser = FirebaseUser.builder()
                            .fcm(fcmToken)
                            .block(false)
                            .userId(userId)
                            .fullName(user.getFullName())
                            .build();
                    documentReference.set(newUser);

                    // Set the user's online status to true
                    userRef.setValue(PresenceModel.builder()
                            .presence(true)
                            .lastSeen(ServerValue.TIMESTAMP)
                            .fcmToken(fcmToken)
                            .build());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle errors here
            }
        });
    }

    public void stop(boolean deleteFcmToken) {
        if (mConnectedListener != null) {
            FirebaseDatabase.getInstance().getReference(".info/connected").removeEventListener(mConnectedListener);
            userRef.onDisconnect().setValue(PresenceModel.builder()
                    .presence(false)
                    .lastSeen(ServerValue.TIMESTAMP)
                    .fcmToken(deleteFcmToken ? null : fcmToken)
                    .build());
        }
        // Set the user's online status to false
        userRef.setValue(PresenceModel.builder()
                .presence(false)
                .lastSeen(ServerValue.TIMESTAMP)
                .fcmToken(deleteFcmToken ? null : fcmToken)
                .build());
    }
}
