package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.Transaction;

public class VerificationStatusResponse {
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("transaction")
    @Expose
    private Transaction transaction;

    public VerificationStatusResponse() {
    }

    public VerificationStatusResponse(String status, Transaction transaction) {
        this.status = status;
        this.transaction = transaction;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }
}