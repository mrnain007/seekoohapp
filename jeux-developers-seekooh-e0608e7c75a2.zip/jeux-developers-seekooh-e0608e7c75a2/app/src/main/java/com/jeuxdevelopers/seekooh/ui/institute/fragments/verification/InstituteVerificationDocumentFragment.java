package com.jeuxdevelopers.seekooh.ui.institute.fragments.verification;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.github.dhaval2404.imagepicker.ImagePicker;
import com.jeuxdevelopers.seekooh.databinding.FragmentInstituteVerificationDocumentBinding;
import com.jeuxdevelopers.seekooh.models.dto.VerificationStatusResponse;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.tutor.fragments.verification.TutorVerificationDocumentFragmentDirections;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.net.URI;

public class InstituteVerificationDocumentFragment extends Fragment {
    private static final String TAG = "InstituteVerificationDo";
    private final int CNIC_FRONT_REQUEST_CODE = 1000;
    private final int CNIC_BACK_REQUEST_CODE = 1001;
    private final int PROOF_DOC_REQUEST_CODE = 1002;

    public Uri cnicFrontUri;
    public Uri cnicBackUri;
    public Uri proofDocUri;

    private boolean isResubmission = false;

    private FragmentInstituteVerificationDocumentBinding binding;
    private InstituteVerificationViewModel viewModel;
    private NavController navController;
    private WaitingDialog waitingDialog;
    private VerificationStatusResponse statusData;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentInstituteVerificationDocumentBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(InstituteVerificationViewModel.class);
        navController = Navigation.findNavController(view);
        getArgs();
        initViews();
        initClickListeners();
        initObservers();
    }

    private void getArgs() {
        Bundle args = getArguments();
        if (args != null) {
            isResubmission = args.getBoolean(Constants.UserVerificationStatus.RESUBMISSION_REQUESTED.name(), false);
            if (isResubmission) {
                Utils.showToastLong(requireContext(), "Documents resubmission required!");
            }
        }
    }

    private void initObservers() {
        viewModel.verificationStatusLiveData
                .observe(getViewLifecycleOwner(), verificationStatusResponse -> {
                    switch (verificationStatusResponse.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), verificationStatusResponse.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(verificationStatusResponse.getMessage());
                            break;
                        case SUCCESS:
                            statusData = verificationStatusResponse.getData();
                            String status = statusData.getStatus();
                            isResubmission = status.equals(Constants.UserVerificationStatus.RESUBMISSION_REQUESTED.name());
                            waitingDialog.dismiss();
                            break;
                    }
                });

        viewModel.submitRequestLiveData
                .observe(getViewLifecycleOwner(), submitVerificationResponse -> {
                    switch (submitVerificationResponse.getStatus()) {
                        case ERROR:
                            waitingDialog.dismiss();
                            Utils.showToast(requireContext(), submitVerificationResponse.getMessage());
                            break;
                        case LOADING:
                            waitingDialog.show(submitVerificationResponse.getMessage());
                            break;
                        case SUCCESS:
                            statusData = submitVerificationResponse.getData();
                            String status = statusData.getStatus();
                            if (status.equals(Constants.UserVerificationStatus.PAYMENT_PENDING.name())) {
                                //navController.navigate(InstituteVerificationDocumentFragmentDirections.actionInstituteVerificationDocumentFragmentToInstituteVerificationPaymentFragment());
                                navController.navigate(InstituteVerificationDocumentFragmentDirections.actionInstituteVerificationDocumentFragmentToInstituteVerificationStatusFragment());
                            } else {
                                navController.navigate(InstituteVerificationDocumentFragmentDirections.actionInstituteVerificationDocumentFragmentToInstituteVerificationStatusFragment());
                            }
                            Utils.showToast(requireContext(), submitVerificationResponse.getMessage());
                            waitingDialog.dismiss();
                            break;
                    }
                });
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext());
        initStepView();
    }

    private void initStepView() {
        binding.stepView.setColumnCount(3);
        binding.stepView.setSteps("Payments", "Documents", "Status");
        binding.stepView.setActiveStep(2);
    }

    private void initClickListeners() {
        binding.cnicFrontImg.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(5120).maxResultSize(1920, 1920).crop(1, 1).start(CNIC_FRONT_REQUEST_CODE);
        });
        binding.cnicBackImg.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(5120).maxResultSize(1920, 1920).crop(1, 1).start(CNIC_BACK_REQUEST_CODE);
        });
        binding.degreeImg.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(5120).maxResultSize(1920, 1920).crop(1, 1).start(PROOF_DOC_REQUEST_CODE);
        });
        binding.uploadBtn.setOnClickListener(v -> {
            if (!validateInput()) {
                return;
            }

            viewModel.submitVerificationRequest(URI.create(cnicFrontUri.toString()), URI.create(cnicBackUri.toString()), URI.create(proofDocUri.toString()));
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CNIC_FRONT_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                cnicFrontUri = data.getData();
                binding.cnicFrontImg.setImageURI(cnicFrontUri);
                binding.frontLabel.setVisibility(View.GONE);
            } else if (resultCode == ImagePicker.RESULT_ERROR) {
                Utils.showToast(requireContext(), ImagePicker.getError(data));
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        } else if (requestCode == CNIC_BACK_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                cnicBackUri = data.getData();
                binding.cnicBackImg.setImageURI(cnicBackUri);
                binding.backLabel.setVisibility(View.GONE);
            } else if (resultCode == ImagePicker.RESULT_ERROR) {
                Utils.showToast(requireContext(), ImagePicker.getError(data));
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        } else if (requestCode == PROOF_DOC_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                proofDocUri = data.getData();
                binding.degreeImg.setImageURI(proofDocUri);
            } else if (resultCode == ImagePicker.RESULT_ERROR) {
                Utils.showToast(requireContext(), ImagePicker.getError(data));
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        }
    }

    private boolean validateInput() {
        boolean isValid = true;
        if (cnicFrontUri == null) {
            Utils.showToast(requireContext(), "CNIC Front is required!");
            isValid = false;
        }

        if (cnicBackUri == null) {
            Utils.showToast(requireContext(), "CNIC Back is required!");
            isValid = false;
        }

        if (proofDocUri == null) {
            Utils.showToast(requireContext(), "Proof document is required!");
            isValid = false;
        }
        return isValid;
    }
}