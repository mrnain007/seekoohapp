package com.jeuxdevelopers.seekooh.ui.institute.activities.details.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.jeuxdevelopers.seekooh.databinding.ItemTutorDetailsSubjectListBinding;

public class SubjectsInstituteDetailsAdapter extends ListAdapter<Object, SubjectsInstituteDetailsAdapter.SubjectViewHolder> {

    private static final DiffUtil.ItemCallback<Object> DIFF_CALLBACK = new DiffUtil.ItemCallback<Object>() {
        @Override
        public boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
//            return oldItem.getEventId().equals(newItem.getEventId());
            return true;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
//            return oldItem.equals(newItem);
            return true;
        }
    };

    public SubjectsInstituteDetailsAdapter() {
        super(DIFF_CALLBACK);
    }

    @NonNull
    @Override
    public SubjectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemTutorDetailsSubjectListBinding binding = ItemTutorDetailsSubjectListBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new SubjectViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull SubjectViewHolder holder, int position) {
        holder.bind(getItem(position));
    }

    public static class SubjectViewHolder extends RecyclerView.ViewHolder {
        private final ItemTutorDetailsSubjectListBinding binding;

        public SubjectViewHolder(ItemTutorDetailsSubjectListBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Object model) {
        }
    }
}
