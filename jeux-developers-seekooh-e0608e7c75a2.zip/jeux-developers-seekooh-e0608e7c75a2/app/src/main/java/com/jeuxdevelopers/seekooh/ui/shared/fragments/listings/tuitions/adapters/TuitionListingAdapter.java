package com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tuitions.adapters;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.paging.PagingDataAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.common.util.CollectionUtils;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.ItemListingAdBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemTuitionListingBinding;
import com.jeuxdevelopers.seekooh.models.AdModel;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.DayOfWeek;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TuitionListing;
import com.jeuxdevelopers.seekooh.models.updates.UpdatedAdModel;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.Arrays;
import java.util.Collection;
import java.util.StringJoiner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TuitionListingAdapter extends PagingDataAdapter<Object, RecyclerView.ViewHolder> {

    private final Listener listener;
    private static int adPosition = 0;
    private static final DiffUtil.ItemCallback<Object> DIFF_CALLBACK = new DiffUtil.ItemCallback<Object>() {
        @Override
        public boolean areItemsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof TuitionListing && newItem instanceof TuitionListing) {
                return ((TuitionListing) oldItem).getId().equals(((TuitionListing) newItem).getId());
            }
            return false;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Object oldItem, @NonNull Object newItem) {
            if (oldItem instanceof TuitionListing && newItem instanceof TuitionListing) {
                return ((TuitionListing) oldItem).equals(((TuitionListing) newItem));
            }
            return false;
        }
    };

    public TuitionListingAdapter(Listener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        int itemCount = getItemCount();

        if (position < getItemCount()) {
            Object object = getItem(position);
            if (object instanceof AdModel) {
                return ViewType.AD_VIEW.ordinal();
            }
            return ViewType.NORMAL_VIEW.ordinal();
        }
        return ViewType.LOADING_VIEW.ordinal();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == ViewType.AD_VIEW.ordinal()) {
            ItemListingAdBinding itemListingAdBinding = ItemListingAdBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new AdViewHolder(itemListingAdBinding);
        }
        ItemTuitionListingBinding binding = ItemTuitionListingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new TuitionListingViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof TuitionListingViewHolder) {
            TuitionListingViewHolder tuitionListingViewHolder = ((TuitionListingViewHolder) holder);

            tuitionListingViewHolder.bind(getItem(position));
            if (getItem(position) instanceof TuitionListing) {
                tuitionListingViewHolder.binding.getRoot().setOnClickListener(v -> {
                    listener.onItemClicked(position, (TuitionListing) getItem(position));
                });
            }
        } else if (holder instanceof AdViewHolder) {
            AdViewHolder adViewHolder = ((AdViewHolder) holder);
            adViewHolder.bind(getItem(position));
        }
    }

    public static class TuitionListingViewHolder extends RecyclerView.ViewHolder {
        private final ItemTuitionListingBinding binding;

        public TuitionListingViewHolder(ItemTuitionListingBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(Object model) {
            if (!(model instanceof TuitionListing)) {
                return;
            }
            TuitionListing data = (TuitionListing) model;
            Glide.with(binding.getRoot()
                            .getContext())
                    .load(data.getProfileImageUrl())
                    .placeholder(R.drawable.profile_image_placeholder)
                    .into(binding.profileImg);
            binding.userNameTv.setText(data.getFullName());
            binding.postTimeTv.setText(Utils.getPrettyTime(data.getCreatedAt()));
            binding.classTypeTv.setText(data.getOnlineClass() ? "Online classes" : data.getCity().getName());
            String subjects = Utils.concatStrLists(", ", Arrays.asList(Utils.toStringList(data.getSubjects(), Subject::getName), data.getSuggestedSubjects()));
            binding.subjectDetailsTv.setText(subjects);
            String grades = Utils.concatStrLists(", ", Arrays.asList(Utils.toStringList(data.getGrades(), Grade::getName), data.getSuggestedGrades()));
            binding.gradeDetailsTv.setText(grades);
            binding.genderDetailsTv.setText(data.getTutorGender() != null ? data.getTutorGender().getName() : "Doesn't matter");
            binding.salaryDetailsTv.setText(Utils.formatCurrency(data.getSalaryAmount()) + " " + data.getSalaryType().getName());

            if (TextUtils.isEmpty(data.getJobDescription())) {
                binding.tuitionDescription.setVisibility(View.GONE);
            } else {
                binding.tuitionDescription.setText(data.getJobDescription());
                binding.tuitionDescription.setVisibility(View.VISIBLE);
            }

            binding.boardDetailsTv.setText(String.join(", ", Utils.toStringList(data.getBoardExams(), Board::getName)));
            binding.daysDetailsTv.setText(String.join(", ", Utils.toStringList(data.getPreferredDays(), DayOfWeek::getName)));
            binding.timingsDetailsTv.setText(Utils.getFormattedTime(data.getTuitionTimeSlot().getFromTime()) + " to " + Utils.getFormattedTime(data.getTuitionTimeSlot().getToTime()));
        }
    }

    public static class AdViewHolder extends RecyclerView.ViewHolder {
        private final ItemListingAdBinding binding;

        public AdViewHolder(ItemListingAdBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(Object model) {
            if (model instanceof AdModel) {
                AdModel adModel = (AdModel) model;
                if (adPosition >= App.updatedAdModelList.size()) {
                    adPosition = 0;
                }
                try {
                    UpdatedAdModel updatedAdModel = App.updatedAdModelList.get(adPosition++);
                    if (updatedAdModel.getBannerImage() != null) {
                        Glide.with(binding.getRoot().getContext()).load(updatedAdModel.getBannerImage()).into(binding.getRoot());
                    }
                    if (updatedAdModel.getUrl() != null) {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = updatedAdModel.getUrl();
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    } else {
                        binding.getRoot().setOnClickListener(v -> {
                            String url = "https://www.seekooh.com";
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse(url));
                            v.getContext().startActivity(intent);
                        });
                    }
                } catch (Exception e) {
                    Log.e("TAG", "bind: ", e);
                }
            }
        }
    }

    public interface Listener {
        void onItemClicked(int position, TuitionListing tuitionListing);
    }

    public enum ViewType {
        LOADING_VIEW, NORMAL_VIEW, AD_VIEW
    }
}
