package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.Address;
import com.jeuxdevelopers.seekooh.models.Experience;
import com.jeuxdevelopers.seekooh.models.Qualification;
import com.jeuxdevelopers.seekooh.models.TutorTimeSlot;

import java.util.List;

public class TutorRegistrationRequest {
    @SerializedName("fullName")
    @Expose
    private String fullName;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("genderId")
    @Expose
    private Integer genderId;
    @SerializedName("tutorProfile")
    @Expose
    private TutorProfile tutorProfile;

    public TutorRegistrationRequest() {
    }

    public TutorRegistrationRequest(String fullName, String email, String password, String phoneNumber, Integer genderId, TutorProfile tutorProfile) {
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.genderId = genderId;
        this.tutorProfile = tutorProfile;
    }

    private TutorRegistrationRequest(Builder builder) {
        setFullName(builder.fullName);
        setEmail(builder.email);
        setPassword(builder.password);
        setPhoneNumber(builder.phoneNumber);
        setGenderId(builder.genderId);
        setTutorProfile(builder.tutorProfile);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Integer getGenderId() {
        return genderId;
    }

    public void setGenderId(Integer genderId) {
        this.genderId = genderId;
    }

    public TutorProfile getTutorProfile() {
        return tutorProfile;
    }

    public void setTutorProfile(TutorProfile tutorProfile) {
        this.tutorProfile = tutorProfile;
    }

    public static class TutorProfile {

        @SerializedName("tagLine")
        @Expose
        private String tagLine;
        @SerializedName("teachOnline")
        @Expose
        private Boolean teachOnline;
        @SerializedName("teachAtLocation")
        @Expose
        private Boolean teachAtLocation;
        @SerializedName("boardExamIds")
        @Expose
        private List<Integer> boardExamIds;
        @SerializedName("cityId")
        @Expose
        private Integer cityId;
        @SerializedName("address")
        @Expose
        private Address address;
        @SerializedName("qualifications")
        @Expose
        private List<Qualification> qualifications;
        @SerializedName("experiences")
        @Expose
        private List<Experience> experiences;
        @SerializedName("subjectIds")
        @Expose
        private List<Integer> subjectIds;
        @SerializedName("classIds")
        @Expose
        private List<Integer> classIds;
        @SerializedName("timeSlots")
        @Expose
        private List<TutorTimeSlot> timeSlots;
        @SerializedName("availableDayValues")
        @Expose
        private List<Integer> availableDayValues;

        public TutorProfile() {
        }

        public TutorProfile(String tagLine, Boolean teachOnline, Boolean teachAtLocation, List<Integer> boardExamIds, Integer cityId, Address address, List<Qualification> qualifications, List<Experience> experiences, List<Integer> subjectIds, List<Integer> classIds, List<TutorTimeSlot> timeSlots, List<Integer> availableDayValues) {
            this.tagLine = tagLine;
            this.teachOnline = teachOnline;
            this.teachAtLocation = teachAtLocation;
            this.boardExamIds = boardExamIds;
            this.cityId = cityId;
            this.address = address;
            this.qualifications = qualifications;
            this.experiences = experiences;
            this.subjectIds = subjectIds;
            this.classIds = classIds;
            this.timeSlots = timeSlots;
            this.availableDayValues = availableDayValues;
        }

        private TutorProfile(Builder builder) {
            setTagLine(builder.tagLine);
            setTeachOnline(builder.teachOnline);
            setTeachAtLocation(builder.teachAtLocation);
            setBoardExamIds(builder.boardExamIds);
            setCityId(builder.cityId);
            setAddress(builder.address);
            setQualifications(builder.qualifications);
            setExperiences(builder.experiences);
            setSubjectIds(builder.subjectIds);
            setClassIds(builder.classIds);
            setTimeSlots(builder.timeSlots);
            setAvailableDayValues(builder.availableDayValues);
        }

        public static Builder builder() {
            return new Builder();
        }

        public String getTagLine() {
            return tagLine;
        }

        public void setTagLine(String tagLine) {
            this.tagLine = tagLine;
        }

        public Boolean getTeachOnline() {
            return teachOnline;
        }

        public void setTeachOnline(Boolean teachOnline) {
            this.teachOnline = teachOnline;
        }

        public Boolean getTeachAtLocation() {
            return teachAtLocation;
        }

        public void setTeachAtLocation(Boolean teachAtLocation) {
            this.teachAtLocation = teachAtLocation;
        }

        public List<Integer> getBoardExamIds() {
            return boardExamIds;
        }

        public void setBoardExamIds(List<Integer> boardExamIds) {
            this.boardExamIds = boardExamIds;
        }

        public Integer getCityId() {
            return cityId;
        }

        public void setCityId(Integer cityId) {
            this.cityId = cityId;
        }

        public Address getAddress() {
            return address;
        }

        public void setAddress(Address address) {
            this.address = address;
        }

        public List<Qualification> getQualifications() {
            return qualifications;
        }

        public void setQualifications(List<Qualification> qualifications) {
            this.qualifications = qualifications;
        }

        public List<Experience> getExperiences() {
            return experiences;
        }

        public void setExperiences(List<Experience> experiences) {
            this.experiences = experiences;
        }

        public List<Integer> getSubjectIds() {
            return subjectIds;
        }

        public void setSubjectIds(List<Integer> subjectIds) {
            this.subjectIds = subjectIds;
        }

        public List<Integer> getClassIds() {
            return classIds;
        }

        public void setClassIds(List<Integer> classIds) {
            this.classIds = classIds;
        }

        public List<TutorTimeSlot> getTimeSlots() {
            return timeSlots;
        }

        public void setTimeSlots(List<TutorTimeSlot> timeSlots) {
            this.timeSlots = timeSlots;
        }

        public List<Integer> getAvailableDayValues() {
            return availableDayValues;
        }

        public void setAvailableDayValues(List<Integer> availableDayValues) {
            this.availableDayValues = availableDayValues;
        }

        public static final class Builder {
            private String tagLine;
            private Boolean teachOnline;
            private Boolean teachAtLocation;
            private List<Integer> boardExamIds;
            private Integer cityId;
            private Address address;
            private List<Qualification> qualifications;
            private List<Experience> experiences;
            private List<Integer> subjectIds;
            private List<Integer> classIds;
            private List<TutorTimeSlot> timeSlots;
            private List<Integer> availableDayValues;

            private Builder() {
            }

            public Builder tagLine(String tagLine) {
                this.tagLine = tagLine;
                return this;
            }

            public Builder teachOnline(Boolean teachOnline) {
                this.teachOnline = teachOnline;
                return this;
            }

            public Builder teachAtLocation(Boolean teachAtLocation) {
                this.teachAtLocation = teachAtLocation;
                return this;
            }

            public Builder boardExamIds(List<Integer> boardExamIds) {
                this.boardExamIds = boardExamIds;
                return this;
            }

            public Builder cityId(Integer cityId) {
                this.cityId = cityId;
                return this;
            }

            public Builder address(Address address) {
                this.address = address;
                return this;
            }

            public Builder qualifications(List<Qualification> qualifications) {
                this.qualifications = qualifications;
                return this;
            }

            public Builder experiences(List<Experience> experiences) {
                this.experiences = experiences;
                return this;
            }

            public Builder subjectIds(List<Integer> subjectIds) {
                this.subjectIds = subjectIds;
                return this;
            }

            public Builder classIds(List<Integer> classIds) {
                this.classIds = classIds;
                return this;
            }

            public Builder timeSlots(List<TutorTimeSlot> timeSlots) {
                this.timeSlots = timeSlots;
                return this;
            }

            public Builder availableDayValues(List<Integer> availableDayValues) {
                this.availableDayValues = availableDayValues;
                return this;
            }

            public TutorProfile build() {
                return new TutorProfile(this);
            }
        }
    }

    public static final class Builder {
        private String fullName;
        private String email;
        private String password;
        private String phoneNumber;
        private Integer genderId;
        private TutorProfile tutorProfile;

        private Builder() {
        }

        public Builder fullName(String fullName) {
            this.fullName = fullName;
            return this;
        }

        public Builder email(String email) {
            this.email = email;
            return this;
        }

        public Builder password(String password) {
            this.password = password;
            return this;
        }

        public Builder phoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }

        public Builder genderId(Integer genderId) {
            this.genderId = genderId;
            return this;
        }

        public Builder tutorProfile(TutorProfile tutorProfile) {
            this.tutorProfile = tutorProfile;
            return this;
        }

        public TutorRegistrationRequest build() {
            return new TutorRegistrationRequest(this);
        }
    }
}