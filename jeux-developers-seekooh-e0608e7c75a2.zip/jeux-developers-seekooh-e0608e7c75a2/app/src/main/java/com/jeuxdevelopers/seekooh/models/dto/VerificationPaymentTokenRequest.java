package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class VerificationPaymentTokenRequest {
    @SerializedName("paymentMethod")
    @Expose
    private PaymentMethod paymentMethod;

    public VerificationPaymentTokenRequest() {
    }

    public VerificationPaymentTokenRequest(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    private VerificationPaymentTokenRequest(Builder builder) {
        setPaymentMethod(builder.paymentMethod);
    }

    public static Builder builder() {
        return new Builder();
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public enum PaymentMethod {
        CARD,
        JAZZ_CASH,
        EASY_PAISA
    }

    public static final class Builder {
        private PaymentMethod paymentMethod;

        private Builder() {
        }

        public Builder paymentMethod(PaymentMethod paymentMethod) {
            this.paymentMethod = paymentMethod;
            return this;
        }

        public VerificationPaymentTokenRequest build() {
            return new VerificationPaymentTokenRequest(this);
        }
    }
}