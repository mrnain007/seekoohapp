package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PaymobResponse {
    @SerializedName("txn_response_code")
    @Expose
    private String txnResponseCode;
    @SerializedName("integration_id")
    @Expose
    private String integrationId;
    @SerializedName("amount_cents")
    @Expose
    private String amountCents;
    @SerializedName("pending")
    @Expose
    private String pending;
    @SerializedName("is_auth")
    @Expose
    private String isAuth;
    @SerializedName("created_at")
    @Expose
    private String createdAt;
    @SerializedName("is_3d_secure")
    @Expose
    private String is3dSecure;
    @SerializedName("source_data.sub_type")
    @Expose
    private String sourceDataSubType;
    @SerializedName("is_standalone_payment")
    @Expose
    private String isStandalonePayment;
    @SerializedName("is_void")
    @Expose
    private String isVoid;
    @SerializedName("updated_at")
    @Expose
    private String updatedAt;
    @SerializedName("captured_amount")
    @Expose
    private String capturedAmount;
    @SerializedName("hmac")
    @Expose
    private String hmac;
    @SerializedName("currency")
    @Expose
    private String currency;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("is_refund")
    @Expose
    private String isRefund;
    @SerializedName("order")
    @Expose
    private String order;
    @SerializedName("owner")
    @Expose
    private String owner;
    @SerializedName("data.message")
    @Expose
    private String dataMessage;
    @SerializedName("merchant_order_id")
    @Expose
    private String merchantOrderId;
    @SerializedName("error_occured")
    @Expose
    private String errorOccured;
    @SerializedName("source_data.pan")
    @Expose
    private String sourceDataPan;
    @SerializedName("source_data.type")
    @Expose
    private String sourceDataType;
    @SerializedName("has_parent_transaction")
    @Expose
    private String hasParentTransaction;
    @SerializedName("acq_response_code")
    @Expose
    private String acqResponseCode;
    @SerializedName("is_capture")
    @Expose
    private String isCapture;
    @SerializedName("merchant_commission")
    @Expose
    private String merchantCommission;
    @SerializedName("is_refunded")
    @Expose
    private String isRefunded;
    @SerializedName("success")
    @Expose
    private String success;
    @SerializedName("profile_id")
    @Expose
    private String profileId;
    @SerializedName("is_voided")
    @Expose
    private String isVoided;
    @SerializedName("refunded_amount_cents")
    @Expose
    private String refundedAmountCents;

    public PaymobResponse() {
    }

    public String getTxnResponseCode() {
        return txnResponseCode;
    }

    public void setTxnResponseCode(String txnResponseCode) {
        this.txnResponseCode = txnResponseCode;
    }

    public String getIntegrationId() {
        return integrationId;
    }

    public void setIntegrationId(String integrationId) {
        this.integrationId = integrationId;
    }

    public String getAmountCents() {
        return amountCents;
    }

    public void setAmountCents(String amountCents) {
        this.amountCents = amountCents;
    }

    public String getPending() {
        return pending;
    }

    public void setPending(String pending) {
        this.pending = pending;
    }

    public String getIsAuth() {
        return isAuth;
    }

    public void setIsAuth(String isAuth) {
        this.isAuth = isAuth;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getIs3dSecure() {
        return is3dSecure;
    }

    public void setIs3dSecure(String is3dSecure) {
        this.is3dSecure = is3dSecure;
    }

    public String getSourceDataSubType() {
        return sourceDataSubType;
    }

    public void setSourceDataSubType(String sourceDataSubType) {
        this.sourceDataSubType = sourceDataSubType;
    }

    public String getIsStandalonePayment() {
        return isStandalonePayment;
    }

    public void setIsStandalonePayment(String isStandalonePayment) {
        this.isStandalonePayment = isStandalonePayment;
    }

    public String getIsVoid() {
        return isVoid;
    }

    public void setIsVoid(String isVoid) {
        this.isVoid = isVoid;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getCapturedAmount() {
        return capturedAmount;
    }

    public void setCapturedAmount(String capturedAmount) {
        this.capturedAmount = capturedAmount;
    }

    public String getHmac() {
        return hmac;
    }

    public void setHmac(String hmac) {
        this.hmac = hmac;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIsRefund() {
        return isRefund;
    }

    public void setIsRefund(String isRefund) {
        this.isRefund = isRefund;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getDataMessage() {
        return dataMessage;
    }

    public void setDataMessage(String dataMessage) {
        this.dataMessage = dataMessage;
    }

    public String getMerchantOrderId() {
        return merchantOrderId;
    }

    public void setMerchantOrderId(String merchantOrderId) {
        this.merchantOrderId = merchantOrderId;
    }

    public String getErrorOccured() {
        return errorOccured;
    }

    public void setErrorOccured(String errorOccured) {
        this.errorOccured = errorOccured;
    }

    public String getSourceDataPan() {
        return sourceDataPan;
    }

    public void setSourceDataPan(String sourceDataPan) {
        this.sourceDataPan = sourceDataPan;
    }

    public String getSourceDataType() {
        return sourceDataType;
    }

    public void setSourceDataType(String sourceDataType) {
        this.sourceDataType = sourceDataType;
    }

    public String getHasParentTransaction() {
        return hasParentTransaction;
    }

    public void setHasParentTransaction(String hasParentTransaction) {
        this.hasParentTransaction = hasParentTransaction;
    }

    public String getAcqResponseCode() {
        return acqResponseCode;
    }

    public void setAcqResponseCode(String acqResponseCode) {
        this.acqResponseCode = acqResponseCode;
    }

    public String getIsCapture() {
        return isCapture;
    }

    public void setIsCapture(String isCapture) {
        this.isCapture = isCapture;
    }

    public String getMerchantCommission() {
        return merchantCommission;
    }

    public void setMerchantCommission(String merchantCommission) {
        this.merchantCommission = merchantCommission;
    }

    public String getIsRefunded() {
        return isRefunded;
    }

    public void setIsRefunded(String isRefunded) {
        this.isRefunded = isRefunded;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getIsVoided() {
        return isVoided;
    }

    public void setIsVoided(String isVoided) {
        this.isVoided = isVoided;
    }

    public String getRefundedAmountCents() {
        return refundedAmountCents;
    }

    public void setRefundedAmountCents(String refundedAmountCents) {
        this.refundedAmountCents = refundedAmountCents;
    }
}
