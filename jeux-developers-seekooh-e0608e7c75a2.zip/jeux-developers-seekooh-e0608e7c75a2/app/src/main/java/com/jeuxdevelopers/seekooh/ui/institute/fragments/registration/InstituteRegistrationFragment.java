package com.jeuxdevelopers.seekooh.ui.institute.fragments.registration;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInStatusCodes;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.FragmentInstituteRegistrationBinding;
import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Gender;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.InstituteType;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.dto.InstituteRegistrationRequest;
import com.jeuxdevelopers.seekooh.ui.shared.activities.auth.AuthActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.terms.TermsAndPrivacyActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.MultiChoiceDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.student.fragments.registration.StudentRegistrationFragmentDirections;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import org.json.JSONException;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class InstituteRegistrationFragment extends Fragment {
    private static final String TAG = "InstituteRegistrationFr";
    private final int PROFILE_IMAGE_REQUEST_CODE = 1000;
    private static final int RC_SIGN_IN = 1001;
    private boolean isTextWatcherEnabled = false;
    private Uri profileImageUri;

    private FragmentInstituteRegistrationBinding binding;
    private InstituteRegistrationViewModel viewModel;
    private NavController navController;
    private WaitingDialog waitingDialog;

    // Drop downs
    private ArrayAdapter<String> instituteTypesArrayAdapter;
    private List<InstituteType> instituteTypeList = new ArrayList<>();
    private InstituteType selectedInstituteType;

    private ArrayAdapter<String> citiesArrayAdapter;
    private List<City> citiesList = new ArrayList<>();
    private City selectedCity;

    private boolean isRegistered = true;

    // Social Auth
    private GoogleSignInOptions googleSignInOptions;
    private GoogleSignInClient googleSignInClient;
    private CallbackManager fbCallbackManager;
    private String facebookId;

    private MultiChoiceDialog<Subject> subjectMultiChoiceDialog;
    private MultiChoiceDialog<Grade> gradeMultiChoiceDialog;
    private MultiChoiceDialog<Board> boardMultiChoiceDialog;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentInstituteRegistrationBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        initClickListeners();
        initObservers();
        initSocialLogins();
        fetchData();
        checkAuthMode();
    }

    private void checkAuthMode() {
        FragmentActivity fragmentActivity = requireActivity();
        if (fragmentActivity instanceof AuthActivity) {
            AuthActivity authActivity = (AuthActivity) fragmentActivity;
            if (authActivity.mode == AuthActivity.Mode.BECOME_INSTITUTE) {
                User user = UserPrefs.getUser(requireContext());
                if (user == null || user.getAccessToken() == null) {
                    return;
                }

                binding.emailTl.setEnabled(false);
                binding.emailTl.getEditText().setText(user.getEmail());
                binding.passwordTl.setVisibility(View.GONE);
                binding.passwordLabel.setVisibility(View.GONE);
                binding.confirmedPasswordTl.setVisibility(View.GONE);
                binding.confirmPasswordLabel.setVisibility(View.GONE);
                binding.passwordTl.getEditText().setText(user.getEmail());
                binding.confirmedPasswordTl.getEditText().setText(user.getEmail());
                binding.phoneTl.setEnabled(false);
                binding.phoneTl.getEditText().setText(user.getPhoneNumber());
                binding.socialAuthLabelTv.setVisibility(View.GONE);
                binding.socialAuthLl.setVisibility(View.GONE);
                binding.gotoLoginBtn.setVisibility(View.GONE);
            }
        }
    }

    private void initSocialLogins() {
        initGoogleLogin();
        initFbLogin();
    }

    private void initFbLogin() {
        disconnectFromFacebook();
        fbCallbackManager = CallbackManager.Factory.create();
        LoginManager.getInstance().registerCallback(fbCallbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                // Get the Access Token
                AccessToken accessToken = loginResult.getAccessToken();
                String token = accessToken.getToken();

                // Get the User ID
                facebookId = accessToken.getUserId();

                // Get the User's Profile
                getFbUserProfile(accessToken);
            }

            @Override
            public void onCancel() {
                // Handle cancel
            }

            @Override
            public void onError(@NonNull FacebookException error) {
                // Handle error
                Log.e(TAG, "initFbLogin onError: " + error.getMessage());
                Utils.showToast(requireContext(), error.getMessage());
            }
        });
    }

    private void getFbUserProfile(AccessToken accessToken) {
        GraphRequest request = GraphRequest.newMeRequest(accessToken, (object, response) -> {
            // Parse the User's Profile information
            if (object != null) {
                try {
                    String name = object.getString("name");
                    String email = object.getString("email");
                    String profilePicUrl = object.getJSONObject("picture").getJSONObject("data").getString("url");

//                    binding.nameTl.getEditText().setText(name);
                    binding.emailTl.setEnabled(false);
                    binding.emailTl.getEditText().setText(email);
                    Glide.with(requireContext())
                            .asBitmap()
                            .load(profilePicUrl)
                            .placeholder(R.drawable.profile_image_placeholder)
                            .into(new CustomTarget<Bitmap>() {
                                @Override
                                public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                    profileImageUri = Utils.bitmapToUri(requireContext(), resource);
                                    binding.profileImg.setImageURI(profileImageUri);
                                }

                                @Override
                                public void onLoadCleared(@Nullable Drawable placeholder) {
                                }
                            });

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e(TAG, "onSuccess: Facebook login response null.");
            }
        });

        // Execute the Graph Request
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,email,picture.type(large)");
        request.setParameters(parameters);
        request.executeAsync();
    }

    public void disconnectFromFacebook() {
        if (AccessToken.getCurrentAccessToken() == null) {
            return; // already logged out
        }
        new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/permissions/", null,
                HttpMethod.DELETE, graphResponse -> LoginManager.getInstance().logOut()).executeAsync();
    }

    private void initGoogleLogin() {
        googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()
                .build();
        googleSignInClient = GoogleSignIn.getClient(requireContext(), googleSignInOptions);
        googleSignInClient.signOut();
    }

    private void handleGoogleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            if (account.getPhotoUrl() != null) {
                Glide.with(requireContext())
                        .asBitmap()
                        .load(account.getPhotoUrl())
                        .placeholder(R.drawable.profile_image_placeholder)
                        .into(new CustomTarget<Bitmap>() {
                            @Override
                            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                profileImageUri = Utils.bitmapToUri(requireContext(), resource);
                                binding.profileImg.setImageURI(profileImageUri);
                            }

                            @Override
                            public void onLoadCleared(@Nullable Drawable placeholder) {
                            }
                        });
            }
            if (account.getEmail() != null) {
                binding.emailTl.setEnabled(false);
                binding.emailTl.getEditText().setText(account.getEmail());
            }
            if (account.getDisplayName() != null) {
//                binding.nameTl.getEditText().setText(account.getDisplayName());
            }
            facebookId = null;
            Log.e(TAG, "handleGoogleSignInResult: ");
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
            int statusCode = e.getStatusCode();

            switch (statusCode) {
                case GoogleSignInStatusCodes.SIGN_IN_FAILED:
                    Utils.showToast(requireContext(), "Sign-in failed. Please try again later.");
                    break;
                case GoogleSignInStatusCodes.NETWORK_ERROR:
                    Utils.showToast(requireContext(), "Network error. Please check your internet connection and try again.");
                    break;
                default:
                    Utils.showToast(requireContext(), "Sign-in failed. Please try again later. " + statusCode);
                    break;
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PROFILE_IMAGE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                profileImageUri = data.getData();
                binding.profileImg.setImageURI(profileImageUri);
            } else if (resultCode == ImagePicker.RESULT_ERROR) {
                Utils.showToast(requireContext(), ImagePicker.getError(data));
            } else {
                Utils.showToast(requireContext(), "Task Cancelled");
            }
        } else if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleGoogleSignInResult(task);
        }
    }

    private void initViews(@NonNull View view) {
        waitingDialog = new WaitingDialog(requireContext());
        navController = Navigation.findNavController(view);
        viewModel = new ViewModelProvider(this).get(InstituteRegistrationViewModel.class);
        setIsRegisteredDropDown();
        setSpannableStringOnSignIn();
    }

    private void setSpannableStringOnSignIn() {
        String text = "Already have an account? ";
        String text2 = "Sign In";
        SpannableString spannableString = new SpannableString(text2);
        spannableString.setSpan(new ForegroundColorSpan(Color.RED), 0, text2.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        binding.gotoLoginBtn.setText(TextUtils.concat(text, spannableString));
    }

    private void initClickListeners() {
        initTextWatcher();
        binding.gotoLoginBtn.setOnClickListener(v -> {
            Navigation.findNavController(v).popBackStack();
        });
        binding.pickImgBtn.setOnClickListener(v -> {
            ImagePicker.with(this).crop().compress(1024).maxResultSize(1920, 1920).crop(1, 1).start(PROFILE_IMAGE_REQUEST_CODE);
        });
        binding.submitBtn.setOnClickListener(v -> {
            if (!validateUserInput()) {
                return;
            }

            if (profileImageUri == null) {
                Utils.showToast(requireContext(), "Please pick a profile image.");
                return;
            }
            String nameOfInstitute = binding.instituteNameTl.getEditText().getText().toString().trim();
            String description = TextUtils.isEmpty(binding.descTv.getEditText().getText().toString().trim()) ? null : binding.descTv.getEditText().getText().toString().trim();
            String phone = binding.phoneTl.getEditText().getText().toString().trim();
            String email = binding.emailTl.getEditText().getText().toString().trim();
            Integer instituteTypeId = selectedInstituteType.getId();
            Integer cityId = selectedCity.getId();
            String password = binding.passwordTl.getEditText().getText().toString().trim();
            List<Subject> selectedSubjects = subjectMultiChoiceDialog.getSelectedItemsList();
            List<Grade> selectedClasses = gradeMultiChoiceDialog.getSelectedItemsList();
            List<Board> selectedBoardExams = boardMultiChoiceDialog.getSelectedItemsList();

            InstituteRegistrationRequest.InstituteProfile instituteProfile = InstituteRegistrationRequest.InstituteProfile.builder()
                    .cityId(cityId)
                    .instituteTypeId(instituteTypeId)
                    .isRegistered(isRegistered)
                    .nameOfInstitute(nameOfInstitute)
                    .description(description)
                    .subjectIds(Utils.toIdList(selectedSubjects, Subject::getId))
                    .classIds(Utils.toIdList(selectedClasses, Grade::getId))
                    .boardExamIds(Utils.toIdList(selectedBoardExams, Board::getId))
                    .build();

            InstituteRegistrationRequest instituteRegistrationRequest = InstituteRegistrationRequest.builder()
                    .phoneNumber(phone)
                    .email(email)
                    .password(password)
                    .facebookId(facebookId != null ? facebookId : null)
                    .instituteProfile(instituteProfile)
                    .build();

            viewModel.registerInstitute(URI.create(profileImageUri.toString()), instituteRegistrationRequest);
        });
        binding.googleBtn.setOnClickListener(v -> {
            Intent signInIntent = googleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, RC_SIGN_IN);
        });
        binding.facebookBtn.setOnClickListener(v -> {
            LoginManager.getInstance().logInWithReadPermissions(this, fbCallbackManager, Arrays.asList("email", "public_profile"));
        });
        binding.classesAcTv.setOnClickListener(v -> {
            gradeMultiChoiceDialog.show("Select classes your institute teaches?");
        });
        binding.subjectAcTv.setOnClickListener(v -> {
            subjectMultiChoiceDialog.show("Select subjects your institute teaches?");
        });
        binding.boardExamAcTv.setOnClickListener(v -> {
            boardMultiChoiceDialog.show("Select board/exam your institute teaches?");
        });

        // Open terms and conditions and privacy policy
        binding.tvTermsLink.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), TermsAndPrivacyActivity.class);
            intent.putExtra("type", TermsAndPrivacyActivity.Type.TERMS);
            startActivity(intent);
        });

        binding.tvPrivacyLink.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), TermsAndPrivacyActivity.class);
            intent.putExtra("type", TermsAndPrivacyActivity.Type.PRIVACY);
            startActivity(intent);
        });
    }

    private void initObservers() {
        viewModel.getInstituteTypesLiveData.observe(getViewLifecycleOwner(), getInstituteTypesResponse -> {
            switch (getInstituteTypesResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), getInstituteTypesResponse.getMessage());
                    break;
                case LOADING:
//                    waitingDialog.show(getInstituteTypesResponse.getMessage());
                    break;
                case SUCCESS:
                    waitingDialog.dismiss();
                    instituteTypeList = getInstituteTypesResponse.getData();
                    setInstituteTypesDropDown();
                    break;
            }
        });

        viewModel.getCitiesLiveData.observe(getViewLifecycleOwner(), getCitiesResponse -> {
            switch (getCitiesResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), getCitiesResponse.getMessage());
                    break;
                case LOADING:
//                    waitingDialog.show(getBoardsResponse.getMessage());
                    break;
                case SUCCESS:
                    waitingDialog.dismiss();
                    citiesList = getCitiesResponse.getData();
                    setCitiesDropDown();
                    break;
            }
        });

        viewModel.instituteRegistrationLiveData.observe(getViewLifecycleOwner(), instituteRegistrationResponse -> {
            switch (instituteRegistrationResponse.getStatus()) {
                case ERROR:
                    waitingDialog.dismiss();
                    Utils.showToast(requireContext(), instituteRegistrationResponse.getMessage());
                    break;
                case LOADING:
                    waitingDialog.show(instituteRegistrationResponse.getMessage());
                    break;
                case SUCCESS:
                    waitingDialog.dismiss();
                    navController.navigate(InstituteRegistrationFragmentDirections
                            .actionInstituteRegistrationFragmentToAuthFragment());
                    Utils.showToast(requireContext(), instituteRegistrationResponse.getMessage());
                    break;
            }
        });

        viewModel.getBoardsLiveData.observe(getViewLifecycleOwner(), getBoardsResponse -> {
            switch (getBoardsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getBoardsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Board> boardList = getBoardsResponse.getData();
                    boardMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            boardList,
                            Board::getName,
                            selectedItemNames -> binding.boardExamAcTv.setText(selectedItemNames));
                    break;
            }
        });

        viewModel.getGradesLiveData.observe(getViewLifecycleOwner(), getGradesResponse -> {
            switch (getGradesResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getGradesResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Grade> gradesList = getGradesResponse.getData();
                    gradeMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            gradesList,
                            Grade::getName,
                            selectedItemNames -> binding.classesAcTv.setText(selectedItemNames));
                    break;
            }
        });

        viewModel.getSubjectsLiveData.observe(getViewLifecycleOwner(), getSubjectsResponse -> {
            switch (getSubjectsResponse.getStatus()) {
                case ERROR:
                    Utils.showToast(requireContext(), getSubjectsResponse.getMessage());
                    break;
                case LOADING:
                    break;
                case SUCCESS:
                    List<Subject> subjectsList = getSubjectsResponse.getData();
                    subjectMultiChoiceDialog = new MultiChoiceDialog<>(requireContext(),
                            subjectsList,
                            Subject::getName,
                            selectedItemNames -> binding.subjectAcTv.setText(selectedItemNames));
                    break;
            }
        });
    }

    private void fetchData() {
        viewModel.getInstituteTypes();
        viewModel.getCities();
        viewModel.getSubjects();
        viewModel.getGrades();
        viewModel.getBoards();
    }

    private void setCitiesDropDown() {
        citiesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(citiesList, City::getName));
        binding.cityAcTv.setAdapter(citiesArrayAdapter);
        binding.cityAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = citiesList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void setInstituteTypesDropDown() {
        instituteTypesArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, Utils.toStringList(instituteTypeList, InstituteType::getName));
        binding.instituteTypeAcTv.setAdapter(instituteTypesArrayAdapter);
        binding.instituteTypeAcTv.setOnItemClickListener((parent, view, position, id) -> {
            selectedInstituteType = instituteTypeList.get(position);
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void setIsRegisteredDropDown() {
        List<String> isRegisteredStringList = Arrays.asList("Unregistered", "Registered");
        ArrayAdapter<String> isRegisteredArrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, isRegisteredStringList);
        binding.registeredAcTv.setAdapter(isRegisteredArrayAdapter);
        binding.registeredAcTv.setOnItemClickListener((parent, view, position, id) -> {
            isRegistered = position != 0;
            if (isTextWatcherEnabled) {
                validateUserInput();
            }
        });
    }

    private void initTextWatcher() {
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isTextWatcherEnabled) {
                    validateUserInput();
                }
            }
        };

        binding.instituteNameTl.getEditText().addTextChangedListener(textWatcher);
        binding.phoneTl.getEditText().addTextChangedListener(textWatcher);
        binding.emailTl.getEditText().addTextChangedListener(textWatcher);
        binding.passwordTl.getEditText().addTextChangedListener(textWatcher);
        binding.confirmedPasswordTl.getEditText().addTextChangedListener(textWatcher);
        binding.subjectTl.getEditText().addTextChangedListener(textWatcher);
        binding.classesTl.getEditText().addTextChangedListener(textWatcher);
        binding.boardTl.getEditText().addTextChangedListener(textWatcher);
    }

    private boolean validateUserInput() {
        isTextWatcherEnabled = true;
        boolean isValid = true;
        String name = binding.instituteNameTl.getEditText().getText().toString().trim();
        String phone = binding.phoneTl.getEditText().getText().toString().trim();
        String email = binding.emailTl.getEditText().getText().toString().trim();
        String password = binding.passwordTl.getEditText().getText().toString().trim();
        String confirmedPassword = binding.confirmedPasswordTl.getEditText().getText().toString().trim();
        String isRegisteredStr = binding.registeredAcTv.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            binding.instituteNameTl.setError("Please enter institute name?");
            isValid = false;
        } else {
            binding.instituteNameTl.setError(null);
        }

        if (TextUtils.isEmpty(phone)) {
            binding.emailTl.setError("Please enter your phone number?");
            isValid = false;
        } else if (!Utils.validatePhoneNumber(phone)) {
            binding.phoneTl.setError("Please enter a valid phone number?");
            isValid = false;
        } else {
            binding.phoneTl.setError(null);
        }

        if (TextUtils.isEmpty(email)) {
            binding.emailTl.setError("Please enter your email address?");
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.emailTl.setError("Please enter a valid email address?");
            isValid = false;
        } else {
            binding.emailTl.setError(null);
        }

        if (selectedCity == null) {
            binding.cityTl.setError("Please select your city?");
            isValid = false;
        } else {
            binding.cityTl.setError(null);
        }

        if (selectedInstituteType == null) {
            binding.instituteTypeTl.setError("Please select institute type?");
            isValid = false;
        } else {
            binding.instituteTypeTl.setError(null);
        }

        if (TextUtils.isEmpty(isRegisteredStr)) {
            binding.registeredTl.setError("Please select registration status?");
            isValid = false;
        } else {
            binding.registeredTl.setError(null);
        }

        if (TextUtils.isEmpty(password)) {
            binding.passwordTl.setError("Please set password for your account");
            isValid = false;
        } else if (password.length() < 8) {
            binding.passwordTl.setError("Password length should be at least 8 character");
            isValid = false;
        } else {
            binding.passwordTl.setError(null);
        }

        if (TextUtils.isEmpty(confirmedPassword)) {
            binding.confirmedPasswordTl.setError("Please confirm your password?");
            isValid = false;
        } else if (!confirmedPassword.equals(password)) {
            binding.confirmedPasswordTl.setError("Password mismatch");
            isValid = false;
        } else {
            binding.confirmedPasswordTl.setError(null);
        }

        if (subjectMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.subjectTl.setError("Please select subjects your institute teaches?");
            isValid = false;
        } else {
            binding.subjectTl.setError(null);
        }

        if (gradeMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.classesTl.setError("Please select classes your institute teaches?");
            isValid = false;
        } else {
            binding.classesTl.setError(null);
        }

        if (boardMultiChoiceDialog.getSelectedItemsList().isEmpty()) {
            binding.boardTl.setError("Please select board/exam your institute teaches?");
            isValid = false;
        } else {
            binding.boardTl.setError(null);
        }

        return isValid;
    }
}