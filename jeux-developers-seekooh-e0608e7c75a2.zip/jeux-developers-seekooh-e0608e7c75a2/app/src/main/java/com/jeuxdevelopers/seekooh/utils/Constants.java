package com.jeuxdevelopers.seekooh.utils;

import java.util.regex.Pattern;

public class Constants {
    public static final String TUTOR_ID = "tutorId";
    public static final String INSTITUTE_ID = "instituteId";
    public static final String COURSE_ID = "courseId";
    public static final String ROLE_STUDENT = "ROLE_STUDENT";
    public static final String ROLE_TUTOR = "ROLE_TUTOR";
    public static final String ROLE_INSTITUTE = "ROLE_INSTITUTE";
    public static final String AUTH_ACTIVITY_MODE = "AuthActivityMode";
    public static final String POST_TUITION_AD = "POST_TUITION_AD";
    public static final String POST_JOB_AD = "POST_JOB_AD";
    public static final String GOTO_INBOX = "GOTO_INBOX";
    public static final String SEARCH_TUITION_ID = "SEARCH_TUITION_ID";
    public static final String SEARCH_JOB_ID = "SEARCH_JOB_ID";
    public static final String PARTICIPANTS = "participants";

    public static final String IS_USER_BLOCK = "block";

    //public static final Pattern PHONE_NUMBER_PATTERN = Pattern.compile("^(\\+\\d{1,3}[- ]?)?\\d{10}$");
    public static final Pattern PHONE_NUMBER_PATTERN = Pattern.compile("^\\+?\\(?[0-9]{1,3}\\)? ?-?[0-9]{1,3} ?-?[0-9]{3,5} ?-?[0-9]{4}( ?-?[0-9]{3})?");


    public static final String GOOGLE_CLIENT_ID = "1089116292798-739n2nf3j3ndjstlebc2t5748lcpfbms.apps.googleusercontent.com";
    public static final String FIRST_TIME = "firstTime";

    public enum UserVerificationStatus {
        DOCUMENTS_REQUIRED, PAYMENT_PENDING, UNDER_REVIEW, VERIFICATION_COMPLETE, RESUBMISSION_REQUESTED
    }

    public enum Currency {
        PKR,
        USD
    }

    public static class Firebase {
        public static final String CHAT = "Chats";
        public static final String USERS = "Users";
        public static final String CHAT_ID = "chatId";
        public static final String MESSAGES = "Messages";
        public static final String FIREBASE_USER = "FirebaseUser";

        public static final String PARTICIPANTS = "participants";
        public static final String PARTICIPANT_IDS = "participantIds";
        public static final String CREATED_AT = "createdAt";
        public static final String UPDATED_AT = "updatedAt";
        public static final String LAST_MESSAGE = "lastMessage";
        public static final String LAST_MESSAGE_TYPE = "lastMessageType";
        public static final String SEEN_BY = "seenBy";
        public static final String FCM_TOKEN = "AAAA_ZRjxr4:APA91bGp0aZHuuewq_wWr1LzsARU2wCVDY4SaDYlnxSkOog1SbXqNJfONwmty0bbTumOyY6pl5BrujtlXf6fLlxpwyB9_kO4M0eK29zwH-KRy_7ldkVzzx3os_zibieHufS2Pj55TnXF";
        public static final String SERVER_KEY = "AAAA_ZRjxr4:APA91bGp0aZHuuewq_wWr1LzsARU2wCVDY4SaDYlnxSkOog1SbXqNJfONwmty0bbTumOyY6pl5BrujtlXf6fLlxpwyB9_kO4M0eK29zwH-KRy_7ldkVzzx3os_zibieHufS2Pj55TnXF";
        public static final String NOTIFICATION_URL = "https://fcm.googleapis.com/fcm/send";
    }
}

