package com.jeuxdevelopers.seekooh.ui.shared.activities.tuitions;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationResponse;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;
import retrofit2.http.Path;

public class AppliedTuitionViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<List<TuitionApplicationResponse>>> appliedTuitionsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<Void>> deleteTuitionApplicationLiveData = new MutableLiveData<>();

    public AppliedTuitionViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getAppliedTuitions() {
        disposables.add(appRepo.getAppliedTuitions()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(appliedTuitionsResource -> {
                    appliedTuitionsLiveData.setValue(appliedTuitionsResource);
                }, throwable -> {
                    appliedTuitionsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void deleteTuitionApplication(@Path("tuitionId") @NonNull Integer tuitionId) {
        disposables.add(appRepo.deleteTuitionApplication(tuitionId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(withdrawalResource -> {
                    deleteTuitionApplicationLiveData.setValue(withdrawalResource);
                }, throwable -> {
                    deleteTuitionApplicationLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
