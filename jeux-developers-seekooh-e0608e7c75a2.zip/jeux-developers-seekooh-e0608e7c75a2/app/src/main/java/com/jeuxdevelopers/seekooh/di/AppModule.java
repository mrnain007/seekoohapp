package com.jeuxdevelopers.seekooh.di;

import javax.inject.Singleton;

import dagger.Module;
import dagger.hilt.InstallIn;

@InstallIn(Singleton.class)
@Module
public class AppModule {
}
