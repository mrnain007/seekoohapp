package com.jeuxdevelopers.seekooh.ui.institute.fragments.jobs;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TeachingJob;
import com.jeuxdevelopers.seekooh.models.dto.CreateTeachingJobRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditTeachingJobRequest;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;
import retrofit2.http.Path;

public class PostJobViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<List<City>>> getCitiesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Grade>>> getGradesLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Subject>>> getSubjectsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<TeachingJob>> createJobLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<TeachingJob>> jobByIdLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<TeachingJob>> editJobLiveData = new MutableLiveData<>();

    public PostJobViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getCities() {
        disposables.add(appRepo.getCities()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getCitiesResponseResource -> {
                    getCitiesLiveData.setValue(getCitiesResponseResource);
                }, throwable -> {
                    getCitiesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getGrades() {
        disposables.add(appRepo.getGrades()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getGradesResponseResource -> {
                    getGradesLiveData.setValue(getGradesResponseResource);
                }, throwable -> {
                    getGradesLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getSubjects() {
        disposables.add(appRepo.getSubjects()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getSubjectsResponseResource -> {
                    getSubjectsLiveData.setValue(getSubjectsResponseResource);
                }, throwable -> {
                    getSubjectsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void createTeachingJob(@NonNull CreateTeachingJobRequest createTeachingJobRequest) {
        disposables.add(appRepo.createTeachingJob(createTeachingJobRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(createJobResource -> {
                    createJobLiveData.setValue(createJobResource);
                }, throwable -> {
                    createJobLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getTeachingJobById(@NonNull Integer jobId) {
        disposables.add(appRepo.getTeachingJobById(jobId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(JobResource -> {
                    jobByIdLiveData.setValue(JobResource);
                }, throwable -> {
                    jobByIdLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void editTeachingJob(@NonNull Integer jobId, @NonNull EditTeachingJobRequest editTeachingJobRequest) {
        disposables.add(appRepo.editTeachingJob(jobId, editTeachingJobRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(editJobResource -> {
                    editJobLiveData.setValue(editJobResource);
                }, throwable -> {
                    editJobLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
