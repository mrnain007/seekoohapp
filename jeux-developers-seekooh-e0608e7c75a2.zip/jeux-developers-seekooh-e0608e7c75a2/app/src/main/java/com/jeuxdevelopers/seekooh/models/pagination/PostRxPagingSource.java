package com.jeuxdevelopers.seekooh.models.pagination;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.paging.PagingState;
import androidx.paging.rxjava3.RxPagingSource;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class PostRxPagingSource extends RxPagingSource<Integer, Post> {
    private static final String TAG = "PostRxPagingSource";

    @NonNull
    @Override
    public Single<LoadResult<Integer, Post>> loadSingle(@NotNull LoadParams<Integer> loadParams) {
        try {
            // If page number is already there then init page variable with it otherwise we are loading fist page
            int page = loadParams.getKey() != null ? loadParams.getKey() : 1;
            // Send request to server with page number
            return getPost(page, loadParams.getLoadSize())
                    // Subscribe the result
                    .subscribeOn(Schedulers.io())
                    // Map result to LoadResult Object
                    .map(posts -> toLoadResult(posts, page))
                    // when error is there return error
                    .onErrorReturn(LoadResult.Error::new);
        } catch (Exception e) {
            // Request ran into error return error
            return Single.just(new LoadResult.Error<>(e));
        }
    }

    // Method to map Movies to LoadResult object
    private LoadResult<Integer, Post> toLoadResult(List<Post> posts, int page) {
        return new LoadResult.Page<>(posts, page == 1 ? null : page - 1, posts.isEmpty() ? null : page + 1);
    }

    @Nullable
    @Override
    public Integer getRefreshKey(@NonNull PagingState<Integer, Post> pagingState) {
        return null;
    }

    public @NonNull
    Single<List<Post>> getPost(@NonNull Integer page, @NonNull Integer itemCount) {
        Log.e(TAG, "getPost: page: " + page + " itemCount: " + itemCount);
        return Single.create(emitter -> {
            Thread.sleep(3000);
            List<Post> postList = new ArrayList<>();
            if (page <= 6) {
                for (int i = page == 1 ? 1 : ((page - 1) * itemCount + 1); i <= (page * itemCount); i++) {
                    postList.add(new Post(i, "Post " + i));
                }
            }
            emitter.onSuccess(postList);
        });
    }
}
