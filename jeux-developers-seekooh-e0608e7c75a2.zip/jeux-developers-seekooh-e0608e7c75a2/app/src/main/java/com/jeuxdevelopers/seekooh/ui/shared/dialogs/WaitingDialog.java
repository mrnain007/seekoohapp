package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;

import com.jeuxdevelopers.seekooh.databinding.DialogWaitingBinding;

public class WaitingDialog extends Dialog {

    private DialogWaitingBinding binding;
    private final Context context;
    private OnBackClicked onBackClicked;
    private String message;
    private Status status;

    public WaitingDialog(@NonNull Context context) {
        super(context);
        this.context = context;
    }

    public WaitingDialog(@NonNull Context context, OnBackClicked onBackClicked) {
        super(context);
        this.context = context;
        this.onBackClicked = onBackClicked;
    }

    @SuppressLint("NewApi")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        binding = DialogWaitingBinding.inflate(LayoutInflater.from(context));
        setContentView(binding.getRoot());
        getWindow().setBackgroundDrawable(new ColorDrawable(context.getResources().getColor(android.R.color.transparent, null)));
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        init();
    }

    private void init() {
        if (message != null) {
            binding.msgTv.setText(message);
        }
    }

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (binding != null) {
            binding.msgTv.setText(message);
        }
    }

    public void show(String message) {
        this.message = message;
        if (binding != null) {
            status = Status.LOADING;
            binding.errorAnim.setVisibility(View.GONE);
            binding.progressBar.setVisibility(View.VISIBLE);
            binding.msgTv.setText(message);
            binding.msgSecTv.setText("please wait");
        }
        show();
    }

    public void showError(String message) {
        this.message = message;
        if (binding != null) {
            status = Status.ERROR;
            binding.progressBar.setVisibility(View.INVISIBLE);
            binding.errorAnim.setVisibility(View.VISIBLE);
            binding.msgTv.setText(message);
            binding.msgSecTv.setText("error");
            if (onBackClicked != null) {
                binding.backBtn.setVisibility(View.VISIBLE);
                binding.backBtn.setOnClickListener(v -> onBackClicked.onClick());
            }
        }
        show();
    }

    public void setMessage(String message) {
        binding.msgTv.setText(message);
    }

    public Status getStatus() {
        return status;
    }

    public interface OnBackClicked {
        void onClick();
    }

    public enum Status {
        ERROR, LOADING
    }
}
