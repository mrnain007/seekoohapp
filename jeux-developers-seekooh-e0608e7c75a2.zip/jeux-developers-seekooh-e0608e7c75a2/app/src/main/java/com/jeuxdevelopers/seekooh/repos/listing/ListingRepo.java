package com.jeuxdevelopers.seekooh.repos.listing;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.TutorListing;

import java.util.List;

import io.reactivex.rxjava3.core.Observable;

public interface ListingRepo {
    Observable<Resource<List<TutorListing>>> getTutorsListing(Integer page, Integer size);
}
