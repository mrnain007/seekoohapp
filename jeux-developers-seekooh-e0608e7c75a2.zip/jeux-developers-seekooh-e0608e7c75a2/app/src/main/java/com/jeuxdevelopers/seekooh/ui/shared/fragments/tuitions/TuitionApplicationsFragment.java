package com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.google.android.gms.common.util.CollectionUtils;
import com.google.gson.Gson;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.FragmentTuitionApplicationsBinding;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.TutorListing;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.chat.FirebaseUser;
import com.jeuxdevelopers.seekooh.models.dto.CourseEnrollmentResponse;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationResponse;
import com.jeuxdevelopers.seekooh.ui.shared.activities.chat.ChatActivity;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.DeleteDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.TuitionApplicationDialog;
import com.jeuxdevelopers.seekooh.ui.shared.dialogs.WaitingDialog;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions.adapters.PostedTuitionsAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.tuitions.adapters.TuitionApplicantAdapter;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.List;

public class TuitionApplicationsFragment extends Fragment {
    private static final String TAG = "TuitionApplicationsFrag";

    private int tuitionId = -1;

    private FragmentTuitionApplicationsBinding binding;
    private NavController navController;
    private TuitionApplicationsViewModel viewModel;
    private TuitionApplicantAdapter tuitionApplicantAdapter;
    private List<TuitionApplicationResponse> data;
    private WaitingDialog waitingDialog;
    private TuitionApplicationDialog tuitionApplicationDialog;
    private DeleteDialog deleteDialog;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentTuitionApplicationsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);
        viewModel = new ViewModelProvider(this).get(TuitionApplicationsViewModel.class);
        initViews();
        initClickListeners();
        initObservers();
        initData();
    }

    private void initData() {
        TuitionApplicationsFragmentArgs args = TuitionApplicationsFragmentArgs.fromBundle(getArguments());
        tuitionId = args.getTuitionId();
        if (tuitionId == -1) {
            waitingDialog.showError("Error parsing tuitionId!");
            return;
        }
        viewModel.getTuitionApplications(tuitionId);
    }

    private void initViews() {
        waitingDialog = new WaitingDialog(requireContext(), () -> {
            requireActivity().onBackPressed();
        });
        deleteDialog = new DeleteDialog(requireContext());
        tuitionApplicationDialog = new TuitionApplicationDialog(requireContext());
        initRecycler();
    }

    private void initClickListeners() {
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            viewModel.getTuitionApplications(tuitionId);
        });
        binding.backBtn.setOnClickListener(v -> {
            navController.popBackStack();
        });
    }

    private void initRecycler() {
        tuitionApplicantAdapter = new TuitionApplicantAdapter((position, tuitionApplicationResponse) -> {
            tuitionApplicationDialog.show(tuitionApplicationResponse, new TuitionApplicationDialog.Listener() {
                @Override
                public void onViewContactClicked(TuitionApplicationResponse tuitionApplicationResponse) {
                    Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                    dialIntent.setData(Uri.parse("tel:" + tuitionApplicationResponse.getTutor().getPhoneNumber()));
                    startActivity(dialIntent);
                }

                @Override
                public void onSendMessageClicked(TuitionApplicationResponse tuitionApplicationResponse) {
                    User user = UserPrefs.getUser(requireContext());
                    if (user == null) {
                        Utils.showToast(requireContext(), "Only logged in users can send messages!");
                        return;
                    }

                    TutorListing data = tuitionApplicationResponse.getTutor();

                    String userId = Utils.toFirebaseId(data.getSeekoohId(), Role.builder().name(Constants.ROLE_TUTOR).build());

                    if (Utils.toFirebaseId(user.getSeekoohId(), user.getAppSettings().getSelectedRole()).equals(userId)) {
                        Utils.showToast(requireContext(), "Cannot send message to your own profile!");
                        return;
                    }

                    FirebaseUser firebaseUser = FirebaseUser.builder()
                            .userId(userId)
                            .profileImgUrl(data.getProfileImageUrl())
                            .fullName(data.getFullName())
                            .build();

                    Intent intent = new Intent(requireContext(), ChatActivity.class);
                    intent.putExtra(Constants.Firebase.FIREBASE_USER, new Gson().toJson(firebaseUser));
                    startActivity(intent);
                }

                @Override
                public void onPositiveBtnClicked(String coverLetter, Integer tuitionId) {

                }

                @Override
                public void onNegativeBtnClicked() {

                }
            });
        });
        binding.rcv.setAdapter(tuitionApplicantAdapter);
    }

    @SuppressLint("SetTextI18n")
    private void initObservers() {
        viewModel.getTuitionApplicationsLiveData.observe(getViewLifecycleOwner(), tuitionApplicationsResponse -> {
            switch (tuitionApplicationsResponse.getStatus()) {
                case ERROR:
                    binding.noContentLayout.getRoot().setVisibility(View.GONE);
                    Utils.showToast(requireContext(), tuitionApplicationsResponse.getMessage());
                    binding.shimmer.setVisibility(View.GONE);
                    binding.swipeRefreshLayout.setRefreshing(false);
                    break;
                case LOADING:
                    binding.noContentLayout.getRoot().setVisibility(View.GONE);
                    binding.shimmer.setVisibility(View.VISIBLE);
                    break;
                case SUCCESS:
                    data = tuitionApplicationsResponse.getData();
                    binding.noContentLayout.getRoot().setVisibility(CollectionUtils.isEmpty(data) ? View.VISIBLE : View.GONE);
                    tuitionApplicantAdapter.submitList(data);
                    binding.swipeRefreshLayout.setRefreshing(false);
                    binding.shimmer.setVisibility(View.GONE);
                    break;
            }
        });
    }
}