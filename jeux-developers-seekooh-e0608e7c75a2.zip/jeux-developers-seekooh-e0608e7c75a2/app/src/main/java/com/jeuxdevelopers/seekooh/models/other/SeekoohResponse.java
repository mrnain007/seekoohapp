package com.jeuxdevelopers.seekooh.models.other;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Map;

public class SeekoohResponse<T> {
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("data")
    @Expose
    private T data;
    @SerializedName("error")
    @Expose
    private String error;
    @SerializedName("message")
    @Expose
    private JsonElement messageJson;
    @SerializedName("messageStr")
    private String message;

    public SeekoohResponse() {
    }

    public SeekoohResponse(Integer status, T data, String error, JsonElement messageJson) {
        this.status = status;
        this.data = data;
        this.error = error;
        this.messageJson = messageJson;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public JsonElement getMessageJson() {
        return messageJson;
    }

    public void setMessageJson(JsonElement messageJson) {
        this.messageJson = messageJson;
    }

    public String getMessage(String defaultMsg) {
        if (message == null) {
            toStrMessage(messageJson);
        }
        return message != null ? message : defaultMsg;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    private void toStrMessage(JsonElement messageJson) {
        if (messageJson == null) {
            return;
        }
        if (messageJson.isJsonObject()) {
            JsonObject messageObject = messageJson.getAsJsonObject();
            for (Map.Entry<String, JsonElement> entry : messageObject.entrySet()) {
                String fieldName = entry.getKey();
                JsonElement errorElement = entry.getValue();
                if (errorElement.isJsonPrimitive() && errorElement.getAsJsonPrimitive().isString()) {
                    message = errorElement.getAsString();
                    break;
                }
            }
        } else if (messageJson.isJsonPrimitive() && messageJson.getAsJsonPrimitive().isString()) {
            message = messageJson.getAsString();
        }
    }
}


