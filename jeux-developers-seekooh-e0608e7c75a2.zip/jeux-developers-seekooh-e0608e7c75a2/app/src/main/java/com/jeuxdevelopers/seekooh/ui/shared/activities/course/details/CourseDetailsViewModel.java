package com.jeuxdevelopers.seekooh.ui.shared.activities.course.details;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.CourseListing;
import com.jeuxdevelopers.seekooh.models.CourseReview;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.dto.CourseEnrollmentResponse;
import com.jeuxdevelopers.seekooh.models.dto.CreateCourseReviewRequest;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;
import retrofit2.http.Path;

public class CourseDetailsViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<CourseListing>> courseListingDetailsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<List<CourseReview>>> courseReviewsLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<CourseReview>> createCourseReviewLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<CourseEnrollmentResponse>> enrollmentRequestLiveData = new MutableLiveData<>();

    public CourseDetailsViewModel() {
        appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void getCourseListingDetails(@NonNull Integer courseId) {
        disposables.add(appRepo.getCourseListingDetails(courseId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(tutorDetailsResource -> {
                    courseListingDetailsLiveData.setValue(tutorDetailsResource);
                }, throwable -> {
                    courseListingDetailsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getCourseReviews(@NonNull Integer courseId) {
        disposables.add(appRepo.getCourseReviews(courseId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(getCourseReviewsResource -> {
                    courseReviewsLiveData.setValue(getCourseReviewsResource);
                }, throwable -> {
                    courseReviewsLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void createCoursesReview(@NonNull Integer courseId, @NonNull CreateCourseReviewRequest createCourseReviewRequest) {
        disposables.add(appRepo.createCoursesReview(courseId, createCourseReviewRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(createCourseReviewResource -> {
                    createCourseReviewLiveData.setValue(createCourseReviewResource);
                }, throwable -> {
                    createCourseReviewLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void courseEnrollment(@NonNull Integer courseId) {
        disposables.add(appRepo.courseEnrollment(courseId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(enrollmentResponse -> {
                    enrollmentRequestLiveData.setValue(enrollmentResponse);
                }, throwable -> {
                    enrollmentRequestLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
