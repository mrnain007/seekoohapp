package com.jeuxdevelopers.seekooh.network.deserializers;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.jeuxdevelopers.seekooh.models.Tuition;

import java.lang.reflect.Type;

public class TuitionStatusDeserializer implements JsonDeserializer<Tuition.Status> {

    @Override
    public Tuition.Status deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        try {
            return Tuition.Status.valueOf(json.getAsString());
        } catch (IllegalArgumentException ex) {
            // Unknown enum value, leave the field as null
            return null;
        }
    }
}
