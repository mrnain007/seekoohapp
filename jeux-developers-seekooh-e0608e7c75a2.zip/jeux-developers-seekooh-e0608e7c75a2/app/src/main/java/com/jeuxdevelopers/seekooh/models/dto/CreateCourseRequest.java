package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.List;

public class CreateCourseRequest {
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("learningGoals")
    @Expose
    private String learningGoals;
    @SerializedName("minRequirements")
    @Expose
    private List<String> minRequirements;
    @SerializedName("targetAudience")
    @Expose
    private String targetAudience;
    @SerializedName("startMinutes")
    @Expose
    private Integer startMinutes;
    @SerializedName("endMinutes")
    @Expose
    private Integer endMinutes;
    @SerializedName("startDate")
    @Expose
    private Long startDate;
    @SerializedName("endDate")
    @Expose
    private Long endDate;
    @SerializedName("isOnline")
    @Expose
    private Boolean isOnline;
    @SerializedName("isInPerson")
    @Expose
    private Boolean isInPerson;
    @SerializedName("dayValues")
    @Expose
    private List<Integer> dayValues;
    @SerializedName("subjectIds")
    @Expose
    private List<Integer> subjectIds;

    public CreateCourseRequest() {
    }

    public CreateCourseRequest(String title, String description, String learningGoals, List<String> minRequirements, String targetAudience, Integer startMinutes, Integer endMinutes, Long startDate, Long endDate, Boolean isOnline, Boolean isInPerson, List<Integer> dayValues, List<Integer> subjectIds) {
        this.title = title;
        this.description = description;
        this.learningGoals = learningGoals;
        this.minRequirements = minRequirements;
        this.targetAudience = targetAudience;
        this.startMinutes = startMinutes;
        this.endMinutes = endMinutes;
        this.startDate = startDate;
        this.endDate = endDate;
        this.isOnline = isOnline;
        this.isInPerson = isInPerson;
        this.dayValues = dayValues;
        this.subjectIds = subjectIds;
    }

    private CreateCourseRequest(Builder builder) {
        setTitle(builder.title);
        setDescription(builder.description);
        setLearningGoals(builder.learningGoals);
        setMinRequirements(builder.minRequirements);
        setTargetAudience(builder.targetAudience);
        setStartMinutes(builder.startMinutes);
        setEndMinutes(builder.endMinutes);
        setStartDate(builder.startDate);
        setEndDate(builder.endDate);
        isOnline = builder.isOnline;
        isInPerson = builder.isInPerson;
        setDayValues(builder.dayValues);
        setSubjectIds(builder.subjectIds);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLearningGoals() {
        return learningGoals;
    }

    public void setLearningGoals(String learningGoals) {
        this.learningGoals = learningGoals;
    }

    public List<String> getMinRequirements() {
        return minRequirements;
    }

    public void setMinRequirements(List<String> minRequirements) {
        this.minRequirements = minRequirements;
    }

    public String getTargetAudience() {
        return targetAudience;
    }

    public void setTargetAudience(String targetAudience) {
        this.targetAudience = targetAudience;
    }

    public Integer getStartMinutes() {
        return startMinutes;
    }

    public void setStartMinutes(Integer startMinutes) {
        this.startMinutes = startMinutes;
    }

    public Integer getEndMinutes() {
        return endMinutes;
    }

    public void setEndMinutes(Integer endMinutes) {
        this.endMinutes = endMinutes;
    }

    public Long getStartDate() {
        return startDate;
    }

    public void setStartDate(Long startDate) {
        this.startDate = startDate;
    }

    public Long getEndDate() {
        return endDate;
    }

    public void setEndDate(Long endDate) {
        this.endDate = endDate;
    }

    public Boolean getOnline() {
        return isOnline;
    }

    public void setOnline(Boolean online) {
        isOnline = online;
    }

    public Boolean getInPerson() {
        return isInPerson;
    }

    public void setInPerson(Boolean inPerson) {
        isInPerson = inPerson;
    }

    public List<Integer> getDayValues() {
        return dayValues;
    }

    public void setDayValues(List<Integer> dayValues) {
        this.dayValues = dayValues;
    }

    public List<Integer> getSubjectIds() {
        return subjectIds;
    }

    public void setSubjectIds(List<Integer> subjectIds) {
        this.subjectIds = subjectIds;
    }

    public static final class Builder {
        private String title;
        private String description;
        private String learningGoals;
        private List<String> minRequirements;
        private String targetAudience;
        private Integer startMinutes;
        private Integer endMinutes;
        private Long startDate;
        private Long endDate;
        private Boolean isOnline;
        private Boolean isInPerson;
        private List<Integer> dayValues;
        private List<Integer> subjectIds;

        private Builder() {
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder learningGoals(String learningGoals) {
            this.learningGoals = learningGoals;
            return this;
        }

        public Builder minRequirements(List<String> minRequirements) {
            this.minRequirements = minRequirements;
            return this;
        }

        public Builder targetAudience(String targetAudience) {
            this.targetAudience = targetAudience;
            return this;
        }

        public Builder startMinutes(Integer startMinutes) {
            this.startMinutes = startMinutes;
            return this;
        }

        public Builder endMinutes(Integer endMinutes) {
            this.endMinutes = endMinutes;
            return this;
        }

        public Builder startDate(Long startDate) {
            this.startDate = startDate;
            return this;
        }

        public Builder endDate(Long endDate) {
            this.endDate = endDate;
            return this;
        }

        public Builder isOnline(Boolean isOnline) {
            this.isOnline = isOnline;
            return this;
        }

        public Builder isInPerson(Boolean isInPerson) {
            this.isInPerson = isInPerson;
            return this;
        }

        public Builder dayValues(List<Integer> dayValues) {
            this.dayValues = dayValues;
            return this;
        }

        public Builder subjectIds(List<Integer> subjectIds) {
            this.subjectIds = subjectIds;
            return this;
        }

        public CreateCourseRequest build() {
            return new CreateCourseRequest(this);
        }
    }
}
