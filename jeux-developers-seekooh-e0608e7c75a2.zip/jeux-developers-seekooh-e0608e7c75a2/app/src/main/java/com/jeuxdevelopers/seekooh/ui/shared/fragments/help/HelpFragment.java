package com.jeuxdevelopers.seekooh.ui.shared.fragments.help;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.jeuxdevelopers.seekooh.databinding.FragmentHelpBinding;

public class HelpFragment extends Fragment implements View.OnClickListener {

    private FragmentHelpBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentHelpBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initClickListeners();
    }

    private void initClickListeners() {
        binding.backBtn.setOnClickListener(this);
        binding.tvFacebook.setOnClickListener(view -> openURL("https://www.facebook.com/seekooh/"));
        binding.tvInstagram.setOnClickListener(view -> openURL("https://www.instagram.com/seekooh.info/"));
        binding.tvTwitter.setOnClickListener(view -> openURL("https://twitter.com/seekooh"));
        binding.tvYoutube.setOnClickListener(view -> openURL("https://www.youtube.com/@seekooh"));
        binding.tvLinkedin.setOnClickListener(view -> openURL("https://www.linkedin.com/company/seekooh/"));
        binding.tvStudents.setOnClickListener(view -> openURL("https://chat.whatsapp.com/Kmtc5T43yOC5jxsSy7F0Mm"));
        binding.tvTutors.setOnClickListener(view -> openURL("https://chat.whatsapp.com/I377UcJuzeTB8nyPp1fyXi"));
        binding.tvInstitutes.setOnClickListener(view -> openURL("https://chat.whatsapp.com/CVA0lMbeSDmG5RGdfL8G2m"));
    }

    public void openURL(String url) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == binding.backBtn.getId()) {
            requireActivity().onBackPressed();
        }
    }
}