package com.jeuxdevelopers.seekooh.ui.shared.fragments.notifications;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.paging.LoadState;

import com.jeuxdevelopers.seekooh.databinding.FragmentNotificationBinding;
import com.jeuxdevelopers.seekooh.ui.shared.activities.main.MainActivity;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.listings.tuitions.adapters.TuitionListingLoadStateAdapter;
import com.jeuxdevelopers.seekooh.ui.shared.fragments.notifications.adapters.NotificationAdapter;
import com.jeuxdevelopers.seekooh.utils.Utils;

public class NotificationFragment extends Fragment {

    private FragmentNotificationBinding binding;
    private NotificationViewModel viewModel;
    private NotificationAdapter notificationAdapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        viewModel = new ViewModelProvider(this).get(NotificationViewModel.class);
        binding = FragmentNotificationBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initRecycler();
        initClickListeners();
        initObservers();
        fetchData();
    }

    private void initObservers() {
        viewModel.pagingLiveData
                .observe(getViewLifecycleOwner(), pagingData -> {
                    notificationAdapter.submitData(getLifecycle(), pagingData);
                });
    }

    private void fetchData() {
        viewModel.init();
    }

    private void initRecycler() {
        // Listing Rcv
        notificationAdapter = new NotificationAdapter((position, notification) -> {
            /*MainActivity mainActivity = (MainActivity) requireActivity();
            mainActivity.handleNotificationClick(notification);*/
        });

        binding.notificationRcv.setAdapter(notificationAdapter.withLoadStateFooter(
                new TuitionListingLoadStateAdapter(v -> {

                })
        ));

        notificationAdapter.addLoadStateListener(combinedLoadStates -> {
            if (combinedLoadStates.getRefresh() instanceof LoadState.Error) {
                LoadState.Error error = (LoadState.Error) combinedLoadStates.getRefresh();

                Utils.showToast(requireContext(), error.getError().getLocalizedMessage());
                binding.shimmer.setVisibility(View.GONE);
                binding.noContentLayout.getRoot().setVisibility(View.VISIBLE);
                binding.notificationRcv.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.Loading) {
                binding.shimmer.setVisibility(View.VISIBLE);
                binding.noContentLayout.getRoot().setVisibility(View.GONE);
                binding.notificationRcv.setVisibility(View.GONE);
            } else if (combinedLoadStates.getRefresh() instanceof LoadState.NotLoading) {
                binding.notificationRcv.setVisibility(View.VISIBLE);
                binding.shimmer.setVisibility(View.GONE);
                binding.swipeRefreshLayout.setRefreshing(false);
                binding.noContentLayout.getRoot().setVisibility(notificationAdapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
            }
            return null;
        });
    }

    private void initClickListeners() {
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            notificationAdapter.refresh();
        });
    }
}