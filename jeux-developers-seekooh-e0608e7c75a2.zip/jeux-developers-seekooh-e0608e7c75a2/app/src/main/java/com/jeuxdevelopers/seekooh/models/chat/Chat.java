package com.jeuxdevelopers.seekooh.models.chat;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.ServerTimestamp;

import java.util.ArrayList;
import java.util.List;

public class Chat {
    private String id;
    private String lastMessage;
    private Message.Type lastMessageType;
    private List<String> participantIds = new ArrayList<>();
    private List<FirebaseUser> participants = new ArrayList<>();
    private List<String> seenBy = new ArrayList<>();
    private Type type;
    @ServerTimestamp
    private Timestamp createdAt;
    @ServerTimestamp
    private Timestamp updatedAt;

    public Chat() {
    }

    private Chat(Builder builder) {
        setId(builder.id);
        setLastMessage(builder.lastMessage);
        setLastMessageType(builder.lastMessageType);
        setParticipantIds(builder.participantIds);
        setParticipants(builder.participants);
        setSeenBy(builder.seenBy);
        setType(builder.type);
        setCreatedAt(builder.createdAt);
        setUpdatedAt(builder.updatedAt);
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }

    public Message.Type getLastMessageType() {
        return lastMessageType;
    }

    public void setLastMessageType(Message.Type lastMessageType) {
        this.lastMessageType = lastMessageType;
    }

    public List<String> getParticipantIds() {
        return participantIds;
    }

    public void setParticipantIds(List<String> participantIds) {
        this.participantIds = participantIds;
    }

    public List<FirebaseUser> getParticipants() {
        return participants;
    }

    public void setParticipants(List<FirebaseUser> participants) {
        this.participants = participants;
    }

    public List<String> getSeenBy() {
        return seenBy;
    }

    public void setSeenBy(List<String> seenBy) {
        this.seenBy = seenBy;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Chat chat = (Chat) o;

        if (id != null ? !id.equals(chat.id) : chat.id != null) return false;
        if (lastMessage != null ? !lastMessage.equals(chat.lastMessage) : chat.lastMessage != null)
            return false;
        if (lastMessageType != chat.lastMessageType) return false;
        if (participantIds != null ? !participantIds.equals(chat.participantIds) : chat.participantIds != null)
            return false;
        if (participants != null ? !participants.equals(chat.participants) : chat.participants != null)
            return false;
        if (type != chat.type) return false;
        if (createdAt != null ? !createdAt.equals(chat.createdAt) : chat.createdAt != null)
            return false;
        return updatedAt != null ? updatedAt.equals(chat.updatedAt) : chat.updatedAt == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (lastMessage != null ? lastMessage.hashCode() : 0);
        result = 31 * result + (lastMessageType != null ? lastMessageType.hashCode() : 0);
        result = 31 * result + (participantIds != null ? participantIds.hashCode() : 0);
        result = 31 * result + (participants != null ? participants.hashCode() : 0);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (createdAt != null ? createdAt.hashCode() : 0);
        result = 31 * result + (updatedAt != null ? updatedAt.hashCode() : 0);
        return result;
    }

    public enum Type {
        PRIVATE, GROUP
    }

    public static final class Builder {
        private String id;
        private String lastMessage;
        private Message.Type lastMessageType;
        private List<String> participantIds = new ArrayList<>();
        private List<FirebaseUser> participants = new ArrayList<>();
        private List<String> seenBy = new ArrayList<>();
        private Type type;
        private Timestamp createdAt;
        private Timestamp updatedAt;

        private Builder() {
        }

        public Builder id(String id) {
            this.id = id;
            return this;
        }

        public Builder lastMessage(String lastMessage) {
            this.lastMessage = lastMessage;
            return this;
        }

        public Builder lastMessageType(Message.Type lastMessageType) {
            this.lastMessageType = lastMessageType;
            return this;
        }

        public Builder participantIds(List<String> participantIds) {
            this.participantIds = participantIds;
            return this;
        }

        public Builder participants(List<FirebaseUser> participants) {
            this.participants = participants;
            return this;
        }

        public Builder seenBy(List<String> seenBy) {
            this.seenBy = seenBy;
            return this;
        }

        public Builder type(Type type) {
            this.type = type;
            return this;
        }

        public Builder createdAt(Timestamp createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public Builder updatedAt(Timestamp updatedAt) {
            this.updatedAt = updatedAt;
            return this;
        }

        public Chat build() {
            return new Chat(this);
        }
    }
}
