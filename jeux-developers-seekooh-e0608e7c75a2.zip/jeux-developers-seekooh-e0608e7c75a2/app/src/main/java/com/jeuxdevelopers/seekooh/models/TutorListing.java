package com.jeuxdevelopers.seekooh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TutorListing {
    @SerializedName("seekoohId")
    @Expose
    private String seekoohId;
    @SerializedName("userId")
    @Expose
    private Integer userId;
    @SerializedName("fullName")
    @Expose
    private String fullName;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("gender")
    @Expose
    private Gender gender;
    @SerializedName("tutorId")
    @Expose
    private Integer tutorId;
    @SerializedName("profileImageUrl")
    @Expose
    private String profileImageUrl;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("reviewCount")
    @Expose
    private Integer reviewCount;
    @SerializedName("tagLine")
    @Expose
    private String tagLine;
    @SerializedName("lastSeen")
    @Expose
    private Long lastSeen;
    @SerializedName("isOnline")
    @Expose
    private Boolean isOnline;
    @SerializedName("isVerified")
    @Expose
    private Boolean isVerified;
    @SerializedName("teachOnline")
    @Expose
    private Boolean teachOnline;
    @SerializedName("teachAtLocation")
    @Expose
    private Boolean teachAtLocation;
    @SerializedName("city")
    @Expose
    private City city;
    @SerializedName("address")
    @Expose
    private Address address;
    @SerializedName("qualifications")
    @Expose
    private List<Qualification> qualifications;
    @SerializedName("experiences")
    @Expose
    private List<Experience> experiences;
    @SerializedName("teachesSubjects")
    @Expose
    private List<Subject> teachesSubjects;
    @SerializedName("teachesClasses")
    @Expose
    private List<Grade> teachesClasses;
    @SerializedName("teachesBoardExams")
    @Expose
    private List<Board> teachesBoardExams;
    @SerializedName("timeSlots")
    @Expose
    private List<TutorTimeSlot> timeSlots;
    @SerializedName("availableDays")
    @Expose
    private List<DayOfWeek> availableDays;

    public TutorListing() {
    }

    public String getSeekoohId() {
        return seekoohId;
    }

    public void setSeekoohId(String seekoohId) {
        this.seekoohId = seekoohId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public Integer getTutorId() {
        return tutorId;
    }

    public void setTutorId(Integer tutorId) {
        this.tutorId = tutorId;
    }

    public String getProfileImageUrl() {
        return profileImageUrl;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Integer getReviewCount() {
        return reviewCount;
    }

    public void setReviewCount(Integer reviewCount) {
        this.reviewCount = reviewCount;
    }

    public String getTagLine() {
        return tagLine;
    }

    public void setTagLine(String tagLine) {
        this.tagLine = tagLine;
    }

    public Long getLastSeen() {
        return lastSeen;
    }

    public void setLastSeen(Long lastSeen) {
        this.lastSeen = lastSeen;
    }

    public Boolean getOnline() {
        return isOnline;
    }

    public void setOnline(Boolean online) {
        isOnline = online;
    }

    public Boolean getVerified() {
        return isVerified;
    }

    public void setVerified(Boolean verified) {
        isVerified = verified;
    }

    public Boolean getTeachOnline() {
        return teachOnline;
    }

    public void setTeachOnline(Boolean teachOnline) {
        this.teachOnline = teachOnline;
    }

    public Boolean getTeachAtLocation() {
        return teachAtLocation;
    }

    public void setTeachAtLocation(Boolean teachAtLocation) {
        this.teachAtLocation = teachAtLocation;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public List<Qualification> getQualifications() {
        return qualifications;
    }

    public void setQualifications(List<Qualification> qualifications) {
        this.qualifications = qualifications;
    }

    public List<Experience> getExperiences() {
        return experiences;
    }

    public void setExperiences(List<Experience> experiences) {
        this.experiences = experiences;
    }

    public List<Subject> getTeachesSubjects() {
        return teachesSubjects;
    }

    public void setTeachesSubjects(List<Subject> teachesSubjects) {
        this.teachesSubjects = teachesSubjects;
    }

    public List<Grade> getTeachesClasses() {
        return teachesClasses;
    }

    public void setTeachesClasses(List<Grade> teachesClasses) {
        this.teachesClasses = teachesClasses;
    }

    public List<Board> getTeachesBoardExams() {
        return teachesBoardExams;
    }

    public void setTeachesBoardExams(List<Board> teachesBoardExams) {
        this.teachesBoardExams = teachesBoardExams;
    }

    public List<TutorTimeSlot> getTimeSlots() {
        return timeSlots;
    }

    public void setTimeSlots(List<TutorTimeSlot> timeSlots) {
        this.timeSlots = timeSlots;
    }

    public List<DayOfWeek> getAvailableDays() {
        return availableDays;
    }

    public void setAvailableDays(List<DayOfWeek> availableDays) {
        this.availableDays = availableDays;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TutorListing that = (TutorListing) o;

        if (seekoohId != null ? !seekoohId.equals(that.seekoohId) : that.seekoohId != null)
            return false;
        if (userId != null ? !userId.equals(that.userId) : that.userId != null) return false;
        if (fullName != null ? !fullName.equals(that.fullName) : that.fullName != null)
            return false;
        if (email != null ? !email.equals(that.email) : that.email != null) return false;
        if (phoneNumber != null ? !phoneNumber.equals(that.phoneNumber) : that.phoneNumber != null)
            return false;
        if (gender != null ? !gender.equals(that.gender) : that.gender != null) return false;
        if (tutorId != null ? !tutorId.equals(that.tutorId) : that.tutorId != null) return false;
        if (profileImageUrl != null ? !profileImageUrl.equals(that.profileImageUrl) : that.profileImageUrl != null)
            return false;
        if (rating != null ? !rating.equals(that.rating) : that.rating != null) return false;
        if (reviewCount != null ? !reviewCount.equals(that.reviewCount) : that.reviewCount != null)
            return false;
        if (tagLine != null ? !tagLine.equals(that.tagLine) : that.tagLine != null) return false;
        if (lastSeen != null ? !lastSeen.equals(that.lastSeen) : that.lastSeen != null)
            return false;
        if (isOnline != null ? !isOnline.equals(that.isOnline) : that.isOnline != null)
            return false;
        if (isVerified != null ? !isVerified.equals(that.isVerified) : that.isVerified != null)
            return false;
        if (teachOnline != null ? !teachOnline.equals(that.teachOnline) : that.teachOnline != null)
            return false;
        if (teachAtLocation != null ? !teachAtLocation.equals(that.teachAtLocation) : that.teachAtLocation != null)
            return false;
        if (city != null ? !city.equals(that.city) : that.city != null) return false;
        if (address != null ? !address.equals(that.address) : that.address != null) return false;
        if (qualifications != null ? !qualifications.equals(that.qualifications) : that.qualifications != null)
            return false;
        if (experiences != null ? !experiences.equals(that.experiences) : that.experiences != null)
            return false;
        if (teachesSubjects != null ? !teachesSubjects.equals(that.teachesSubjects) : that.teachesSubjects != null)
            return false;
        if (teachesClasses != null ? !teachesClasses.equals(that.teachesClasses) : that.teachesClasses != null)
            return false;
        if (teachesBoardExams != null ? !teachesBoardExams.equals(that.teachesBoardExams) : that.teachesBoardExams != null)
            return false;
        if (timeSlots != null ? !timeSlots.equals(that.timeSlots) : that.timeSlots != null)
            return false;
        return availableDays != null ? availableDays.equals(that.availableDays) : that.availableDays == null;
    }

    @Override
    public int hashCode() {
        int result = seekoohId != null ? seekoohId.hashCode() : 0;
        result = 31 * result + (userId != null ? userId.hashCode() : 0);
        result = 31 * result + (fullName != null ? fullName.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (phoneNumber != null ? phoneNumber.hashCode() : 0);
        result = 31 * result + (gender != null ? gender.hashCode() : 0);
        result = 31 * result + (tutorId != null ? tutorId.hashCode() : 0);
        result = 31 * result + (profileImageUrl != null ? profileImageUrl.hashCode() : 0);
        result = 31 * result + (rating != null ? rating.hashCode() : 0);
        result = 31 * result + (reviewCount != null ? reviewCount.hashCode() : 0);
        result = 31 * result + (tagLine != null ? tagLine.hashCode() : 0);
        result = 31 * result + (lastSeen != null ? lastSeen.hashCode() : 0);
        result = 31 * result + (isOnline != null ? isOnline.hashCode() : 0);
        result = 31 * result + (isVerified != null ? isVerified.hashCode() : 0);
        result = 31 * result + (teachOnline != null ? teachOnline.hashCode() : 0);
        result = 31 * result + (teachAtLocation != null ? teachAtLocation.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (address != null ? address.hashCode() : 0);
        result = 31 * result + (qualifications != null ? qualifications.hashCode() : 0);
        result = 31 * result + (experiences != null ? experiences.hashCode() : 0);
        result = 31 * result + (teachesSubjects != null ? teachesSubjects.hashCode() : 0);
        result = 31 * result + (teachesClasses != null ? teachesClasses.hashCode() : 0);
        result = 31 * result + (teachesBoardExams != null ? teachesBoardExams.hashCode() : 0);
        result = 31 * result + (timeSlots != null ? timeSlots.hashCode() : 0);
        result = 31 * result + (availableDays != null ? availableDays.hashCode() : 0);
        return result;
    }
}
