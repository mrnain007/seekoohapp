package com.jeuxdevelopers.seekooh.ui.tutor.fragments.verification;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.dto.VerificationFeeResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenRequest;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationStatusResponse;
import com.jeuxdevelopers.seekooh.repos.app.AppRepo;
import com.jeuxdevelopers.seekooh.repos.app.AppRepoImpl;

import java.net.URI;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class TutorVerificationViewModel extends ViewModel {
    private final CompositeDisposable disposables = new CompositeDisposable();
    private final AppRepo appRepo;

    public MutableLiveData<Resource<VerificationStatusResponse>> submitRequestLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<VerificationStatusResponse>> resubmitRequestLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<VerificationStatusResponse>> verificationStatusLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<VerificationPaymentTokenResponse>> verificationPaymentTokenLiveData = new MutableLiveData<>();
    public MutableLiveData<Resource<VerificationFeeResponse>> verificationFeeLiveData = new MutableLiveData<>();

    public TutorVerificationViewModel() {
        this.appRepo = new AppRepoImpl(disposables);
    }

    @Override
    protected void onCleared() {
        disposables.dispose();
        super.onCleared();
    }

    public void submitVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI degreeUri) {
        disposables.add(appRepo.submitTutorVerificationRequest(cnicFrontUri, cnicBackUri, degreeUri)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(verificationResource -> {
                    submitRequestLiveData.setValue(verificationResource);
                }, throwable -> {
                    submitRequestLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void resubmitVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI degreeUri) {
        disposables.add(appRepo.resubmitTutorVerificationRequest(cnicFrontUri, cnicBackUri, degreeUri)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(verificationResource -> {
                    resubmitRequestLiveData.setValue(verificationResource);
                }, throwable -> {
                    resubmitRequestLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getTutorVerificationStatus() {
        disposables.add(appRepo.getTutorVerificationStatus()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(verificationStatusResource -> {
                    verificationStatusLiveData.setValue(verificationStatusResource);
                }, throwable -> {
                    verificationStatusLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getTutorVerificationPaymentToken(@NonNull VerificationPaymentTokenRequest verificationPaymentTokenRequest) {
        disposables.add(appRepo.getTutorVerificationPaymentToken(verificationPaymentTokenRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(paymentTokenResource -> {
                    verificationPaymentTokenLiveData.setValue(paymentTokenResource);
                }, throwable -> {
                    verificationPaymentTokenLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }

    public void getTutorVerificationFee() {
        disposables.add(appRepo.getTutorVerificationFee()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(verificationFeeResource -> {
                    verificationFeeLiveData.setValue(verificationFeeResource);
                }, throwable -> {
                    verificationFeeLiveData.setValue(Resource.error(throwable.getMessage(), null));
                }));
    }
}
