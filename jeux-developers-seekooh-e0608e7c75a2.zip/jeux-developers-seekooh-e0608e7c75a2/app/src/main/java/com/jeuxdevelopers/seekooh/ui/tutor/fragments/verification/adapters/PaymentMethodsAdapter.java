package com.jeuxdevelopers.seekooh.ui.tutor.fragments.verification.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.databinding.ItemRcvPaymentMethodBinding;
import com.jeuxdevelopers.seekooh.databinding.ItemRcvSliderBinding;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenRequest;

public class PaymentMethodsAdapter extends ListAdapter<PaymentMethodsAdapter.PaymentMethod, PaymentMethodsAdapter.PaymentMethodViewHolder> {
    private static final DiffUtil.ItemCallback<PaymentMethod> DIFF_CALLBACK = new DiffUtil.ItemCallback<PaymentMethod>() {
        @Override
        public boolean areItemsTheSame(@NonNull PaymentMethod oldItem, @NonNull PaymentMethod newItem) {
            return oldItem.getPaymentMethod().equals(newItem.getPaymentMethod());
        }

        @Override
        public boolean areContentsTheSame(@NonNull PaymentMethod oldItem, @NonNull PaymentMethod newItem) {
            return oldItem.equals(newItem);
        }
    };

//    private final Listener listener;
    private VerificationPaymentTokenRequest.PaymentMethod selectedPaymentMethod = VerificationPaymentTokenRequest.PaymentMethod.CARD;

    public PaymentMethodsAdapter() {
        super(DIFF_CALLBACK);
    }

    public VerificationPaymentTokenRequest.PaymentMethod getSelectedPaymentMethod() {
        return selectedPaymentMethod;
    }

    @NonNull
    @Override
    public PaymentMethodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemRcvPaymentMethodBinding binding = ItemRcvPaymentMethodBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new PaymentMethodViewHolder(binding);
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onBindViewHolder(@NonNull PaymentMethodViewHolder holder, int position) {
        PaymentMethod model = getItem(position);
        holder.bind(model);
        if (model.getPaymentMethod() == selectedPaymentMethod) {
            holder.binding.cl.setBackgroundResource(R.drawable.payment_method_item_bg);
        } else {
            holder.binding.cl.setBackgroundResource(0);
        }
        holder.binding.getRoot().setOnClickListener(v -> {
            selectedPaymentMethod = getItem(position).getPaymentMethod();
            notifyDataSetChanged();
        });
    }

    public static class PaymentMethodViewHolder extends RecyclerView.ViewHolder {
        private final ItemRcvPaymentMethodBinding binding;

        public PaymentMethodViewHolder(ItemRcvPaymentMethodBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(PaymentMethod model) {
            Context context = binding.getRoot().getContext();
            binding.imageView.setImageDrawable(model.getIcon());
        }
    }

    public interface Listener {
        void onItemClicked(PaymentMethod data, int position);
    }

    public static class PaymentMethod {
        private VerificationPaymentTokenRequest.PaymentMethod paymentMethod;
        private Drawable icon;

        public PaymentMethod() {
        }

        public PaymentMethod(VerificationPaymentTokenRequest.PaymentMethod paymentMethod, Drawable icon) {
            this.paymentMethod = paymentMethod;
            this.icon = icon;
        }

        private PaymentMethod(Builder builder) {
            setPaymentMethod(builder.paymentMethod);
            setIcon(builder.icon);
        }

        public static Builder builder() {
            return new Builder();
        }

        public VerificationPaymentTokenRequest.PaymentMethod getPaymentMethod() {
            return paymentMethod;
        }

        public void setPaymentMethod(VerificationPaymentTokenRequest.PaymentMethod paymentMethod) {
            this.paymentMethod = paymentMethod;
        }

        public Drawable getIcon() {
            return icon;
        }

        public void setIcon(Drawable icon) {
            this.icon = icon;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            PaymentMethod that = (PaymentMethod) o;

            if (paymentMethod != that.paymentMethod) return false;
            return icon != null ? icon.equals(that.icon) : that.icon == null;
        }

        @Override
        public int hashCode() {
            int result = paymentMethod != null ? paymentMethod.hashCode() : 0;
            result = 31 * result + (icon != null ? icon.hashCode() : 0);
            return result;
        }

        public static final class Builder {
            private VerificationPaymentTokenRequest.PaymentMethod paymentMethod;
            private Drawable icon;

            private Builder() {
            }

            public Builder paymentMethod(VerificationPaymentTokenRequest.PaymentMethod paymentMethod) {
                this.paymentMethod = paymentMethod;
                return this;
            }

            public Builder icon(Drawable icon) {
                this.icon = icon;
                return this;
            }

            public PaymentMethod build() {
                return new PaymentMethod(this);
            }
        }
    }
}
