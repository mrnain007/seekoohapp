package com.jeuxdevelopers.seekooh.models;

public class AdModel {
    private String bannerImageUrl;
    private String url;

    public AdModel() {
    }

    public AdModel(String bannerImageUrl, String url) {
        this.bannerImageUrl = bannerImageUrl;
        this.url = url;
    }

    public String getBannerImageUrl() {
        return bannerImageUrl;
    }

    public void setBannerImageUrl(String bannerImageUrl) {
        this.bannerImageUrl = bannerImageUrl;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
