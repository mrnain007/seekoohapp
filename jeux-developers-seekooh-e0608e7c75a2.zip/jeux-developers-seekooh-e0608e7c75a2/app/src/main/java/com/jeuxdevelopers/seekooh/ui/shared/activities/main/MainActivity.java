package com.jeuxdevelopers.seekooh.ui.shared.activities.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.NavOptions;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import com.jeuxdevelopers.seekooh.R;
import com.jeuxdevelopers.seekooh.app.App;
import com.jeuxdevelopers.seekooh.databinding.ActivityMainBinding;
import com.jeuxdevelopers.seekooh.models.AppSettings;
import com.jeuxdevelopers.seekooh.models.InstituteProfile;
import com.jeuxdevelopers.seekooh.models.Notification;
import com.jeuxdevelopers.seekooh.models.Role;
import com.jeuxdevelopers.seekooh.models.User;
import com.jeuxdevelopers.seekooh.models.dto.AuthenticationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TokenRefreshRequest;
import com.jeuxdevelopers.seekooh.models.dto.TokenRefreshResponse;
import com.jeuxdevelopers.seekooh.ui.shared.activities.chat.ChatActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.chat.ChatViewModel;
import com.jeuxdevelopers.seekooh.ui.shared.activities.jobs.PostJobActivity;
import com.jeuxdevelopers.seekooh.ui.shared.activities.tuitions.PostTuitionActivity;
import com.jeuxdevelopers.seekooh.utils.Constants;
import com.jeuxdevelopers.seekooh.utils.UserPrefs;
import com.jeuxdevelopers.seekooh.utils.Utils;

import java.util.Optional;

public class MainActivity extends AppCompatActivity {

    private MainViewModel viewModel;
    private ActivityMainBinding binding;
    private NavController navController;
    public Long searchTuitionId;
    public Long searchJobId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);
        initNavController();
        initBottomNav();
        initClickListeners();
        getArgs();
        initObservers();
        tokenRefresh();
    }

    private void tokenRefresh() {
        User user = UserPrefs.getUser(this);
        if (user == null) {
            return;
        }

        TokenRefreshRequest tokenRefreshRequest = TokenRefreshRequest.builder()
                .refreshToken(user.getRefreshToken())
                .build();
        viewModel.tokenRefresh(tokenRefreshRequest);
    }

    private void initObservers() {
        viewModel.tokenRefreshLiveData
                .observe(this, tokenRefreshResource -> {
                    switch (tokenRefreshResource.getStatus()) {
                        case ERROR:
                            Utils.showToast(this, tokenRefreshResource.getMessage());
                            break;
                        case LOADING:
                            break;
                        case SUCCESS:
                            User oldUser = UserPrefs.getUser(this);
                            TokenRefreshResponse tokenRefreshResponse = tokenRefreshResource.getData();
                            User user = Utils.dtoToUser(tokenRefreshResponse);
                            if (oldUser != null) {
                                user.setAppSettings(oldUser.getAppSettings());
                            }
                            UserPrefs.saveUser(this, user);
                            break;
                    }
                });
    }

    private void getArgs() {
        String gotoInboxStr = getIntent().getStringExtra(Constants.GOTO_INBOX);
        long tuitionIdArg = getIntent().getLongExtra(Constants.SEARCH_TUITION_ID, -1);
        long jobIdArg = getIntent().getLongExtra(Constants.SEARCH_JOB_ID, -1);
        if (gotoInboxStr != null) {
            binding.bottomNav.setSelectedItemId(R.id.inboxFragment);
        }
        if (tuitionIdArg != -1) {
            searchTuitionId = tuitionIdArg;
        }
        if (jobIdArg != -1) {
            searchJobId = jobIdArg;
            binding.bottomNav.setSelectedItemId(R.id.settingsFragment);
        }
    }

    private void initClickListeners() {
        binding.navFab.setOnClickListener(v -> {
            User user = UserPrefs.getUser(this);
            if (user == null) {
                Utils.showToast(this, "Only logged in users can post ad!");
                return;
            }

            Role selectedRole = user.getAppSettings().getSelectedRole();
            switch (selectedRole.getName()) {
                case Constants.ROLE_STUDENT:
                    Intent intent1 = new Intent(this, PostTuitionActivity.class);
                    intent1.putExtra(Constants.POST_TUITION_AD, "true");
                    startActivity(intent1);
                    break;
                case Constants.ROLE_TUTOR:
                    boolean isTutorVerified = user.getTutorProfile().getVerified();
                    if (isTutorVerified) {
                        navController.navigate(R.id.createCourseFragment);
                    } else {
                        Utils.showToast(this, "Only verified tutors can create courses!");
                    }
                    break;
                case Constants.ROLE_INSTITUTE:
                    boolean isInstituteVerified = user.getInstituteProfile().getVerified();
                    if (isInstituteVerified) {
                        Intent intent2 = new Intent(this, PostJobActivity.class);
                        intent2.putExtra(Constants.POST_JOB_AD, "true");
                        startActivity(intent2);
                    } else {
                        Utils.showToast(this, "Only verified institutes can post jobs!");
                    }
                    break;
            }

        });
    }

    private void initNavController() {
        final NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_container_view);
        navController = navHostFragment.getNavController();
        NavigationUI.setupWithNavController(binding.bottomNav, navController);
    }

    private void initBottomNav() {
        navController.addOnDestinationChangedListener((navController, navDestination, bundle) -> {
            int destinationId = navDestination.getId();
            if (destinationId == R.id.homeFragment ||
                    destinationId == R.id.inboxFragment ||
                    destinationId == R.id.notificationFragment ||
                    destinationId == R.id.settingsFragment) {
                binding.bottomNavGroup.setVisibility(View.VISIBLE);
            } else {
                binding.bottomNavGroup.setVisibility(View.GONE);
            }
        });
    }

    public void handleNotificationClick(Notification notification) {
        switch (notification.getType()) {
            case UNREAD_MESSAGE:
                String chatId = notification.getChatId();
                Intent intent = new Intent(this, ChatActivity.class);
                intent.putExtra(Constants.Firebase.CHAT_ID, chatId);
                binding.bottomNav.setSelectedItemId(R.id.inboxFragment);
                break;
            case TUITION_MATCH:
                searchTuitionId = notification.getTuitionId();
                binding.bottomNav.setSelectedItemId(R.id.homeFragment);
                break;
            case JOB_MATCH:
                searchJobId = notification.getJobId();
                binding.bottomNav.setSelectedItemId(R.id.settingsFragment);
                break;
        }
    }
}