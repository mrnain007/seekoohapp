package com.jeuxdevelopers.seekooh.models.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.jeuxdevelopers.seekooh.models.Experience;
import com.jeuxdevelopers.seekooh.models.Qualification;

import java.util.List;

public class EditTeachingJobRequest {
    @SerializedName("isOnline")
    @Expose
    private Boolean isOnline;
    @SerializedName("isInPerson")
    @Expose
    private Boolean isInPerson;
    @SerializedName("verifiedTutorsOnly")
    @Expose
    private Boolean verifiedTutorsOnly;
    @SerializedName("jobTitle")
    @Expose
    private String jobTitle;
    @SerializedName("area")
    @Expose
    private String area;
    @SerializedName("jobDescription")
    @Expose
    private String jobDescription;
    @SerializedName("languageSkills")
    @Expose
    private String languageSkills;
    @SerializedName("expertise")
    @Expose
    private String expertise;
    @SerializedName("salaryAmount")
    @Expose
    private Double salaryAmount;
    @SerializedName("cityId")
    @Expose
    private Integer cityId;
    @SerializedName("benefits")
    @Expose
    private List<String> benefits;
    @SerializedName("contractType")
    @Expose
    private ContractType contractType;
    @SerializedName("subjectIds")
    @Expose
    private List<Integer> subjectIds;
    @SerializedName("suggestedSubjects")
    @Expose
    private List<String> suggestedSubjects;
    @SerializedName("gradeIds")
    @Expose
    private List<Integer> gradeIds;
    @SerializedName("suggestedGrades")
    @Expose
    private List<String> suggestedGrades;
    @SerializedName("qualification")
    @Expose
    private Qualification qualification;
    @SerializedName("experience")
    @Expose
    private Experience experience;
    @SerializedName("tutorGenderId")
    @Expose
    private Integer tutorGenderId;

    public EditTeachingJobRequest() {
    }

    private EditTeachingJobRequest(Builder builder) {
        isOnline = builder.isOnline;
        isInPerson = builder.isInPerson;
        setVerifiedTutorsOnly(builder.verifiedTutorsOnly);
        setJobTitle(builder.jobTitle);
        setArea(builder.area);
        setJobDescription(builder.jobDescription);
        setLanguageSkills(builder.languageSkills);
        setExpertise(builder.expertise);
        setSalaryAmount(builder.salaryAmount);
        setCityId(builder.cityId);
        setBenefits(builder.benefits);
        setContractType(builder.contractType);
        setSubjectIds(builder.subjectIds);
        setSuggestedSubjects(builder.suggestedSubjects);
        setGradeIds(builder.gradeIds);
        setSuggestedGrades(builder.suggestedGrades);
        setQualification(builder.qualification);
        setExperience(builder.experience);
        setTutorGenderId(builder.tutorGenderId);
    }

    public static Builder builder() {
        return new Builder();
    }

    public Boolean getOnline() {
        return isOnline;
    }

    public void setOnline(Boolean online) {
        isOnline = online;
    }

    public Boolean getInPerson() {
        return isInPerson;
    }

    public void setInPerson(Boolean inPerson) {
        isInPerson = inPerson;
    }

    public Boolean getVerifiedTutorsOnly() {
        return verifiedTutorsOnly;
    }

    public void setVerifiedTutorsOnly(Boolean verifiedTutorsOnly) {
        this.verifiedTutorsOnly = verifiedTutorsOnly;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public String getLanguageSkills() {
        return languageSkills;
    }

    public void setLanguageSkills(String languageSkills) {
        this.languageSkills = languageSkills;
    }

    public String getExpertise() {
        return expertise;
    }

    public void setExpertise(String expertise) {
        this.expertise = expertise;
    }

    public Double getSalaryAmount() {
        return salaryAmount;
    }

    public void setSalaryAmount(Double salaryAmount) {
        this.salaryAmount = salaryAmount;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public List<String> getBenefits() {
        return benefits;
    }

    public void setBenefits(List<String> benefits) {
        this.benefits = benefits;
    }

    public ContractType getContractType() {
        return contractType;
    }

    public void setContractType(ContractType contractType) {
        this.contractType = contractType;
    }

    public List<Integer> getSubjectIds() {
        return subjectIds;
    }

    public void setSubjectIds(List<Integer> subjectIds) {
        this.subjectIds = subjectIds;
    }

    public List<String> getSuggestedSubjects() {
        return suggestedSubjects;
    }

    public void setSuggestedSubjects(List<String> suggestedSubjects) {
        this.suggestedSubjects = suggestedSubjects;
    }

    public List<Integer> getGradeIds() {
        return gradeIds;
    }

    public void setGradeIds(List<Integer> gradeIds) {
        this.gradeIds = gradeIds;
    }

    public List<String> getSuggestedGrades() {
        return suggestedGrades;
    }

    public void setSuggestedGrades(List<String> suggestedGrades) {
        this.suggestedGrades = suggestedGrades;
    }

    public Qualification getQualification() {
        return qualification;
    }

    public void setQualification(Qualification qualification) {
        this.qualification = qualification;
    }

    public Experience getExperience() {
        return experience;
    }

    public void setExperience(Experience experience) {
        this.experience = experience;
    }

    public Integer getTutorGenderId() {
        return tutorGenderId;
    }

    public void setTutorGenderId(Integer tutorGenderId) {
        this.tutorGenderId = tutorGenderId;
    }

    public enum ContractType {
        TEMPORARY,
        PERMANENT,
        FIXED_TERM,
        PART_TIME,
        SUBSTITUTE,
        VISITING_FACULTY
    }

    public static final class Builder {
        private Boolean isOnline;
        private Boolean isInPerson;
        private Boolean verifiedTutorsOnly;
        private String jobTitle;
        private String area;
        private String jobDescription;
        private String languageSkills;
        private String expertise;
        private Double salaryAmount;
        private Integer cityId;
        private List<String> benefits;
        private ContractType contractType;
        private List<Integer> subjectIds;
        private List<String> suggestedSubjects;
        private List<Integer> gradeIds;
        private List<String> suggestedGrades;
        private Qualification qualification;
        private Experience experience;
        private Integer tutorGenderId;

        private Builder() {
        }

        public Builder isOnline(Boolean isOnline) {
            this.isOnline = isOnline;
            return this;
        }

        public Builder isInPerson(Boolean isInPerson) {
            this.isInPerson = isInPerson;
            return this;
        }

        public Builder verifiedTutorsOnly(Boolean verifiedTutorsOnly) {
            this.verifiedTutorsOnly = verifiedTutorsOnly;
            return this;
        }

        public Builder jobTitle(String jobTitle) {
            this.jobTitle = jobTitle;
            return this;
        }

        public Builder area(String area) {
            this.area = area;
            return this;
        }

        public Builder jobDescription(String jobDescription) {
            this.jobDescription = jobDescription;
            return this;
        }

        public Builder languageSkills(String languageSkills) {
            this.languageSkills = languageSkills;
            return this;
        }

        public Builder expertise(String expertise) {
            this.expertise = expertise;
            return this;
        }

        public Builder salaryAmount(Double salaryAmount) {
            this.salaryAmount = salaryAmount;
            return this;
        }

        public Builder cityId(Integer cityId) {
            this.cityId = cityId;
            return this;
        }

        public Builder benefits(List<String> benefits) {
            this.benefits = benefits;
            return this;
        }

        public Builder contractType(ContractType contractType) {
            this.contractType = contractType;
            return this;
        }

        public Builder subjectIds(List<Integer> subjectIds) {
            this.subjectIds = subjectIds;
            return this;
        }

        public Builder suggestedSubjects(List<String> suggestedSubjects) {
            this.suggestedSubjects = suggestedSubjects;
            return this;
        }

        public Builder gradeIds(List<Integer> gradeIds) {
            this.gradeIds = gradeIds;
            return this;
        }

        public Builder suggestedGrades(List<String> suggestedGrades) {
            this.suggestedGrades = suggestedGrades;
            return this;
        }

        public Builder qualification(Qualification qualification) {
            this.qualification = qualification;
            return this;
        }

        public Builder experience(Experience experience) {
            this.experience = experience;
            return this;
        }

        public Builder tutorGenderId(Integer tutorGenderId) {
            this.tutorGenderId = tutorGenderId;
            return this;
        }

        public EditTeachingJobRequest build() {
            return new EditTeachingJobRequest(this);
        }
    }
}
