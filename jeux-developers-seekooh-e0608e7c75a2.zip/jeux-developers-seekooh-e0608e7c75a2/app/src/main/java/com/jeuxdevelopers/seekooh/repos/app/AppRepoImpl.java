package com.jeuxdevelopers.seekooh.repos.app;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.jeuxdevelopers.seekooh.models.Board;
import com.jeuxdevelopers.seekooh.models.City;
import com.jeuxdevelopers.seekooh.models.Course;
import com.jeuxdevelopers.seekooh.models.CourseListing;
import com.jeuxdevelopers.seekooh.models.CourseReview;
import com.jeuxdevelopers.seekooh.models.Grade;
import com.jeuxdevelopers.seekooh.models.InstituteDetails;
import com.jeuxdevelopers.seekooh.models.InstituteReview;
import com.jeuxdevelopers.seekooh.models.InstituteType;
import com.jeuxdevelopers.seekooh.models.Resource;
import com.jeuxdevelopers.seekooh.models.SalaryType;
import com.jeuxdevelopers.seekooh.models.Subject;
import com.jeuxdevelopers.seekooh.models.TeachingJob;
import com.jeuxdevelopers.seekooh.models.Tuition;
import com.jeuxdevelopers.seekooh.models.TutorDetails;
import com.jeuxdevelopers.seekooh.models.TutorReview;
import com.jeuxdevelopers.seekooh.models.dto.AdSettingsResponse;
import com.jeuxdevelopers.seekooh.models.dto.CourseEnrollmentResponse;
import com.jeuxdevelopers.seekooh.models.dto.CreateCourseRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateCourseReviewRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateInstituteReviewRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateTeachingJobRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateTuitionRequest;
import com.jeuxdevelopers.seekooh.models.dto.CreateTutorReviewRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditCourseRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditPrivacySettingsRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditTeachingJobRequest;
import com.jeuxdevelopers.seekooh.models.dto.EditTuitionRequest;
import com.jeuxdevelopers.seekooh.models.dto.GetProfileResponse;
import com.jeuxdevelopers.seekooh.models.dto.PrivacySettingsResponse;
import com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationRequest;
import com.jeuxdevelopers.seekooh.models.dto.TeachingJobApplicationResponse;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationRequest;
import com.jeuxdevelopers.seekooh.models.dto.TuitionApplicationResponse;
import com.jeuxdevelopers.seekooh.models.dto.UpdateInstituteProfileRequest;
import com.jeuxdevelopers.seekooh.models.dto.UpdateStudentProfileRequest;
import com.jeuxdevelopers.seekooh.models.dto.UpdateTutorProfileRequest;
import com.jeuxdevelopers.seekooh.models.dto.VerificationFeeResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenRequest;
import com.jeuxdevelopers.seekooh.models.dto.VerificationPaymentTokenResponse;
import com.jeuxdevelopers.seekooh.models.dto.VerificationStatusResponse;
import com.jeuxdevelopers.seekooh.network.SeekoohService;
import com.jeuxdevelopers.seekooh.network.ServiceUtils;
import com.jeuxdevelopers.seekooh.utils.NetworkUtils;

import java.net.URI;
import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.schedulers.Schedulers;
import okhttp3.MultipartBody;

public class AppRepoImpl implements AppRepo {
    private final SeekoohService seekoohService;
    private final CompositeDisposable disposables;

    public AppRepoImpl(CompositeDisposable disposables) {
        this.disposables = disposables;
        seekoohService = ServiceUtils.createSeekoohService(SeekoohService.class);
    }

    @Override
    public Observable<Resource<List<Board>>> getBoards() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Boards list is being fetched.", null));
            disposables.add(seekoohService.getBoards()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getBoardsResponse -> {
                        if (NetworkUtils.isValidResponse(getBoardsResponse)) {
                            emitter.onNext(Resource.success(getBoardsResponse.getMessage("Boards list fetched successfully."), getBoardsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getBoardsResponse.getMessage("Failed to fetch boards list."), null));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch boards list.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<City>>> getCities() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Cities list is being fetched.", null));
            disposables.add(seekoohService.getCities()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getCitiesResponse -> {
                        if (NetworkUtils.isValidResponse(getCitiesResponse)) {
                            emitter.onNext(Resource.success(getCitiesResponse.getMessage("Cities list fetched successfully."), getCitiesResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getCitiesResponse.getMessage("Failed to fetch Cities list."), null));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch Cities list.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<Grade>>> getGrades() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Grades list is being fetched.", null));
            disposables.add(seekoohService.getGrades()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getGradesResponse -> {
                        if (NetworkUtils.isValidResponse(getGradesResponse)) {
                            emitter.onNext(Resource.success(getGradesResponse.getMessage("Grades list fetched successfully."), getGradesResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getGradesResponse.getMessage("Failed to fetch Grades list."), getGradesResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch Grades list.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<Subject>>> getSubjects() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Subjects list is being fetched.", null));
            disposables.add(seekoohService.getSubjects()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getSubjectsResponse -> {
                        if (NetworkUtils.isValidResponse(getSubjectsResponse)) {
                            emitter.onNext(Resource.success(getSubjectsResponse.getMessage("Subjects list fetched successfully."), getSubjectsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getSubjectsResponse.getMessage("Failed to fetch subjects list."), getSubjectsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch subjects list.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<InstituteType>>> getInstituteTypes() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Institute type list is being fetched.", null));
            disposables.add(seekoohService.getInstituteTypes()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getSubjectsResponse -> {
                        if (NetworkUtils.isValidResponse(getSubjectsResponse)) {
                            emitter.onNext(Resource.success(getSubjectsResponse.getMessage("Institute type list fetched successfully."), getSubjectsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getSubjectsResponse.getMessage("Failed to fetch institute type list."), getSubjectsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch institute type list.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<SalaryType>>> getSalaryTypes() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Salary type list is being fetched.", null));
            disposables.add(seekoohService.getSalaryTypes()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getSalaryTypesResponse -> {
                        if (NetworkUtils.isValidResponse(getSalaryTypesResponse)) {
                            emitter.onNext(Resource.success(getSalaryTypesResponse.getMessage("Salary type list fetched successfully."), getSalaryTypesResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getSalaryTypesResponse.getMessage("Failed to fetch salary type list."), getSalaryTypesResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch salary type list.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<TutorDetails>> getTutorDetails(@NonNull Integer tutorId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Tutor details is being fetched.", null));
            disposables.add(seekoohService.getTutorListingDetails(tutorId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getTutorDetailsResponse -> {
                        if (NetworkUtils.isValidResponse(getTutorDetailsResponse)) {
                            emitter.onNext(Resource.success(getTutorDetailsResponse.getMessage("Tutor details fetched successfully."), getTutorDetailsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getTutorDetailsResponse.getMessage("Failed to fetch tutor details."), getTutorDetailsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch tutor details.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<TutorReview>>> getTutorReviews(@NonNull Integer tutorId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Tutor reviews is being fetched.", null));
            disposables.add(seekoohService.getTutorReviews(tutorId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getTutorReviewsResponse -> {
                        if (NetworkUtils.isValidResponse(getTutorReviewsResponse)) {
                            emitter.onNext(Resource.success(getTutorReviewsResponse.getMessage("Tutor reviews fetched successfully."), getTutorReviewsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getTutorReviewsResponse.getMessage("Failed to fetch tutor reviews."), getTutorReviewsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch tutor reviews.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<TutorReview>> createTutorReview(@NonNull Integer tutorId, @NonNull CreateTutorReviewRequest createTutorReviewRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Review is being submitted.", null));
            disposables.add(seekoohService.createTutorReview(tutorId, createTutorReviewRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(createTutorReviewResponse -> {
                        if (NetworkUtils.isValidResponse(createTutorReviewResponse)) {
                            emitter.onNext(Resource.success(createTutorReviewResponse.getMessage("Review submitted successfully."), createTutorReviewResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(createTutorReviewResponse.getMessage("Failed to submit review."), createTutorReviewResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit review.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<GetProfileResponse>> getProfile() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Profile is being fetched.", null));
            disposables.add(seekoohService.getProfile()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getSubjectsResponse -> {
                        if (NetworkUtils.isValidResponse(getSubjectsResponse)) {
                            emitter.onNext(Resource.success(getSubjectsResponse.getMessage("Profile fetched successfully."), getSubjectsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getSubjectsResponse.getMessage("Failed to fetch profile."), getSubjectsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch profile.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<GetProfileResponse>> updateStudentProfile(@Nullable URI studentProfileImageUri, @NonNull UpdateStudentProfileRequest updateStudentProfileRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Profile update request is being processed.", null));
            MultipartBody.Part studentProfileImage = studentProfileImageUri != null ?
                    NetworkUtils.uriToMultipartImage(studentProfileImageUri, "studentProfileImage") : null;
            disposables.add(seekoohService.updateStudentProfile(studentProfileImage, updateStudentProfileRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(updateStudentProfileResponse -> {
                        if (NetworkUtils.isValidResponse(updateStudentProfileResponse)) {
                            emitter.onNext(Resource.success(updateStudentProfileResponse.getMessage("Profile updated successfully."), updateStudentProfileResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(updateStudentProfileResponse.getMessage("Failed to update profile."), updateStudentProfileResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to update profile.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<GetProfileResponse>> updateTutorProfile(@Nullable URI tutorProfileImageUri, @Nullable URI tutorProfileVideoUri, @NonNull UpdateTutorProfileRequest updateTutorProfileRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Profile update request is being processed.", null));

            MultipartBody.Part tutorProfileImage = tutorProfileImageUri != null ?
                    NetworkUtils.uriToMultipartImage(tutorProfileImageUri, "tutorProfileImage") : null;

            MultipartBody.Part tutorProfileVideo = tutorProfileVideoUri != null ?
                    NetworkUtils.uriToMultipartVideo(tutorProfileVideoUri, "tutorProfileVideo") : null;

            disposables.add(seekoohService.updateTutorProfile(tutorProfileImage, tutorProfileVideo, updateTutorProfileRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(updateTutorProfileResponse -> {
                        if (NetworkUtils.isValidResponse(updateTutorProfileResponse)) {
                            emitter.onNext(Resource.success(updateTutorProfileResponse.getMessage("Profile updated successfully."), updateTutorProfileResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(updateTutorProfileResponse.getMessage("Failed to update profile."), updateTutorProfileResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to update profile.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<GetProfileResponse>> updateInstituteProfile(@Nullable URI instituteProfileImageUri, @NonNull UpdateInstituteProfileRequest updateInstituteProfileRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Profile update request is being processed.", null));

            MultipartBody.Part instituteProfileImage = instituteProfileImageUri != null ?
                    NetworkUtils.uriToMultipartImage(instituteProfileImageUri, "instituteProfileImage") : null;

            disposables.add(seekoohService.updateInstituteProfile(instituteProfileImage, updateInstituteProfileRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(updateInstituteProfileResponse -> {
                        if (NetworkUtils.isValidResponse(updateInstituteProfileResponse)) {
                            emitter.onNext(Resource.success(updateInstituteProfileResponse.getMessage("Profile updated successfully."), updateInstituteProfileResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(updateInstituteProfileResponse.getMessage("Failed to update profile."), updateInstituteProfileResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to update profile.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<Tuition>> createTuition(@NonNull CreateTuitionRequest createTuitionRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Tuition request is being submitted.", null));
            disposables.add(seekoohService.createTuition(createTuitionRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(createTuitionResponse -> {
                        if (NetworkUtils.isValidResponse(createTuitionResponse)) {
                            emitter.onNext(Resource.success(createTuitionResponse.getMessage("Tuition request submitted successfully."), createTuitionResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(createTuitionResponse.getMessage("Failed to submit tuition request."), createTuitionResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit tuition request.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<Tuition>> getTuitionById(@NonNull Integer tuitionId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Tuition details is being fetched.", null));
            disposables.add(seekoohService.getTuitionById(tuitionId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getTuitionDetailsResponse -> {
                        if (NetworkUtils.isValidResponse(getTuitionDetailsResponse)) {
                            emitter.onNext(Resource.success(getTuitionDetailsResponse.getMessage("Tuition details fetched successfully."), getTuitionDetailsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getTuitionDetailsResponse.getMessage("Failed to fetch tuition details."), getTuitionDetailsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch tuition details.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<Tuition>>> getMyTuitions() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Posted tuitions is being fetched.", null));
            disposables.add(seekoohService.getMyTuitions()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getMyTuitionsResponse -> {
                        if (NetworkUtils.isValidResponse(getMyTuitionsResponse)) {
                            emitter.onNext(Resource.success(getMyTuitionsResponse.getMessage("Posted tuitions fetched successfully."), getMyTuitionsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getMyTuitionsResponse.getMessage("Failed to fetch posted tuitions."), getMyTuitionsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch tuition details.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<Tuition>> editTuition(@NonNull Integer tuitionId, @NonNull EditTuitionRequest editTuitionRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Update tuition request is being processed.", null));
            disposables.add(seekoohService.editTuition(tuitionId, editTuitionRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(editTuitionResponse -> {
                        if (NetworkUtils.isValidResponse(editTuitionResponse)) {
                            emitter.onNext(Resource.success(editTuitionResponse.getMessage("Tuition updated successfully."), editTuitionResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(editTuitionResponse.getMessage("Failed to update tuition."), editTuitionResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to update tuition..");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<Void>> deleteTuition(@NonNull Integer tuitionId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Tuition deletion request is being processed.", null));
            disposables.add(seekoohService.deleteTuition(tuitionId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(deleteTuitionResponse -> {
                        emitter.onNext(Resource.success(deleteTuitionResponse.getMessage("Tuition deleted successfully."), deleteTuitionResponse.getData()));
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to delete tuition..");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<TuitionApplicationResponse>> applyToTuition(@NonNull Integer tuitionId, @NonNull TuitionApplicationRequest tuitionApplicationRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Tuition application is being processed.", null));
            disposables.add(seekoohService.applyToTuition(tuitionId, tuitionApplicationRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(applyToTuitionResponse -> {
                        if (NetworkUtils.isValidResponse(applyToTuitionResponse)) {
                            emitter.onNext(Resource.success(applyToTuitionResponse.getMessage("Tuition application submitted successfully."), applyToTuitionResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(applyToTuitionResponse.getMessage("Failed to submit tuition application."), applyToTuitionResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit tuition application.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<Void>> deleteTuitionApplication(@NonNull Integer tuitionId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Application withdrawal request is being processed.", null));
            disposables.add(seekoohService.deleteTuitionApplication(tuitionId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(withdrawalResponse -> {
                        emitter.onNext(Resource.success(withdrawalResponse.getMessage("Application withdrawal successful."), withdrawalResponse.getData()));
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to withdraw application.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<TuitionApplicationResponse>>> getAppliedTuitions() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Tuition applications are being fetched.", null));
            disposables.add(seekoohService.getAppliedTuitions()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(appliedTuitionsResponse -> {
                        if (NetworkUtils.isValidResponse(appliedTuitionsResponse)) {
                            emitter.onNext(Resource.success(appliedTuitionsResponse.getMessage("Tuition applications fetched successfully."), appliedTuitionsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(appliedTuitionsResponse.getMessage("Failed to fetch tuition applications."), appliedTuitionsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch tuition applications.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<Course>> createCourse(@NonNull CreateCourseRequest createCourseRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Course is being submitted.", null));
            disposables.add(seekoohService.createCourse(createCourseRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(createCourseResponse -> {
                        if (NetworkUtils.isValidResponse(createCourseResponse)) {
                            emitter.onNext(Resource.success(createCourseResponse.getMessage("Course submitted successfully."), createCourseResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(createCourseResponse.getMessage("Failed to submit course."), createCourseResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit course.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<Course>>> getMyCourses() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Posted courses is being fetched.", null));
            disposables.add(seekoohService.getMyCourses()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getMyCoursesResponse -> {
                        if (NetworkUtils.isValidResponse(getMyCoursesResponse)) {
                            emitter.onNext(Resource.success(getMyCoursesResponse.getMessage("Posted courses fetched successfully."), getMyCoursesResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getMyCoursesResponse.getMessage("Failed to fetch posted courses."), getMyCoursesResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch posted courses.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<Course>> editCourse(@NonNull Integer courseId, @NonNull EditCourseRequest editCourseRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Update course request is being processed.", null));
            disposables.add(seekoohService.editCourse(courseId, editCourseRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(editCourseResponse -> {
                        if (NetworkUtils.isValidResponse(editCourseResponse)) {
                            emitter.onNext(Resource.success(editCourseResponse.getMessage("Course updated successfully."), editCourseResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(editCourseResponse.getMessage("Failed to update course."), editCourseResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to update course..");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<Void>> deleteCourse(@NonNull Integer courseId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Course deletion request is being processed.", null));
            disposables.add(seekoohService.deleteCourse(courseId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(deleteCourseResponse -> {
                        emitter.onNext(Resource.success(deleteCourseResponse.getMessage("Course deleted successfully."), deleteCourseResponse.getData()));
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to delete course..");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<Course>> getCourseDetailsById(@NonNull Integer courseId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Course details is being fetched.", null));
            disposables.add(seekoohService.getCourseById(courseId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getCourseDetailsResponse -> {
                        if (NetworkUtils.isValidResponse(getCourseDetailsResponse)) {
                            emitter.onNext(Resource.success(getCourseDetailsResponse.getMessage("Course details fetched successfully."), getCourseDetailsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getCourseDetailsResponse.getMessage("Failed to fetch course details."), getCourseDetailsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch course details.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<CourseListing>> getCourseListingDetails(@NonNull Integer courseId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Course details is being fetched.", null));
            disposables.add(seekoohService.getCourseListingDetails(courseId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getCourseListingDetailsResponse -> {
                        if (NetworkUtils.isValidResponse(getCourseListingDetailsResponse)) {
                            emitter.onNext(Resource.success(getCourseListingDetailsResponse.getMessage("Course details fetched successfully."), getCourseListingDetailsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getCourseListingDetailsResponse.getMessage("Failed to fetch course details."), getCourseListingDetailsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch course details.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<CourseReview>> createCoursesReview(@NonNull Integer courseId, @NonNull CreateCourseReviewRequest createCourseReviewRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Review is being submitted.", null));
            disposables.add(seekoohService.createCoursesReview(courseId, createCourseReviewRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(createReviewResponse -> {
                        if (NetworkUtils.isValidResponse(createReviewResponse)) {
                            emitter.onNext(Resource.success(createReviewResponse.getMessage("Review submitted successfully."), createReviewResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(createReviewResponse.getMessage("Failed to submit review."), createReviewResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit review.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<CourseReview>>> getCourseReviews(@NonNull Integer courseId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Course reviews is being fetched.", null));
            disposables.add(seekoohService.getCourseReviews(courseId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getCourseReviewsResponse -> {
                        if (NetworkUtils.isValidResponse(getCourseReviewsResponse)) {
                            emitter.onNext(Resource.success(getCourseReviewsResponse.getMessage("Course reviews fetched successfully."), getCourseReviewsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getCourseReviewsResponse.getMessage("Failed to fetch course reviews."), getCourseReviewsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch course reviews.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<CourseEnrollmentResponse>> courseEnrollment(@NonNull Integer courseId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Enrollment request is being processed.", null));
            disposables.add(seekoohService.courseEnrollment(courseId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(enrollmentResponse -> {
                        if (NetworkUtils.isValidResponse(enrollmentResponse)) {
                            emitter.onNext(Resource.success(enrollmentResponse.getMessage("Enrollment request submitted successfully."), enrollmentResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(enrollmentResponse.getMessage("Failed to submit enrollment request."), enrollmentResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit enrollment request.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<VerificationStatusResponse>> submitTutorVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI degreeUri) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Verification request is being processed.", null));
            MultipartBody.Part cnicFront = NetworkUtils.uriToMultipart(cnicFrontUri, "cnicFront");
            MultipartBody.Part cnicBack = NetworkUtils.uriToMultipart(cnicBackUri, "cnicBack");
            MultipartBody.Part degree = NetworkUtils.uriToMultipart(degreeUri, "degree");
            disposables.add(seekoohService.submitTutorVerificationRequest(cnicFront, cnicBack, degree)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(submitTutorVerificationResponse -> {
                        if (NetworkUtils.isValidResponse(submitTutorVerificationResponse)) {
                            emitter.onNext(Resource.success(submitTutorVerificationResponse.getMessage("Verification request submitted successfully."), submitTutorVerificationResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(submitTutorVerificationResponse.getMessage("Failed to submit verification request."), submitTutorVerificationResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit verification request.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<VerificationStatusResponse>> resubmitTutorVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI degreeUri) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Verification request is being processed.", null));
            MultipartBody.Part cnicFront = NetworkUtils.uriToMultipart(cnicFrontUri, "cnicFront");
            MultipartBody.Part cnicBack = NetworkUtils.uriToMultipart(cnicBackUri, "cnicBack");
            MultipartBody.Part degree = NetworkUtils.uriToMultipart(degreeUri, "degree");
            disposables.add(seekoohService.resubmitTutorVerificationRequest(cnicFront, cnicBack, degree)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(resubmitTutorVerificationResponse -> {
                        if (NetworkUtils.isValidResponse(resubmitTutorVerificationResponse)) {
                            emitter.onNext(Resource.success(resubmitTutorVerificationResponse.getMessage("Verification request resubmitted successfully."), resubmitTutorVerificationResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(resubmitTutorVerificationResponse.getMessage("Failed to resubmit verification request."), resubmitTutorVerificationResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to resubmit verification request.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<VerificationStatusResponse>> getTutorVerificationStatus() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Verification status is being fetched.", null));
            disposables.add(seekoohService.getTutorVerificationStatus()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getVerificationStatusResponse -> {
                        if (NetworkUtils.isValidResponse(getVerificationStatusResponse)) {
                            emitter.onNext(Resource.success(getVerificationStatusResponse.getMessage("Verification status fetched successfully."), getVerificationStatusResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getVerificationStatusResponse.getMessage("Failed to fetch verification status."), getVerificationStatusResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch verification status.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<VerificationPaymentTokenResponse>> getTutorVerificationPaymentToken(@NonNull VerificationPaymentTokenRequest verificationPaymentTokenRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Verification payment token is being fetched.", null));
            disposables.add(seekoohService.getTutorVerificationPaymentToken()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getVerificationPaymentTokenResponse -> {
                        if (NetworkUtils.isValidResponse(getVerificationPaymentTokenResponse)) {
                            emitter.onNext(Resource.success(getVerificationPaymentTokenResponse.getMessage("Verification payment token fetched successfully."), getVerificationPaymentTokenResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getVerificationPaymentTokenResponse.getMessage("Failed to fetch verification payment token."), getVerificationPaymentTokenResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch verification payment token.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<VerificationFeeResponse>> getTutorVerificationFee() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Verification fee details is being fetched.", null));
            disposables.add(seekoohService.getTutorVerificationFee()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getVerificationFeeResponse -> {
                        if (NetworkUtils.isValidResponse(getVerificationFeeResponse)) {
                            emitter.onNext(Resource.success(getVerificationFeeResponse.getMessage("Verification fee details fetched successfully."), getVerificationFeeResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getVerificationFeeResponse.getMessage("Failed to fetch verification fee details."), getVerificationFeeResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch verification verification fee details.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<VerificationStatusResponse>> submitInstituteVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI proofDocUri) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Verification request is being processed.", null));
            MultipartBody.Part cnicFront = NetworkUtils.uriToMultipart(cnicFrontUri, "cnicFront");
            MultipartBody.Part cnicBack = NetworkUtils.uriToMultipart(cnicBackUri, "cnicBack");
            MultipartBody.Part proofDoc = NetworkUtils.uriToMultipart(proofDocUri, "proofDoc");
            disposables.add(seekoohService.submitInstituteVerificationRequest(cnicFront, cnicBack, proofDoc)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(submitInstituteVerificationResponse -> {
                        if (NetworkUtils.isValidResponse(submitInstituteVerificationResponse)) {
                            emitter.onNext(Resource.success(submitInstituteVerificationResponse.getMessage("Verification request submitted successfully."), submitInstituteVerificationResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(submitInstituteVerificationResponse.getMessage("Failed to submit verification request."), submitInstituteVerificationResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit verification request.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<VerificationStatusResponse>> resubmitInstituteVerificationRequest(@NonNull URI cnicFrontUri, @NonNull URI cnicBackUri, @NonNull URI proofDocUri) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Verification request is being processed.", null));
            MultipartBody.Part cnicFront = NetworkUtils.uriToMultipart(cnicFrontUri, "cnicFront");
            MultipartBody.Part cnicBack = NetworkUtils.uriToMultipart(cnicBackUri, "cnicBack");
            MultipartBody.Part proofDoc = NetworkUtils.uriToMultipart(proofDocUri, "proofDoc");
            disposables.add(seekoohService.resubmitInstituteVerificationRequest(cnicFront, cnicBack, proofDoc)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(resubmitInstituteVerificationResponse -> {
                        if (NetworkUtils.isValidResponse(resubmitInstituteVerificationResponse)) {
                            emitter.onNext(Resource.success(resubmitInstituteVerificationResponse.getMessage("Verification request resubmitted successfully."), resubmitInstituteVerificationResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(resubmitInstituteVerificationResponse.getMessage("Failed to resubmit verification request."), resubmitInstituteVerificationResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to resubmit verification request.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<VerificationStatusResponse>> getInstituteVerificationStatus() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Verification status is being fetched.", null));
            disposables.add(seekoohService.getInstituteVerificationStatus()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getVerificationStatusResponse -> {
                        if (NetworkUtils.isValidResponse(getVerificationStatusResponse)) {
                            emitter.onNext(Resource.success(getVerificationStatusResponse.getMessage("Verification status fetched successfully."), getVerificationStatusResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getVerificationStatusResponse.getMessage("Failed to fetch verification status."), getVerificationStatusResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch verification status.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<VerificationPaymentTokenResponse>> getInstituteVerificationPaymentToken(@NonNull VerificationPaymentTokenRequest verificationPaymentTokenRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Verification payment token is being fetched.", null));
            disposables.add(seekoohService.getInstituteVerificationPaymentToken()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getVerificationPaymentTokenResponse -> {
                        if (NetworkUtils.isValidResponse(getVerificationPaymentTokenResponse)) {
                            System.out.println(getVerificationPaymentTokenResponse.toString());
                            emitter.onNext(Resource.success(getVerificationPaymentTokenResponse.getMessage("Verification payment token fetched successfully."), getVerificationPaymentTokenResponse.getData()));
                        } else {
                            System.out.println(getVerificationPaymentTokenResponse.toString());
                            emitter.onNext(Resource.error(getVerificationPaymentTokenResponse.getMessage("Failed to fetch verification payment token."), getVerificationPaymentTokenResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch verification payment token.");
                        System.out.println(errorMsg+"Failed to fetch");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<VerificationFeeResponse>> getInstituteVerificationFee() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Verification fee details is being fetched.", null));
            disposables.add(seekoohService.getInstituteVerificationFee()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getVerificationFeeResponse -> {
                        if (NetworkUtils.isValidResponse(getVerificationFeeResponse)) {
                            emitter.onNext(Resource.success(getVerificationFeeResponse.getMessage("Verification fee details fetched successfully."), getVerificationFeeResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getVerificationFeeResponse.getMessage("Failed to fetch verification fee details."), getVerificationFeeResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch verification verification fee details.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<InstituteDetails>> getInstituteListingDetails(@NonNull Integer instituteId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Institute details is being fetched.", null));
            disposables.add(seekoohService.getInstituteListingDetails(instituteId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getInstituteIdDetailsResponse -> {
                        if (NetworkUtils.isValidResponse(getInstituteIdDetailsResponse)) {
                            emitter.onNext(Resource.success(getInstituteIdDetailsResponse.getMessage("Institute details fetched successfully."), getInstituteIdDetailsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getInstituteIdDetailsResponse.getMessage("Failed to fetch institute details."), getInstituteIdDetailsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch institute details.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<InstituteReview>>> getInstituteReviews(@NonNull Integer instituteId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Institute reviews is being fetched.", null));
            disposables.add(seekoohService.getInstituteReviews(instituteId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getInstituteReviewsResponse -> {
                        if (NetworkUtils.isValidResponse(getInstituteReviewsResponse)) {
                            emitter.onNext(Resource.success(getInstituteReviewsResponse.getMessage("Institute reviews fetched successfully."), getInstituteReviewsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getInstituteReviewsResponse.getMessage("Failed to fetch institute reviews."), getInstituteReviewsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch institute reviews.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<InstituteReview>> createInstituteReview(@NonNull Integer instituteId, @NonNull CreateInstituteReviewRequest createInstituteReviewRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Review is being submitted.", null));
            disposables.add(seekoohService.createInstituteReview(instituteId, createInstituteReviewRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(createInstituteReviewResponse -> {
                        if (NetworkUtils.isValidResponse(createInstituteReviewResponse)) {
                            emitter.onNext(Resource.success(createInstituteReviewResponse.getMessage("Review submitted successfully."), createInstituteReviewResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(createInstituteReviewResponse.getMessage("Failed to submit review."), createInstituteReviewResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit review.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<TeachingJob>> createTeachingJob(@NonNull CreateTeachingJobRequest createTeachingJobRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Job request is being submitted.", null));
            disposables.add(seekoohService.createTeachingJob(createTeachingJobRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(createJobResponse -> {
                        if (NetworkUtils.isValidResponse(createJobResponse)) {
                            emitter.onNext(Resource.success(createJobResponse.getMessage("Job request submitted successfully."), createJobResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(createJobResponse.getMessage("Failed to submit job request."), createJobResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit job request.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<TeachingJob>> editTeachingJob(@NonNull Integer jobId, @NonNull EditTeachingJobRequest editTeachingJobRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Update job request is being processed.", null));
            disposables.add(seekoohService.editTeachingJob(jobId, editTeachingJobRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(editJobResponse -> {
                        if (NetworkUtils.isValidResponse(editJobResponse)) {
                            emitter.onNext(Resource.success(editJobResponse.getMessage("Job updated successfully."), editJobResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(editJobResponse.getMessage("Failed to update job."), editJobResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to update job.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<Void>> deleteTeachingJob(@NonNull Integer jobId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Job deletion request is being processed.", null));
            disposables.add(seekoohService.deleteTeachingJob(jobId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(deleteJobResponse -> {
                        emitter.onNext(Resource.success(deleteJobResponse.getMessage("Job deleted successfully."), deleteJobResponse.getData()));
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to delete job.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<TeachingJob>> getTeachingJobById(@NonNull Integer jobId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Job details is being fetched.", null));
            disposables.add(seekoohService.getTeachingJobById(jobId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getJobDetailsResponse -> {
                        if (NetworkUtils.isValidResponse(getJobDetailsResponse)) {
                            emitter.onNext(Resource.success(getJobDetailsResponse.getMessage("Job details fetched successfully."), getJobDetailsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getJobDetailsResponse.getMessage("Failed to fetch job details."), getJobDetailsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch job details.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<TeachingJob>>> getMyTeachingJobs() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Posted jobs is being fetched.", null));
            disposables.add(seekoohService.getMyTeachingJobs()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(getMyJobsResponse -> {
                        if (NetworkUtils.isValidResponse(getMyJobsResponse)) {
                            emitter.onNext(Resource.success(getMyJobsResponse.getMessage("Posted jobs fetched successfully."), getMyJobsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(getMyJobsResponse.getMessage("Failed to fetch posted jobs."), getMyJobsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch posted jobs.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<TeachingJobApplicationResponse>> applyToTeachingJob(@NonNull Integer jobId, @NonNull TeachingJobApplicationRequest jobApplicationRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Job application is being processed.", null));
            disposables.add(seekoohService.applyToTeachingJob(jobId, jobApplicationRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(applyToJobResponse -> {
                        if (NetworkUtils.isValidResponse(applyToJobResponse)) {
                            emitter.onNext(Resource.success(applyToJobResponse.getMessage("Job application submitted successfully."), applyToJobResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(applyToJobResponse.getMessage("Failed to submit job application."), applyToJobResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to submit job application.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<Void>> deleteJobApplication(@NonNull Integer jobId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Application withdrawal request is being processed.", null));
            disposables.add(seekoohService.deleteJobApplication(jobId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(withdrawalResponse -> {
                        emitter.onNext(Resource.success(withdrawalResponse.getMessage("Application withdrawal successful."), withdrawalResponse.getData()));
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to withdraw application.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<TeachingJobApplicationResponse>>> getAppliedTeachingJobs() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Job applications are being fetched.", null));
            disposables.add(seekoohService.getAppliedTeachingJobs()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(appliedJobsResponse -> {
                        if (NetworkUtils.isValidResponse(appliedJobsResponse)) {
                            emitter.onNext(Resource.success(appliedJobsResponse.getMessage("Job applications fetched successfully."), appliedJobsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(appliedJobsResponse.getMessage("Failed to fetch job applications."), appliedJobsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch job applications.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<TuitionApplicationResponse>>> getTuitionApplications(@NonNull Integer tuitionId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Tuition applications are being fetched.", null));
            disposables.add(seekoohService.getTuitionApplications(tuitionId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(tuitionApplicationsResponse -> {
                        if (NetworkUtils.isValidResponse(tuitionApplicationsResponse)) {
                            emitter.onNext(Resource.success(tuitionApplicationsResponse.getMessage("Tuition applications fetched successfully."), tuitionApplicationsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(tuitionApplicationsResponse.getMessage("Failed to fetch tuition applications."), tuitionApplicationsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch tuition applications.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<TeachingJobApplicationResponse>>> getJobApplications(@NonNull Integer jobId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Job applications are being fetched.", null));
            disposables.add(seekoohService.getJobApplications(jobId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(jobApplicationsResponse -> {
                        if (NetworkUtils.isValidResponse(jobApplicationsResponse)) {
                            emitter.onNext(Resource.success(jobApplicationsResponse.getMessage("Job applications fetched successfully."), jobApplicationsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(jobApplicationsResponse.getMessage("Failed to fetch job applications."), jobApplicationsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch job applications.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<List<CourseEnrollmentResponse>>> getCourseEnrollments(@NonNull Integer courseId) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Course enrollments are being fetched.", null));
            disposables.add(seekoohService.getCourseEnrollments(courseId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(courseEnrollmentsResponse -> {
                        if (NetworkUtils.isValidResponse(courseEnrollmentsResponse)) {
                            emitter.onNext(Resource.success(courseEnrollmentsResponse.getMessage("Course enrollments fetched successfully."), courseEnrollmentsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(courseEnrollmentsResponse.getMessage("Failed to fetch course enrollments."), courseEnrollmentsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch course enrollments.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<AdSettingsResponse>> getAdSettings() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Ad settings are being fetched.", null));
            disposables.add(seekoohService.getAdSettings()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(adSettingsResponse -> {
                        if (NetworkUtils.isValidResponse(adSettingsResponse)) {
                            emitter.onNext(Resource.success(adSettingsResponse.getMessage("Ad settings fetched successfully."), adSettingsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(adSettingsResponse.getMessage("Failed to fetch Ad settings."), adSettingsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch Ad settings.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<PrivacySettingsResponse>> getPrivacySettings() {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Privacy settings are being fetched.", null));
            disposables.add(seekoohService.getPrivacySettings()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(privacySettingsResponse -> {
                        if (NetworkUtils.isValidResponse(privacySettingsResponse)) {
                            emitter.onNext(Resource.success(privacySettingsResponse.getMessage("Privacy settings fetched successfully."), privacySettingsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(privacySettingsResponse.getMessage("Failed to fetch privacy settings."), privacySettingsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to fetch privacy settings.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }

    @Override
    public Observable<Resource<PrivacySettingsResponse>> editPrivacySettings(@NonNull EditPrivacySettingsRequest editPrivacySettingsRequest) {
        return Observable.create(emitter -> {
            emitter.onNext(Resource.loading("Privacy settings are being updated.", null));
            disposables.add(seekoohService.editPrivacySettings(editPrivacySettingsRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(privacySettingsResponse -> {
                        if (NetworkUtils.isValidResponse(privacySettingsResponse)) {
                            emitter.onNext(Resource.success(privacySettingsResponse.getMessage("Privacy settings updated successfully."), privacySettingsResponse.getData()));
                        } else {
                            emitter.onNext(Resource.error(privacySettingsResponse.getMessage("Failed to update privacy settings."), privacySettingsResponse.getData()));
                        }
                    }, throwable -> {
                        String errorMsg = NetworkUtils.fetchMessageFromThrowable(throwable, "Failed to update privacy settings.");
                        emitter.onNext(Resource.error(errorMsg, null));
                    }));
        });
    }
}
