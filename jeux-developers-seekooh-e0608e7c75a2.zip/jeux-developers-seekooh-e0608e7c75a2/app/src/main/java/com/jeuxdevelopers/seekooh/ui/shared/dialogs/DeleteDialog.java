package com.jeuxdevelopers.seekooh.ui.shared.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.airbnb.lottie.L;
import com.jeuxdevelopers.seekooh.databinding.DialogDeleteBinding;
import com.jeuxdevelopers.seekooh.databinding.DialogFilterTutorsBinding;

public class DeleteDialog extends Dialog {

    private final DialogDeleteBinding binding;
    private Listener listener;

    public DeleteDialog(@NonNull Context context) {
        super(context);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        binding = DialogDeleteBinding.inflate(LayoutInflater.from(getContext()));
        setContentView(binding.getRoot());
        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        getWindow().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(getContext(), android.R.color.transparent)));

        initDialog();
    }

    @Override
    public void show() {
    }

    public void show(String primaryText, String secondaryText, Listener listener) {
        this.listener = listener;
        binding.primaryText.setText(primaryText);
        binding.secondaryText.setText(secondaryText);
        super.show();
    }

    private void initDialog() {
        binding.positiveBtn.setOnClickListener(v -> {
            listener.onPositiveBtnClicked();
        });
        binding.negativeBtn.setOnClickListener(v -> {
            listener.onNegativeBtnClicked();
        });
    }

    public interface Listener {
        void onPositiveBtnClicked();
        void onNegativeBtnClicked();
    }
}
